import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { AuthProvider } from "@/components/auth-provider"
import { SupabaseProvider } from "@/contexts/supabase-context"
import { Toaster } from "@/components/ui/toaster"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Aplia - Assistentes de IA para Profissionais da Saúde",
  description:
    "Plataforma de assistentes de IA especializados para profissionais da saúde, com agendamento inteligente e integração com WhatsApp.",
  keywords: "IA, saúde, assistente virtual, agendamento, WhatsApp, médicos, profissionais da saúde",
  authors: [{ name: "Aplia" }],
  creator: "Aplia",
  publisher: "Aplia",
  robots: "index, follow",
  openGraph: {
    type: "website",
    locale: "pt_BR",
    url: "https://aplia.com.br",
    title: "Aplia - Assistentes de IA para Profissionais da Saúde",
    description: "Plataforma de assistentes de IA especializados para profissionais da saúde",
    siteName: "Aplia",
  },
  twitter: {
    card: "summary_large_image",
    title: "Aplia - Assistentes de IA para Profissionais da Saúde",
    description: "Plataforma de assistentes de IA especializados para profissionais da saúde",
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="pt-BR">
      <body className={inter.className}>
        <SupabaseProvider>
          <AuthProvider>
            {children}
            <Toaster />
          </AuthProvider>
        </SupabaseProvider>
      </body>
    </html>
  )
}
