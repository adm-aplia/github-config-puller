"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/hooks/use-toast"
import { generateValidCPF } from "@/lib/utils/cpf-validator"

export default function TestSubscriptionPage() {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<any>(null)
  const { toast } = useToast()

  const testSubscription = async () => {
    setLoading(true)
    setResult(null)

    try {
      const testData = {
        nome: "João Silva Teste",
        email: "joao.teste@exemplo.com",
        telefone: "11999887766",
        documento: generateValidCPF(),
        plano: "Básico",
        user_id: "test-user-123",
        cep: "01310100",
        endereco: "Rua Teste",
        numero: "100",
        cartao: {
          nomeCartao: "JOAO SILVA",
          numeroCartao: "4000000000000010", // Cartão de teste Asaas
          mesExpiracao: "12",
          anoExpiracao: "2025",
          cvv: "123",
        },
      }

      console.log("🧪 [TEST] Testando criação de assinatura...")
      console.log("📝 [TEST] Dados de teste:", {
        ...testData,
        documento: "***",
        cartao: "***",
      })

      const response = await fetch("/api/subscription/create", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(testData),
      })

      const data = await response.json()
      setResult(data)

      if (data.success) {
        toast({
          title: "✅ Teste bem-sucedido!",
          description: "Assinatura de teste criada com sucesso",
        })
      } else {
        toast({
          variant: "destructive",
          title: "❌ Teste falhou",
          description: data.error || "Erro desconhecido",
        })
      }
    } catch (error: any) {
      console.error("❌ [TEST] Erro no teste:", error)
      toast({
        variant: "destructive",
        title: "Erro no teste",
        description: error.message,
      })
      setResult({ error: error.message })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto p-6">
      <Card className="max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle>🧪 Teste de Assinatura Recorrente</CardTitle>
          <CardDescription>
            Teste a criação de assinatura com dados válidos usando o método direto (sem tokenização)
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Button onClick={testSubscription} disabled={loading} className="w-full">
            {loading ? "Testando..." : "🚀 Testar Criação de Assinatura"}
          </Button>

          {result && (
            <div className="mt-6">
              <h3 className="font-semibold mb-2">Resultado do Teste:</h3>
              <pre className="bg-muted p-4 rounded-md text-sm overflow-auto max-h-96">
                {JSON.stringify(result, null, 2)}
              </pre>
            </div>
          )}

          <div className="text-sm text-muted-foreground space-y-2">
            <p>
              <strong>📋 Dados de Teste:</strong>
            </p>
            <ul className="list-disc list-inside space-y-1">
              <li>Nome: João Silva Teste</li>
              <li>CPF: Gerado automaticamente (válido)</li>
              <li>Telefone: (11) 99988-7766</li>
              <li>Cartão: 4000 0000 0000 0010 (teste Asaas)</li>
              <li>Plano: Básico (R$ 199/mês)</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
