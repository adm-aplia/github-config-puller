"use client"

import { useEffect } from "react"
import { useSearchParams } from "next/navigation"

export default function GoogleAuthClose() {
  const searchParams = useSearchParams()
  const success = searchParams.get("success") === "true"

  useEffect(() => {
    // Enviar mensagem para a janela pai antes de fechar
    if (window.opener) {
      window.opener.postMessage(
        {
          type: "GOOGLE_AUTH_CALLBACK",
          success,
          message: success
            ? "Integração com Google Calendar realizada com sucesso!"
            : "Falha na integração com Google Calendar.",
        },
        "*",
      )

      // Fechar a janela após um pequeno delay para garantir que a mensagem foi enviada
      setTimeout(() => {
        window.close()
      }, 1000)
    }
  }, [success])

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-background">
      <div className="text-center p-8 max-w-md">
        <h1 className="text-2xl font-bold mb-4">{success ? "Integração Concluída!" : "Falha na Integração"}</h1>
        <p className="mb-4">
          {success
            ? "A integração com o Google Calendar foi realizada com sucesso. Esta janela será fechada automaticamente."
            : "Ocorreu um erro durante a integração com o Google Calendar. Esta janela será fechada automaticamente."}
        </p>
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
      </div>
    </div>
  )
}
