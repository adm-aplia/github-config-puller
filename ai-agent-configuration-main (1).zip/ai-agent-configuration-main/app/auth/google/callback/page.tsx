"use client"

import { useEffect, useState, useRef } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Loader2, CheckCircle, AlertCircle } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export default function GoogleCallback() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [status, setStatus] = useState<"loading" | "success" | "error">("loading")
  const [message, setMessage] = useState("")
  const [error, setError] = useState<string | null>(null)
  const processingRef = useRef(false)

  useEffect(() => {
    const processAuth = async () => {
      if (processingRef.current) return
      processingRef.current = true

      try {
        const code = searchParams.get("code")
        const state = searchParams.get("state")
        const errorParam = searchParams.get("error")

        console.log("Processing auth with:", {
          code: code ? code.substring(0, 20) + "..." : null,
          state,
          error: errorParam,
        })

        if (errorParam) {
          setStatus("error")
          setMessage(`Erro de autenticação: ${errorParam}`)
          return
        }

        if (!code) {
          setStatus("error")
          setMessage("Código de autorização não encontrado")
          return
        }

        const redirectUri = `${process.env.NEXT_PUBLIC_APP_URL}/auth/google/callback`

        let userId = null
        if (state) {
          try {
            const stateObj = JSON.parse(decodeURIComponent(state))
            userId = stateObj.user_id
            console.log("User ID from state:", userId)
          } catch (err) {
            console.error("Erro ao analisar state:", err)
          }
        }

        // Send the REAL authorization code to webhook
        const webhookPayload = {
          type: "google_auth_code",
          code: code, // Real code from Google OAuth
          user_id: userId,
          redirect_uri: redirectUri,
          timestamp: new Date().toISOString(),
          url: window.location.href,
          state: state,
        }

        console.log("Sending real code to webhook:", {
          ...webhookPayload,
          code: code.substring(0, 20) + "...",
        })

        const webhookResponse = await fetch(
          "https://dinastia-n8n-webhook.qhw5xb.easypanel.host/webhook/google-calendar-event-creator",
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(webhookPayload),
          },
        )

        if (!webhookResponse.ok) {
          throw new Error(`Webhook failed: ${webhookResponse.status}`)
        }

        const webhookResult = await webhookResponse.json()
        console.log("Webhook success:", webhookResult)

        setStatus("success")
        setMessage("Código de autorização enviado com sucesso! Aguarde enquanto processamos sua autenticação.")

        if (window.opener) {
          window.opener.postMessage({ type: "google-auth-success" }, window.location.origin)
          setTimeout(() => window.close(), 3000)
        } else {
          setTimeout(() => {
            const returnUrl = sessionStorage.getItem("auth_return_url") || "/dashboard/integracoes"
            router.push(`${returnUrl}?auth_success=true`)
          }, 2000)
        }
      } catch (err) {
        console.error("Erro:", err)
        setStatus("error")
        setMessage("Falha ao processar autenticação")
        setError(err instanceof Error ? err.message : "Erro desconhecido")

        if (window.opener) {
          window.opener.postMessage(
            { type: "google-auth-error", error: err instanceof Error ? err.message : "Erro desconhecido" },
            window.location.origin,
          )
        }
      }
    }

    processAuth()
  }, [searchParams, router])

  const handleClose = () => {
    if (window.opener) {
      window.close()
    } else {
      const returnUrl = sessionStorage.getItem("auth_return_url") || "/dashboard/configuracao"
      router.push(returnUrl)
    }
  }

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-50">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-center">
            {status === "loading"
              ? "Processando autenticação do Google..."
              : status === "success"
                ? "Autenticação em processamento"
                : "Erro na autenticação"}
          </CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col items-center space-y-4">
          {status === "loading" && (
            <>
              <Loader2 className="h-16 w-16 text-blue-500 animate-spin" />
              <p className="text-center text-gray-600">
                Enviando seu código de autorização...
                <br />
                Por favor, aguarde.
              </p>
            </>
          )}

          {status === "success" && (
            <>
              <CheckCircle className="h-16 w-16 text-green-500" />
              <Alert className="bg-green-50 border-green-200">
                <AlertTitle>Sucesso!</AlertTitle>
                <AlertDescription>{message}</AlertDescription>
              </Alert>
            </>
          )}

          {status === "error" && (
            <>
              <AlertCircle className="h-16 w-16 text-red-500" />
              <Alert variant="destructive">
                <AlertTitle>Erro</AlertTitle>
                <AlertDescription>{message}</AlertDescription>
              </Alert>
              {error && (
                <div className="w-full mt-2 p-3 bg-gray-100 rounded-md overflow-auto max-h-32">
                  <pre className="text-xs whitespace-pre-wrap">{error}</pre>
                </div>
              )}
            </>
          )}
        </CardContent>
        <CardFooter className="flex justify-center">
          {status !== "loading" && <Button onClick={handleClose}>Fechar</Button>}
        </CardFooter>
      </Card>
    </div>
  )
}
