"use client"

import { useState } from "react"
import Image from "next/image"
import { Logo } from "@/components/logo"
import LoginForm from "@/components/login-form"

export default function LoginPage() {
  const [isConfirmationScreen, setIsConfirmationScreen] = useState(false)

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      {/* Lado esquerdo - Imagem de fundo */}
      <div className="hidden md:flex md:w-1/2 bg-aplia-blue relative">
        <div className="absolute inset-0 flex items-center justify-center p-8">
          <Image
            src="/abstract-geometric-shapes.png"
            alt="Padrão geométrico abstrato"
            width={600}
            height={600}
            className="max-w-full max-h-full object-contain opacity-20"
          />
        </div>
        <div className="absolute inset-0 flex flex-col items-center justify-center p-8 z-10">
          <Logo variant="white" className="w-48 h-auto mb-8" />
          <h1 className="text-3xl md:text-4xl font-bold text-white text-center mb-4">
            Inteligência Artificial para Saúde
          </h1>
          <p className="text-lg text-white/80 text-center max-w-md">
            Transformando o atendimento médico com assistentes virtuais inteligentes e personalizados.
          </p>
        </div>
      </div>

      {/* Lado direito - Formulário de login */}
      <div className="flex-1 flex flex-col items-center justify-center p-6 md:p-12 bg-gray-50">
        <div className="w-full max-w-md">
          {!isConfirmationScreen && (
            <div className="mb-8 text-center">
              <Logo variant="color" className="w-32 h-auto mx-auto mb-6 md:hidden" />
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Acesse sua conta</h2>
              <p className="text-gray-600 dark:text-gray-400">Entre com suas credenciais</p>
            </div>
          )}

          {isConfirmationScreen && (
            <div className="mb-8 text-center">
              <Logo variant="color" className="w-32 h-auto mx-auto mb-6 md:hidden" />
            </div>
          )}

          <LoginForm onConfirmationScreen={setIsConfirmationScreen} />
        </div>
      </div>
    </div>
  )
}
