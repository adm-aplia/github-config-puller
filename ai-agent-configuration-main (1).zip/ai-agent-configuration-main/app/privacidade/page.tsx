import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ArrowLeft, Shield } from "lucide-react"

export default function PrivacyPage() {
  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4 max-w-4xl">
        <div className="mb-6">
          <Link href="/">
            <Button variant="ghost" className="mb-4">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Voltar
            </Button>
          </Link>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-3xl font-bold text-center flex items-center justify-center gap-2">
              <Shield className="h-8 w-8" />
              Política de Privacidade
            </CardTitle>
            <p className="text-center text-muted-foreground">Última atualização: 22/05/2025</p>
          </CardHeader>
          <CardContent className="prose prose-gray max-w-none">
            <div className="space-y-6">
              <div>
                <h2 className="text-xl font-semibold mb-3">Política de Privacidade – Aplia</h2>
                <p className="text-gray-700">
                  A Aplia se compromete com a privacidade e proteção dos dados dos seus usuários. Esta Política de
                  Privacidade descreve como coletamos, usamos e protegemos as informações fornecidas ao utilizar nossa
                  plataforma.
                </p>
              </div>

              <div>
                <h3 className="text-lg font-semibold mb-2">1. Coleta de Informações</h3>
                <p className="text-gray-700">
                  Coletamos dados fornecidos diretamente por você, como nome, e-mail e preferências, bem como dados
                  necessários para integração com o Google Calendar, incluindo permissões para visualizar e modificar
                  eventos na sua agenda.
                </p>
              </div>

              <div>
                <h3 className="text-lg font-semibold mb-2">2. Uso das Informações</h3>
                <p className="text-gray-700 mb-3">Utilizamos as informações coletadas para:</p>
                <ul className="list-disc list-inside text-gray-700 space-y-1">
                  <li>Agendar compromissos automaticamente em sua agenda</li>
                  <li>Enviar notificações e resumos</li>
                  <li>Melhorar nossos serviços e suporte</li>
                </ul>
              </div>

              <div>
                <h3 className="text-lg font-semibold mb-2">3. Compartilhamento</h3>
                <p className="text-gray-700">
                  Não vendemos nem compartilhamos seus dados com terceiros, exceto quando necessário para operação do
                  serviço (ex: Google APIs), sob termos de confidencialidade.
                </p>
              </div>

              <div>
                <h3 className="text-lg font-semibold mb-2">4. Segurança</h3>
                <p className="text-gray-700">
                  Adotamos medidas técnicas e organizacionais para proteger seus dados contra acessos não autorizados,
                  perda ou alteração.
                </p>
              </div>

              <div>
                <h3 className="text-lg font-semibold mb-2">5. Seus Direitos</h3>
                <p className="text-gray-700">
                  Você pode solicitar acesso, correção ou exclusão dos seus dados a qualquer momento, enviando um e-mail
                  para{" "}
                  <a href="mailto:suporte@aplia.com" className="text-blue-600 hover:underline">
                    suporte@aplia.com
                  </a>
                  .
                </p>
              </div>

              <div>
                <h3 className="text-lg font-semibold mb-2">6. Google OAuth</h3>
                <p className="text-gray-700">
                  Nosso aplicativo usa OAuth 2.0 para autenticação e só acessa dados com seu consentimento explícito. Em
                  nenhum momento armazenamos suas credenciais.
                </p>
              </div>

              <div>
                <h3 className="text-lg font-semibold mb-2">7. Alterações</h3>
                <p className="text-gray-700">
                  Podemos atualizar esta política periodicamente. Notificaremos você em caso de mudanças relevantes.
                </p>
              </div>

              <div className="border-t pt-6">
                <h3 className="text-lg font-semibold mb-2">Contato:</h3>
                <p className="text-gray-700">
                  Para dúvidas, entre em contato:{" "}
                  <a href="mailto:suporte@aplia.com" className="text-blue-600 hover:underline">
                    suporte@aplia.com
                  </a>
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
