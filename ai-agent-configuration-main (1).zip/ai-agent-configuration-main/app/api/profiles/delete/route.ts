import { type NextRequest, NextResponse } from "next/server"
import { supabase } from "@/lib/supabase"

// Função para enviar webhook
async function sendWebhook(data: any, action: "create" | "update" | "delete") {
  try {
    const webhookUrl = "https://aplia-n8n-webhook.kopfcf.easypanel.host/webhook/questionario"

    console.log(`📤 Enviando webhook ${action} para:`, webhookUrl)

    const controller = new AbortController()
    const timeoutId = setTimeout(() => controller.abort(), 10000) // 10 segundos timeout

    const webhookPayload = {
      ...data,
      action,
      timestamp: new Date().toISOString(),
    }

    console.log(`📤 Payload do webhook ${action}:`, JSON.stringify(webhookPayload, null, 2))

    const webhookResponse = await fetch(webhookUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "User-Agent": "Aplia-Medical-AI/1.0",
        "X-Webhook-Event": `profile.${action}`,
      },
      body: JSON.stringify(webhookPayload),
      signal: controller.signal,
    })

    clearTimeout(timeoutId)

    if (webhookResponse.ok) {
      console.log(`✅ Webhook ${action} enviado com sucesso!`)
      const responseText = await webhookResponse.text()
      console.log(`✅ Resposta do webhook ${action}:`, responseText)
    } else {
      console.warn(`⚠️ Webhook ${action} retornou status ${webhookResponse.status}: ${webhookResponse.statusText}`)
    }
  } catch (webhookError: any) {
    if (webhookError.name === "AbortError") {
      console.warn(`⏱️ Webhook ${action} timeout - continuando sem webhook`)
    } else {
      console.warn(`⚠️ Erro ao enviar webhook ${action} (não crítico):`, webhookError.message)
    }
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get("id")
    const user_id = searchParams.get("user_id")

    console.log("🗑️ API profiles/delete - Parâmetros:", { id, user_id })

    // Validações
    if (!id) {
      console.log("❌ ID do perfil não fornecido")
      return NextResponse.json({ error: "ID do perfil é obrigatório" }, { status: 400 })
    }

    if (!user_id) {
      console.log("❌ user_id não fornecido")
      return NextResponse.json({ error: "user_id é obrigatório" }, { status: 400 })
    }

    // Buscar o perfil antes de deletar (para o webhook)
    const { data: profileData, error: fetchError } = await supabase
      .from("professional_profiles")
      .select("*")
      .eq("id", id)
      .eq("user_id", user_id)
      .single()

    if (fetchError) {
      console.error("❌ Erro ao buscar perfil para deletar:", fetchError)
      return NextResponse.json({ error: "Perfil não encontrado" }, { status: 404 })
    }

    console.log("📋 Perfil encontrado para deletar:", profileData)

    // Deletar o perfil
    const { error: deleteError } = await supabase
      .from("professional_profiles")
      .delete()
      .eq("id", id)
      .eq("user_id", user_id)

    if (deleteError) {
      console.error("❌ Erro ao deletar perfil:", deleteError)
      return NextResponse.json({ error: "Erro ao deletar perfil: " + deleteError.message }, { status: 500 })
    }

    console.log("✅ Perfil deletado com sucesso")

    // Enviar webhook após sucesso
    try {
      await sendWebhook(
        {
          id: profileData.id,
          user_id: profileData.user_id,
          fullname: profileData.fullname,
          specialty: profileData.specialty,
          deleted_at: new Date().toISOString(),
        },
        "delete",
      )
    } catch (webhookError) {
      console.error("⚠️ Erro no webhook (não crítico):", webhookError)
    }

    return NextResponse.json({
      success: true,
      message: "Perfil deletado com sucesso",
    })
  } catch (error) {
    console.error("❌ Erro interno na API profiles/delete:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}
