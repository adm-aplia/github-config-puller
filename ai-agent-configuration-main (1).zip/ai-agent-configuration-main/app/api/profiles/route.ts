import { NextRequest, NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get("user_id")
    const profileId = searchParams.get("id")

    console.log("🔍 API /profiles GET - Parâmetros:", { userId, profileId })

    if (!userId) {
      console.log("❌ API /profiles GET - user_id é obrigatório")
      return NextResponse.json(
        { error: "user_id é obrigatório" },
        { status: 400 }
      )
    }

    // Se profileId foi fornecido, buscar perfil específico
    if (profileId) {
      console.log("🔍 Buscando perfil específico:", profileId)

      const { data: profile, error } = await supabase
        .from("professional_profiles")
        .select("*")
        .eq("id", profileId)
        .eq("user_id", userId)
        .single()

      if (error) {
        console.error("❌ Erro ao buscar perfil específico:", error)
        return NextResponse.json(
          { error: "Erro ao buscar perfil", details: error.message },
          { status: 500 }
        )
      }

      if (!profile) {
        console.log("❌ Perfil não encontrado:", profileId)
        return NextResponse.json(
          { error: "Perfil não encontrado" },
          { status: 404 }
        )
      }

      console.log("✅ Perfil específico encontrado:", profile)
      return NextResponse.json({
        success: true,
        profile: profile
      })
    }

    // Buscar todos os perfis do usuário
    console.log("🔍 Buscando todos os perfis do usuário:", userId)

    const { data: profiles, error } = await supabase
      .from("professional_profiles")
      .select("*")
      .eq("user_id", userId)
      .order("created_at", { ascending: false })

    if (error) {
      console.error("❌ Erro ao buscar perfis:", error)
      return NextResponse.json(
        { error: "Erro ao buscar perfis", details: error.message },
        { status: 500 }
      )
    }

    console.log("✅ Perfis encontrados:", profiles?.length || 0)

    return NextResponse.json({
      success: true,
      profiles: profiles || []
    })

  } catch (error) {
    console.error("❌ Erro interno na API /profiles GET:", error)
    return NextResponse.json(
      { error: "Erro interno do servidor" },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    console.log("📝 API /profiles POST - Dados recebidos:", body)

    const {
      user_id,
      fullname,
      specialty,
      professionalid,
      phonenumber,
      email,
      education,
      locations,
      workinghours,
      procedures,
      healthinsurance,
      paymentmethods,
      consultationfees,
      cancellationpolicy,
      consultationduration,
      timebetweenconsultations,
      reschedulingpolicy,
      onlineconsultations,
      reminderpreferences,
      requiredpatientinfo,
      appointmentconditions,
      medicalhistoryrequirements,
      agerequirements,
      communicationchannels,
      preappointmentinfo,
      requireddocuments,
    } = body

    if (!user_id) {
      console.log("❌ API /profiles POST - user_id é obrigatório")
      return NextResponse.json(
        { error: "user_id é obrigatório" },
        { status: 400 }
      )
    }

    if (!fullname || !specialty) {
      console.log("❌ API /profiles POST - Nome e especialidade são obrigatórios")
      return NextResponse.json(
        { error: "Nome e especialidade são obrigatórios" },
        { status: 400 }
      )
    }

    // Inserir novo perfil
    const { data: newProfile, error } = await supabase
      .from("professional_profiles")
      .insert([
        {
          user_id,
          fullname,
          specialty,
          professionalid,
          phonenumber,
          email,
          education,
          locations,
          workinghours,
          procedures,
          healthinsurance,
          paymentmethods,
          consultationfees,
          cancellationpolicy,
          consultationduration,
          timebetweenconsultations,
          reschedulingpolicy,
          onlineconsultations,
          reminderpreferences,
          requiredpatientinfo,
          appointmentconditions,
          medicalhistoryrequirements,
          agerequirements,
          communicationchannels,
          preappointmentinfo,
          requireddocuments,
        },
      ])
      .select()
      .single()

    if (error) {
      console.error("❌ Erro ao criar perfil:", error)
      return NextResponse.json(
        { error: "Erro ao criar perfil", details: error.message },
        { status: 500 }
      )
    }

    console.log("✅ Perfil criado com sucesso:", newProfile)

    return NextResponse.json({
      success: true,
      profile: newProfile,
    })

  } catch (error) {
    console.error("❌ Erro interno na API /profiles POST:", error)
    return NextResponse.json(
      { error: "Erro interno do servidor" },
      { status: 500 }
    )
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json()
    console.log("📝 API /profiles PUT - Dados recebidos:", body)

    const {
      id,
      user_id,
      fullname,
      specialty,
      professionalid,
      phonenumber,
      email,
      education,
      locations,
      workinghours,
      procedures,
      healthinsurance,
      paymentmethods,
      consultationfees,
      cancellationpolicy,
      consultationduration,
      timebetweenconsultations,
      reschedulingpolicy,
      onlineconsultations,
      reminderpreferences,
      requiredpatientinfo,
      appointmentconditions,
      medicalhistoryrequirements,
      agerequirements,
      communicationchannels,
      preappointmentinfo,
      requireddocuments,
    } = body

    if (!id || !user_id) {
      console.log("❌ API /profiles PUT - id e user_id são obrigatórios")
      return NextResponse.json(
        { error: "id e user_id são obrigatórios" },
        { status: 400 }
      )
    }

    if (!fullname || !specialty) {
      console.log("❌ API /profiles PUT - Nome e especialidade são obrigatórios")
      return NextResponse.json(
        { error: "Nome e especialidade são obrigatórios" },
        { status: 400 }
      )
    }

    // Atualizar perfil
    const { data: updatedProfile, error } = await supabase
      .from("professional_profiles")
      .update({
        fullname,
        specialty,
        professionalid,
        phonenumber,
        email,
        education,
        locations,
        workinghours,
        procedures,
        healthinsurance,
        paymentmethods,
        consultationfees,
        cancellationpolicy,
        consultationduration,
        timebetweenconsultations,
        reschedulingpolicy,
        onlineconsultations,
        reminderpreferences,
        requiredpatientinfo,
        appointmentconditions,
        medicalhistoryrequirements,
        agerequirements,
        communicationchannels,
        preappointmentinfo,
        requireddocuments,
        updated_at: new Date().toISOString(),
      })
      .eq("id", id)
      .eq("user_id", user_id)
      .select()
      .single()

    if (error) {
      console.error("❌ Erro ao atualizar perfil:", error)
      return NextResponse.json(
        { error: "Erro ao atualizar perfil", details: error.message },
        { status: 500 }
      )
    }

    if (!updatedProfile) {
      console.log("❌ Perfil não encontrado para atualização:", id)
      return NextResponse.json(
        { error: "Perfil não encontrado" },
        { status: 404 }
      )
    }

    console.log("✅ Perfil atualizado com sucesso:", updatedProfile)

    return NextResponse.json({
      success: true,
      profile: updatedProfile,
    })

  } catch (error) {
    console.error("❌ Erro interno na API /profiles PUT:", error)
    return NextResponse.json(
      { error: "Erro interno do servidor" },
      { status: 500 }
    )
  }
}
