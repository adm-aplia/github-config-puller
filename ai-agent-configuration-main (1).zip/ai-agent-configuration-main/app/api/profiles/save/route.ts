import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    console.log("📥 API profiles/save - Dados recebidos:", body)

    const {
      fullname,
      specialty,
      professionalid,
      phonenumber,
      email,
      education,
      locations,
      workinghours,
      procedures,
      healthinsurance,
      paymentmethods,
      consultationfees,
      cancellationpolicy,
      consultationduration,
      timebetweenconsultations,
      reschedulingpolicy,
      onlineconsultations,
      reminderpreferences,
      requiredpatientinfo,
      appointmentconditions,
      medicalhistoryrequirements,
      agerequirements,
      communicationchannels,
      preappointmentinfo,
      requireddocuments,
      user_id,
      id, // Para edição
    } = body

    // Validação básica
    if (!fullname || !fullname.trim()) {
      console.log("❌ fullname não fornecido")
      return NextResponse.json({ success: false, error: "Nome completo é obrigatório" }, { status: 400 })
    }

    if (!specialty || !specialty.trim()) {
      console.log("❌ specialty não fornecido")
      return NextResponse.json({ success: false, error: "Especialidade é obrigatória" }, { status: 400 })
    }

    if (!user_id) {
      console.log("❌ user_id não fornecido")
      return NextResponse.json({ success: false, error: "ID do usuário é obrigatório" }, { status: 400 })
    }

    // Se não tem ID, é criação - verificar limites do plano
    if (!id) {
      console.log("🔍 Verificando limites do plano para criação de perfil")

      // Buscar informações do plano do usuário
      const { data: userData, error: userError } = await supabase
        .from("profiles")
        .select(`
          *,
          assinaturas!inner(
            plano_id,
            status,
            planos!inner(
              nome,
              profiles_limit
            )
          )
        `)
        .eq("id", user_id)
        .eq("assinaturas.status", "ACTIVE")
        .single()

      if (userError) {
        console.error("❌ Erro ao buscar dados do usuário:", userError)
        return NextResponse.json({ success: false, error: "Erro ao verificar plano do usuário" }, { status: 500 })
      }

      const profilesLimit = userData?.assinaturas?.planos?.profiles_limit || 0
      console.log("📊 Limite de perfis do plano:", profilesLimit)

      // Contar perfis existentes
      const { count: existingProfilesCount, error: countError } = await supabase
        .from("professional_profiles")
        .select("*", { count: "exact", head: true })
        .eq("user_id", user_id)

      if (countError) {
        console.error("❌ Erro ao contar perfis existentes:", countError)
        return NextResponse.json({ success: false, error: "Erro ao verificar perfis existentes" }, { status: 500 })
      }

      console.log("📊 Perfis existentes:", existingProfilesCount)
      console.log("📊 Limite do plano:", profilesLimit)

      // Verificar se atingiu o limite
      if (existingProfilesCount >= profilesLimit) {
        console.log("❌ Limite de perfis atingido")
        return NextResponse.json(
          {
            success: false,
            error: `Limite de ${profilesLimit} perfis atingido. Faça upgrade do seu plano para criar mais perfis.`,
          },
          { status: 403 },
        )
      }
    }

    const profileData = {
      fullname: fullname.trim(),
      specialty: specialty.trim(),
      professionalid: professionalid?.trim() || "",
      phonenumber: phonenumber?.trim() || "",
      email: email?.trim() || "",
      education: education?.trim() || "",
      locations: locations?.trim() || "",
      workinghours: workinghours?.trim() || "",
      procedures: procedures?.trim() || "",
      healthinsurance: healthinsurance?.trim() || "",
      paymentmethods: paymentmethods?.trim() || "",
      consultationfees: consultationfees?.trim() || "",
      cancellationpolicy: cancellationpolicy?.trim() || "",
      consultationduration: consultationduration?.trim() || "",
      timebetweenconsultations: timebetweenconsultations?.trim() || "",
      reschedulingpolicy: reschedulingpolicy?.trim() || "",
      onlineconsultations: onlineconsultations?.trim() || "",
      reminderpreferences: reminderpreferences?.trim() || "",
      requiredpatientinfo: requiredpatientinfo?.trim() || "",
      appointmentconditions: appointmentconditions?.trim() || "",
      medicalhistoryrequirements: medicalhistoryrequirements?.trim() || "",
      agerequirements: agerequirements?.trim() || "",
      communicationchannels: communicationchannels?.trim() || "",
      preappointmentinfo: preappointmentinfo?.trim() || "",
      requireddocuments: requireddocuments?.trim() || "",
      user_id,
      updated_at: new Date().toISOString(),
    }

    let result

    if (id) {
      // Edição
      console.log("✏️ Editando perfil existente:", id)
      const { data, error } = await supabase
        .from("professional_profiles")
        .update(profileData)
        .eq("id", id)
        .eq("user_id", user_id)
        .select()
        .single()

      if (error) {
        console.error("❌ Erro ao editar perfil:", error)
        throw new Error(`Erro ao editar perfil: ${error.message}`)
      }

      result = data
      console.log("✅ Perfil editado com sucesso:", result)
    } else {
      // Criação
      console.log("➕ Criando novo perfil")
      const { data, error } = await supabase
        .from("professional_profiles")
        .insert({
          ...profileData,
          created_at: new Date().toISOString(),
        })
        .select()
        .single()

      if (error) {
        console.error("❌ Erro ao criar perfil:", error)
        throw new Error(`Erro ao criar perfil: ${error.message}`)
      }

      result = data
      console.log("✅ Perfil criado com sucesso:", result)
    }

    return NextResponse.json({
      success: true,
      profile: result,
      message: id ? "Perfil atualizado com sucesso" : "Perfil criado com sucesso",
    })
  } catch (error) {
    console.error("❌ Erro ao salvar perfil:", error)
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "Erro interno do servidor",
      },
      { status: 500 },
    )
  }
}
