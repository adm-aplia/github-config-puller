import { NextResponse } from "next/server"
import { getSupabaseServerClient } from "@/lib/supabase"

// GET - Listar todos os prompts do usuário
export async function GET(request: Request) {
  try {
    const supabase = getSupabaseServerClient()

    // Obter usuário atual
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Usuário não autenticado" }, { status: 401 })
    }

    // Obter parâmetros de consulta
    const url = new URL(request.url)
    const type = url.searchParams.get("type")
    const questionnaireId = url.searchParams.get("questionnaireId")
    const isActive = url.searchParams.get("isActive")

    // Construir consulta
    let query = supabase.from("prompts").select("*").eq("user_id", user.id).order("created_at", { ascending: false })

    // Aplicar filtros
    if (type) {
      query = query.eq("prompt_type", type)
    }
    if (questionnaireId) {
      query = query.eq("questionnaire_id", questionnaireId)
    }
    if (isActive !== null) {
      query = query.eq("is_active", isActive === "true")
    }

    const { data, error } = await query

    if (error) {
      console.error("Erro ao buscar prompts:", error)
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json(data)
  } catch (error: any) {
    console.error("Erro ao processar requisição:", error)
    return NextResponse.json({ error: error.message || "Erro desconhecido" }, { status: 500 })
  }
}

// POST - Criar um novo prompt
export async function POST(request: Request) {
  try {
    const supabase = getSupabaseServerClient()
    const promptData = await request.json()

    // Obter usuário atual
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Usuário não autenticado" }, { status: 401 })
    }

    // Validar dados
    if (!promptData.prompt_text) {
      return NextResponse.json({ error: "Texto do prompt é obrigatório" }, { status: 400 })
    }

    // Inserir prompt
    const { data, error } = await supabase
      .from("prompts")
      .insert({
        user_id: user.id,
        questionnaire_id: promptData.questionnaire_id || null,
        prompt_text: promptData.prompt_text,
        prompt_type: promptData.prompt_type || "general",
        is_active: promptData.is_active !== undefined ? promptData.is_active : true,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      })
      .select()
      .single()

    if (error) {
      console.error("Erro ao criar prompt:", error)
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json(data)
  } catch (error: any) {
    console.error("Erro ao processar requisição:", error)
    return NextResponse.json({ error: error.message || "Erro desconhecido" }, { status: 500 })
  }
}
