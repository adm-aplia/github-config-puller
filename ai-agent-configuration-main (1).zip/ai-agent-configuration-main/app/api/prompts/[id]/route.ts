import { NextResponse } from "next/server"
import { getSupabaseServerClient } from "@/lib/supabase"

// GET - Obter um prompt específico
export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const supabase = getSupabaseServerClient()
    const id = params.id

    // Obter usuário atual
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Usuário não autenticado" }, { status: 401 })
    }

    const { data, error } = await supabase.from("prompts").select("*").eq("id", id).eq("user_id", user.id).single()

    if (error) {
      console.error(`Erro ao buscar prompt ${id}:`, error)
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    if (!data) {
      return NextResponse.json({ error: "Prompt não encontrado" }, { status: 404 })
    }

    return NextResponse.json(data)
  } catch (error: any) {
    console.error("Erro ao processar requisição:", error)
    return NextResponse.json({ error: error.message || "Erro desconhecido" }, { status: 500 })
  }
}

// PUT - Atualizar um prompt
export async function PUT(request: Request, { params }: { params: { id: string } }) {
  try {
    const supabase = getSupabaseServerClient()
    const id = params.id
    const promptData = await request.json()

    // Obter usuário atual
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Usuário não autenticado" }, { status: 401 })
    }

    // Verificar se o prompt existe e pertence ao usuário
    const { data: existingPrompt, error: fetchError } = await supabase
      .from("prompts")
      .select("user_id")
      .eq("id", id)
      .single()

    if (fetchError) {
      console.error(`Erro ao verificar prompt ${id}:`, fetchError)
      return NextResponse.json({ error: fetchError.message }, { status: 500 })
    }

    if (!existingPrompt) {
      return NextResponse.json({ error: "Prompt não encontrado" }, { status: 404 })
    }

    if (existingPrompt.user_id !== user.id) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 403 })
    }

    // Atualizar o prompt
    const { data, error } = await supabase
      .from("prompts")
      .update({
        questionnaire_id: promptData.questionnaire_id,
        prompt_text: promptData.prompt_text,
        prompt_type: promptData.prompt_type,
        is_active: promptData.is_active,
        updated_at: new Date().toISOString(),
      })
      .eq("id", id)
      .select()
      .single()

    if (error) {
      console.error(`Erro ao atualizar prompt ${id}:`, error)
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json(data)
  } catch (error: any) {
    console.error("Erro ao processar requisição:", error)
    return NextResponse.json({ error: error.message || "Erro desconhecido" }, { status: 500 })
  }
}

// DELETE - Excluir um prompt
export async function DELETE(request: Request, { params }: { params: { id: string } }) {
  try {
    const supabase = getSupabaseServerClient()
    const id = params.id

    // Obter usuário atual
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Usuário não autenticado" }, { status: 401 })
    }

    // Verificar se o prompt existe e pertence ao usuário
    const { data: existingPrompt, error: fetchError } = await supabase
      .from("prompts")
      .select("user_id")
      .eq("id", id)
      .single()

    if (fetchError) {
      console.error(`Erro ao verificar prompt ${id}:`, fetchError)
      return NextResponse.json({ error: fetchError.message }, { status: 500 })
    }

    if (!existingPrompt) {
      return NextResponse.json({ error: "Prompt não encontrado" }, { status: 404 })
    }

    if (existingPrompt.user_id !== user.id) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 403 })
    }

    // Excluir o prompt
    const { error } = await supabase.from("prompts").delete().eq("id", id)

    if (error) {
      console.error(`Erro ao excluir prompt ${id}:`, error)
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json({ success: true })
  } catch (error: any) {
    console.error("Erro ao processar requisição:", error)
    return NextResponse.json({ error: error.message || "Erro desconhecido" }, { status: 500 })
  }
}
