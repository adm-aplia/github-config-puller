import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/supabase-server"

export async function GET(request: NextRequest) {
  try {
    const supabase = createClient()

    // Verificar se o usuário está autenticado
    const {
      data: { session },
      error: authError,
    } = await supabase.auth.getSession()

    if (authError) {
      console.log("❌ Erro de autenticação:", authError)
      return NextResponse.json({ error: "Erro de autenticação" }, { status: 401 })
    }

    if (!session?.user) {
      console.log("❌ Usuário não autenticado: Sessão não encontrada")
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
    }

    const user = session.user
    console.log("🔍 Buscando perfil para user_id:", user.id)

    // Buscar dados do perfil na tabela profiles
    const { data: profile, error: profileError } = await supabase
      .from("profiles")
      .select("*")
      .eq("id", user.id)
      .single()

    if (profileError) {
      console.log("❌ Erro ao buscar perfil:", profileError)

      // Se o perfil não existe, criar um básico
      if (profileError.code === "PGRST116") {
        const newProfile = {
          id: user.id,
          email: user.email,
          name: user.user_metadata?.name || user.email?.split("@")[0] || "Usuário",
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        }

        const { data: createdProfile, error: createError } = await supabase
          .from("profiles")
          .insert(newProfile)
          .select()
          .single()

        if (createError) {
          console.log("❌ Erro ao criar perfil:", createError)
          return NextResponse.json({ error: "Erro ao criar perfil" }, { status: 500 })
        }

        console.log("✅ Perfil criado:", createdProfile)
        return NextResponse.json(createdProfile)
      }

      return NextResponse.json({ error: "Perfil não encontrado" }, { status: 404 })
    }

    console.log("✅ Perfil encontrado:", profile)
    return NextResponse.json(profile)
  } catch (error) {
    console.error("❌ Erro interno:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}
