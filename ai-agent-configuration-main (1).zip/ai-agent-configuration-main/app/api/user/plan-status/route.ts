import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get("user_id") || searchParams.get("userId")

    console.log("🔍 Plan Status API - userId recebido:", userId)

    if (!userId || userId === "undefined" || userId === "null") {
      console.error("❌ Plan Status API: userId inválido:", userId)
      return NextResponse.json({ error: "user_id é obrigatório e deve ser válido" }, { status: 400 })
    }

    // Verificar se é um UUID válido
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i
    if (!uuidRegex.test(userId)) {
      console.error("❌ Plan Status API: userId não é um UUID válido:", userId)
      return NextResponse.json({ error: "user_id deve ser um UUID válido" }, { status: 400 })
    }

    console.log("🔍 Plan Status API: Buscando dados para userId:", userId)

    // 1. Buscar cliente
    const { data: cliente, error: clienteError } = await supabase
      .from("clientes")
      .select("*")
      .eq("user_id", userId)
      .single()

    console.log("📊 Cliente query result:", { cliente, clienteError })

    if (clienteError || !cliente) {
      console.log("⚠️ Cliente não encontrado, usando plano básico:", clienteError?.message)
      return NextResponse.json({
        planName: "Básico",
        plan_name: "Básico",
        limits: {
          profiles_limit: 0,
          whatsapp_instances_limit: 1,
          appointments_limit: 300,
          assistants_limit: 1,
        },
        usage: {
          profiles_count: 0,
          whatsapp_instances_count: 0,
          appointments_count: 0,
          assistants_count: 0,
        },
        isActive: false,
      })
    }

    console.log("📊 Cliente encontrado:", cliente)

    // 2. Definir limites baseado no plano do cliente
    let planLimits = {
      profiles_limit: 0,
      whatsapp_instances_limit: 1,
      appointments_limit: 300,
      assistants_limit: 1,
    }

    // Mapear planos para limites corretos
    switch (cliente.plano) {
      case "Básico":
        planLimits = {
          profiles_limit: 0,
          whatsapp_instances_limit: 1,
          appointments_limit: 300,
          assistants_limit: 1,
        }
        break
      case "Profissional":
        planLimits = {
          profiles_limit: 3, // ✅ CORRIGIDO: Plano Profissional permite 3 perfis
          whatsapp_instances_limit: 3,
          appointments_limit: 1000,
          assistants_limit: 3,
        }
        break
      case "Clínica":
        planLimits = {
          profiles_limit: 5,
          whatsapp_instances_limit: 5,
          appointments_limit: 2000,
          assistants_limit: 5,
        }
        break
      case "Empresa":
        planLimits = {
          profiles_limit: 10,
          whatsapp_instances_limit: 10,
          appointments_limit: 5000,
          assistants_limit: 10,
        }
        break
      default:
        console.log("⚠️ Plano não reconhecido:", cliente.plano, "usando limites básicos")
    }

    console.log("📊 Limites do plano definidos:", planLimits)

    // 3. Buscar contagem de perfis profissionais
    let profilesCount = 0
    try {
      const { count, error: profilesError } = await supabase
        .from("professional_profiles")
        .select("*", { count: "exact", head: true })
        .eq("user_id", userId)

      if (profilesError) {
        console.error("❌ Erro ao contar perfis profissionais:", profilesError)
      } else {
        profilesCount = count || 0
      }
    } catch (error) {
      console.error("❌ Erro crítico ao contar perfis profissionais:", error)
    }

    console.log("📊 Contagem de perfis profissionais:", profilesCount)

    // 4. Buscar contagem de instâncias WhatsApp
    let whatsappCount = 0
    try {
      const { count, error: whatsappError } = await supabase
        .from("whatsapp_instances")
        .select("*", { count: "exact", head: true })
        .eq("user_id", userId)

      if (whatsappError) {
        console.error("❌ Erro ao contar instâncias WhatsApp:", whatsappError)
      } else {
        whatsappCount = count || 0
      }
    } catch (error) {
      console.error("❌ Erro crítico ao contar instâncias WhatsApp:", error)
    }

    console.log("📊 Contagem de instâncias WhatsApp:", whatsappCount)

    // 5. Buscar contagem de agendamentos
    let appointmentsCount = 0
    try {
      const { count, error: appointmentsError } = await supabase
        .from("appointments")
        .select("*", { count: "exact", head: true })
        .eq("user_id", userId)

      if (appointmentsError) {
        console.error("❌ Erro ao contar agendamentos:", appointmentsError)
      } else {
        appointmentsCount = count || 0
      }
    } catch (error) {
      console.error("❌ Erro crítico ao contar agendamentos:", error)
    }

    console.log("📊 Contagem de agendamentos:", appointmentsCount)

    // 6. Buscar contagem de assistentes (usando professional_profiles)
    const assistantsCount = profilesCount // Assistentes = perfis profissionais

    console.log("📊 Contagem de assistentes:", assistantsCount)

    // 7. Montar resposta
    const planStatus = {
      planName: cliente.plano || "Básico",
      plan_name: cliente.plano || "Básico",
      limits: planLimits,
      usage: {
        profiles_count: profilesCount,
        whatsapp_instances_count: whatsappCount,
        appointments_count: appointmentsCount,
        assistants_count: assistantsCount,
      },
      isActive: cliente.is_active || false,
    }

    console.log("📊 Status do plano final:", planStatus)

    return NextResponse.json(planStatus)
  } catch (error) {
    console.error("❌ Erro crítico na API de status do plano:", error)

    // Retornar resposta de fallback em caso de erro crítico
    return NextResponse.json(
      {
        planName: "Básico",
        plan_name: "Básico",
        limits: {
          profiles_limit: 0,
          whatsapp_instances_limit: 1,
          appointments_limit: 300,
          assistants_limit: 1,
        },
        usage: {
          profiles_count: 0,
          whatsapp_instances_count: 0,
          appointments_count: 0,
          assistants_count: 0,
        },
        isActive: false,
        error: "Erro interno do servidor",
      },
      { status: 500 },
    )
  }
}
