import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/supabase-server"
import { AsaasService } from "@/lib/services/asaas-service"

export async function POST(request: NextRequest) {
  console.log("🚫 [API] Iniciando cancelamento de assinatura")

  try {
    const body = await request.json()
    const { subscription_id } = body

    if (!subscription_id) {
      return NextResponse.json({ success: false, error: "ID da assinatura é obrigatório" }, { status: 400 })
    }

    const supabase = createClient()

    // Obter usuário atual
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser()

    if (userError || !user) {
      return NextResponse.json({ success: false, error: "Usuário não autenticado" }, { status: 401 })
    }

    // Verificar se a assinatura pertence ao usuário
    const { data: assinatura } = await supabase
      .from("assinaturas")
      .select(`
        *,
        clientes!inner(user_id)
      `)
      .eq("subscription_id", subscription_id)
      .eq("clientes.user_id", user.id)
      .single()

    if (!assinatura) {
      return NextResponse.json({ success: false, error: "Assinatura não encontrada" }, { status: 404 })
    }

    // Cancelar no Asaas
    try {
      await AsaasService.cancelSubscription(subscription_id)
      console.log("✅ [API] Assinatura cancelada no Asaas")
    } catch (error: any) {
      console.error("❌ [API] Erro ao cancelar no Asaas:", error)
      return NextResponse.json(
        {
          success: false,
          error: "Erro ao cancelar assinatura",
          message: error.message,
        },
        { status: 500 },
      )
    }

    // Atualizar status no Supabase
    const { error: updateError } = await supabase
      .from("assinaturas")
      .update({
        status: "canceled",
        updated_at: new Date().toISOString(),
      })
      .eq("subscription_id", subscription_id)

    if (updateError) {
      console.error("❌ [API] Erro ao atualizar status no Supabase:", updateError)
      return NextResponse.json(
        {
          success: false,
          error: "Erro ao atualizar status da assinatura",
          message: updateError.message,
        },
        { status: 500 },
      )
    }

    console.log("🎉 [API] Assinatura cancelada com sucesso")

    return NextResponse.json({
      success: true,
      message: "Assinatura cancelada com sucesso",
    })
  } catch (error: any) {
    console.error("❌ [API] Erro crítico ao cancelar assinatura:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Erro interno do servidor",
        message: error.message,
      },
      { status: 500 },
    )
  }
}
