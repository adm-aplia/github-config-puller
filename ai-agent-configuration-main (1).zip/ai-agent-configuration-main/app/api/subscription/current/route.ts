import { type NextRequest, NextResponse } from "next/server"
import { createServerClient } from "@supabase/ssr"
import { AsaasService } from "@/lib/services/asaas-service"
import { cookies } from "next/headers"

export async function GET(request: NextRequest) {
  console.log("🔍 [API] Buscando assinatura atual do usuário")

  try {
    const cookieStore = await cookies()

    const supabase = createServerClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
      {
        cookies: {
          getAll() {
            return cookieStore.getAll()
          },
          setAll(cookiesToSet) {
            try {
              cookiesToSet.forEach(({ name, value, options }) => cookieStore.set(name, value, options))
            } catch {
              // The `setAll` method was called from a Server Component.
              // This can be ignored if you have middleware refreshing
              // user sessions.
            }
          },
        },
      },
    )

    // Obter usuário atual da sessão
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser()

    if (userError || !user) {
      console.error("❌ [API] Usuário não autenticado:", userError?.message || "No user")
      return NextResponse.json(
        {
          success: false,
          error: "Usuário não autenticado",
          subscription: null,
          payments: [],
        },
        { status: 401 },
      )
    }

    console.log("✅ [API] Usuário autenticado:", user.id)

    // Buscar cliente do usuário
    const { data: cliente, error: clienteError } = await supabase
      .from("clientes")
      .select("*")
      .eq("user_id", user.id)
      .single()

    if (clienteError || !cliente) {
      console.log("ℹ️ [API] Nenhum cliente encontrado para o usuário")
      return NextResponse.json({
        success: true,
        subscription: null,
        payments: [],
        message: "Nenhum cliente encontrado",
      })
    }

    console.log("✅ [API] Cliente encontrado:", cliente.id)

    // Buscar assinatura ativa do cliente
    const { data: assinatura, error: assinaturaError } = await supabase
      .from("assinaturas")
      .select("*")
      .eq("id_cliente_supabase", cliente.id)
      .order("created_at", { ascending: false })
      .limit(1)
      .single()

    if (assinaturaError || !assinatura) {
      console.log("ℹ️ [API] Nenhuma assinatura encontrada para o cliente")
      return NextResponse.json({
        success: true,
        subscription: null,
        payments: [],
        message: "Nenhuma assinatura encontrada",
      })
    }

    console.log("✅ [API] Assinatura encontrada:", assinatura.subscription_id)

    // Buscar status atualizado no Asaas (opcional)
    let statusAtualizado = assinatura.status
    try {
      if (assinatura.subscription_id && !assinatura.subscription_id.includes("test_")) {
        const asaasSubscription = await AsaasService.getSubscription(assinatura.subscription_id)
        statusAtualizado = asaasSubscription.status

        // Atualizar status no Supabase se mudou
        if (statusAtualizado !== assinatura.status) {
          await supabase.from("assinaturas").update({ status: statusAtualizado }).eq("id", assinatura.id)
        }
      }
    } catch (error) {
      console.warn("⚠️ [API] Não foi possível buscar status no Asaas:", error)
    }

    // Simular histórico de pagamentos
    const payments = []

    // Adicionar primeira cobrança se existir
    if (assinatura.first_payment_id) {
      payments.push({
        id: assinatura.first_payment_id,
        valor: assinatura.valor,
        status: assinatura.first_payment_status || "confirmed",
        data_vencimento: assinatura.data_contratacao,
        descricao: `${assinatura.plano} - Primeira mensalidade`,
      })
    }

    console.log("✅ [API] Dados da assinatura carregados com sucesso")

    return NextResponse.json({
      success: true,
      subscription: {
        ...assinatura,
        status: statusAtualizado,
      },
      payments,
    })
  } catch (error: any) {
    console.error("❌ [API] Erro ao buscar assinatura:", error)

    // Sempre retornar JSON, mesmo em caso de erro
    return NextResponse.json(
      {
        success: false,
        error: "Erro interno do servidor",
        message: error?.message || "Erro desconhecido",
        subscription: null,
        payments: [],
      },
      { status: 500 },
    )
  }
}
