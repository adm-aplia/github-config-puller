import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/supabase-server"
import { AsaasService } from "@/lib/services/asaas-service"

export async function POST(request: NextRequest) {
  console.log("🚀 [API] Iniciando processo de assinatura com cobrança imediata")

  try {
    // Parse do body
    let body
    try {
      body = await request.json()
      console.log("📝 [API] Dados recebidos (mascarados):", {
        nome: body.nome,
        email: body.email,
        telefone: body.telefone ? "***" : undefined,
        documento: body.documento ? "***" : undefined,
        plano: body.plano,
        user_id: body.user_id,
        cartao: body.cartao ? "***" : undefined,
        cobranca_imediata: body.cobranca_imediata || true, // Default: true
      })
    } catch (parseError) {
      console.error("❌ [API] Erro ao fazer parse do JSON:", parseError)
      return NextResponse.json(
        {
          success: false,
          error: "Dados inválidos enviados",
          message: "Erro ao processar dados da requisição",
        },
        { status: 400 },
      )
    }

    // Validar dados obrigatórios
    const { nome, email, telefone, documento, plano, user_id, cartao, cobranca_imediata = true } = body

    if (!nome || !email || !telefone || !documento || !plano) {
      console.error("❌ [API] Dados obrigatórios faltando")
      return NextResponse.json(
        {
          success: false,
          error: "Dados obrigatórios não fornecidos",
          message: "Nome, email, telefone, documento e plano são obrigatórios",
        },
        { status: 400 },
      )
    }

    if (
      !cartao ||
      !cartao.nomeCartao ||
      !cartao.numeroCartao ||
      !cartao.mesExpiracao ||
      !cartao.anoExpiracao ||
      !cartao.cvv
    ) {
      console.error("❌ [API] Dados do cartão faltando")
      return NextResponse.json(
        {
          success: false,
          error: "Dados do cartão obrigatórios não fornecidos",
          message: "Todos os dados do cartão são obrigatórios",
        },
        { status: 400 },
      )
    }

    // Validar plano
    const planosValidos = ["Básico", "Profissional", "Empresarial"]
    if (!planosValidos.includes(plano)) {
      console.error("❌ [API] Plano inválido:", plano)
      return NextResponse.json(
        {
          success: false,
          error: `Plano inválido. Planos válidos: ${planosValidos.join(", ")}`,
        },
        { status: 400 },
      )
    }

    // Obter configurações do plano
    const planosConfig = {
      Básico: {
        valor: 199.0,
        descricao: "Plano Básico Aplia – 1 número WhatsApp, até 300 agendamentos, 1 assistente, suporte por e-mail.",
      },
      Profissional: {
        valor: 399.0,
        descricao:
          "Plano Profissional Aplia – 3 números WhatsApp, até 1000 agendamentos, 3 assistentes, suporte prioritário, relatórios avançados.",
      },
      Empresarial: {
        valor: 899.0,
        descricao:
          "Plano Empresarial Aplia – +10 números WhatsApp, agendamentos ilimitados, assistentes ilimitados, suporte 24/7, integração com sistemas hospitalares, personalização avançada.",
      },
    }

    const planoConfig = planosConfig[plano as keyof typeof planosConfig]
    console.log("📋 [API] Configuração do plano:", planoConfig)

    // Inicializar Supabase
    const supabase = createClient()

    // 1. Verificar/Criar cliente no Supabase
    console.log("🔍 [API] Verificando cliente no Supabase...")

    let clienteSupabase
    const { data: clienteExistente } = await supabase
      .from("clientes")
      .select("*")
      .or(`cpf_cnpj.eq.${documento},email.eq.${email}`)
      .single()

    if (clienteExistente) {
      console.log("✅ [API] Cliente já existe no Supabase:", clienteExistente.id)
      clienteSupabase = clienteExistente
    } else {
      console.log("➕ [API] Criando novo cliente no Supabase...")
      const { data: novoCliente, error: erroCliente } = await supabase
        .from("clientes")
        .insert({
          nome,
          email,
          telefone,
          cpf_cnpj: documento,
          plano,
          data_contratacao: new Date().toISOString(),
          status: "ativo",
          user_id,
        })
        .select()
        .single()

      if (erroCliente) {
        console.error("❌ [API] Erro ao criar cliente no Supabase:", erroCliente)
        return NextResponse.json(
          {
            success: false,
            error: "Erro ao criar cliente no banco de dados",
            message: erroCliente.message,
          },
          { status: 500 },
        )
      }

      clienteSupabase = novoCliente
      console.log("✅ [API] Cliente criado no Supabase:", clienteSupabase.id)
    }

    // 2. Verificar/Criar cliente no Asaas
    console.log("🏢 [API] Processando cliente no Asaas...")

    let customerIdAsaas = clienteSupabase.customer_id_asaas

    if (!customerIdAsaas) {
      console.log("➕ [API] Criando cliente no Asaas...")
      try {
        const clienteAsaas = await AsaasService.createCustomer({
          name: nome,
          cpfCnpj: documento,
          email: email,
          phone: telefone,
          mobilePhone: telefone,
        })

        customerIdAsaas = clienteAsaas.id
        console.log("✅ [API] Cliente criado no Asaas:", customerIdAsaas)

        // Atualizar cliente no Supabase com customer_id
        await supabase.from("clientes").update({ customer_id_asaas: customerIdAsaas }).eq("id", clienteSupabase.id)
      } catch (error: any) {
        console.error("❌ [API] Erro ao criar cliente no Asaas:", error)
        return NextResponse.json(
          {
            success: false,
            error: "Erro ao criar cliente no Asaas",
            message: error.message,
          },
          { status: 500 },
        )
      }
    } else {
      console.log("✅ [API] Cliente já existe no Asaas:", customerIdAsaas)
    }

    // 3. Criar assinatura com ou sem cobrança imediata
    console.log(`🔄 [API] Criando assinatura ${cobranca_imediata ? "com cobrança imediata" : "recorrente"}...`)

    const proximoVencimento = new Date()
    proximoVencimento.setMonth(proximoVencimento.getMonth() + 1)

    const subscriptionData = {
      customer: customerIdAsaas,
      billingType: "CREDIT_CARD" as const,
      value: planoConfig.valor,
      cycle: "MONTHLY" as const,
      description: planoConfig.descricao,
      nextDueDate: proximoVencimento.toISOString().split("T")[0],
      creditCard: {
        holderName: cartao.nomeCartao,
        number: cartao.numeroCartao,
        expiryMonth: cartao.mesExpiracao,
        expiryYear: cartao.anoExpiracao,
        ccv: cartao.cvv,
      },
      creditCardHolderInfo: {
        name: nome,
        email: email,
        cpfCnpj: documento,
        postalCode: body.cep || "01310100",
        addressNumber: body.numero || "100",
        addressComplement: body.endereco || "",
        phone: telefone,
        mobilePhone: telefone,
      },
      remoteIp: request.ip || request.headers.get("x-forwarded-for") || "127.0.0.1",
    }

    let assinaturaAsaas
    let cobrancaAsaas = null

    try {
      if (cobranca_imediata) {
        // Criar assinatura com cobrança imediata
        const result = await AsaasService.createSubscriptionWithImmediateCharge(subscriptionData)
        assinaturaAsaas = result.subscription
        cobrancaAsaas = result.payment
        console.log("✅ [API] Assinatura criada com cobrança imediata:", {
          subscription: assinaturaAsaas.id,
          payment: cobrancaAsaas.id,
          paymentStatus: cobrancaAsaas.status,
        })
      } else {
        // Criar apenas assinatura recorrente
        assinaturaAsaas = await AsaasService.createSubscriptionDirect(subscriptionData)
        console.log("✅ [API] Assinatura recorrente criada:", assinaturaAsaas.id)
      }
    } catch (error: any) {
      console.error("❌ [API] Erro ao criar assinatura:", error)
      return NextResponse.json(
        {
          success: false,
          error: "Erro ao criar assinatura",
          message: error.message,
        },
        { status: 500 },
      )
    }

    // 4. Salvar assinatura no Supabase
    console.log("💾 [API] Salvando assinatura no Supabase...")

    try {
      const { data: assinaturaSupabase, error: erroAssinatura } = await supabase
        .from("assinaturas")
        .insert({
          id_cliente_supabase: clienteSupabase.id,
          customer_id_asaas: customerIdAsaas,
          subscription_id: assinaturaAsaas.id,
          credit_card_token: null,
          plano: plano,
          valor: planoConfig.valor,
          descricao: planoConfig.descricao,
          status: assinaturaAsaas.status,
          data_contratacao: new Date().toISOString(),
          next_due_date: assinaturaAsaas.nextDueDate,
          remote_ip: request.ip || "127.0.0.1",
          // Salvar dados da cobrança imediata se existir
          first_payment_id: cobrancaAsaas?.id || null,
          first_payment_status: cobrancaAsaas?.status || null,
        })
        .select()
        .single()

      if (erroAssinatura) {
        console.error("❌ [API] Erro ao salvar assinatura no Supabase:", erroAssinatura)
        return NextResponse.json(
          {
            success: false,
            error: "Erro ao salvar assinatura no banco de dados",
            message: erroAssinatura.message,
          },
          { status: 500 },
        )
      }

      console.log("✅ [API] Assinatura salva no Supabase:", assinaturaSupabase.id)

      // 5. Retornar sucesso
      console.log("🎉 [API] Processo de assinatura concluído com sucesso!")

      return NextResponse.json({
        success: true,
        message: cobranca_imediata
          ? "Assinatura criada e primeira cobrança processada com sucesso"
          : "Assinatura criada com sucesso",
        data: {
          cliente: {
            id: clienteSupabase.id,
            nome: clienteSupabase.nome,
            email: clienteSupabase.email,
            plano: clienteSupabase.plano,
            status: clienteSupabase.status,
          },
          assinatura: {
            id: assinaturaSupabase.id,
            subscription_id: assinaturaAsaas.id,
            status: assinaturaAsaas.status,
            valor: planoConfig.valor,
            descricao: planoConfig.descricao,
            next_due_date: assinaturaAsaas.nextDueDate,
          },
          cobranca_imediata: cobrancaAsaas
            ? {
                id: cobrancaAsaas.id,
                status: cobrancaAsaas.status,
                valor: cobrancaAsaas.value,
                data_vencimento: cobrancaAsaas.dueDate,
                invoice_url: cobrancaAsaas.invoiceUrl,
              }
            : null,
        },
      })
    } catch (error: any) {
      console.error("❌ [API] Erro ao salvar no Supabase:", error)
      return NextResponse.json(
        {
          success: false,
          error: "Erro ao salvar dados",
          message: error.message,
        },
        { status: 500 },
      )
    }
  } catch (error: any) {
    console.error("❌ [API] Erro crítico:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Erro interno do servidor",
        message: error.message || "Erro inesperado",
        stack: process.env.NODE_ENV === "development" ? error.stack : undefined,
      },
      { status: 500 },
    )
  }
}
