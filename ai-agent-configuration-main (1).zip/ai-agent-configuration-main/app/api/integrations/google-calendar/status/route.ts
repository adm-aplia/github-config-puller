import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get("user_id")

    console.log("🔍 Google Calendar Status API - userId recebido:", userId)

    if (!userId || userId === "undefined" || userId === "null") {
      console.error("❌ Google Calendar Status API: userId inválido:", userId)
      return NextResponse.json({ error: "user_id é obrigatório e deve ser válido" }, { status: 400 })
    }

    // Verificar se é um UUID válido
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i
    if (!uuidRegex.test(userId)) {
      console.error("❌ Google Calendar Status API: userId não é um UUID válido:", userId)
      return NextResponse.json({ error: "user_id deve ser um UUID válido" }, { status: 400 })
    }

    console.log("🔍 Buscando credenciais Google para usuário:", userId)

    // 1. Buscar credenciais Google do usuário
    const { data: credentials, error: credentialsError } = await supabase
      .from("google_credentials")
      .select("*")
      .eq("user_id", userId)
      .order("created_at", { ascending: false })

    if (credentialsError) {
      console.error("❌ Erro ao buscar credenciais Google:", credentialsError)
      return NextResponse.json({ error: "Erro ao buscar credenciais Google" }, { status: 500 })
    }

    console.log("📧 Credenciais Google encontradas:", credentials?.length || 0)

    // 2. Buscar perfis profissionais do usuário para filtrar os links
    const { data: userProfiles, error: profilesError } = await supabase
      .from("professional_profiles")
      .select("id")
      .eq("user_id", userId)

    if (profilesError) {
      console.error("❌ Erro ao buscar perfis do usuário:", profilesError)
      return NextResponse.json({ error: "Erro ao buscar perfis do usuário" }, { status: 500 })
    }

    const userProfileIds = userProfiles?.map((p) => p.id) || []
    console.log("👤 IDs dos perfis do usuário:", userProfileIds)

    // 3. Buscar links de perfis (apenas para os perfis do usuário)
    let profileLinks: any[] = []
    if (userProfileIds.length > 0) {
      const { data: links, error: linksError } = await supabase
        .from("google_profile_links")
        .select("*")
        .in("professional_profile_id", userProfileIds)
        .order("created_at", { ascending: false })

      if (linksError) {
        console.error("❌ Erro ao buscar links de perfis:", linksError)
      } else {
        profileLinks = links || []
      }
    }

    console.log("🔗 Links de perfis encontrados:", profileLinks.length)

    // 4. Mapear credenciais com informações de vinculação
    const credentialsWithLinks = (credentials || []).map((credential) => {
      // Verificar se esta credencial está vinculada a algum perfil
      const linkedProfile = profileLinks.find((link) => link.google_credential_id === credential.id)

      return {
        ...credential,
        linked: !!linkedProfile,
        professional_profile_id: linkedProfile?.professional_profile_id || null,
      }
    })

    console.log("📊 Credenciais com informações de vinculação:", credentialsWithLinks)

    return NextResponse.json({
      success: true,
      credentials: credentialsWithLinks,
      links: profileLinks,
    })
  } catch (error) {
    console.error("❌ Erro interno na API de status do Google Calendar:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}
