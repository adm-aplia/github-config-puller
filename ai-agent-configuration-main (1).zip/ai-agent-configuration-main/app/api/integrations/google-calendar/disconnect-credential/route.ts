import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/supabase-server"

export async function POST(request: NextRequest) {
  try {
    const { credentialId } = await request.json()

    if (!credentialId) {
      return NextResponse.json({ error: "ID da credencial é obrigatório" }, { status: 400 })
    }

    const supabase = await createClient()

    // Primeiro, remover todas as vinculações de perfis profissionais
    const { error: linkError } = await supabase
      .from("google_profile_links")
      .delete()
      .eq("google_credential_id", credentialId)

    if (linkError) {
      console.error("Erro ao remover vinculações:", linkError)
      return NextResponse.json({ error: "Erro ao remover vinculações de perfis" }, { status: 500 })
    }

    // Depois, remover a credencial
    const { error: credentialError } = await supabase.from("google_credentials").delete().eq("id", credentialId)

    if (credentialError) {
      console.error("Erro ao remover credencial:", credentialError)
      return NextResponse.json({ error: "Erro ao remover credencial" }, { status: 500 })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Erro na API de desconexão:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}
