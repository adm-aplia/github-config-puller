import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { user_id, profile_id, credential_id } = body

    console.log("🔗 Google Calendar Link Profile API - dados recebidos:", { user_id, profile_id, credential_id })

    // Validar parâmetros
    if (!user_id || user_id === "undefined" || user_id === "null") {
      console.error("❌ user_id inválido:", user_id)
      return NextResponse.json({ error: "user_id é obrigatório e deve ser válido" }, { status: 400 })
    }

    if (!profile_id || profile_id === "undefined" || profile_id === "null") {
      console.error("❌ profile_id inválido:", profile_id)
      return NextResponse.json({ error: "profile_id é obrigatório e deve ser válido" }, { status: 400 })
    }

    if (!credential_id || credential_id === "undefined" || credential_id === "null") {
      console.error("❌ credential_id inválido:", credential_id)
      return NextResponse.json({ error: "credential_id é obrigatório e deve ser válido" }, { status: 400 })
    }

    // Verificar se são UUIDs válidos
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i
    if (!uuidRegex.test(user_id) || !uuidRegex.test(profile_id) || !uuidRegex.test(credential_id)) {
      console.error("❌ Um ou mais IDs não são UUIDs válidos")
      return NextResponse.json({ error: "IDs devem ser UUIDs válidos" }, { status: 400 })
    }

    // 1. Verificar se o perfil pertence ao usuário
    const { data: profile, error: profileError } = await supabase
      .from("professional_profiles")
      .select("*")
      .eq("id", profile_id)
      .eq("user_id", user_id)
      .single()

    if (profileError || !profile) {
      console.error("❌ Perfil não encontrado ou não pertence ao usuário:", profileError)
      return NextResponse.json({ error: "Perfil não encontrado ou não autorizado" }, { status: 404 })
    }

    console.log("✅ Perfil validado:", profile.fullname)

    // 2. Verificar se a credencial pertence ao usuário
    const { data: credential, error: credentialError } = await supabase
      .from("google_credentials")
      .select("*")
      .eq("id", credential_id)
      .eq("user_id", user_id)
      .single()

    if (credentialError || !credential) {
      console.error("❌ Credencial não encontrada ou não pertence ao usuário:", credentialError)
      return NextResponse.json({ error: "Credencial não encontrada ou não autorizada" }, { status: 404 })
    }

    console.log("✅ Credencial validada:", credential.email)

    // 3. Verificar se já existe um link para este perfil
    const { data: existingLink, error: existingLinkError } = await supabase
      .from("google_profile_links")
      .select("*")
      .eq("professional_profile_id", profile_id)
      .single()

    if (existingLink) {
      console.log("⚠️ Perfil já possui vinculação, removendo link anterior...")

      // Remover link anterior
      const { error: deleteError } = await supabase
        .from("google_profile_links")
        .delete()
        .eq("professional_profile_id", profile_id)

      if (deleteError) {
        console.error("❌ Erro ao remover link anterior:", deleteError)
        return NextResponse.json({ error: "Erro ao atualizar vinculação" }, { status: 500 })
      }
    }

    // 4. Criar novo link
    const { data: newLink, error: linkError } = await supabase
      .from("google_profile_links")
      .insert([
        {
          google_credential_id: credential_id,
          professional_profile_id: profile_id,
        },
      ])
      .select()
      .single()

    if (linkError) {
      console.error("❌ Erro ao criar link:", linkError)
      return NextResponse.json({ error: "Erro ao vincular conta Google" }, { status: 500 })
    }

    console.log("✅ Link criado com sucesso:", newLink.id)

    return NextResponse.json({
      success: true,
      message: "Conta Google vinculada com sucesso",
      link: newLink,
      credential_email: credential.email,
      profile_name: profile.fullname,
    })
  } catch (error) {
    console.error("❌ Erro interno na API de vinculação Google:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get("user_id")
    const profileId = searchParams.get("profile_id")

    console.log("🗑️ Google Calendar Unlink Profile API - dados recebidos:", { userId, profileId })

    // Validar parâmetros
    if (!userId || userId === "undefined" || userId === "null") {
      console.error("❌ user_id inválido:", userId)
      return NextResponse.json({ error: "user_id é obrigatório e deve ser válido" }, { status: 400 })
    }

    if (!profileId || profileId === "undefined" || profileId === "null") {
      console.error("❌ profile_id inválido:", profileId)
      return NextResponse.json({ error: "profile_id é obrigatório e deve ser válido" }, { status: 400 })
    }

    // Verificar se são UUIDs válidos
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i
    if (!uuidRegex.test(userId) || !uuidRegex.test(profileId)) {
      console.error("❌ Um ou mais IDs não são UUIDs válidos")
      return NextResponse.json({ error: "IDs devem ser UUIDs válidos" }, { status: 400 })
    }

    // 1. Verificar se o perfil pertence ao usuário
    const { data: profile, error: profileError } = await supabase
      .from("professional_profiles")
      .select("*")
      .eq("id", profileId)
      .eq("user_id", userId)
      .single()

    if (profileError || !profile) {
      console.error("❌ Perfil não encontrado ou não pertence ao usuário:", profileError)
      return NextResponse.json({ error: "Perfil não encontrado ou não autorizado" }, { status: 404 })
    }

    console.log("✅ Perfil validado para desvinculação:", profile.fullname)

    // 2. Remover link
    const { error: deleteError } = await supabase
      .from("google_profile_links")
      .delete()
      .eq("professional_profile_id", profileId)

    if (deleteError) {
      console.error("❌ Erro ao remover link:", deleteError)
      return NextResponse.json({ error: "Erro ao desvincular conta Google" }, { status: 500 })
    }

    console.log("✅ Link removido com sucesso")

    return NextResponse.json({
      success: true,
      message: "Conta Google desvinculada com sucesso",
      profile_name: profile.fullname,
    })
  } catch (error) {
    console.error("❌ Erro interno na API de desvinculação Google:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}
