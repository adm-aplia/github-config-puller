import { type NextRequest, NextResponse } from "next/server"
import { BillingService } from "@/lib/services/billing-service"
import { getSupabaseServerClient } from "@/lib/supabase/supabase-server"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    console.log("📨 Webhook Asaas recebido:", JSON.stringify(body, null, 2))

    const supabase = await getSupabaseServerClient()

    // 1. Processar eventos de PAGAMENTO
    if (body.event && body.payment) {
      const { event, payment } = body

      console.log(`💰 Evento de pagamento: ${event} - Status: ${payment.status}`)

      // Atualizar status da cobrança no Supabase (se existir tabela cobrancas)
      try {
        await supabase
          .from("cobrancas")
          .update({
            status: payment.status,
            updated_at: new Date().toISOString(),
          })
          .eq("id_cobranca", payment.id)
      } catch (error) {
        console.log("⚠️ Tabela cobrancas não encontrada ou erro ao atualizar")
      }

      // Se o pagamento foi confirmado, ativar cliente
      if (payment.status === "RECEIVED" || payment.status === "CONFIRMED") {
        try {
          // Buscar cliente pelo customer_id
          const { data: cliente } = await supabase
            .from("clientes")
            .select("*")
            .eq("customer_id", payment.customer)
            .single()

          if (cliente) {
            // Ativar cliente
            await BillingService.activateClient(cliente.id)
            console.log(`🎉 Cliente ${cliente.nome} ativado após pagamento confirmado`)

            // Atualizar metadados do usuário
            if (cliente.user_id) {
              await supabase.auth.admin.updateUserById(cliente.user_id, {
                user_metadata: {
                  is_paid: true,
                  plan: cliente.plano,
                  payment_confirmed_at: new Date().toISOString(),
                },
              })
              console.log(`👤 Usuário ${cliente.user_id} ativado com sucesso!`)
            }
          }
        } catch (activationError) {
          console.error("❌ Erro ao ativar cliente/usuário:", activationError)
        }
      }
    }

    // 2. Processar eventos de ASSINATURA
    if (body.event && body.subscription) {
      const { event, subscription: sub } = body

      console.log(`🔄 Evento de assinatura: ${event} - Status: ${sub.status}`)

      // Atualizar status e next_due_date da assinatura
      const { error: subscriptionError } = await supabase
        .from("assinaturas")
        .update({
          status: sub.status,
          next_due_date: sub.nextDueDate,
          updated_at: new Date().toISOString(),
        })
        .eq("subscription_id", sub.id)

      if (subscriptionError) {
        console.error("❌ Erro ao atualizar assinatura:", subscriptionError)
      } else {
        console.log(`✅ Assinatura ${sub.id} atualizada - Status: ${sub.status}`)
      }

      // Processar eventos específicos de assinatura
      switch (event) {
        case "SUBSCRIPTION_CREATED":
          console.log(`🆕 Nova assinatura criada: ${sub.id}`)
          break

        case "SUBSCRIPTION_UPDATED":
          console.log(`🔄 Assinatura atualizada: ${sub.id}`)
          break

        case "SUBSCRIPTION_CANCELED":
          console.log(`❌ Assinatura cancelada: ${sub.id}`)

          // Desativar cliente quando assinatura for cancelada
          try {
            const { data: assinatura } = await supabase
              .from("assinaturas")
              .select("cliente_id, clientes(*)")
              .eq("subscription_id", sub.id)
              .single()

            if (assinatura?.cliente_id) {
              await supabase
                .from("clientes")
                .update({
                  status: "inativo",
                  is_active: false,
                  updated_at: new Date().toISOString(),
                })
                .eq("id", assinatura.cliente_id)

              console.log(`🔒 Cliente desativado após cancelamento da assinatura`)
            }
          } catch (error) {
            console.error("❌ Erro ao desativar cliente:", error)
          }
          break

        case "SUBSCRIPTION_SUSPENDED":
          console.log(`⏸️ Assinatura suspensa: ${sub.id}`)
          break

        case "SUBSCRIPTION_REACTIVATED":
          console.log(`▶️ Assinatura reativada: ${sub.id}`)
          break

        default:
          console.log(`📋 Evento de assinatura não tratado: ${event}`)
      }
    }

    return NextResponse.json({
      success: true,
      message: "Webhook processado com sucesso",
      processed: {
        payment: !!body.payment,
        subscription: !!body.subscription,
        event: body.event,
      },
    })
  } catch (error: any) {
    console.error("❌ Erro no webhook Asaas:", error)

    return NextResponse.json(
      {
        success: false,
        error: error.message,
        timestamp: new Date().toISOString(),
      },
      { status: 500 },
    )
  }
}
