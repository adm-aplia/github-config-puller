import { type NextRequest, NextResponse } from "next/server"
import { BillingService } from "@/lib/services/billing-service"

export async function GET(request: NextRequest, { params }: { params: { email: string } }) {
  try {
    const email = decodeURIComponent(params.email)

    if (!email) {
      return NextResponse.json({ success: false, error: "Email não fornecido" }, { status: 400 })
    }

    console.log("🔍 Buscando cliente:", email)

    const cliente = await BillingService.getClienteByEmail(email)

    if (!cliente) {
      return NextResponse.json({ success: false, message: "Cliente não encontrado" }, { status: 404 })
    }

    // Buscar cobranças do cliente
    const cobrancas = await BillingService.getCobrancasByCliente(cliente.id)

    return NextResponse.json({
      success: true,
      data: {
        cliente,
        cobrancas,
      },
    })
  } catch (error: any) {
    console.error("❌ Erro ao buscar cliente:", error)

    return NextResponse.json(
      {
        success: false,
        error: error.message || "Erro interno do servidor",
      },
      { status: 500 },
    )
  }
}
