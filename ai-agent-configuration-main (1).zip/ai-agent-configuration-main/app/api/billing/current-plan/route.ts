import { type NextRequest, NextResponse } from "next/server"
import { getSupabaseServerClient } from "@/lib/supabase/supabase-server"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get("userId")

    if (!userId) {
      return NextResponse.json({ success: false, error: "User ID é obrigatório" }, { status: 400 })
    }

    const supabase = await getSupabaseServerClient()

    // Buscar cliente e plano atual
    const { data: cliente, error } = await supabase
      .from("clientes")
      .select(`
        *,
        planos (*)
      `)
      .eq("user_id", userId)
      .eq("is_active", true)
      .single()

    if (error) {
      if (error.code === "PGRST116") {
        return NextResponse.json({
          success: true,
          data: {
            hasActivePlan: false,
            currentPlan: null,
          },
        })
      }
      throw error
    }

    return NextResponse.json({
      success: true,
      data: {
        hasActivePlan: true,
        currentPlan: cliente.plano,
        planDetails: cliente.planos,
        cliente: {
          id: cliente.id,
          nome: cliente.nome,
          email: cliente.email,
          status: cliente.status,
          data_contratacao: cliente.data_contratacao,
        },
      },
    })
  } catch (error: any) {
    console.error("Erro ao buscar plano atual:", error)

    return NextResponse.json(
      {
        success: false,
        error: error.message || "Erro interno do servidor",
      },
      { status: 500 },
    )
  }
}
