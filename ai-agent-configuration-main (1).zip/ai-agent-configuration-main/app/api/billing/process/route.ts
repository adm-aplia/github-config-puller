import { type NextRequest, NextResponse } from "next/server"
import { BillingService } from "@/lib/services/billing-service"

export async function POST(request: NextRequest) {
  console.log("🚀 API de cobrança chamada")

  try {
    const body = await request.json()
    console.log("📝 Dados recebidos:", { ...body, documento: "***", telefone: "***" })

    // Validar dados obrigatórios
    const { nome, email, telefone, documento, plano, user_id } = body

    if (!nome || !email || !telefone || !documento || !plano) {
      console.log("❌ Dados obrigatórios faltando")
      return NextResponse.json(
        {
          success: false,
          error: "Dados obrigatórios não fornecidos. Necessário: nome, email, telefone, documento, plano",
        },
        { status: 400 },
      )
    }

    // Validar user_id (opcional, mas recomendado)
    if (!user_id) {
      console.warn("⚠️ Aviso: user_id não fornecido. A ativação automática da conta não será possível.")
    }

    // Validar plano
    const planosValidos = ["Básico", "Profissional", "Empresarial"]
    if (!planosValidos.includes(plano)) {
      console.log("❌ Plano inválido:", plano)
      return NextResponse.json(
        {
          success: false,
          error: `Plano inválido. Planos válidos: ${planosValidos.join(", ")}`,
        },
        { status: 400 },
      )
    }

    console.log("✅ Validações passaram, iniciando processo de cobrança")

    // Processar cadastro e cobrança
    const result = await BillingService.processBilling({
      nome,
      email,
      telefone,
      documento,
      plano,
      user_id,
      endereco: body.endereco || "",
      cidade: body.cidade || "",
      estado: body.estado || "",
      cep: body.cep || "",
      observacoes: body.observacoes || "",
    })

    console.log("📊 Resultado do processamento:", { success: result.success })

    if (result.success) {
      console.log("✅ Processo concluído com sucesso!")

      return NextResponse.json({
        success: true,
        message: "Cadastro e cobrança processados com sucesso",
        data: {
          cliente: {
            id: result.cliente.id,
            nome: result.cliente.nome,
            email: result.cliente.email,
            plano: result.cliente.plano,
            status: result.cliente.status,
            user_id: result.cliente.user_id,
          },
          cobranca: {
            id: result.cobranca.id,
            valor: result.cobranca.valor,
            status: result.status,
            descricao: result.descricao,
            dueDate: result.dueDate,
            paymentLink: result.paymentLink,
          },
        },
      })
    } else {
      console.log("❌ Processo falhou:", result.error)

      return NextResponse.json(
        {
          success: false,
          error: result.error,
          message: "Falha no processo de cadastro e cobrança",
        },
        { status: 500 },
      )
    }
  } catch (error: any) {
    console.error("❌ Erro crítico na API de cobrança:", error)
    console.error("Stack trace:", error.stack)

    // Retornar erro mais detalhado
    return NextResponse.json(
      {
        success: false,
        error: error.message || "Erro interno do servidor",
        message: "Erro inesperado no processo de cobrança",
        details: process.env.NODE_ENV === "development" ? error.stack : undefined,
      },
      { status: 500 },
    )
  }
}
