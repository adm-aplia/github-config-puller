import { NextResponse } from "next/server"
import { getSupabaseServerClient } from "@/lib/supabase"

export async function POST(request: Request) {
  try {
    const { email, password, name } = await request.json()

    if (!email || !password || !name) {
      return NextResponse.json({ error: "Email, senha e nome são obrigatórios" }, { status: 400 })
    }

    const supabase = getSupabaseServerClient()

    // Verificar se o usuário já existe
    const { data: existingUsers } = await supabase.from("profiles").select("id").eq("email", email).limit(1)

    if (existingUsers && existingUsers.length > 0) {
      return NextResponse.json({ error: "Usuário já existe" }, { status: 400 })
    }

    // Criar o usuário
    const { data: authData, error: authError } = await supabase.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
      user_metadata: { name },
    })

    if (authError) {
      return NextResponse.json({ error: authError.message }, { status: 500 })
    }

    // Criar o perfil do usuário
    if (authData.user) {
      const { error: profileError } = await supabase.from("profiles").insert({
        id: authData.user.id,
        name,
        email,
      })

      if (profileError) {
        return NextResponse.json({ error: profileError.message, user: authData.user }, { status: 500 })
      }
    }

    return NextResponse.json({ success: true, user: authData.user })
  } catch (error: any) {
    return NextResponse.json({ error: error.message || "Erro desconhecido" }, { status: 500 })
  }
}
