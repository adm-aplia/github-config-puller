import { type NextRequest, NextResponse } from "next/server"

export const GET = async (request: NextRequest): Promise<NextResponse> => {
  const url = new URL(request.url)
  const code = url.searchParams.get("code")
  const state = url.searchParams.get("state")
  const error = url.searchParams.get("error")

  console.log("Google callback received:", { code: code?.substring(0, 20) + "...", state, error })

  if (error) {
    console.error("Google OAuth error:", error)
    return NextResponse.redirect(new URL(`/dashboard/integracoes?auth_error=${encodeURIComponent(error)}`, request.url))
  }

  if (!code) {
    console.error("No authorization code received")
    return NextResponse.redirect(new URL("/dashboard/integracoes?auth_error=no_code", request.url))
  }

  try {
    let userId = null
    if (state) {
      try {
        const stateObj = JSON.parse(decodeURIComponent(state))
        userId = stateObj.user_id
        console.log("Extracted user_id from state:", userId)
      } catch (err) {
        console.error("Error parsing state:", err)
      }
    }

    const redirectUri = `${process.env.NEXT_PUBLIC_APP_URL}/auth/google/callback`

    // Send the REAL code to webhook
    const webhookUrl = "https://dinastia-n8n-webhook.qhw5xb.easypanel.host/webhook/google-calendar-event-creator"

    const webhookPayload = {
      type: "google_auth_code",
      code: code, // This is the REAL code from Google
      user_id: userId,
      redirect_uri: redirectUri,
      timestamp: new Date().toISOString(),
      state: state,
      full_url: request.url,
    }

    console.log("Sending to webhook:", { ...webhookPayload, code: code.substring(0, 20) + "..." })

    const response = await fetch(webhookUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(webhookPayload),
    })

    if (!response.ok) {
      console.error("Failed to send data to webhook:", response.status, response.statusText)
      const errorText = await response.text()
      console.error("Webhook error response:", errorText)
      return NextResponse.redirect(new URL("/dashboard/integracoes?auth_error=webhook_failed", request.url))
    }

    const webhookResult = await response.json()
    console.log("Webhook response:", webhookResult)

    return NextResponse.redirect(new URL("/dashboard/integracoes?auth_success=true", request.url))
  } catch (error) {
    console.error("Error in Google callback:", error)
    return NextResponse.redirect(
      new URL(`/dashboard/integracoes?auth_error=${encodeURIComponent("callback_failed")}`, request.url),
    )
  }
}
