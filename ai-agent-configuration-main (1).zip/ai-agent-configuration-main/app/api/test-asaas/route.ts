import { type NextRequest, NextResponse } from "next/server"

const ASAAS_API_URL = "https://api.asaas.com/v3"
const ASAAS_ACCESS_TOKEN =
  "$aact_prod_000MzkwODA2MWY2OGM3MWRlMDU2NWM3MzJlNzZmNGZhZGY6OmI3MDE2NTdlLTRjNjAtNDNhZS04NDVjLWQ2NDVmZjVlOGQyZTo6JGFhY2hfZDc1MGU2NTQtOTUwNS00OGI2LWJlMWUtNTJkZWRkMzFlZmM4"

export async function GET() {
  console.log("🔗 Testando conectividade com Asaas...")

  try {
    const response = await fetch(`${ASAAS_API_URL}/customers?limit=1`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        access_token: ASAAS_ACCESS_TOKEN,
        "User-Agent": "Aplia/1.0",
      },
    })

    console.log("📡 Status da resposta:", response.status, response.statusText)
    console.log("📡 Headers da resposta:", Object.fromEntries(response.headers.entries()))

    const responseText = await response.text()
    console.log("📡 Texto da resposta:", responseText)

    if (!response.ok) {
      return NextResponse.json(
        {
          success: false,
          error: `HTTP ${response.status}: ${response.statusText}`,
          response: responseText,
        },
        { status: response.status },
      )
    }

    let data
    try {
      data = JSON.parse(responseText)
    } catch (parseError) {
      return NextResponse.json(
        {
          success: false,
          error: "Resposta não é JSON válido",
          response: responseText,
        },
        { status: 500 },
      )
    }

    return NextResponse.json({
      success: true,
      message: "Conectividade OK",
      data: data,
    })
  } catch (error: any) {
    console.error("❌ Erro de conectividade:", error)

    return NextResponse.json(
      {
        success: false,
        error: error.message,
        type: error.name,
      },
      { status: 500 },
    )
  }
}

export async function POST(request: NextRequest) {
  console.log("🏢 Testando criação de cliente...")

  try {
    const body = await request.json()
    console.log("📝 Dados recebidos:", body)

    const response = await fetch(`${ASAAS_API_URL}/customers`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        access_token: ASAAS_ACCESS_TOKEN,
        "User-Agent": "Aplia/1.0",
      },
      body: JSON.stringify(body),
    })

    console.log("📡 Status da resposta:", response.status, response.statusText)
    console.log("📡 Headers da resposta:", Object.fromEntries(response.headers.entries()))

    const responseText = await response.text()
    console.log("📡 Texto da resposta:", responseText)

    if (!response.ok) {
      return NextResponse.json(
        {
          success: false,
          error: `HTTP ${response.status}: ${response.statusText}`,
          response: responseText,
        },
        { status: response.status },
      )
    }

    let data
    try {
      data = JSON.parse(responseText)
    } catch (parseError) {
      return NextResponse.json(
        {
          success: false,
          error: "Resposta não é JSON válido",
          response: responseText,
        },
        { status: 500 },
      )
    }

    return NextResponse.json({
      success: true,
      message: "Cliente criado com sucesso",
      data: data,
    })
  } catch (error: any) {
    console.error("❌ Erro ao criar cliente:", error)

    return NextResponse.json(
      {
        success: false,
        error: error.message,
        type: error.name,
      },
      { status: 500 },
    )
  }
}
