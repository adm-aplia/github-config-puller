import { type NextRequest, NextResponse } from "next/server"
import { PermissionsService } from "@/lib/services/permissions-service"
import { getSupabaseServerClient } from "@/lib/supabase-singleton"

export async function GET(request: NextRequest) {
  try {
    // Extrair token do header Authorization
    const authHeader = request.headers.get("authorization")
    if (!authHeader?.startsWith("Bearer ")) {
      return NextResponse.json({ error: "Token de autorização necessário" }, { status: 401 })
    }

    const token = authHeader.substring(7)
    const supabase = await getSupabaseServerClient()

    // Verificar token e obter usuário
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser(token)

    if (authError || !user) {
      return NextResponse.json({ error: "Token inválido" }, { status: 401 })
    }

    // Obter limites e uso do usuário
    const data = await PermissionsService.getUserLimitsAndUsage(user.id)

    if (!data) {
      return NextResponse.json({ error: "Usuário não possui assinatura ativa" }, { status: 403 })
    }

    return NextResponse.json({
      success: true,
      data,
    })
  } catch (error) {
    console.error("Erro ao verificar permissões:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}
