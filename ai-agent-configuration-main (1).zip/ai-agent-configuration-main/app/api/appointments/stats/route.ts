import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

// Usar Service Role para acesso direto ao banco
const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get("userId")
    const startDate = searchParams.get("startDate")
    const endDate = searchParams.get("endDate")

    console.log("📊 Buscando estatísticas de agendamentos:", { userId, startDate, endDate })

    if (!userId) {
      return NextResponse.json({ error: "userId é obrigatório" }, { status: 400 })
    }

    // Query base para agendamentos do usuário
    let query = supabase.from("appointments").select("id, status, appointment_date, created_at").eq("user_id", userId)

    // Aplicar filtros de data se fornecidos
    if (startDate) {
      query = query.gte("appointment_date", startDate)
    }
    if (endDate) {
      query = query.lte("appointment_date", endDate)
    }

    const { data: appointments, error } = await query

    if (error) {
      console.error("❌ Erro ao buscar agendamentos:", error)
      return NextResponse.json({ error: "Erro ao buscar agendamentos" }, { status: 500 })
    }

    console.log(`📋 Encontrados ${appointments?.length || 0} agendamentos`)

    // Calcular estatísticas por status
    const stats = {
      total: appointments?.length || 0,
      scheduled: appointments?.filter((a) => a.status === "scheduled").length || 0,
      confirmed: appointments?.filter((a) => a.status === "confirmed").length || 0,
      completed: appointments?.filter((a) => a.status === "completed").length || 0,
      cancelled: appointments?.filter((a) => a.status === "cancelled").length || 0,
      "no-show": appointments?.filter((a) => a.status === "no-show").length || 0,
      rescheduled: appointments?.filter((a) => a.status === "rescheduled").length || 0,
    }

    console.log("📈 Estatísticas calculadas:", stats)

    return NextResponse.json(stats)
  } catch (error) {
    console.error("❌ Erro interno na API de estatísticas:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json()
    const { appointmentId, status, userId } = body

    console.log("🔄 Atualizando status do agendamento:", { appointmentId, status, userId })

    if (!appointmentId || !status || !userId) {
      return NextResponse.json({ error: "appointmentId, status e userId são obrigatórios" }, { status: 400 })
    }

    // Validar status
    const validStatuses = ["scheduled", "confirmed", "completed", "cancelled", "no-show", "rescheduled"]
    if (!validStatuses.includes(status)) {
      return NextResponse.json({ error: `Status inválido. Use: ${validStatuses.join(", ")}` }, { status: 400 })
    }

    // Atualizar o agendamento
    const { data, error } = await supabase
      .from("appointments")
      .update({
        status,
        updated_at: new Date().toISOString(),
      })
      .eq("id", appointmentId)
      .eq("user_id", userId) // Garantir que o usuário só atualize seus próprios agendamentos
      .select()
      .single()

    if (error) {
      console.error("❌ Erro ao atualizar agendamento:", error)
      return NextResponse.json({ error: "Erro ao atualizar agendamento" }, { status: 500 })
    }

    console.log("✅ Agendamento atualizado com sucesso:", data)

    return NextResponse.json({
      success: true,
      appointment: data,
      message: `Status alterado para ${status}`,
    })
  } catch (error) {
    console.error("❌ Erro interno na atualização:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}
