import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

export async function GET(request: NextRequest) {
  try {
    console.log("🧪 [TEST API] Iniciando teste completo de agendamentos...")

    const { searchParams } = new URL(request.url)
    const userId = searchParams.get("userId")

    if (!userId) {
      return NextResponse.json({ error: "User ID é obrigatório para teste" }, { status: 400 })
    }

    // 1. Verificar estrutura da tabela
    console.log("📋 [TEST API] Verificando estrutura da tabela...")
    const { data: tableInfo, error: tableError } = await supabase.from("appointments").select("*").limit(1)

    if (tableError) {
      console.error("❌ [TEST API] Erro ao verificar tabela:", tableError)
      return NextResponse.json(
        {
          error: "Erro ao verificar tabela appointments",
          details: tableError.message,
        },
        { status: 500 },
      )
    }

    // 2. Buscar todos os agendamentos do usuário
    console.log("🔍 [TEST API] Buscando todos os agendamentos do usuário...")
    const { data: allAppointments, error: allError } = await supabase
      .from("appointments")
      .select("*")
      .eq("user_id", userId)
      .order("appointment_date", { ascending: false })

    if (allError) {
      console.error("❌ [TEST API] Erro ao buscar agendamentos:", allError)
      return NextResponse.json(
        {
          error: "Erro ao buscar agendamentos",
          details: allError.message,
        },
        { status: 500 },
      )
    }

    console.log(`📊 [TEST API] Total de agendamentos encontrados: ${allAppointments?.length || 0}`)

    // 3. Calcular estatísticas detalhadas
    const stats = {
      total: allAppointments?.length || 0,
      scheduled: allAppointments?.filter((apt) => apt.status === "scheduled").length || 0,
      confirmed: allAppointments?.filter((apt) => apt.status === "confirmed").length || 0,
      completed: allAppointments?.filter((apt) => apt.status === "completed").length || 0,
      cancelled: allAppointments?.filter((apt) => apt.status === "cancelled").length || 0,
      noShow: allAppointments?.filter((apt) => apt.status === "no-show").length || 0,
    }

    // 4. Agrupar por status
    const statusBreakdown =
      allAppointments?.reduce((acc: any, apt) => {
        acc[apt.status] = (acc[apt.status] || 0) + 1
        return acc
      }, {}) || {}

    // 5. Agrupar por mês
    const monthlyBreakdown =
      allAppointments?.reduce((acc: any, apt) => {
        const month = apt.appointment_date.substring(0, 7) // YYYY-MM
        acc[month] = (acc[month] || 0) + 1
        return acc
      }, {}) || {}

    // 6. Últimos 5 agendamentos
    const recentAppointments =
      allAppointments?.slice(0, 5).map((apt) => ({
        id: apt.id,
        patient_name: apt.patient_name,
        appointment_date: apt.appointment_date,
        appointment_time: apt.appointment_time,
        status: apt.status,
        created_at: apt.created_at,
      })) || []

    // 7. Teste de filtro por data (mês atual)
    const currentMonth = new Date().toISOString().substring(0, 7) // YYYY-MM
    const currentMonthStart = `${currentMonth}-01`
    const currentMonthEnd = `${currentMonth}-31`

    const { data: currentMonthAppointments, error: monthError } = await supabase
      .from("appointments")
      .select("*")
      .eq("user_id", userId)
      .gte("appointment_date", currentMonthStart)
      .lte("appointment_date", currentMonthEnd)

    const currentMonthStats = {
      total: currentMonthAppointments?.length || 0,
      scheduled: currentMonthAppointments?.filter((apt) => apt.status === "scheduled").length || 0,
      confirmed: currentMonthAppointments?.filter((apt) => apt.status === "confirmed").length || 0,
      completed: currentMonthAppointments?.filter((apt) => apt.status === "completed").length || 0,
      cancelled: currentMonthAppointments?.filter((apt) => apt.status === "cancelled").length || 0,
      noShow: currentMonthAppointments?.filter((apt) => apt.status === "no-show").length || 0,
    }

    console.log("✅ [TEST API] Teste completo finalizado")

    return NextResponse.json({
      success: true,
      message: "Teste completo de agendamentos executado com sucesso",
      data: {
        // Estatísticas gerais
        generalStats: stats,

        // Breakdown detalhado
        statusBreakdown,
        monthlyBreakdown,

        // Agendamentos recentes
        recentAppointments,

        // Estatísticas do mês atual
        currentMonth: {
          period: `${currentMonth} (${currentMonthStart} a ${currentMonthEnd})`,
          stats: currentMonthStats,
          appointments:
            currentMonthAppointments?.map((apt) => ({
              patient_name: apt.patient_name,
              date: apt.appointment_date,
              time: apt.appointment_time,
              status: apt.status,
            })) || [],
        },

        // Informações de debug
        debug: {
          userId,
          totalAppointmentsFound: allAppointments?.length || 0,
          tableAccessible: !tableError,
          queryErrors: {
            allAppointments: allError?.message || null,
            currentMonth: monthError?.message || null,
          },
        },
      },
    })
  } catch (error: any) {
    console.error("❌ [TEST API] Erro inesperado:", error)
    return NextResponse.json(
      {
        error: "Erro interno do servidor no teste",
        details: error.message,
      },
      { status: 500 },
    )
  }
}
