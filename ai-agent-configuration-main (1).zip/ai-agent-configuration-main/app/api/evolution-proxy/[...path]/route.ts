import { type NextRequest, NextResponse } from "next/server"

const EVOLUTION_API_URL = "https://aplia-evolution.kopfcf.easypanel.host"
const EVOLUTION_API_KEY = "F9CDB41C7A534C3B58A77B219BA6F"

export async function GET(request: NextRequest, { params }: { params: { path: string[] } }) {
  try {
    const path = params.path.join("/")
    const url = new URL(request.url)
    const queryString = url.search

    const apiUrl = `${EVOLUTION_API_URL}/${path}${queryString}`

    console.log("🔍 [EVOLUTION DEBUG] GET Request:")
    console.log("- Original URL:", request.url)
    console.log("- API URL:", apiUrl)
    console.log("- API Key:", EVOLUTION_API_KEY.substring(0, 8) + "...")

    const response = await fetch(apiUrl, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        apikey: EVOLUTION_API_KEY,
      },
      cache: "no-store",
    })

    const contentType = response.headers.get("content-type")

    console.log("📡 [EVOLUTION DEBUG] Response:")
    console.log("- Status:", response.status)
    console.log("- Content-Type:", contentType)

    if (!response.ok) {
      console.error(`❌ API returned error: ${response.status} ${response.statusText}`)
      const errorText = await response.text()
      console.error("Error response:", errorText.substring(0, 200))

      return NextResponse.json(
        { error: `API Error: ${response.status}`, details: errorText.substring(0, 200) },
        { status: response.status },
      )
    }

    // Verificar se a resposta é JSON
    if (contentType && contentType.includes("application/json")) {
      const data = await response.json()
      console.log(
        "✅ [EVOLUTION DEBUG] Success - Data received:",
        Array.isArray(data) ? `Array with ${data.length} items` : typeof data,
      )
      return NextResponse.json(data)
    } else {
      // Se não for JSON, retornar erro
      const text = await response.text()
      console.error("❌ Non-JSON response:", text.substring(0, 200))

      return NextResponse.json(
        { error: "Invalid response format", details: "API returned non-JSON response" },
        { status: 500 },
      )
    }
  } catch (error) {
    console.error("❌ [EVOLUTION DEBUG] Proxy error:", error)
    return NextResponse.json({ error: "Proxy error", details: error.message }, { status: 500 })
  }
}

export async function POST(request: NextRequest, { params }: { params: { path: string[] } }) {
  try {
    const path = params.path.join("/")
    const body = await request.json()

    const apiUrl = `${EVOLUTION_API_URL}/${path}`

    console.log("🔍 [EVOLUTION DEBUG] POST Request:")
    console.log("- API URL:", apiUrl)
    console.log("- Body:", JSON.stringify(body, null, 2))
    console.log("- API Key:", EVOLUTION_API_KEY.substring(0, 8) + "...")

    const response = await fetch(apiUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        apikey: EVOLUTION_API_KEY,
      },
      body: JSON.stringify(body),
    })

    const contentType = response.headers.get("content-type")

    console.log("📡 [EVOLUTION DEBUG] Response:")
    console.log("- Status:", response.status)
    console.log("- Content-Type:", contentType)

    if (!response.ok) {
      console.error(`❌ API returned error: ${response.status} ${response.statusText}`)
      const errorText = await response.text()
      console.error("Error response:", errorText.substring(0, 200))

      return NextResponse.json(
        { error: `API Error: ${response.status}`, details: errorText.substring(0, 200) },
        { status: response.status },
      )
    }

    // Verificar se a resposta é JSON
    if (contentType && contentType.includes("application/json")) {
      const data = await response.json()
      console.log(
        "✅ [EVOLUTION DEBUG] Success - Data received:",
        Array.isArray(data) ? `Array with ${data.length} items` : typeof data,
      )
      return NextResponse.json(data)
    } else {
      // Se não for JSON, retornar erro
      const text = await response.text()
      console.error("❌ Non-JSON response:", text.substring(0, 200))

      return NextResponse.json(
        { error: "Invalid response format", details: "API returned non-JSON response" },
        { status: 500 },
      )
    }
  } catch (error) {
    console.error("❌ [EVOLUTION DEBUG] Proxy error:", error)
    return NextResponse.json({ error: "Proxy error", details: error.message }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { path: string[] } }) {
  try {
    const path = params.path.join("/")
    const url = new URL(request.url)
    const queryString = url.search

    const apiUrl = `${EVOLUTION_API_URL}/${path}${queryString}`

    console.log("🔍 [EVOLUTION DEBUG] DELETE Request:")
    console.log("- API URL:", apiUrl)
    console.log("- API Key:", EVOLUTION_API_KEY.substring(0, 8) + "...")

    const response = await fetch(apiUrl, {
      method: "DELETE",
      headers: {
        "Content-Type": "application/json",
        apikey: EVOLUTION_API_KEY,
      },
    })

    const contentType = response.headers.get("content-type")

    console.log("📡 [EVOLUTION DEBUG] Response:")
    console.log("- Status:", response.status)
    console.log("- Content-Type:", contentType)

    if (!response.ok) {
      console.error(`❌ API returned error: ${response.status} ${response.statusText}`)
      const errorText = await response.text()
      console.error("Error response:", errorText.substring(0, 200))

      return NextResponse.json(
        { error: `API Error: ${response.status}`, details: errorText.substring(0, 200) },
        { status: response.status },
      )
    }

    // Verificar se a resposta é JSON
    if (contentType && contentType.includes("application/json")) {
      const data = await response.json()
      console.log(
        "✅ [EVOLUTION DEBUG] Success - Data received:",
        Array.isArray(data) ? `Array with ${data.length} items` : typeof data,
      )
      return NextResponse.json(data)
    } else {
      // Se não for JSON, retornar erro
      const text = await response.text()
      console.error("❌ Non-JSON response:", text.substring(0, 200))

      return NextResponse.json(
        { error: "Invalid response format", details: "API returned non-JSON response" },
        { status: 500 },
      )
    }
  } catch (error) {
    console.error("❌ [EVOLUTION DEBUG] Proxy error:", error)
    return NextResponse.json({ error: "Proxy error", details: error.message }, { status: 500 })
  }
}
