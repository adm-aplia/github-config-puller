import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get("user_id")

    if (!userId) {
      return NextResponse.json({ success: false, error: "user_id é obrigatório" }, { status: 400 })
    }

    console.log("🔍 Buscando conexões WhatsApp para usuário:", userId)

    // Buscar todas as instâncias WhatsApp do usuário
    const { data: connections, error } = await supabase
      .from("whatsapp_instances")
      .select("*")
      .eq("user_id", userId)
      .order("created_at", { ascending: false })

    if (error) {
      console.error("❌ Erro ao buscar conexões WhatsApp:", error)
      return NextResponse.json({ success: false, error: "Erro ao buscar conexões WhatsApp" }, { status: 500 })
    }

    console.log("📱 Conexões encontradas:", connections?.length || 0)

    // Mapear conexões para o formato esperado
    const mappedConnections = (connections || []).map((conn) => ({
      id: conn.id,
      instance_name: conn.instance_name,
      profile_name: conn.profile_name,
      status: conn.status,
      professional_profile_id: conn.professional_profile_id,
      phone_number: conn.phone_number,
      profile_picture_url: conn.profile_picture_url,
      last_connected_at: conn.last_connected_at,
      created_at: conn.created_at,
      updated_at: conn.updated_at,
    }))

    // Calcular estatísticas
    const stats = {
      total: mappedConnections.length,
      connected: mappedConnections.filter((conn) => conn.status === "connected").length,
      connecting: mappedConnections.filter((conn) => conn.status === "connecting").length,
      disconnected: mappedConnections.filter((conn) => conn.status === "disconnected").length,
    }

    return NextResponse.json({
      success: true,
      connections: mappedConnections,
      stats,
    })
  } catch (error) {
    console.error("❌ Erro interno na API WhatsApp status:", error)
    return NextResponse.json({ success: false, error: "Erro interno do servidor" }, { status: 500 })
  }
}
