import { type NextRequest, NextResponse } from "next/server"
import { getSupabaseServerClient } from "@/lib/supabase-singleton"
import { WhatsAppService } from "@/lib/services/whatsapp-service"
import { PermissionsService } from "@/lib/services/permissions-service"

export async function POST(request: NextRequest, { params }: { params: { action: string } }) {
  try {
    const supabase = await getSupabaseServerClient()

    // Verificar autenticação
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError || !user) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
    }

    const { action } = params
    const body = await request.json()

    // VERIFICAR PLANO ATIVO OBRIGATÓRIO
    const { data: cliente } = await supabase
      .from("clientes")
      .select("*, planos(*)")
      .eq("user_id", user.id)
      .eq("is_active", true)
      .eq("status", "ativo")
      .single()

    if (!cliente) {
      return NextResponse.json(
        {
          error: "Plano ativo necessário",
          code: "NO_ACTIVE_PLAN",
          message: "Você precisa de um plano ativo para usar esta funcionalidade",
          redirect: "/dashboard/planos",
        },
        { status: 403 },
      )
    }

    switch (action) {
      case "create":
        // Verificar limite de WhatsApp
        const canCreate = await PermissionsService.canCreateWhatsAppInstance(user.id)

        if (!canCreate.allowed) {
          return NextResponse.json(
            {
              error: canCreate.reason,
              code: "LIMIT_EXCEEDED",
              current_usage: canCreate.current_usage,
              limit: canCreate.limit,
              message: `Limite atingido: ${canCreate.current_usage}/${canCreate.limit} instâncias WhatsApp`,
            },
            { status: 403 },
          )
        }

        const { instanceName } = body
        if (!instanceName) {
          return NextResponse.json({ error: "Nome da instância é obrigatório" }, { status: 400 })
        }

        const instance = await WhatsAppService.createInstance(instanceName)
        await PermissionsService.incrementUsage(user.id, "whatsapp")

        return NextResponse.json(instance)

      case "sync":
        const instances = await WhatsAppService.syncInstances()
        return NextResponse.json(instances)

      case "delete":
        const { instanceId } = body
        if (!instanceId) {
          return NextResponse.json({ error: "ID da instância é obrigatório" }, { status: 400 })
        }

        await WhatsAppService.deleteInstance(instanceId)
        await PermissionsService.decrementUsage(user.id, "whatsapp")

        return NextResponse.json({ success: true })

      default:
        return NextResponse.json({ error: "Ação não reconhecida" }, { status: 400 })
    }
  } catch (error: any) {
    console.error(`Erro na API WhatsApp [${params.action}]:`, error)
    return NextResponse.json({ error: error.message || "Erro interno" }, { status: 500 })
  }
}

export async function GET(request: NextRequest, { params }: { params: { action: string } }) {
  try {
    const supabase = await getSupabaseServerClient()

    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError || !user) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
    }

    const { action } = params

    switch (action) {
      case "list":
        const instances = await WhatsAppService.getUserInstances()
        return NextResponse.json(instances)

      case "stats":
        const stats = await WhatsAppService.getInstanceStats()
        return NextResponse.json(stats)

      default:
        return NextResponse.json({ error: "Ação não reconhecida" }, { status: 400 })
    }
  } catch (error: any) {
    console.error(`Erro na API WhatsApp GET [${params.action}]:`, error)
    return NextResponse.json({ error: error.message || "Erro interno" }, { status: 500 })
  }
}
