"use client"

import { useEffect, useState } from "react"
import { useTheme } from "next-themes"
import { Moon, Sun, Loader2 } from "lucide-react" // Adicionado Loader2

import { Button } from "@/components/ui/button"
import LoginForm from "@/components/login-form" // Importado o novo componente
import { useAuth } from "@/components/auth-provider" // Importado useAuth

export default function HomePage() {
  // Renomeado para HomePage para clareza
  const [mounted, setMounted] = useState(false)
  const { theme, setTheme } = useTheme()
  const auth = useAuth() // Obtendo o contexto de autenticação

  useEffect(() => {
    setMounted(true)
  }, [])

  // Mostrar um loader global para a página enquanto o auth não está inicializado
  // Isso é diferente do loader dentro do LoginForm, que é específico para o formulário.
  if (!auth.isInitialized && mounted) {
    return (
      <div className="min-h-screen flex flex-col justify-center items-center bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
        <Loader2 className="h-12 w-12 animate-spin text-blue-600 mb-6" />
        <p className="text-lg text-gray-700 dark:text-gray-300">Carregando...</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col justify-center py-12 sm:px-6 lg:px-8 bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 relative">
      {mounted && (
        <div className="absolute top-4 right-4">
          <Button
            variant="outline"
            size="icon"
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border-gray-200 dark:border-gray-700 hover:bg-white dark:hover:bg-gray-800"
            aria-label="Alternar tema"
          >
            {theme === "dark" ? (
              <Sun className="h-4 w-4 text-yellow-500" />
            ) : (
              <Moon className="h-4 w-4 text-gray-700" />
            )}
          </Button>
        </div>
      )}

      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="flex justify-center mb-8">
          <img
            src={
              theme === "dark"
                ? "/Aplia_logotipo_variação cor 2 fundo transparente.png"
                : "/LOGO FUNDO TRANSPARENTE.png"
            }
            alt="Aplia"
            className="h-12 w-auto"
          />
        </div>
      </div>

      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white dark:bg-gray-800 py-8 px-6 shadow-xl sm:rounded-2xl sm:px-10 border border-gray-200 dark:border-gray-700">
          <div className="mb-6 text-center">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Acesse sua conta</h2>
            <p className="text-sm text-gray-600 dark:text-gray-400">Entre com suas credenciais</p>
          </div>
          <LoginForm /> {/* Usando o novo componente LoginForm */}
        </div>
      </div>
    </div>
  )
}
