"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { Separator } from "@/components/ui/separator"
import { useToast } from "@/hooks/use-toast"
import { Loader2, Eye, EyeOff, Shield, CheckCircle } from "lucide-react"
import { useAuth } from "@/hooks/use-auth"
import { getSupabaseInstance } from "@/lib/supabase-singleton"
import { AuthDebug } from "@/components/debug/auth-debug"

// Interface para o perfil do usuário
interface UserProfile {
  id: string
  name: string | null
  first_name: string | null
  last_name: string | null
  email: string | null
  phone: string | null
  specialty: string | null
  notifications_email: boolean
  notifications_push: boolean
  notifications_sms: boolean
  notifications_appointments: boolean
  notifications_messages: boolean
}

// Interface para dados de troca de senha
interface PasswordChangeData {
  currentPassword: string
  newPassword: string
  confirmPassword: string
}

export default function ConfiguracaoPage() {
  const [isLoading, setIsLoading] = useState(false)
  const [isLoadingProfile, setIsLoadingProfile] = useState(true)
  const [isChangingPassword, setIsChangingPassword] = useState(false)
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null)
  const [activeTab, setActiveTab] = useState("perfil")
  const [showPasswords, setShowPasswords] = useState({
    current: false,
    new: false,
    confirm: false,
  })
  const [passwordData, setPasswordData] = useState<PasswordChangeData>({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  })
  const { toast } = useToast()
  const { user, isLoading: authLoading } = useAuth()
  const profileLoaded = useRef(false)

  // Carregar dados do perfil do usuário - SIMPLIFICADO
  const loadUserProfile = async () => {
    if (!user || profileLoaded.current) return

    try {
      setIsLoadingProfile(true)
      const supabase = getSupabaseInstance()

      if (!supabase) {
        throw new Error("Cliente Supabase não inicializado")
      }

      // Busca SIMPLES - sem RLS, deve funcionar agora
      const { data: profiles, error } = await supabase
        .from("profiles")
        .select("*")
        .or(`id.eq.${user.id},email.eq.${user.email}`)

      if (error) {
        console.error("❌ Erro na busca:", error)
        toast({
          variant: "destructive",
          title: "Erro ao carregar perfil",
          description: `Erro: ${error.message}`,
        })
        return
      }

      if (!profiles || profiles.length === 0) {
        toast({
          variant: "destructive",
          title: "Perfil não encontrado",
          description: "Nenhum perfil foi encontrado para este usuário.",
        })
        return
      }

      // Usar o primeiro perfil encontrado (ou o que tem ID correto)
      const profile = profiles.find((p) => p.id === user.id) || profiles[0]

      // Atualizar campos de nome se necessário
      if (profile.name && (!profile.first_name || !profile.last_name)) {
        const nameParts = profile.name.split(" ")
        const updates = {
          first_name: profile.first_name || nameParts[0] || "",
          last_name: profile.last_name || nameParts.slice(1).join(" ") || "",
          updated_at: new Date().toISOString(),
        }

        const { data: updatedData, error: updateError } = await supabase
          .from("profiles")
          .update(updates)
          .eq("id", profile.id)
          .select()
          .single()

        if (!updateError && updatedData) {
          setUserProfile(updatedData)
        } else {
          setUserProfile(profile)
        }
      } else {
        setUserProfile(profile)
      }

      profileLoaded.current = true
    } catch (error) {
      console.error("❌ Erro geral ao carregar perfil:", error)
      toast({
        variant: "destructive",
        title: "Erro ao carregar perfil",
        description: "Erro inesperado. Verifique o console para detalhes.",
      })
    } finally {
      setIsLoadingProfile(false)
    }
  }

  useEffect(() => {
    // Reseta o flag quando o componente é montado
    profileLoaded.current = false

    if (user && !authLoading) {
      loadUserProfile()
    }

    // Limpa o flag quando o componente é desmontado
    return () => {
      profileLoaded.current = false
    }
  }, [user, authLoading])

  useEffect(() => {
    // Verificar parâmetros de URL para erros ou sucesso de autenticação
    const urlParams = new URLSearchParams(window.location.search)
    const tab = urlParams.get("tab")

    if (tab) {
      setActiveTab(tab)
    }
  }, [])

  // Validar força da senha
  const validatePasswordStrength = (password: string) => {
    const minLength = password.length >= 8
    const hasUpperCase = /[A-Z]/.test(password)
    const hasLowerCase = /[a-z]/.test(password)
    const hasNumbers = /\d/.test(password)
    const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password)

    return {
      minLength,
      hasUpperCase,
      hasLowerCase,
      hasNumbers,
      hasSpecialChar,
      isValid: minLength && hasUpperCase && hasLowerCase && hasNumbers && hasSpecialChar,
    }
  }

  // Função para alterar senha
  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user) return

    // Validações
    if (!passwordData.currentPassword) {
      toast({
        variant: "destructive",
        title: "Senha atual obrigatória",
        description: "Por favor, informe sua senha atual.",
      })
      return
    }

    if (!passwordData.newPassword) {
      toast({
        variant: "destructive",
        title: "Nova senha obrigatória",
        description: "Por favor, informe a nova senha.",
      })
      return
    }

    if (passwordData.newPassword !== passwordData.confirmPassword) {
      toast({
        variant: "destructive",
        title: "Senhas não coincidem",
        description: "A nova senha e a confirmação devem ser iguais.",
      })
      return
    }

    const passwordValidation = validatePasswordStrength(passwordData.newPassword)
    if (!passwordValidation.isValid) {
      toast({
        variant: "destructive",
        title: "Senha muito fraca",
        description: "A senha deve ter pelo menos 8 caracteres, incluindo maiúsculas, minúsculas, números e símbolos.",
      })
      return
    }

    if (passwordData.currentPassword === passwordData.newPassword) {
      toast({
        variant: "destructive",
        title: "Senha igual à atual",
        description: "A nova senha deve ser diferente da senha atual.",
      })
      return
    }

    setIsChangingPassword(true)

    try {
      const supabase = getSupabaseInstance()

      if (!supabase) {
        throw new Error("Cliente Supabase não inicializado")
      }

      // Primeiro, verificar se a senha atual está correta
      const { error: signInError } = await supabase.auth.signInWithPassword({
        email: user.email!,
        password: passwordData.currentPassword,
      })

      if (signInError) {
        toast({
          variant: "destructive",
          title: "Senha atual incorreta",
          description: "A senha atual informada está incorreta.",
        })
        return
      }

      // Alterar a senha
      const { error: updateError } = await supabase.auth.updateUser({
        password: passwordData.newPassword,
      })

      if (updateError) {
        console.error("Erro ao alterar senha:", updateError)
        toast({
          variant: "destructive",
          title: "Erro ao alterar senha",
          description: updateError.message || "Não foi possível alterar a senha.",
        })
        return
      }

      // Limpar os campos
      setPasswordData({
        currentPassword: "",
        newPassword: "",
        confirmPassword: "",
      })

      toast({
        title: "Senha alterada com sucesso!",
        description: "Sua senha foi atualizada. Use a nova senha no próximo login.",
      })
    } catch (error) {
      console.error("Erro ao alterar senha:", error)
      toast({
        variant: "destructive",
        title: "Erro inesperado",
        description: "Ocorreu um erro inesperado ao alterar a senha.",
      })
    } finally {
      setIsChangingPassword(false)
    }
  }

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user || !userProfile) return

    setIsLoading(true)

    try {
      const supabase = getSupabaseInstance()

      if (!supabase) {
        throw new Error("Cliente Supabase não inicializado")
      }

      const formData = new FormData(e.target as HTMLFormElement)

      const updatedProfile = {
        first_name: formData.get("first_name") as string,
        last_name: formData.get("last_name") as string,
        phone: formData.get("phone") as string,
        updated_at: new Date().toISOString(),
      }

      const { data, error } = await supabase.from("profiles").update(updatedProfile).eq("id", user.id).select().single()

      if (error) {
        console.error("Erro ao salvar perfil:", error)
        throw error
      }

      setUserProfile(data)

      toast({
        title: "Configurações salvas",
        description: "Suas configurações foram atualizadas com sucesso",
      })
    } catch (error) {
      console.error("Erro ao salvar configurações:", error)
      toast({
        variant: "destructive",
        title: "Erro ao salvar",
        description: "Não foi possível salvar as configurações",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleSaveNotifications = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user || !userProfile) return

    setIsLoading(true)

    try {
      const supabase = getSupabaseInstance()

      if (!supabase) {
        throw new Error("Cliente Supabase não inicializado")
      }

      const formData = new FormData(e.target as HTMLFormElement)

      const updatedNotifications = {
        notifications_email: formData.get("notifications_email") === "on",
        notifications_push: formData.get("notifications_push") === "on",
        notifications_sms: formData.get("notifications_sms") === "on",
        notifications_appointments: formData.get("notifications_appointments") === "on",
        notifications_messages: formData.get("notifications_messages") === "on",
        updated_at: new Date().toISOString(),
      }

      const { data, error } = await supabase
        .from("profiles")
        .update(updatedNotifications)
        .eq("id", user.id)
        .select()
        .single()

      if (error) {
        console.error("Erro ao salvar notificações:", error)
        throw error
      }

      setUserProfile(data)

      toast({
        title: "Preferências salvas",
        description: "Suas preferências de notificação foram atualizadas",
      })
    } catch (error) {
      console.error("Erro ao salvar notificações:", error)
      toast({
        variant: "destructive",
        title: "Erro ao salvar",
        description: "Não foi possível salvar as preferências",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Componente para mostrar força da senha
  const PasswordStrengthIndicator = ({ password }: { password: string }) => {
    if (!password) return null

    const validation = validatePasswordStrength(password)

    return (
      <div className="mt-2 space-y-2">
        <div className="text-sm font-medium">Força da senha:</div>
        <div className="space-y-1 text-xs">
          <div className={`flex items-center gap-2 ${validation.minLength ? "text-green-600" : "text-red-600"}`}>
            {validation.minLength ? (
              <CheckCircle className="h-3 w-3" />
            ) : (
              <div className="h-3 w-3 rounded-full border border-current" />
            )}
            Pelo menos 8 caracteres
          </div>
          <div className={`flex items-center gap-2 ${validation.hasUpperCase ? "text-green-600" : "text-red-600"}`}>
            {validation.hasUpperCase ? (
              <CheckCircle className="h-3 w-3" />
            ) : (
              <div className="h-3 w-3 rounded-full border border-current" />
            )}
            Pelo menos uma letra maiúscula
          </div>
          <div className={`flex items-center gap-2 ${validation.hasLowerCase ? "text-green-600" : "text-red-600"}`}>
            {validation.hasLowerCase ? (
              <CheckCircle className="h-3 w-3" />
            ) : (
              <div className="h-3 w-3 rounded-full border border-current" />
            )}
            Pelo menos uma letra minúscula
          </div>
          <div className={`flex items-center gap-2 ${validation.hasNumbers ? "text-green-600" : "text-red-600"}`}>
            {validation.hasNumbers ? (
              <CheckCircle className="h-3 w-3" />
            ) : (
              <div className="h-3 w-3 rounded-full border border-current" />
            )}
            Pelo menos um número
          </div>
          <div className={`flex items-center gap-2 ${validation.hasSpecialChar ? "text-green-600" : "text-red-600"}`}>
            {validation.hasSpecialChar ? (
              <CheckCircle className="h-3 w-3" />
            ) : (
              <div className="h-3 w-3 rounded-full border border-current" />
            )}
            Pelo menos um símbolo (!@#$%^&*)
          </div>
        </div>
      </div>
    )
  }

  if (authLoading || isLoadingProfile) {
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-4rem)]">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Configurações</h1>
        <p className="text-muted-foreground">Gerencie suas configurações e preferências</p>
      </div>

      <Tabs
        defaultValue="perfil"
        className="space-y-4"
        value={activeTab}
        onValueChange={(value) => setActiveTab(value)}
      >
        <TabsList className="overflow-x-auto flex w-full">
          <TabsTrigger value="perfil">Perfil</TabsTrigger>
          <TabsTrigger value="notificacoes">Notificações</TabsTrigger>
          <TabsTrigger value="seguranca">Segurança</TabsTrigger>
        </TabsList>

        <TabsContent value="perfil">
          <form onSubmit={handleSaveSettings}>
            <Card>
              <CardHeader>
                <CardTitle>Informações do Perfil</CardTitle>
                <CardDescription>Atualize suas informações pessoais e configurações de perfil</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex flex-col sm:flex-row gap-4">
                  <div className="space-y-2 flex-1">
                    <Label htmlFor="first_name">Nome</Label>
                    <Input id="first_name" name="first_name" defaultValue={userProfile?.first_name || ""} />
                  </div>
                  <div className="space-y-2 flex-1">
                    <Label htmlFor="last_name">Sobrenome</Label>
                    <Input id="last_name" name="last_name" defaultValue={userProfile?.last_name || ""} />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input id="email" type="email" defaultValue={userProfile?.email || ""} disabled />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone">Número de Telefone</Label>
                  <Input id="phone" name="phone" defaultValue={userProfile?.phone || ""} />
                </div>
              </CardContent>
              <CardFooter className="flex justify-end">
                <Button type="submit" disabled={isLoading}>
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Salvando...
                    </>
                  ) : (
                    "Salvar Alterações"
                  )}
                </Button>
              </CardFooter>
            </Card>
          </form>
        </TabsContent>

        <TabsContent value="notificacoes">
          <form onSubmit={handleSaveNotifications}>
            <Card>
              <CardHeader>
                <CardTitle>Preferências de Notificação</CardTitle>
                <CardDescription>Configure como e quando deseja receber notificações</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="notifications_email">Notificações por Email</Label>
                    <p className="text-sm text-muted-foreground">Receber notificações por email</p>
                  </div>
                  <Switch
                    id="notifications_email"
                    name="notifications_email"
                    defaultChecked={userProfile?.notifications_email || false}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="notifications_push">Notificações Push</Label>
                    <p className="text-sm text-muted-foreground">Receber notificações no navegador</p>
                  </div>
                  <Switch
                    id="notifications_push"
                    name="notifications_push"
                    defaultChecked={userProfile?.notifications_push || false}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="notifications_sms">Notificações por SMS</Label>
                    <p className="text-sm text-muted-foreground">Receber notificações por SMS</p>
                  </div>
                  <Switch
                    id="notifications_sms"
                    name="notifications_sms"
                    defaultChecked={userProfile?.notifications_sms || false}
                  />
                </div>

                <Separator />

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="notifications_appointments">Lembretes de Agendamentos</Label>
                    <p className="text-sm text-muted-foreground">Receber lembretes de agendamentos</p>
                  </div>
                  <Switch
                    id="notifications_appointments"
                    name="notifications_appointments"
                    defaultChecked={userProfile?.notifications_appointments || false}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="notifications_messages">Novas Mensagens</Label>
                    <p className="text-sm text-muted-foreground">Receber notificações de novas mensagens</p>
                  </div>
                  <Switch
                    id="notifications_messages"
                    name="notifications_messages"
                    defaultChecked={userProfile?.notifications_messages || false}
                  />
                </div>
              </CardContent>
              <CardFooter className="flex justify-end">
                <Button type="submit" disabled={isLoading}>
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Salvando...
                    </>
                  ) : (
                    "Salvar Preferências"
                  )}
                </Button>
              </CardFooter>
            </Card>
          </form>
        </TabsContent>

        <TabsContent value="seguranca">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5" />
                Segurança
              </CardTitle>
              <CardDescription>Altere sua senha e gerencie configurações de segurança</CardDescription>
            </CardHeader>
            <form onSubmit={handleChangePassword}>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="current-password">Senha Atual</Label>
                  <div className="relative">
                    <Input
                      id="current-password"
                      type={showPasswords.current ? "text" : "password"}
                      value={passwordData.currentPassword}
                      onChange={(e) => setPasswordData({ ...passwordData, currentPassword: e.target.value })}
                      placeholder="Digite sua senha atual"
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                      onClick={() => setShowPasswords({ ...showPasswords, current: !showPasswords.current })}
                    >
                      {showPasswords.current ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="new-password">Nova Senha</Label>
                  <div className="relative">
                    <Input
                      id="new-password"
                      type={showPasswords.new ? "text" : "password"}
                      value={passwordData.newPassword}
                      onChange={(e) => setPasswordData({ ...passwordData, newPassword: e.target.value })}
                      placeholder="Digite sua nova senha"
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                      onClick={() => setShowPasswords({ ...showPasswords, new: !showPasswords.new })}
                    >
                      {showPasswords.new ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </Button>
                  </div>
                  <PasswordStrengthIndicator password={passwordData.newPassword} />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="confirm-password">Confirmar Nova Senha</Label>
                  <div className="relative">
                    <Input
                      id="confirm-password"
                      type={showPasswords.confirm ? "text" : "password"}
                      value={passwordData.confirmPassword}
                      onChange={(e) => setPasswordData({ ...passwordData, confirmPassword: e.target.value })}
                      placeholder="Confirme sua nova senha"
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                      onClick={() => setShowPasswords({ ...showPasswords, confirm: !showPasswords.confirm })}
                    >
                      {showPasswords.confirm ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </Button>
                  </div>
                  {passwordData.confirmPassword && passwordData.newPassword !== passwordData.confirmPassword && (
                    <p className="text-sm text-red-600">As senhas não coincidem</p>
                  )}
                </div>
              </CardContent>
              <CardFooter className="flex justify-end">
                <Button type="submit" disabled={isChangingPassword}>
                  {isChangingPassword ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Alterando Senha...
                    </>
                  ) : (
                    "Alterar Senha"
                  )}
                </Button>
              </CardFooter>
            </form>
          </Card>
        </TabsContent>
      </Tabs>
      <AuthDebug />
    </div>
  )
}
