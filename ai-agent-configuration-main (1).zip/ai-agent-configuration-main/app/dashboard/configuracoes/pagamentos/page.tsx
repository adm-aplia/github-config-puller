"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { useToast } from "@/hooks/use-toast"
import {
  CreditCard,
  Calendar,
  DollarSign,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Settings,
  RefreshCw,
  Trash2,
} from "lucide-react"
import { useAuth } from "@/hooks/use-auth"

interface Subscription {
  id: string
  subscription_id: string
  plano: string
  valor: number
  status: string
  next_due_date: string
  data_contratacao: string
  first_payment_id?: string
  first_payment_status?: string
}

interface PaymentHistory {
  id: string
  valor: number
  status: string
  data_vencimento: string
  descricao: string
}

export default function PagamentosPage() {
  const [subscription, setSubscription] = useState<Subscription | null>(null)
  const [paymentHistory, setPaymentHistory] = useState<PaymentHistory[]>([])
  const [loading, setLoading] = useState(true)
  const [cancelLoading, setCancelLoading] = useState(false)
  const { user } = useAuth()
  const { toast } = useToast()

  useEffect(() => {
    if (user) {
      loadSubscriptionData()
    }
  }, [user])

  const loadSubscriptionData = async () => {
    try {
      setLoading(true)

      // Buscar assinatura ativa
      const response = await fetch("/api/subscription/current", {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      })

      if (response.ok) {
        const data = await response.json()
        setSubscription(data.subscription)
        setPaymentHistory(data.payments || [])
      }
    } catch (error) {
      console.error("Erro ao carregar dados da assinatura:", error)
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Não foi possível carregar os dados da assinatura",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleCancelSubscription = async () => {
    if (!subscription) return

    const confirmed = window.confirm("Tem certeza que deseja cancelar sua assinatura? Esta ação não pode ser desfeita.")

    if (!confirmed) return

    try {
      setCancelLoading(true)

      const response = await fetch("/api/subscription/cancel", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          subscription_id: subscription.subscription_id,
        }),
      })

      const result = await response.json()

      if (result.success) {
        toast({
          title: "Assinatura cancelada",
          description: "Sua assinatura foi cancelada com sucesso",
        })
        loadSubscriptionData() // Recarregar dados
      } else {
        throw new Error(result.message)
      }
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Erro ao cancelar",
        description: error.message || "Não foi possível cancelar a assinatura",
      })
    } finally {
      setCancelLoading(false)
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status.toLowerCase()) {
      case "active":
      case "ativo":
        return <Badge className="bg-green-100 text-green-800">Ativo</Badge>
      case "canceled":
      case "cancelado":
        return <Badge variant="destructive">Cancelado</Badge>
      case "pending":
      case "pendente":
        return <Badge variant="secondary">Pendente</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  const getPaymentStatusIcon = (status: string) => {
    switch (status.toLowerCase()) {
      case "confirmed":
      case "received":
      case "aprovado":
        return <CheckCircle className="h-4 w-4 text-green-600" />
      case "pending":
      case "pendente":
        return <RefreshCw className="h-4 w-4 text-yellow-600" />
      case "overdue":
      case "vencido":
        return <AlertTriangle className="h-4 w-4 text-red-600" />
      default:
        return <XCircle className="h-4 w-4 text-gray-600" />
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("pt-BR")
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value)
  }

  if (loading) {
    return (
      <div className="container mx-auto p-6">
        <div className="flex items-center gap-2 mb-6">
          <Settings className="h-6 w-6" />
          <h1 className="text-2xl font-bold">Configurações de Pagamento</h1>
        </div>
        <div className="grid gap-6">
          <Card>
            <CardContent className="p-6">
              <div className="animate-pulse space-y-4">
                <div className="h-4 bg-gray-200 rounded w-1/4"></div>
                <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                <div className="h-4 bg-gray-200 rounded w-1/3"></div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto p-6">
      <div className="flex items-center gap-2 mb-6">
        <Settings className="h-6 w-6" />
        <h1 className="text-2xl font-bold">Configurações de Pagamento</h1>
      </div>

      <div className="grid gap-6">
        {/* Assinatura Atual */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CreditCard className="h-5 w-5" />
              Assinatura Atual
            </CardTitle>
            <CardDescription>Gerencie sua assinatura e forma de pagamento</CardDescription>
          </CardHeader>
          <CardContent>
            {subscription ? (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-semibold text-lg">Plano {subscription.plano}</h3>
                    <p className="text-muted-foreground">{formatCurrency(subscription.valor)}/mês</p>
                  </div>
                  {getStatusBadge(subscription.status)}
                </div>

                <Separator />

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <p className="text-sm font-medium">Próximo vencimento</p>
                      <p className="text-sm text-muted-foreground">{formatDate(subscription.next_due_date)}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <DollarSign className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <p className="text-sm font-medium">Valor mensal</p>
                      <p className="text-sm text-muted-foreground">{formatCurrency(subscription.valor)}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <p className="text-sm font-medium">Contratado em</p>
                      <p className="text-sm text-muted-foreground">{formatDate(subscription.data_contratacao)}</p>
                    </div>
                  </div>
                </div>

                <Separator />

                <div className="flex gap-2">
                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={handleCancelSubscription}
                    disabled={cancelLoading || subscription.status === "canceled"}
                  >
                    {cancelLoading ? (
                      <>
                        <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                        Cancelando...
                      </>
                    ) : (
                      <>
                        <Trash2 className="mr-2 h-4 w-4" />
                        Cancelar Assinatura
                      </>
                    )}
                  </Button>

                  <Button variant="outline" size="sm" onClick={loadSubscriptionData}>
                    <RefreshCw className="mr-2 h-4 w-4" />
                    Atualizar
                  </Button>
                </div>
              </div>
            ) : (
              <div className="text-center py-8">
                <CreditCard className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="font-semibold mb-2">Nenhuma assinatura ativa</h3>
                <p className="text-muted-foreground mb-4">Você não possui uma assinatura ativa no momento</p>
                <Button onClick={() => (window.location.href = "/dashboard/planos")}>Ver Planos Disponíveis</Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Histórico de Pagamentos */}
        {subscription && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="h-5 w-5" />
                Histórico de Pagamentos
              </CardTitle>
              <CardDescription>Acompanhe todos os seus pagamentos</CardDescription>
            </CardHeader>
            <CardContent>
              {paymentHistory.length > 0 ? (
                <div className="space-y-4">
                  {paymentHistory.map((payment) => (
                    <div key={payment.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center gap-3">
                        {getPaymentStatusIcon(payment.status)}
                        <div>
                          <p className="font-medium">{payment.descricao}</p>
                          <p className="text-sm text-muted-foreground">
                            Vencimento: {formatDate(payment.data_vencimento)}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold">{formatCurrency(payment.valor)}</p>
                        <p className="text-sm text-muted-foreground capitalize">{payment.status}</p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <DollarSign className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">Nenhum pagamento encontrado</p>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Informações Importantes */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5" />
              Informações Importantes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 text-sm">
              <p>• As cobranças são processadas automaticamente todo mês na data de vencimento</p>
              <p>• Você pode cancelar sua assinatura a qualquer momento</p>
              <p>• Após o cancelamento, você terá acesso até o final do período pago</p>
              <p>• Em caso de problemas com pagamento, entre em contato com nosso suporte</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
