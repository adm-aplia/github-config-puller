"use client"

import { useState, useCallback, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Separator } from "@/components/ui/separator"
import { useRouter } from "next/navigation"
import { useToast } from "@/hooks/use-toast"
import {
  MessageCircle,
  Calendar,
  Bot,
  Mail,
  BarChart3,
  Building2,
  Users,
  Clock,
  Settings,
  CreditCard,
  DollarSign,
  AlertTriangle,
  CheckCircle,
  XCircle,
  RefreshCw,
  Trash2,
  Edit,
  Download,
} from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

const plans = [
  {
    id: "basico",
    name: "Básico",
    price: "R$ 199/mês",
    description: "Para profissionais individuais que buscam eficiência e baixo custo.",
    features: [
      { icon: <MessageCircle className="h-4 w-4 text-red-500" />, text: "1 Número de whatsapp" },
      { icon: <Calendar className="h-4 w-4 text-red-500" />, text: "Até 300 agendamentos/mês" },
      { icon: <Bot className="h-4 w-4 text-red-500" />, text: "1 Assistente personalizado" },
      { icon: <Mail className="h-4 w-4 text-red-500" />, text: "Suporte por e-mail" },
    ],
    callToAction: "Inicie agora e organize sua agenda com praticidade.",
    buttonText: "Começar agora",
    cardClass: "bg-card border-border hover:bg-accent/50 transition-colors duration-200",
    textClass: "text-foreground",
    priceClass: "text-foreground",
  },
  {
    id: "profissional",
    name: "Profissional",
    price: "R$ 399/mês",
    description: "Recomendado para clínicas que desejam crescer.",
    popular: true,
    features: [
      { icon: <MessageCircle className="h-4 w-4 text-red-500" />, text: "3 Números de whatsApp" },
      { icon: <Calendar className="h-4 w-4 text-red-500" />, text: "Até 1.000 agendamentos/mês" },
      { icon: <Bot className="h-4 w-4 text-red-500" />, text: "3 assistentes personalizado" },
      { icon: <Users className="h-4 w-4 text-red-500" />, text: "Suporte prioritário" },
      { icon: <BarChart3 className="h-4 w-4 text-red-500" />, text: "Relatórios Avançados" },
    ],
    callToAction: "Adquira já e otimize sua operação.",
    buttonText: "Escolher plano",
    cardClass: "bg-card border-border hover:bg-accent/50 transition-colors duration-200",
    textClass: "text-foreground",
    priceClass: "text-foreground",
  },
  {
    id: "empresarial",
    name: "Empresarial",
    price: "R$ 899/mês",
    description: "Desenvolvido para clínicas e hospitais de grande porte.",
    features: [
      { icon: <MessageCircle className="h-4 w-4 text-red-500" />, text: "+10 Números de whatsApp" },
      { icon: <Calendar className="h-4 w-4 text-red-500" />, text: "Agendamentos ilimitados" },
      { icon: <Bot className="h-4 w-4 text-red-500" />, text: "Assistentes ilimitados" },
      { icon: <Clock className="h-4 w-4 text-red-500" />, text: "Suporte 24/7 dedicado" },
      { icon: <Building2 className="h-4 w-4 text-red-500" />, text: "Integração com sistemas hospitalares" },
      { icon: <Settings className="h-4 w-4 text-red-500" />, text: "Personalização avançada" },
    ],
    callToAction: "Inicie agora e organize sua agenda com praticidade.",
    buttonText: "Contato comercial",
    cardClass: "bg-slate-900 border-slate-700 hover:bg-slate-800 transition-colors duration-200",
    textClass: "text-white",
    priceClass: "text-red-400",
  },
]

interface Subscription {
  id: string
  subscription_id: string
  plano: string
  valor: number
  status: string
  next_due_date: string
  data_contratacao: string
  payment_method?: string
  card_last_digits?: string
  card_brand?: string
}

interface PaymentHistory {
  id: string
  valor: number
  status: string
  data_vencimento: string
  data_pagamento?: string
  descricao: string
  invoice_url?: string
}

export default function PlanosPage() {
  const router = useRouter()
  const { toast } = useToast()
  const tabsRef = useRef<HTMLDivElement>(null)

  // Estados para gestão de pagamentos
  const [subscription, setSubscription] = useState<Subscription | null>(null)
  const [paymentHistory, setPaymentHistory] = useState<PaymentHistory[]>([])
  const [loading, setLoading] = useState(false)
  const [cancelLoading, setCancelLoading] = useState(false)
  const [updateCardLoading, setUpdateCardLoading] = useState(false)
  const [showUpdateCard, setShowUpdateCard] = useState(false)
  const [showCancelConfirm, setShowCancelConfirm] = useState(false)
  const [currentTab, setCurrentTab] = useState("planos")

  // ✅ Função para carregar dados apenas quando necessário (aba pagamentos)
  const loadSubscriptionData = useCallback(async () => {
    try {
      setLoading(true)

      const response = await fetch("/api/subscription/current", {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include",
      })

      // ✅ Verificar se a resposta é JSON válida
      const contentType = response.headers.get("content-type")
      if (!contentType || !contentType.includes("application/json")) {
        throw new Error("Resposta da API não é JSON válida")
      }

      const data = await response.json()

      if (data.success) {
        setSubscription(data.subscription)
        setPaymentHistory(data.payments || [])
      } else {
        console.error("Erro na API:", data.error)
        // ✅ Não mostra toast de erro se for apenas "sem assinatura"
        if (data.error !== "Usuário não autenticado" && data.subscription === null) {
          // Usuário sem assinatura é normal, não é erro
          setSubscription(null)
          setPaymentHistory([])
        } else if (data.error === "Usuário não autenticado") {
          toast({
            variant: "destructive",
            title: "Erro de autenticação",
            description: "Faça login novamente para acessar seus dados",
          })
        }
      }
    } catch (error: any) {
      console.error("Erro ao carregar dados da assinatura:", error)
      toast({
        variant: "destructive",
        title: "Erro ao carregar dados",
        description: "Não foi possível carregar os dados da assinatura. Tente novamente.",
      })
    } finally {
      setLoading(false)
    }
  }, [toast])

  // ✅ Função para trocar de aba
  const handleTabChange = (value: string) => {
    setCurrentTab(value)
    if (value === "pagamentos" && !subscription && !loading) {
      loadSubscriptionData()
    }
  }

  // ✅ Função para ir para aba de planos
  const goToPlansTab = () => {
    setCurrentTab("planos")
  }

  const handlePlanSelection = (planId: string) => {
    if (planId === "empresarial") {
      window.open("mailto:contato@aplia.com.br?subject=Interesse no Plano Empresarial", "_blank")
    } else {
      router.push(`/checkout?plano=${planId}`)
    }
  }

  const handleCancelSubscription = async () => {
    if (!subscription) return

    try {
      setCancelLoading(true)

      const response = await fetch("/api/subscription/cancel", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify({
          subscription_id: subscription.subscription_id,
        }),
      })

      const result = await response.json()

      if (result.success) {
        toast({
          title: "Assinatura cancelada",
          description: "Sua assinatura foi cancelada com sucesso",
        })
        setShowCancelConfirm(false)
        loadSubscriptionData()
      } else {
        throw new Error(result.message)
      }
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Erro ao cancelar",
        description: error.message || "Não foi possível cancelar a assinatura",
      })
    } finally {
      setCancelLoading(false)
    }
  }

  const handleUpdateCard = async (cardData: any) => {
    try {
      setUpdateCardLoading(true)

      const response = await fetch("/api/subscription/update-card", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify({
          subscription_id: subscription?.subscription_id,
          ...cardData,
        }),
      })

      const result = await response.json()

      if (result.success) {
        toast({
          title: "Cartão atualizado",
          description: "Dados do cartão atualizados com sucesso",
        })
        setShowUpdateCard(false)
        loadSubscriptionData()
      } else {
        throw new Error(result.message)
      }
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Erro ao atualizar",
        description: error.message || "Não foi possível atualizar o cartão",
      })
    } finally {
      setUpdateCardLoading(false)
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status.toLowerCase()) {
      case "active":
      case "ativo":
        return <Badge className="bg-green-100 text-green-800">Ativo</Badge>
      case "canceled":
      case "cancelado":
        return <Badge variant="destructive">Cancelado</Badge>
      case "pending":
      case "pendente":
        return <Badge variant="secondary">Pendente</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  const getPaymentStatusIcon = (status: string) => {
    switch (status.toLowerCase()) {
      case "confirmed":
      case "received":
      case "aprovado":
        return <CheckCircle className="h-4 w-4 text-green-600" />
      case "pending":
      case "pendente":
        return <RefreshCw className="h-4 w-4 text-yellow-600" />
      case "overdue":
      case "vencido":
        return <AlertTriangle className="h-4 w-4 text-red-600" />
      default:
        return <XCircle className="h-4 w-4 text-gray-600" />
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("pt-BR")
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value)
  }

  return (
    <div className="min-h-screen bg-background -m-6">
      <div className="container mx-auto px-4 py-12">
        <Tabs value={currentTab} className="w-full" onValueChange={handleTabChange} ref={tabsRef}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="planos">Planos Disponíveis</TabsTrigger>
            <TabsTrigger value="pagamentos">Gestão de Pagamentos</TabsTrigger>
          </TabsList>

          {/* Aba de Planos - ✅ Funciona sem autenticação */}
          <TabsContent value="planos" className="space-y-8">
            <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto mt-8">
              {plans.map((plan) => (
                <Card
                  key={plan.id}
                  className={`relative rounded-3xl shadow-lg ${plan.cardClass} border-2 flex flex-col h-full`}
                >
                  {plan.popular && (
                    <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                      <Badge className="bg-red-500 hover:bg-red-600 text-white px-4 py-1 text-sm font-medium rounded-full">
                        Mais popular
                      </Badge>
                    </div>
                  )}

                  <CardHeader className="pb-4 pt-8 px-8">
                    <CardTitle className={`text-2xl font-bold ${plan.textClass} mb-2`}>{plan.name}</CardTitle>
                    <div className={`text-2xl font-bold ${plan.priceClass} mb-4`}>{plan.price}</div>
                    <hr
                      className={`border-t-2 mb-4 ${plan.id === "empresarial" ? "border-slate-600" : "border-border"}`}
                    />
                    <CardDescription className={`${plan.textClass} text-sm leading-relaxed`}>
                      {plan.description}
                    </CardDescription>
                  </CardHeader>

                  <CardContent className="px-8 pb-6 flex-grow">
                    <ul className="space-y-3">
                      {plan.features.map((feature, index) => (
                        <li key={index} className="flex items-center gap-3">
                          {feature.icon}
                          <span className={`${plan.textClass} text-sm`}>{feature.text}</span>
                        </li>
                      ))}
                    </ul>

                    <div className="mt-6">
                      <p className={`${plan.textClass} text-sm leading-relaxed`}>{plan.callToAction}</p>
                    </div>
                  </CardContent>

                  <CardFooter className="px-8 pb-8 mt-auto">
                    <Button
                      onClick={() => handlePlanSelection(plan.id)}
                      className="w-full bg-red-500 hover:bg-red-600 text-white py-3 text-base font-medium rounded-xl transition-colors duration-200"
                    >
                      {plan.buttonText}
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>

            {/* Trust Indicators */}
            <div className="mt-16 text-center">
              <div className="flex justify-center items-center gap-8 opacity-60">
                <div className="text-xs text-muted-foreground">🔒 Pagamento Seguro</div>
                <div className="text-xs text-muted-foreground">✅ Cancele Quando Quiser</div>
                <div className="text-xs text-muted-foreground">📞 Suporte Especializado</div>
              </div>
            </div>
          </TabsContent>

          {/* Aba de Gestão de Pagamentos - ✅ Só carrega quando necessário */}
          <TabsContent value="pagamentos" className="space-y-6">
            {loading ? (
              <Card>
                <CardContent className="p-6">
                  <div className="animate-pulse space-y-4">
                    <div className="h-4 bg-gray-200 rounded w-1/4"></div>
                    <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                    <div className="h-4 bg-gray-200 rounded w-1/3"></div>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <>
                {/* Assinatura Atual */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <CreditCard className="h-5 w-5" />
                      Assinatura Atual
                    </CardTitle>
                    <CardDescription>Gerencie sua assinatura e forma de pagamento</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {subscription ? (
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <h3 className="font-semibold text-lg">Plano {subscription.plano}</h3>
                            <p className="text-muted-foreground">{formatCurrency(subscription.valor)}/mês</p>
                          </div>
                          {getStatusBadge(subscription.status)}
                        </div>

                        <Separator />

                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <div className="flex items-center gap-2">
                            <Calendar className="h-4 w-4 text-muted-foreground" />
                            <div>
                              <p className="text-sm font-medium">Próximo vencimento</p>
                              <p className="text-sm text-muted-foreground">{formatDate(subscription.next_due_date)}</p>
                            </div>
                          </div>

                          <div className="flex items-center gap-2">
                            <DollarSign className="h-4 w-4 text-muted-foreground" />
                            <div>
                              <p className="text-sm font-medium">Valor mensal</p>
                              <p className="text-sm text-muted-foreground">{formatCurrency(subscription.valor)}</p>
                            </div>
                          </div>

                          <div className="flex items-center gap-2">
                            <CreditCard className="h-4 w-4 text-muted-foreground" />
                            <div>
                              <p className="text-sm font-medium">Forma de pagamento</p>
                              <p className="text-sm text-muted-foreground">
                                {subscription.card_brand || "Cartão"} •••• {subscription.card_last_digits || "****"}
                              </p>
                            </div>
                          </div>
                        </div>

                        <Separator />

                        <div className="flex gap-2">
                          <Dialog open={showUpdateCard} onOpenChange={setShowUpdateCard}>
                            <DialogTrigger asChild>
                              <Button variant="outline" size="sm">
                                <Edit className="mr-2 h-4 w-4" />
                                Alterar Cartão
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>Alterar Dados do Cartão</DialogTitle>
                                <DialogDescription>Atualize as informações do seu cartão de crédito</DialogDescription>
                              </DialogHeader>
                              <div className="grid gap-4 py-4">
                                <div className="grid gap-2">
                                  <Label htmlFor="card-number">Número do Cartão</Label>
                                  <Input id="card-number" placeholder="1234 5678 9012 3456" />
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                  <div className="grid gap-2">
                                    <Label htmlFor="expiry">Validade</Label>
                                    <Input id="expiry" placeholder="MM/AA" />
                                  </div>
                                  <div className="grid gap-2">
                                    <Label htmlFor="cvv">CVV</Label>
                                    <Input id="cvv" placeholder="123" />
                                  </div>
                                </div>
                              </div>
                              <DialogFooter>
                                <Button variant="outline" onClick={() => setShowUpdateCard(false)}>
                                  Cancelar
                                </Button>
                                <Button onClick={() => handleUpdateCard({})} disabled={updateCardLoading}>
                                  {updateCardLoading ? (
                                    <>
                                      <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                                      Atualizando...
                                    </>
                                  ) : (
                                    "Atualizar"
                                  )}
                                </Button>
                              </DialogFooter>
                            </DialogContent>
                          </Dialog>

                          <Dialog open={showCancelConfirm} onOpenChange={setShowCancelConfirm}>
                            <DialogTrigger asChild>
                              <Button variant="destructive" size="sm" disabled={subscription.status === "canceled"}>
                                <Trash2 className="mr-2 h-4 w-4" />
                                Cancelar Assinatura
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>Cancelar Assinatura</DialogTitle>
                                <DialogDescription>
                                  Tem certeza que deseja cancelar sua assinatura? Esta ação não pode ser desfeita.
                                </DialogDescription>
                              </DialogHeader>
                              <div className="py-4">
                                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                                  <div className="flex items-start gap-2">
                                    <AlertTriangle className="h-5 w-5 text-yellow-600 mt-0.5" />
                                    <div>
                                      <p className="text-sm font-medium text-yellow-800">Importante:</p>
                                      <p className="text-sm text-yellow-700 mt-1">
                                        Após o cancelamento, você terá acesso até o final do período pago atual.
                                      </p>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <DialogFooter>
                                <Button variant="outline" onClick={() => setShowCancelConfirm(false)}>
                                  Manter Assinatura
                                </Button>
                                <Button
                                  variant="destructive"
                                  onClick={handleCancelSubscription}
                                  disabled={cancelLoading}
                                >
                                  {cancelLoading ? (
                                    <>
                                      <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                                      Cancelando...
                                    </>
                                  ) : (
                                    "Confirmar Cancelamento"
                                  )}
                                </Button>
                              </DialogFooter>
                            </DialogContent>
                          </Dialog>

                          <Button variant="outline" size="sm" onClick={loadSubscriptionData}>
                            <RefreshCw className="mr-2 h-4 w-4" />
                            Atualizar
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <div className="text-center py-8">
                        <CreditCard className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                        <h3 className="font-semibold mb-2">Nenhuma assinatura ativa</h3>
                        <p className="text-muted-foreground mb-4">Você não possui uma assinatura ativa no momento</p>
                        <Button onClick={goToPlansTab} className="bg-red-500 hover:bg-red-600 text-white">
                          Ver Planos Disponíveis
                        </Button>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Histórico de Pagamentos */}
                {subscription && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <DollarSign className="h-5 w-5" />
                        Histórico de Pagamentos
                      </CardTitle>
                      <CardDescription>Acompanhe todos os seus pagamentos</CardDescription>
                    </CardHeader>
                    <CardContent>
                      {paymentHistory.length > 0 ? (
                        <div className="space-y-4">
                          {paymentHistory.map((payment) => (
                            <div key={payment.id} className="flex items-center justify-between p-4 border rounded-lg">
                              <div className="flex items-center gap-3">
                                {getPaymentStatusIcon(payment.status)}
                                <div>
                                  <p className="font-medium">{payment.descricao}</p>
                                  <p className="text-sm text-muted-foreground">
                                    Vencimento: {formatDate(payment.data_vencimento)}
                                    {payment.data_pagamento && <> • Pago em: {formatDate(payment.data_pagamento)}</>}
                                  </p>
                                </div>
                              </div>
                              <div className="flex items-center gap-2">
                                <div className="text-right">
                                  <p className="font-semibold">{formatCurrency(payment.valor)}</p>
                                  <p className="text-sm text-muted-foreground capitalize">{payment.status}</p>
                                </div>
                                {payment.invoice_url && (
                                  <Button variant="ghost" size="sm" asChild>
                                    <a href={payment.invoice_url} target="_blank" rel="noopener noreferrer">
                                      <Download className="h-4 w-4" />
                                    </a>
                                  </Button>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="text-center py-8">
                          <DollarSign className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                          <p className="text-muted-foreground">Nenhum pagamento encontrado</p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                )}
              </>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
