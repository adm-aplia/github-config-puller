"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { AppointmentCalendar } from "@/components/dashboard/appointment-calendar"
import { CreateAppointmentModal } from "@/components/appointments/create-appointment-modal" // Importar o novo modal

export default function AppointmentsPage() {
  const [refreshCalendar, setRefreshCalendar] = useState(0) // Estado para forçar o refresh do calendário

  const handleAppointmentCreated = () => {
    setRefreshCalendar((prev) => prev + 1) // Incrementa para forçar o re-render do calendário
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold tracking-tight">Agendamentos</h1>
        <CreateAppointmentModal onAppointmentCreated={handleAppointmentCreated} /> {/* Usar o modal aqui */}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Visão Geral dos Agendamentos</CardTitle>
          <CardDescription>Visualize e gerencie todos os agendamentos da sua clínica.</CardDescription>
        </CardHeader>
        <CardContent>
          <AppointmentCalendar key={refreshCalendar} /> {/* Adicionar key para forçar re-render */}
        </CardContent>
      </Card>
    </div>
  )
}
