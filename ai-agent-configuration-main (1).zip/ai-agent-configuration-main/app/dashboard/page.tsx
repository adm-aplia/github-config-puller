"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Overview } from "@/components/dashboard/overview"
import { RecentConversations } from "@/components/dashboard/recent-conversations"
import { DashboardCustomizer } from "@/components/dashboard/dashboard-customizer"
import { Button } from "@/components/ui/button"
import { RefreshCw, Activity, Calendar, MessageSquare, Users } from "lucide-react"
import { StatsService } from "@/lib/services/stats-service"
import { Skeleton } from "@/components/ui/skeleton"
import type { DashboardWidget } from "@/lib/services/dashboard-settings-service"

export default function DashboardPage() {
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date())
  const [loading, setLoading] = useState(false)
  const [initialLoading, setInitialLoading] = useState(true)
  const [stats, setStats] = useState({
    totalConversations: 0,
    activeConversations: 0,
    profileCount: 0,
    instanceCount: 0,
    connectedInstanceCount: 0,
    messageCount: 0,
    appointmentCount: 0,
    chartData: [],
    previousPeriod: {
      totalConversations: 0,
      messageCount: 0,
      appointmentCount: 0,
    },
  })

  const [dashboardSettings, setDashboardSettings] = useState({
    visible_widgets: ["recent_conversations", "whatsapp_status"] as DashboardWidget[],
  })

  const handleSettingsChange = (settings: { visible_widgets: DashboardWidget[] }) => {
    setDashboardSettings(settings)
  }

  // Função para atualizar os dados do dashboard
  const refreshDashboard = async () => {
    setLoading(true)
    try {
      const dashboardStats = await StatsService.getDashboardStats("month", true)
      setStats(dashboardStats)
    } catch (error) {
      console.error("Erro ao atualizar dashboard:", error)
    } finally {
      setLastUpdated(new Date())
      setLoading(false)
      setInitialLoading(false)
    }
  }

  // Carregar dados iniciais
  useEffect(() => {
    refreshDashboard()

    // Atualizar a cada 1 minuto
    const interval = setInterval(() => {
      refreshDashboard()
    }, 60000) // 1 minuto em milissegundos

    return () => clearInterval(interval)
  }, [])

  // Calcular porcentagens de mudança
  const calculatePercentChange = (current: number, previous: number) => {
    if (previous === 0) return current > 0 ? 100 : 0
    return Math.round(((current - previous) / previous) * 100)
  }

  const conversationsPercentChange = calculatePercentChange(
    stats.totalConversations,
    stats.previousPeriod?.totalConversations || 0,
  )

  const appointmentsPercentChange = calculatePercentChange(
    stats.appointmentCount,
    stats.previousPeriod?.appointmentCount || 0,
  )

  // Componente de card de estatística
  const StatCard = ({
    title,
    value,
    description,
    icon: Icon,
    loading: isLoading,
  }: {
    title: string
    value: string | number
    description: string
    icon: React.ElementType
    loading?: boolean
  }) => (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <>
            <Skeleton className="h-8 w-20 mb-1" />
            <Skeleton className="h-4 w-32" />
          </>
        ) : (
          <>
            <div className="text-2xl font-bold h-8 flex items-center">{value}</div>
            <p className="text-xs text-muted-foreground">{description}</p>
          </>
        )}
      </CardContent>
    </Card>
  )

  return (
    <div className="flex flex-col gap-4">
      {/* Header Section */}
      <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-muted-foreground">
            Visão geral da sua plataforma Aplia
            <span className="text-xs ml-2">Última atualização: {lastUpdated.toLocaleTimeString("pt-BR")}</span>
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={refreshDashboard}
            disabled={loading}
            className="flex items-center gap-2 bg-transparent"
          >
            <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
            <span className="sr-only md:not-sr-only">Atualizar</span>
          </Button>
          <DashboardCustomizer onSettingsChange={handleSettingsChange} />
        </div>
      </header>

      {/* Stats Cards */}
      <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Conversas Totais"
          value={`+${stats.totalConversations}`}
          description={`${conversationsPercentChange > 0 ? "+" : ""}${conversationsPercentChange}% em relação ao mês anterior`}
          icon={MessageSquare}
          loading={initialLoading}
        />
        <StatCard
          title="Agendamentos"
          value={`+${stats.appointmentCount}`}
          description={`${appointmentsPercentChange > 0 ? "+" : ""}${appointmentsPercentChange}% em relação ao mês anterior`}
          icon={Calendar}
          loading={initialLoading}
        />
        <StatCard
          title="Perfis Ativos"
          value={stats.profileCount}
          description={
            stats.profileCount > 0 ? `${stats.profileCount} perfis configurados` : "Nenhum perfil configurado"
          }
          icon={Users}
          loading={initialLoading}
        />
        <StatCard
          title="Instâncias WhatsApp"
          value={`${stats.connectedInstanceCount}/${stats.instanceCount}`}
          description={`${stats.connectedInstanceCount} de ${stats.instanceCount} conectadas`}
          icon={Activity}
          loading={initialLoading}
        />
      </div>

      {/* Main Content Grid */}
      <div className="grid gap-4 grid-cols-1 lg:grid-cols-7">
        {/* Chart Section */}
        <Card className="col-span-1 lg:col-span-4">
          <CardHeader>
            <CardTitle>Conversas</CardTitle>
            <CardDescription>Número de conversas nos últimos 30 dias</CardDescription>
          </CardHeader>
          <CardContent className="pl-2">
            {initialLoading ? <Skeleton className="h-[350px] w-full" /> : <Overview data={stats.chartData} />}
          </CardContent>
        </Card>

        {/* Recent Conversations */}
        <Card className="col-span-1 lg:col-span-3">
          <CardHeader>
            <CardTitle>Conversas Recentes</CardTitle>
            <CardDescription>Últimas conversas registradas</CardDescription>
          </CardHeader>
          <CardContent>
            <RecentConversations />
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
