"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { ConversationsList } from "@/components/conversations/conversations-list"
import { DateRangePicker } from "@/components/date-range-picker"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Download } from "lucide-react"
import { ConversationService } from "@/lib/services/conversation-service"

export default function ConversasPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [isExporting, setIsExporting] = useState(false)
  const [dateRange, setDateRange] = useState<{ from?: Date; to?: Date }>({})

  // Função para exportar conversas
  const exportConversations = async () => {
    try {
      setIsExporting(true)

      // Construir filtros baseados nos estados atuais
      const filters: any = {}

      if (statusFilter !== "all") {
        filters.status = statusFilter
      }

      if (dateRange.from) {
        filters.startDate = dateRange.from.toISOString()
      }

      if (dateRange.to) {
        filters.endDate = dateRange.to.toISOString()
      }

      if (searchQuery) {
        filters.search = searchQuery
      }

      // Buscar todas as conversas com os filtros aplicados
      const { data } = await ConversationService.getUserConversations(filters)

      if (!data || data.length === 0) {
        alert("Não há dados para exportar")
        return
      }

      // Formatar dados para CSV
      const headers = [
        "ID",
        "Nome do Contato",
        "Telefone",
        "Status",
        "Data de Criação",
        "Última Atualização",
        "Profissional",
      ]
      const csvData = data.map((conv) => [
        conv.id,
        conv.contact_name || "Sem nome",
        conv.contact_phone || "Sem telefone",
        conv.status,
        new Date(conv.created_at).toLocaleString(),
        new Date(conv.updated_at).toLocaleString(),
        conv.professional_profiles?.fullName || "Sem profissional",
      ])

      // Criar conteúdo CSV
      const csvContent = [headers.join(","), ...csvData.map((row) => row.join(","))].join("\n")

      // Criar e baixar arquivo
      const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
      const url = URL.createObjectURL(blob)
      const link = document.createElement("a")
      link.setAttribute("href", url)
      link.setAttribute("download", `conversas-${new Date().toISOString().split("T")[0]}.csv`)
      link.style.visibility = "hidden"
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
    } catch (error) {
      console.error("Erro ao exportar conversas:", error)
      alert("Erro ao exportar conversas")
    } finally {
      setIsExporting(false)
    }
  }

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Conversas</h1>
        <p className="text-muted-foreground">Visualize e gerencie conversas com pacientes</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Histórico de Conversas</CardTitle>
          <CardDescription>Navegue e pesquise em todas as interações com pacientes</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Pesquisar conversas..."
                className="pl-8"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="flex flex-col sm:flex-row gap-4">
              <DateRangePicker value={dateRange} onChange={setDateRange} />
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Filtrar por status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas as Conversas</SelectItem>
                  <SelectItem value="active">Ativas</SelectItem>
                  <SelectItem value="closed">Fechadas</SelectItem>
                  <SelectItem value="flagged">Sinalizadas</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline" className="gap-2" onClick={exportConversations} disabled={isExporting}>
                <Download className="h-4 w-4" />
                {isExporting ? "Exportando..." : "Exportar"}
              </Button>
            </div>
          </div>

          <ConversationsList
            searchQuery={searchQuery}
            statusFilter={statusFilter !== "all" ? statusFilter : undefined}
            dateRange={dateRange}
          />
        </CardContent>
      </Card>
    </div>
  )
}
