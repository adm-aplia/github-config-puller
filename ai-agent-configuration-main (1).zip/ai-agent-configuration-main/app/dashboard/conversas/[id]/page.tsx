"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, MessageCircle, Phone, Calendar, User } from "lucide-react"
import Link from "next/link"
import { ConversationService } from "@/lib/services/conversation-service"
import { CreateAppointmentButton } from "@/app/dashboard/conversations/[id]/components/create-appointment-button"

interface ConversationPageProps {
  params: {
    id: string
  }
}

export default function ConversationPage({ params }: ConversationPageProps) {
  const [conversation, setConversation] = useState<any>(null)
  const [messages, setMessages] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    async function loadConversation() {
      try {
        setIsLoading(true)
        const conversationData = await ConversationService.getConversationById(params.id)
        const messagesData = await ConversationService.getConversationMessages(params.id)

        setConversation(conversationData)
        setMessages(messagesData || [])
      } catch (error) {
        console.error("Erro ao carregar conversa:", error)
      } finally {
        setIsLoading(false)
      }
    }

    if (params.id) {
      loadConversation()
    }
  }, [params.id])

  if (isLoading) {
    return (
      <div className="container mx-auto py-6">
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-muted-foreground">Carregando conversa...</p>
          </div>
        </div>
      </div>
    )
  }

  if (!conversation) {
    return (
      <div className="container mx-auto py-6">
        <div className="mb-6">
          <Link href="/dashboard/conversas">
            <Button variant="ghost" className="mb-4">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Voltar para Conversas
            </Button>
          </Link>
        </div>
        <Card>
          <CardContent className="p-6">
            <p className="text-center text-muted-foreground">Conversa não encontrada.</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-6">
      <div className="mb-6">
        <Link href="/dashboard/conversas">
          <Button variant="ghost" className="mb-4">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Voltar para Conversas
          </Button>
        </Link>
      </div>

      <div className="grid gap-6">
        {/* Header da Conversa */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <MessageCircle className="h-5 w-5" />
                  <CardTitle>{conversation.contact_name || "Sem nome"}</CardTitle>
                </div>
                <Badge variant={conversation.status === "active" ? "default" : "secondary"}>
                  {conversation.status === "active" ? "Ativa" : "Inativa"}
                </Badge>
              </div>
              <div className="flex gap-2">
                <CreateAppointmentButton contactPhone={conversation.contact_phone} conversationId={conversation.id} />
              </div>
            </div>
            <CardDescription className="flex items-center gap-4">
              <span className="flex items-center gap-1">
                <Phone className="h-4 w-4" />
                {conversation.contact_phone}
              </span>
              <span className="flex items-center gap-1">
                <Calendar className="h-4 w-4" />
                {new Date(conversation.created_at).toLocaleDateString()}
              </span>
              {conversation.professional_profiles && (
                <span className="flex items-center gap-1">
                  <User className="h-4 w-4" />
                  {conversation.professional_profiles.fullName}
                </span>
              )}
            </CardDescription>
          </CardHeader>
        </Card>

        {/* Mensagens */}
        <Card>
          <CardHeader>
            <CardTitle>Histórico de Mensagens</CardTitle>
            <CardDescription>{messages.length} mensagem(s) nesta conversa</CardDescription>
          </CardHeader>
          <CardContent>
            {messages.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">Nenhuma mensagem encontrada nesta conversa.</p>
            ) : (
              <div className="space-y-4">
                {messages.map((message, index) => (
                  <div key={index} className={`flex ${message.fromMe ? "justify-end" : "justify-start"}`}>
                    <div
                      className={`max-w-[70%] rounded-lg p-3 ${
                        message.fromMe ? "bg-primary text-primary-foreground" : "bg-muted"
                      }`}
                    >
                      <p className="text-sm">{message.body || message.content}</p>
                      <p className="text-xs opacity-70 mt-1">
                        {new Date(message.timestamp || message.created_at).toLocaleString()}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
