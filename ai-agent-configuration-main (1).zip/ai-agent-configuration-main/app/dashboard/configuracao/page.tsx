"use client"

import type React from "react"
import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { Separator } from "@/components/ui/separator"
import { useToast } from "@/hooks/use-toast"
import { Loader2 } from "lucide-react"
import { useAuth } from "@/hooks/use-auth"
import { getSupabaseInstance } from "@/lib/supabase-singleton"

// Interface para as credenciais do Google
interface GoogleCredential {
  id?: string
  user_id: string
  email: string
  name?: string
  professional_profile_id?: string | null
  professional_profile?: {
    id: string
    fullName: string
    specialty?: string
  } | null
}

// Declarando as variáveis GOOGLE_CLIENT_ID e GOOGLE_SCOPES
const GOOGLE_CLIENT_ID = process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID || ""
const GOOGLE_SCOPES = [
  "https://www.googleapis.com/auth/calendar",
  "https://www.googleapis.com/auth/calendar.events",
  "https://www.googleapis.com/auth/userinfo.email",
  "https://www.googleapis.com/auth/userinfo.profile",
  "openid",
].join(" ")

export default function ConfiguracaoPage() {
  const [isLoading, setIsLoading] = useState(false)
  const [isGoogleConnected, setIsGoogleConnected] = useState(false)
  const [isCheckingConnection, setIsCheckingConnection] = useState(false)
  const [googleUserInfo, setGoogleUserInfo] = useState<any>(null)
  const [activeTab, setActiveTab] = useState("perfil")
  const [googleCredentials, setGoogleCredentials] = useState<GoogleCredential[]>([])
  const [loadingCredentials, setLoadingCredentials] = useState(false)
  const [disconnectingCredential, setDisconnectingCredential] = useState<string | null>(null)
  const { toast } = useToast()
  const { user, isLoading: authLoading } = useAuth()
  const [isMobile, setIsMobile] = useState(false)
  const hasCheckedConnection = useRef(false)
  const isIntegrationsTabActive = activeTab === "integracoes"
  const popupMessageLogged = useRef(false)

  // Função principal que constrói a URL de autenticação
  const handleGoogleCalendarConnect = () => {
    if (!user) {
      toast({
        variant: "destructive",
        title: "Erro de autenticação",
        description: "Você precisa estar logado para conectar ao Google Agenda",
      })
      return
    }

    setIsLoading(true)

    try {
      // Criar um objeto state com o ID do usuário
      const stateObj = { user_id: user.id }
      const stateParam = encodeURIComponent(JSON.stringify(stateObj))

      // Salvar a URL de retorno para dispositivos móveis
      if (isMobile) {
        sessionStorage.setItem("auth_return_url", window.location.pathname)
      }

      // 🔗 CONSTRUIR A URL DE REDIRECIONAMENTO
      const redirectUri = `${process.env.NEXT_PUBLIC_APP_URL}/auth/google/callback`

      // 🔗 URL COMPLETA DE AUTENTICAÇÃO GOOGLE
      const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?client_id=${GOOGLE_CLIENT_ID}&redirect_uri=${encodeURIComponent(redirectUri)}&response_type=code&scope=${encodeURIComponent(GOOGLE_SCOPES)}&access_type=offline&prompt=consent&state=${stateParam}`

      if (isMobile) {
        // Em dispositivos móveis, redirecionar a janela atual
        window.location.href = authUrl
      } else {
        // Em desktop, abrir um popup
        const width = 600
        const height = 700
        const left = window.screenX + (window.outerWidth - width) / 2
        const top = window.screenY + (window.outerHeight - height) / 2

        // Resetar o flag de log de mensagem
        popupMessageLogged.current = false

        const authWindow = window.open(
          authUrl,
          "googleAuthPopup",
          `width=${width},height=${height},left=${left},top=${top},resizable=yes,scrollbars=yes,status=yes`,
        )

        // Monitorar o fechamento do popup
        const checkPopupClosed = setInterval(() => {
          if (authWindow?.closed) {
            clearInterval(checkPopupClosed)
            setIsLoading(false)

            // Verificar se a integração foi bem-sucedida após o fechamento do popup
            setTimeout(() => {
              fetchGoogleCredentials()
              if (user) {
                checkUserGoogleIntegration()
              }
            }, 1000)
          }
        }, 500)
      }
    } catch (error) {
      console.error("Erro ao iniciar autenticação:", error)
      toast({
        variant: "destructive",
        title: "Erro ao conectar",
        description: error instanceof Error ? error.message : "Ocorreu um erro ao conectar com o Google",
      })
      setIsLoading(false)
    }
  }

  // Resto das funções...
  const fetchGoogleCredentials = async () => {
    try {
      setLoadingCredentials(true)
      hasCheckedConnection.current = true

      const supabase = getSupabaseInstance()
      if (!supabase || !user?.email) return

      const { data: credentials, error: credentialsError } = await supabase
        .from("google_credentials")
        .select("*")
        .eq("email", user.email)
        .order("created_at", { ascending: false })

      if (credentialsError) {
        throw new Error(credentialsError.message)
      }

      if (!credentials || credentials.length === 0) {
        setGoogleCredentials([])
        return
      }

      const credentialIds = credentials.map((c) => c.id)
      const { data: profileLinks } = await supabase
        .from("google_profile_links")
        .select("google_credential_id, professional_profile_id")
        .in("google_credential_id", credentialIds)

      let professionalProfiles: any[] = []
      if (profileLinks && profileLinks.length > 0) {
        const profileIds = profileLinks.map((link) => link.professional_profile_id)
        const { data: profiles } = await supabase
          .from("professional_profiles")
          .select("id, fullName, specialty")
          .in("id", profileIds)

        if (profiles) {
          professionalProfiles = profiles
        }
      }

      const formattedData = credentials.map((credential) => {
        const profileLink = profileLinks?.find((link) => link.google_credential_id === credential.id)
        const professionalProfile = profileLink
          ? professionalProfiles.find((profile) => profile.id === profileLink.professional_profile_id)
          : null

        return {
          id: credential.id,
          user_id: credential.user_id,
          email: credential.email,
          name: credential.name,
          professional_profile_id: profileLink?.professional_profile_id || null,
          professional_profile: professionalProfile || null,
        }
      })

      setGoogleCredentials(formattedData)

      if (formattedData.length > 0) {
        setIsGoogleConnected(true)
      }
    } catch (error) {
      console.error("Erro ao buscar integrações:", error)
      toast({
        variant: "destructive",
        title: "Erro de conexão",
        description: "Não foi possível conectar ao servidor para buscar as integrações",
      })
    } finally {
      setLoadingCredentials(false)
    }
  }

  const checkUserGoogleIntegration = async () => {
    if (!user) return

    try {
      setIsCheckingConnection(true)
      const timestamp = new Date().getTime()
      const response = await fetch(`/api/integrations/google-calendar/status?userId=${user.id}&t=${timestamp}`, {
        cache: "no-store",
        headers: {
          "Cache-Control": "no-cache, no-store, must-revalidate",
          Pragma: "no-cache",
          Expires: "0",
        },
      })

      if (response.ok) {
        const data = await response.json()
        setIsGoogleConnected(data.connected)
        if (data.connected && data.userInfo) {
          setGoogleUserInfo(data.userInfo)
        }
      }
    } catch (error) {
      console.error("Erro ao verificar integração do usuário:", error)
    } finally {
      setIsCheckingConnection(false)
    }
  }

  // Outros handlers...
  const handleDisconnectGoogle = async () => {
    if (!user) return

    setIsLoading(true)
    try {
      const response = await fetch("/api/integrations/google-calendar/disconnect", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ userId: user.id }),
      })

      if (!response.ok) {
        throw new Error("Falha ao desconectar do Google Calendar")
      }

      setIsGoogleConnected(false)
      setGoogleUserInfo(null)
      fetchGoogleCredentials()

      toast({
        title: "Google Agenda desconectado",
        description: "Sua conta do Google Agenda foi desconectada com sucesso",
      })
    } catch (error) {
      console.error("Erro ao desconectar:", error)
      toast({
        variant: "destructive",
        title: "Erro ao desconectar",
        description: "Não foi possível desconectar do Google Calendar",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleUnlinkProfile = async (credentialId: string) => {
    try {
      setDisconnectingCredential(credentialId)
      const supabase = getSupabaseInstance()
      if (!supabase) throw new Error("Cliente Supabase não inicializado")

      const { error } = await supabase.from("google_profile_links").delete().eq("google_credential_id", credentialId)
      if (error) throw new Error(error.message)

      fetchGoogleCredentials()
      toast({
        title: "Perfil desvinculado",
        description: "O perfil profissional foi desvinculado com sucesso.",
      })
    } catch (error) {
      console.error("Erro ao desvincular perfil:", error)
      toast({
        variant: "destructive",
        title: "Erro ao desvincular",
        description: "Não foi possível desvincular o perfil profissional.",
      })
    } finally {
      setDisconnectingCredential(null)
    }
  }

  const handleDisconnectCredential = async (credentialId: string) => {
    if (!credentialId) return

    setDisconnectingCredential(credentialId)
    try {
      const response = await fetch("/api/integrations/google-calendar/disconnect-credential", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ credentialId }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.message || "Falha ao desconectar conta do Google")
      }

      fetchGoogleCredentials()
      toast({
        title: "Conta desconectada",
        description: "A conta do Google foi desconectada com sucesso",
      })
    } catch (error) {
      console.error("Erro ao desconectar credencial:", error)
      toast({
        variant: "destructive",
        title: "Erro ao desconectar",
        description: error instanceof Error ? error.message : "Não foi possível desconectar a conta do Google",
      })
    } finally {
      setDisconnectingCredential(null)
    }
  }

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      await new Promise((resolve) => setTimeout(resolve, 1500))
      toast({
        title: "Configurações salvas",
        description: "Suas configurações foram atualizadas com sucesso",
      })
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Algo deu errado",
        description: "Por favor, tente novamente mais tarde",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleRefreshCredentials = () => {
    if (!user?.email) {
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Usuário não encontrado. Faça login novamente.",
      })
      return
    }

    hasCheckedConnection.current = false
    fetchGoogleCredentials()
    toast({
      title: "Atualizando...",
      description: "Buscando integrações mais recentes.",
    })
  }

  // Effects
  useEffect(() => {
    setIsMobile(window.innerWidth <= 768)

    const urlParams = new URLSearchParams(window.location.search)
    const authError = urlParams.get("auth_error")
    const authSuccess = urlParams.get("auth_success")
    const tab = urlParams.get("tab")

    if (tab) {
      setActiveTab(tab)
    }

    if (authError) {
      toast({
        variant: "destructive",
        title: "Erro na autenticação",
        description: decodeURIComponent(authError),
      })
      window.history.replaceState({}, document.title, window.location.pathname)
    }

    if (authSuccess) {
      toast({
        title: "Google Agenda conectado",
        description: "Sua conta do Google Agenda foi conectada com sucesso",
      })
      window.history.replaceState({}, document.title, window.location.pathname)
      fetchGoogleCredentials()
    }

    const messageHandler = (event: MessageEvent) => {
      if (event.origin !== window.location.origin) return

      if (!popupMessageLogged.current && event.data.type) {
        console.log("Mensagem recebida do popup:", event.data)
        popupMessageLogged.current = true
      }

      if (event.data.type === "google-auth-success") {
        setIsGoogleConnected(true)
        setGoogleUserInfo(event.data.userInfo)
        toast({
          title: "Google Agenda conectado",
          description: "Sua conta do Google Agenda foi conectada com sucesso",
        })
        fetchGoogleCredentials()
      }

      if (event.data.type === "google-auth-error") {
        toast({
          variant: "destructive",
          title: "Erro na autenticação",
          description: event.data.error || "Ocorreu um erro durante a autenticação",
        })
      }
    }

    window.addEventListener("message", messageHandler)
    return () => {
      window.removeEventListener("message", messageHandler)
    }
  }, [toast])

  useEffect(() => {
    if (user?.id && user?.email && !hasCheckedConnection.current) {
      fetchGoogleCredentials()
    }
  }, [user?.id, user?.email])

  useEffect(() => {
    if (isIntegrationsTabActive && user) {
      checkUserGoogleIntegration()
    }
  }, [isIntegrationsTabActive, user])

  if (authLoading) {
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-4rem)]">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Configurações</h1>
        <p className="text-muted-foreground">Gerencie suas configurações e preferências</p>
      </div>

      <Tabs
        defaultValue="perfil"
        className="space-y-4"
        value={activeTab}
        onValueChange={(value) => setActiveTab(value)}
      >
        <TabsList className="overflow-x-auto flex w-full">
          <TabsTrigger value="perfil">Perfil</TabsTrigger>
          <TabsTrigger value="notificacoes">Notificações</TabsTrigger>
          <TabsTrigger value="seguranca">Segurança</TabsTrigger>
        </TabsList>

        <TabsContent value="perfil">
          <form onSubmit={handleSaveSettings}>
            <Card>
              <CardHeader>
                <CardTitle>Informações do Perfil</CardTitle>
                <CardDescription>Atualize suas informações pessoais e configurações de perfil</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex flex-col sm:flex-row gap-4">
                  <div className="space-y-2 flex-1">
                    <Label htmlFor="nome">Nome</Label>
                    <Input id="nome" defaultValue={user?.user_metadata?.name || ""} required />
                  </div>
                  <div className="space-y-2 flex-1">
                    <Label htmlFor="sobrenome">Sobrenome</Label>
                    <Input id="sobrenome" defaultValue="" required />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input id="email" type="email" defaultValue={user?.email || ""} disabled />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="telefone">Número de Telefone</Label>
                  <Input id="telefone" defaultValue="" required />
                </div>
              </CardContent>
              <CardFooter className="flex justify-end">
                <Button type="submit" disabled={isLoading}>
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Salvando...
                    </>
                  ) : (
                    "Salvar Alterações"
                  )}
                </Button>
              </CardFooter>
            </Card>
          </form>
        </TabsContent>

        <TabsContent value="notificacoes">
          <Card>
            <CardHeader>
              <CardTitle>Preferências de Notificação</CardTitle>
              <CardDescription>Configure como e quando deseja receber notificações</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="email-notif">Notificações por Email</Label>
                  <p className="text-sm text-muted-foreground">Receber notificações por email</p>
                </div>
                <Switch id="email-notif" defaultChecked />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="push-notif">Notificações Push</Label>
                  <p className="text-sm text-muted-foreground">Receber notificações no navegador</p>
                </div>
                <Switch id="push-notif" defaultChecked />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="sms-notif">Notificações por SMS</Label>
                  <p className="text-sm text-muted-foreground">Receber notificações por SMS</p>
                </div>
                <Switch id="sms-notif" />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="agendamentos-notif">Lembretes de Agendamentos</Label>
                  <p className="text-sm text-muted-foreground">Receber lembretes de agendamentos</p>
                </div>
                <Switch id="agendamentos-notif" defaultChecked />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="mensagens-notif">Novas Mensagens</Label>
                  <p className="text-sm text-muted-foreground">Receber notificações de novas mensagens</p>
                </div>
                <Switch id="mensagens-notif" defaultChecked />
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button>Salvar Preferências</Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="seguranca">
          <Card>
            <CardHeader>
              <CardTitle>Segurança</CardTitle>
              <CardDescription>Gerencie sua senha e configurações de segurança</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="current-password">Senha Atual</Label>
                <Input id="current-password" type="password" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="new-password">Nova Senha</Label>
                <Input id="new-password" type="password" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirm-password">Confirmar Nova Senha</Label>
                <Input id="confirm-password" type="password" />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="two-factor">Autenticação de Dois Fatores</Label>
                  <p className="text-sm text-muted-foreground">Adicione uma camada extra de segurança</p>
                </div>
                <Switch id="two-factor" />
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button>Atualizar Senha</Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
