"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { RefreshCw, Plus, User, Loader2 } from "lucide-react"
import { ProfilesList } from "@/components/profiles/profiles-list"
import { CreateProfileModal } from "@/components/profiles/create-profile-modal"
import { useAuth } from "@/hooks/use-auth"
import { usePermissions } from "@/hooks/use-permissions"
import { useToast } from "@/hooks/use-toast"

export default function PerfisPage() {
  const [refreshKey, setRefreshKey] = useState(0)
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false)
  const [isCreatingProfile, setIsCreatingProfile] = useState(false)
  const [profilesCount, setProfilesCount] = useState(0)

  const { user } = useAuth()
  const { toast } = useToast()
  const { planStatus, loading: planLoading, error: planError, permissions, limits, usage } = usePermissions()

  // Função para atualizar a página
  const handleRefresh = () => {
    console.log("🔄 Atualizando página de perfis...")
    setRefreshKey((prev) => prev + 1)
  }

  // Função para criar novo perfil
  const handleCreateProfile = () => {
    if (!permissions.canCreateProfile.allowed) {
      toast({
        title: "Limite atingido",
        description: permissions.canCreateProfile.reason,
        variant: "destructive",
      })
      return
    }

    console.log("➕ Abrindo modal de criação de perfil...")
    setIsCreateModalOpen(true)
  }

  // Função para lidar com sucesso da criação
  const handleCreateModalSuccess = async () => {
    console.log("✅ Perfil criado com sucesso")
    setIsCreateModalOpen(false)
    setIsCreatingProfile(false)
    handleRefresh()
    toast({
      title: "Sucesso",
      description: "Perfil criado com sucesso",
    })
  }

  // Função para buscar contagem de perfis
  const fetchProfilesCount = async () => {
    if (!user?.id) return

    try {
      const response = await fetch(`/api/profiles?user_id=${user.id}`)
      if (response.ok) {
        const data = await response.json()
        setProfilesCount(data.profiles?.length || 0)
      }
    } catch (error) {
      console.error("❌ Erro ao buscar contagem de perfis:", error)
    }
  }

  // Carregar contagem de perfis quando o componente montar
  useEffect(() => {
    fetchProfilesCount()
  }, [user?.id, refreshKey])

  return (
    <div className="container mx-auto py-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Perfis Profissionais</h1>
          <p className="text-muted-foreground">Visualize seus perfis profissionais cadastrados</p>
        </div>
        <div className="flex items-center gap-2">
          <Button onClick={handleRefresh} variant="outline" className="flex items-center gap-2 bg-transparent">
            <RefreshCw className="h-4 w-4" />
            Atualizar
          </Button>
          <Button
            onClick={handleCreateProfile}
            disabled={planLoading || !permissions.canCreateProfile.allowed || isCreatingProfile}
            className="bg-red-500 hover:bg-red-600 text-white gap-2"
          >
            <Plus className="h-4 w-4" />
            {isCreatingProfile ? "Criando..." : "Novo Perfil"}
          </Button>
        </div>
      </div>

      {/* Informações do Plano */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            Informações do Plano
          </CardTitle>
        </CardHeader>
        <CardContent>
          {planLoading ? (
            <div className="flex items-center gap-2">
              <Loader2 className="h-4 w-4 animate-spin" />
              <span>Carregando informações do plano...</span>
            </div>
          ) : planStatus ? (
            <div className="flex items-center gap-4">
              <Badge variant="destructive" className="bg-red-500">
                {planStatus.planName}
              </Badge>
              <span className="text-sm">
                <span className="font-medium">{usage?.profiles_count || profilesCount}</span> de{" "}
                <span className="font-medium">{limits?.profiles_limit === -1 ? "∞" : limits?.profiles_limit || 0}</span>{" "}
                perfis utilizados
              </span>
              {limits?.profiles_limit !== -1 && (
                <span className="text-sm text-green-600">
                  <span className="font-medium">
                    {Math.max(0, (limits?.profiles_limit || 0) - (usage?.profiles_count || profilesCount))}
                  </span>{" "}
                  perfis disponíveis
                </span>
              )}
              {!permissions.canCreateProfile.allowed && (
                <Badge variant="destructive" className="bg-orange-500">
                  Limite atingido
                </Badge>
              )}
            </div>
          ) : (
            <span className="text-sm text-muted-foreground">Não foi possível carregar informações do plano</span>
          )}
        </CardContent>
      </Card>

      {/* Lista de Perfis */}
      <ProfilesList refreshKey={refreshKey} />

      {/* Modal de Criação */}
      <CreateProfileModal
        isOpen={isCreateModalOpen}
        onClose={() => {
          setIsCreateModalOpen(false)
          setIsCreatingProfile(false)
        }}
        onProfileCreated={handleCreateModalSuccess}
      />
    </div>
  )
}
