import { ProfileFormDebug } from "@/components/profiles/profile-form-debug"

export default function NovoPerfilDebugPage() {
  return (
    <div className="container mx-auto py-6">
      <div className="mb-6">
        <h1 className="text-3xl font-bold">Novo Perfil (Debug Mode)</h1>
        <p className="text-muted-foreground">
          Esta página inclui informações de debug para identificar problemas na criação de perfis.
        </p>
      </div>
      <ProfileFormDebug />
    </div>
  )
}
