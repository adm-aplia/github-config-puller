import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { WhatsAppManager } from "@/components/whatsapp/whatsapp-manager"

export default function WhatsAppPage() {
  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Integração WhatsApp</h1>
        <p className="text-muted-foreground">Conecte e gerencie seus números do WhatsApp</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Conexões WhatsApp</CardTitle>
          <CardDescription>Gerencie seus números de WhatsApp conectados</CardDescription>
        </CardHeader>
        <CardContent>
          <WhatsAppManager />
        </CardContent>
      </Card>
    </div>
  )
}
