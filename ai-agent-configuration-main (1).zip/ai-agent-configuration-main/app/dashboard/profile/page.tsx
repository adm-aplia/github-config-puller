"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { Separator } from "@/components/ui/separator"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useToast } from "@/hooks/use-toast"
import { Loader2, Camera } from "lucide-react"
import { ProfileAvatarEditor } from "@/components/profile-avatar-editor"
import { useSupabase } from "@/contexts/supabase-context"

export default function ProfilePage() {
  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null)
  const [isAvatarEditorOpen, setIsAvatarEditorOpen] = useState(false)
  const [profileData, setProfileData] = useState({
    name: "",
    lastName: "",
    email: "",
    phone: "",
    specialty: "",
  })

  const { toast } = useToast()
  const supabase = useSupabase()

  // Carregar dados do perfil ao iniciar
  useEffect(() => {
    async function loadProfile() {
      try {
        setIsLoading(true)

        // Obter usuário atual
        const {
          data: { user },
        } = await supabase.auth.getUser()

        if (!user) {
          throw new Error("Usuário não autenticado")
        }

        // Carregar perfil básico
        const { data: profileData, error: profileError } = await supabase
          .from("profiles")
          .select("*")
          .eq("id", user.id)
          .single()

        if (profileError && profileError.code !== "PGRST116") {
          console.error("Erro ao carregar perfil:", profileError)
          throw profileError
        }

        // Carregar perfil profissional (se existir)
        const { data: professionalData, error: professionalError } = await supabase
          .from("professional_profiles")
          .select("*")
          .eq("user_id", user.id)
          .single()

        if (professionalError && professionalError.code !== "PGRST116") {
          console.error("Erro ao carregar perfil profissional:", professionalError)
        }

        // Combinar dados
        const fullName = profileData?.name || user.user_metadata?.name || ""
        const nameParts = fullName.split(" ")
        const firstName = nameParts[0] || ""
        const lastName = nameParts.slice(1).join(" ") || ""

        setProfileData({
          name: firstName,
          lastName: lastName,
          email: profileData?.email || user.email || "",
          phone: professionalData?.phoneNumber || "",
          specialty: professionalData?.specialty || "",
        })

        // Carregar avatar
        setAvatarUrl(professionalData?.avatar_url || null)

        console.log("Perfil carregado:", { profileData, professionalData })
      } catch (error) {
        console.error("Erro ao carregar perfil:", error)
        toast({
          variant: "destructive",
          title: "Erro ao carregar perfil",
          description: "Não foi possível carregar seus dados. Tente novamente mais tarde.",
        })
      } finally {
        setIsLoading(false)
      }
    }

    loadProfile()
  }, [supabase, toast])

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSaving(true)

    try {
      // Obter usuário atual
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        throw new Error("Usuário não autenticado")
      }

      // Atualizar perfil básico
      const { error: profileError } = await supabase
        .from("profiles")
        .update({
          name: `${profileData.name} ${profileData.lastName}`.trim(),
          email: profileData.email,
          updated_at: new Date().toISOString(),
        })
        .eq("id", user.id)

      if (profileError) {
        throw profileError
      }

      // Verificar se já existe perfil profissional
      const { data: existingProfile } = await supabase
        .from("professional_profiles")
        .select("id")
        .eq("user_id", user.id)
        .single()

      if (existingProfile) {
        // Atualizar perfil profissional existente
        const { error: professionalError } = await supabase
          .from("professional_profiles")
          .update({
            fullName: `${profileData.name} ${profileData.lastName}`.trim(),
            email: profileData.email,
            phoneNumber: profileData.phone,
            specialty: profileData.specialty,
            avatar_url: avatarUrl,
            updated_at: new Date().toISOString(),
          })
          .eq("id", existingProfile.id)

        if (professionalError) {
          throw professionalError
        }
      } else {
        // Criar novo perfil profissional
        const { error: professionalError } = await supabase.from("professional_profiles").insert({
          user_id: user.id,
          fullName: `${profileData.name} ${profileData.lastName}`.trim(),
          email: profileData.email,
          phoneNumber: profileData.phone,
          specialty: profileData.specialty,
          avatar_url: avatarUrl,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        })

        if (professionalError) {
          throw professionalError
        }
      }

      toast({
        title: "Perfil atualizado",
        description: "Seu perfil foi atualizado com sucesso",
      })
    } catch (error: any) {
      console.error("Erro ao salvar perfil:", error)
      toast({
        variant: "destructive",
        title: "Algo deu errado",
        description: error.message || "Por favor, tente novamente mais tarde",
      })
    } finally {
      setIsSaving(false)
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { id, value } = e.target
    setProfileData((prev) => ({
      ...prev,
      [id === "first-name"
        ? "name"
        : id === "last-name"
          ? "lastName"
          : id === "phone"
            ? "phone"
            : id === "specialty"
              ? "specialty"
              : "email"]: value,
    }))
  }

  const handleAvatarChange = (newAvatarUrl: string) => {
    setAvatarUrl(newAvatarUrl)
  }

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Configurações de Perfil</h1>
        <p className="text-muted-foreground">Gerencie suas configurações de conta e preferências</p>
      </div>

      <Tabs defaultValue="profile" className="space-y-4">
        <TabsList>
          <TabsTrigger value="profile">Perfil</TabsTrigger>
          <TabsTrigger value="notifications">Notificações</TabsTrigger>
          <TabsTrigger value="security">Segurança</TabsTrigger>
        </TabsList>

        <TabsContent value="profile">
          <form onSubmit={handleSaveProfile}>
            <Card>
              <CardHeader>
                <CardTitle>Informações do Perfil</CardTitle>
                <CardDescription>Atualize suas informações pessoais e configurações de perfil</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex flex-col items-center space-y-4 sm:flex-row sm:space-y-0 sm:space-x-4">
                  <div className="relative group">
                    <Avatar className="h-24 w-24">
                      <AvatarImage src={avatarUrl || "/placeholder.svg?height=96&width=96"} alt="Perfil" />
                      <AvatarFallback>{profileData.name.substring(0, 2).toUpperCase()}</AvatarFallback>
                    </Avatar>
                    <button
                      type="button"
                      onClick={() => setIsAvatarEditorOpen(true)}
                      className="absolute inset-0 flex items-center justify-center bg-black/50 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <Camera className="h-6 w-6 text-white" />
                    </button>
                  </div>
                  <div className="space-y-2">
                    <Button type="button" variant="outline" size="sm" onClick={() => setIsAvatarEditorOpen(true)}>
                      Alterar Avatar
                    </Button>
                    <p className="text-xs text-muted-foreground">JPG, GIF ou PNG. Tamanho máximo de 2MB.</p>
                  </div>
                </div>

                <Separator />

                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="first-name">Nome</Label>
                    <Input id="first-name" value={profileData.name} onChange={handleInputChange} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="last-name">Sobrenome</Label>
                    <Input id="last-name" value={profileData.lastName} onChange={handleInputChange} />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input id="email" type="email" value={profileData.email} onChange={handleInputChange} />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone">Número de Telefone</Label>
                  <Input id="phone" type="tel" value={profileData.phone} onChange={handleInputChange} />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="specialty">Especialidade Médica</Label>
                  <Input id="specialty" value={profileData.specialty} onChange={handleInputChange} />
                </div>
              </CardContent>
              <CardFooter className="flex justify-end">
                <Button type="submit" disabled={isSaving}>
                  {isSaving ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Salvando...
                    </>
                  ) : (
                    "Salvar Alterações"
                  )}
                </Button>
              </CardFooter>
            </Card>
          </form>
        </TabsContent>

        <TabsContent value="notifications">
          <Card>
            <CardHeader>
              <CardTitle>Configurações de Notificações</CardTitle>
              <CardDescription>Configure como e quando você recebe notificações</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Notificações por Email</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="email-new-conversation">Novas conversas</Label>
                    <Switch id="email-new-conversation" defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="email-agent-status">Mudanças de status do agente</Label>
                    <Switch id="email-agent-status" defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="email-whatsapp-connection">Problemas de conexão do WhatsApp</Label>
                    <Switch id="email-whatsapp-connection" defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="email-weekly-summary">Relatórios semanais</Label>
                    <Switch id="email-weekly-summary" defaultChecked />
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <h3 className="text-lg font-medium">Notificações do Navegador</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="browser-new-message">Novas mensagens</Label>
                    <Switch id="browser-new-message" defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="browser-agent-alert">Alertas de agente</Label>
                    <Switch id="browser-agent-alert" defaultChecked />
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button type="button">Salvar Preferências</Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="security">
          <Card>
            <CardHeader>
              <CardTitle>Configurações de Segurança</CardTitle>
              <CardDescription>Gerencie sua senha e preferências de segurança</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Alterar Senha</h3>
                <div className="space-y-3">
                  <div className="space-y-2">
                    <Label htmlFor="current-password">Senha Atual</Label>
                    <Input id="current-password" type="password" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="new-password">Nova Senha</Label>
                    <Input id="new-password" type="password" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="confirm-password">Confirmar Nova Senha</Label>
                    <Input id="confirm-password" type="password" />
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <h3 className="text-lg font-medium">Autenticação de Dois Fatores</h3>
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="two-factor" className="block mb-1">
                      Ativar Autenticação de Dois Fatores
                    </Label>
                    <p className="text-sm text-muted-foreground">
                      Adicione uma camada extra de segurança à sua conta com autenticação de dois fatores.
                    </p>
                  </div>
                  <Switch id="two-factor" />
                </div>
                <div className="space-y-2 mt-4">
                  <Button type="button" variant="outline" className="w-full sm:w-auto">
                    Configurar Autenticação de Dois Fatores
                  </Button>
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <h3 className="text-lg font-medium">Gerenciamento de Sessão</h3>
                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground">
                    Você está atualmente conectado em 2 dispositivos. Você pode sair de todas as outras sessões, exceto
                    a atual.
                  </p>
                  <Button type="button" variant="outline" className="w-full sm:w-auto">
                    Sair de Todos os Outros Dispositivos
                  </Button>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button type="button">Salvar Configurações de Segurança</Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>

      <ProfileAvatarEditor
        open={isAvatarEditorOpen}
        onOpenChange={setIsAvatarEditorOpen}
        onAvatarChange={handleAvatarChange}
      />
    </div>
  )
}
