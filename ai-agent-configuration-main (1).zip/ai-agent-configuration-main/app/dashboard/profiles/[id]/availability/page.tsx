"use client"

import { useState } from "react"
import { useRouter, useParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar } from "@/components/ui/calendar"
import { useToast } from "@/hooks/use-toast"
import { ArrowLeft, Loader2, Plus, Trash2 } from "lucide-react"
import { Badge } from "@/components/ui/badge"

export default function ProfileAvailabilityPage() {
  const router = useRouter()
  const params = useParams()
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(false)
  const [date, setDate] = useState<Date | undefined>(new Date())
  const [exceptions, setExceptions] = useState<
    Array<{
      id: string
      startDate: string
      endDate: string
      reason: string
    }>
  >([
    {
      id: "1",
      startDate: "2023-12-24",
      endDate: "2023-12-25",
      reason: "Natal",
    },
    {
      id: "2",
      startDate: "2023-12-31",
      endDate: "2024-01-01",
      reason: "Ano Novo",
    },
  ])

  const [newException, setNewException] = useState({
    startDate: "",
    endDate: "",
    reason: "",
  })

  const addException = () => {
    if (!newException.startDate || !newException.endDate || !newException.reason) {
      toast({
        variant: "destructive",
        title: "Campos obrigatórios",
        description: "Preencha todos os campos para adicionar uma exceção",
      })
      return
    }

    setExceptions([
      ...exceptions,
      {
        id: Date.now().toString(),
        ...newException,
      },
    ])

    setNewException({
      startDate: "",
      endDate: "",
      reason: "",
    })

    toast({
      title: "Exceção adicionada",
      description: "A exceção foi adicionada com sucesso",
    })
  }

  const removeException = (id: string) => {
    setExceptions(exceptions.filter((exception) => exception.id !== id))

    toast({
      title: "Exceção removida",
      description: "A exceção foi removida com sucesso",
    })
  }

  const handleSave = async () => {
    setIsLoading(true)

    try {
      // Simulação de envio para API
      await new Promise((resolve) => setTimeout(resolve, 1500))

      toast({
        title: "Disponibilidade atualizada",
        description: "As configurações de disponibilidade foram atualizadas com sucesso",
      })
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Erro ao salvar",
        description: "Ocorreu um erro ao salvar as configurações de disponibilidade",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="sm" onClick={() => router.push(`/dashboard/profiles/${params.id}`)}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Voltar
        </Button>
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Gerenciar Disponibilidade</h1>
          <p className="text-muted-foreground">Configure os dias e horários de disponibilidade do profissional</p>
        </div>
      </div>

      <Tabs defaultValue="calendar" className="space-y-6">
        <TabsList>
          <TabsTrigger value="calendar">Calendário</TabsTrigger>
          <TabsTrigger value="exceptions">Exceções</TabsTrigger>
          <TabsTrigger value="settings">Configurações</TabsTrigger>
        </TabsList>

        <TabsContent value="calendar">
          <Card>
            <CardHeader>
              <CardTitle>Calendário de Disponibilidade</CardTitle>
              <CardDescription>Visualize e gerencie a disponibilidade do profissional</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col md:flex-row gap-6">
                <div className="md:w-1/2">
                  <Calendar mode="single" selected={date} onSelect={setDate} className="rounded-md border" />
                </div>

                <div className="md:w-1/2 space-y-4">
                  <h3 className="font-medium">Detalhes do dia selecionado</h3>

                  {date && (
                    <>
                      <p className="text-sm">
                        {date.toLocaleDateString("pt-BR", {
                          weekday: "long",
                          year: "numeric",
                          month: "long",
                          day: "numeric",
                        })}
                      </p>

                      <div className="space-y-4 mt-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="morning-start">Manhã - Início</Label>
                            <Select defaultValue="08:00">
                              <SelectTrigger id="morning-start">
                                <SelectValue placeholder="Selecione" />
                              </SelectTrigger>
                              <SelectContent>
                                {["", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30", "10:00"].map((time) => (
                                  <SelectItem key={time} value={time}>
                                    {time || "Não atende"}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="morning-end">Manhã - Fim</Label>
                            <Select defaultValue="12:00">
                              <SelectTrigger id="morning-end">
                                <SelectValue placeholder="Selecione" />
                              </SelectTrigger>
                              <SelectContent>
                                {["", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00"].map((time) => (
                                  <SelectItem key={time} value={time}>
                                    {time || "Não atende"}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="afternoon-start">Tarde - Início</Label>
                            <Select defaultValue="14:00">
                              <SelectTrigger id="afternoon-start">
                                <SelectValue placeholder="Selecione" />
                              </SelectTrigger>
                              <SelectContent>
                                {["", "13:00", "13:30", "14:00", "14:30", "15:00", "15:30"].map((time) => (
                                  <SelectItem key={time} value={time}>
                                    {time || "Não atende"}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="afternoon-end">Tarde - Fim</Label>
                            <Select defaultValue="18:00">
                              <SelectTrigger id="afternoon-end">
                                <SelectValue placeholder="Selecione" />
                              </SelectTrigger>
                              <SelectContent>
                                {["", "16:00", "16:30", "17:00", "17:30", "18:00", "18:30", "19:00"].map((time) => (
                                  <SelectItem key={time} value={time}>
                                    {time || "Não atende"}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="day-note">Observação para este dia</Label>
                          <Textarea id="day-note" placeholder="Ex: Apenas consultas de retorno neste dia" rows={2} />
                        </div>

                        <div className="flex justify-end">
                          <Button>Salvar Alterações</Button>
                        </div>
                      </div>
                    </>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="exceptions">
          <Card>
            <CardHeader>
              <CardTitle>Exceções de Disponibilidade</CardTitle>
              <CardDescription>Adicione períodos em que o profissional não estará disponível</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="exception-start">Data de início</Label>
                    <Input
                      type="date"
                      id="exception-start"
                      value={newException.startDate}
                      onChange={(e) =>
                        setNewException({
                          ...newException,
                          startDate: e.target.value,
                        })
                      }
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="exception-end">Data de fim</Label>
                    <Input
                      type="date"
                      id="exception-end"
                      value={newException.endDate}
                      onChange={(e) =>
                        setNewException({
                          ...newException,
                          endDate: e.target.value,
                        })
                      }
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="exception-reason">Motivo</Label>
                    <Input
                      id="exception-reason"
                      placeholder="Ex: Férias, Congresso, etc."
                      value={newException.reason}
                      onChange={(e) =>
                        setNewException({
                          ...newException,
                          reason: e.target.value,
                        })
                      }
                    />
                  </div>
                </div>

                <Button type="button" onClick={addException} className="gap-2">
                  <Plus className="h-4 w-4" />
                  Adicionar Exceção
                </Button>
              </div>

              <div className="space-y-4">
                <h3 className="font-medium">Exceções cadastradas</h3>

                {exceptions.length === 0 ? (
                  <p className="text-sm text-muted-foreground">Nenhuma exceção cadastrada</p>
                ) : (
                  <div className="space-y-2">
                    {exceptions.map((exception) => (
                      <div key={exception.id} className="flex items-center justify-between p-3 border rounded-md">
                        <div className="flex items-center gap-3">
                          <Badge variant="outline">
                            {new Date(exception.startDate).toLocaleDateString("pt-BR")} a{" "}
                            {new Date(exception.endDate).toLocaleDateString("pt-BR")}
                          </Badge>
                          <span className="text-sm">{exception.reason}</span>
                        </div>

                        <Button variant="ghost" size="sm" onClick={() => removeException(exception.id)}>
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings">
          <Card>
            <CardHeader>
              <CardTitle>Configurações de Disponibilidade</CardTitle>
              <CardDescription>Configure as regras gerais de disponibilidade</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="appointment-duration">Duração padrão das consultas (minutos)</Label>
                <Select defaultValue="30">
                  <SelectTrigger id="appointment-duration">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    {["15", "20", "30", "40", "45", "60"].map((duration) => (
                      <SelectItem key={duration} value={duration}>
                        {duration} minutos
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="min-advance">Antecedência mínima para agendamento (horas)</Label>
                <Select defaultValue="24">
                  <SelectTrigger id="min-advance">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    {["2", "4", "6", "12", "24", "48", "72"].map((hours) => (
                      <SelectItem key={hours} value={hours}>
                        {hours} horas
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="max-advance">Antecedência máxima para agendamento (dias)</Label>
                <Select defaultValue="60">
                  <SelectTrigger id="max-advance">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    {["7", "15", "30", "45", "60", "90", "120"].map((days) => (
                      <SelectItem key={days} value={days}>
                        {days} dias
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="buffer-time">Tempo de intervalo entre consultas (minutos)</Label>
                <Select defaultValue="10">
                  <SelectTrigger id="buffer-time">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    {["0", "5", "10", "15", "20", "30"].map((minutes) => (
                      <SelectItem key={minutes} value={minutes}>
                        {minutes} minutos
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="availability-notes">Observações gerais sobre disponibilidade</Label>
                <Textarea
                  id="availability-notes"
                  placeholder="Ex: Preferência para primeiras consultas pela manhã"
                  rows={3}
                />
              </div>
            </CardContent>
            <CardFooter>
              <Button className="ml-auto" onClick={handleSave} disabled={isLoading}>
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Salvando...
                  </>
                ) : (
                  "Salvar Configurações"
                )}
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
