"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { Loader2, ArrowLeft } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import Link from "next/link"
import { useSupabase } from "@/contexts/supabase-context"
import { useAuth } from "@/components/auth-provider"
import { notFound } from "next/navigation"

interface ProfileDetailsProps {
  params: { id: string }
}

export default function ProfileDetailsPage({ params }: ProfileDetailsProps) {
  const [profile, setProfile] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const { toast } = useToast()
  const { supabase } = useSupabase()
  const { user, isAuthenticated, isInitialized } = useAuth()
  const id = params.id

  useEffect(() => {
    if (id === "new") {
      notFound()
    } else if (isInitialized && isAuthenticated && user && supabase) {
      fetchProfile()
    }
  }, [id, isInitialized, isAuthenticated, user, supabase])

  const fetchProfile = async () => {
    try {
      setIsLoading(true)
      console.log("🔍 Buscando perfil:", id, "para usuário:", user?.id)

      const { data, error } = await supabase
        .from("professional_profiles")
        .select("*")
        .eq("id", id)
        .eq("user_id", user?.id)
        .single()

      if (error) {
        console.error("❌ Erro na query:", error)
        throw new Error("Falha ao carregar perfil")
      }

      console.log("✅ Perfil encontrado:", data)
      setProfile(data)
    } catch (err: any) {
      console.error("Erro ao carregar perfil:", err)
      setError(err.message || "Erro ao carregar perfil")
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Não foi possível carregar os dados do perfil.",
      })
    } finally {
      setIsLoading(false)
    }
  }

  if (!isInitialized || isLoading) {
    return (
      <div className="container mx-auto py-8">
        <div className="flex justify-center items-center py-12">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </div>
    )
  }

  if (!isAuthenticated) {
    return (
      <div className="container mx-auto py-8">
        <div className="text-center py-8">
          <p className="text-muted-foreground">Você precisa estar logado para ver este perfil</p>
        </div>
      </div>
    )
  }

  if (error || !profile) {
    return (
      <div className="container mx-auto py-8">
        <div className="text-center py-8">
          <p className="text-red-500">{error || "Perfil não encontrado"}</p>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-8">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon" asChild>
            <Link href="/dashboard/perfis">
              <ArrowLeft className="h-4 w-4" />
            </Link>
          </Button>
          <h1 className="text-3xl font-bold">{profile.fullName}</h1>
        </div>
      </div>

      <div className="mb-4">
        <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
          <p className="text-sm text-yellow-800">
            <strong>Aviso:</strong> Funcionalidade de edição temporariamente indisponível para manutenção.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle>Perfil</CardTitle>
            </CardHeader>
            <CardContent className="flex flex-col items-center">
              <h2 className="text-xl font-bold">{profile.fullName}</h2>
              <p className="text-muted-foreground">{profile.specialty || "Sem especialidade"}</p>
              <p className="text-sm mt-2">{profile.professionalId || ""}</p>
            </CardContent>
          </Card>
        </div>

        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Informações Gerais</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">E-mail</h3>
                <p>{profile.email || "Não informado"}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">Telefone</h3>
                <p>{profile.phoneNumber || "Não informado"}</p>
              </div>
            </div>

            <Separator />

            <div>
              <h3 className="text-sm font-medium text-muted-foreground">Formação Acadêmica</h3>
              <p className="whitespace-pre-line">{profile.education || "Não informado"}</p>
            </div>

            <Separator />

            <div>
              <h3 className="text-sm font-medium text-muted-foreground">Procedimentos Realizados</h3>
              <p className="whitespace-pre-line">{profile.procedures || "Não informado"}</p>
            </div>

            <Separator />

            <div>
              <h3 className="text-sm font-medium text-muted-foreground">Locais de Atendimento</h3>
              <p className="whitespace-pre-line">{profile.locations || "Não informado"}</p>
            </div>

            <Separator />

            <div>
              <h3 className="text-sm font-medium text-muted-foreground">Horários de Atendimento</h3>
              <p className="whitespace-pre-line">{profile.workingHours || "Não informado"}</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
