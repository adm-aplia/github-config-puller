"use client"

import { useState, useEffect } from "react"
import { useRouter, useParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import {
  Loader2,
  ChevronLeft,
  ChevronRight,
  User,
  MapPin,
  CreditCard,
  Calendar,
  FileText,
  MessageSquare,
  X,
} from "lucide-react"
import { useSupabase } from "@/contexts/supabase-context"
import { supabase } from "@/lib/supabase"

interface FormData {
  // Etapa 1: Informações Básicas
  fullName: string
  specialty: string
  professionalId: string
  phoneNumber: string
  email: string
  education: string

  // Etapa 2: Localização e Atendimento
  locations: string
  workingHours: string
  procedures: string

  // Etapa 3: Planos e Pagamento
  healthInsurance: string
  paymentMethods: string
  consultationFees: string
  cancellationPolicy: string

  // Etapa 4: Agendamento e Políticas
  consultationDuration: string
  timeBetweenConsultations: string
  reschedulingPolicy: string
  onlineConsultations: string
  reminderPreferences: string

  // Etapa 5: Requisitos do Paciente
  requiredPatientInfo: string
  appointmentConditions: string
  medicalHistoryRequirements: string
  ageRequirements: string

  // Etapa 6: Comunicação e Documentos
  communicationChannels: string
  preAppointmentInfo: string
  requiredDocuments: string
  additionalInfo: string
}

const STEPS = [
  { id: 1, title: "Informações Básicas", icon: User, description: "Dados pessoais e profissionais" },
  { id: 2, title: "Localização e Atendimento", icon: MapPin, description: "Local e horários de trabalho" },
  { id: 3, title: "Planos e Pagamento", icon: CreditCard, description: "Convênios e formas de pagamento" },
  { id: 4, title: "Agendamento e Políticas", icon: Calendar, description: "Regras de agendamento" },
  { id: 5, title: "Requisitos do Paciente", icon: FileText, description: "Informações necessárias" },
  { id: 6, title: "Comunicação e Documentos", icon: MessageSquare, description: "Canais e documentos" },
]

// Função para enviar webhook
async function sendWebhook(data: any, action: "create" | "update" | "delete") {
  try {
    const webhookUrl = "https://aplia-n8n-webhook.kopfcf.easypanel.host/webhook/questionario"

    console.log(`📤 Enviando webhook ${action} para:`, webhookUrl)

    const controller = new AbortController()
    const timeoutId = setTimeout(() => controller.abort(), 10000) // 10 segundos timeout

    const webhookPayload = {
      ...data,
      action,
      timestamp: new Date().toISOString(),
    }

    console.log(`📤 Payload do webhook ${action}:`, JSON.stringify(webhookPayload, null, 2))

    const webhookResponse = await fetch(webhookUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "User-Agent": "Aplia-Medical-AI/1.0",
        "X-Webhook-Event": `profile.${action}`,
      },
      body: JSON.stringify(webhookPayload),
      signal: controller.signal,
    })

    clearTimeout(timeoutId)

    if (webhookResponse.ok) {
      console.log(`✅ Webhook ${action} enviado com sucesso!`)
      const responseText = await webhookResponse.text()
      console.log(`✅ Resposta do webhook ${action}:`, responseText)
    } else {
      console.warn(`⚠️ Webhook ${action} retornou status ${webhookResponse.status}: ${webhookResponse.statusText}`)
    }
  } catch (webhookError: any) {
    if (webhookError.name === "AbortError") {
      console.warn(`⏱️ Webhook ${action} timeout - continuando sem webhook`)
    } else {
      console.warn(`⚠️ Erro ao enviar webhook ${action} (não crítico):`, webhookError.message)
    }
  }
}

export default function EditProfilePage() {
  const router = useRouter()
  const params = useParams()
  const profileId = params.id as string

  const [currentStep, setCurrentStep] = useState(1)
  const [isSaving, setIsSaving] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [isUserLoading, setIsUserLoading] = useState(true)
  const [currentUser, setCurrentUser] = useState<any>(null)
  const [isOpen, setIsOpen] = useState(true)
  const [formData, setFormData] = useState<FormData>({
    // Etapa 1: Informações Básicas
    fullName: "",
    specialty: "",
    professionalId: "",
    phoneNumber: "",
    email: "",
    education: "",

    // Etapa 2: Localização e Atendimento
    locations: "",
    workingHours: "",
    procedures: "",

    // Etapa 3: Planos e Pagamento
    healthInsurance: "",
    paymentMethods: "",
    consultationFees: "",
    cancellationPolicy: "",

    // Etapa 4: Agendamento e Políticas
    consultationDuration: "",
    timeBetweenConsultations: "",
    reschedulingPolicy: "",
    onlineConsultations: "",
    reminderPreferences: "",

    // Etapa 5: Requisitos do Paciente
    requiredPatientInfo: "",
    appointmentConditions: "",
    medicalHistoryRequirements: "",
    ageRequirements: "",

    // Etapa 6: Comunicação e Documentos
    communicationChannels: "",
    preAppointmentInfo: "",
    requiredDocuments: "",
    additionalInfo: "",
  })

  const { toast } = useToast()
  const { user: contextUser, isInitialized } = useSupabase()

  // Método alternativo para obter usuário diretamente do Supabase
  useEffect(() => {
    const getCurrentUser = async () => {
      try {
        console.log("🔍 Edit Page - Obtendo usuário atual...")

        // Método 1: Tentar do contexto primeiro
        console.log("👤 Context User:", contextUser)

        // Método 2: Obter diretamente do Supabase
        const {
          data: { user },
          error,
        } = await supabase.auth.getUser()
        console.log("🔑 User direto do Supabase:", user)
        console.log("❌ Erro (se houver):", error)

        // Método 3: Obter da sessão
        const {
          data: { session },
          error: sessionError,
        } = await supabase.auth.getSession()
        console.log("📱 Session:", session?.user)
        console.log("❌ Session Error (se houver):", sessionError)

        // Usar o primeiro método que funcionar
        let finalUser = null

        if (contextUser?.id) {
          console.log("✅ Usando user do contexto")
          finalUser = contextUser
        } else if (user?.id) {
          console.log("✅ Usando user direto do Supabase")
          finalUser = user
        } else if (session?.user?.id) {
          console.log("✅ Usando user da sessão")
          finalUser = session.user
        }

        if (finalUser) {
          console.log("🎉 Usuário encontrado:", {
            id: finalUser.id,
            email: finalUser.email,
            method: contextUser?.id ? "context" : user?.id ? "direct" : "session",
          })
          setCurrentUser(finalUser)
        } else {
          console.log("❌ Nenhum usuário encontrado em nenhum método")
        }
      } catch (error) {
        console.error("❌ Erro ao obter usuário:", error)
      } finally {
        setIsUserLoading(false)
      }
    }

    getCurrentUser()
  }, [contextUser, isInitialized])

  // Carregar dados do perfil quando o usuário for carregado
  useEffect(() => {
    if (profileId && !isUserLoading) {
      loadProfileData()
    }
  }, [profileId, isUserLoading])

  const loadProfileData = async () => {
    try {
      setIsLoading(true)
      console.log("📥 Carregando dados do perfil:", profileId)

      const response = await fetch(`/api/profiles?id=${profileId}`)
      if (!response.ok) {
        throw new Error("Erro ao carregar perfil")
      }

      const result = await response.json()
      const profile = result.data

      console.log("✅ Perfil carregado:", profile)

      // Preencher o formulário com os dados do perfil
      setFormData({
        fullName: profile.fullName || "",
        specialty: profile.specialty || "",
        professionalId: profile.professionalId || "",
        phoneNumber: profile.phoneNumber || "",
        email: profile.email || "",
        education: profile.education || "",
        locations: profile.locations || "",
        workingHours: profile.workingHours || "",
        procedures: profile.procedures || "",
        healthInsurance: profile.healthInsurance || "",
        paymentMethods: profile.paymentMethods || "",
        consultationFees: profile.consultationFees || "",
        cancellationPolicy: profile.cancellationPolicy || "",
        consultationDuration: profile.consultationDuration || "",
        timeBetweenConsultations: profile.timeBetweenConsultations || "",
        reschedulingPolicy: profile.reschedulingPolicy || "",
        onlineConsultations: profile.onlineConsultations || "",
        reminderPreferences: profile.reminderPreferences || "",
        requiredPatientInfo: profile.requiredPatientInfo || "",
        appointmentConditions: profile.appointmentConditions || "",
        medicalHistoryRequirements: profile.medicalHistoryRequirements || "",
        ageRequirements: profile.ageRequirements || "",
        communicationChannels: profile.communicationChannels || "",
        preAppointmentInfo: profile.preAppointmentInfo || "",
        requiredDocuments: profile.requiredDocuments || "",
        additionalInfo: profile.additionalInfo || "",
      })
    } catch (error: any) {
      console.error("❌ Erro ao carregar perfil:", error)
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Não foi possível carregar os dados do perfil.",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleInputChange = (field: keyof FormData, value: string) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  const nextStep = () => {
    if (currentStep < STEPS.length) {
      setCurrentStep(currentStep + 1)
    }
  }

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1)
    }
  }

  const handleClose = () => {
    setIsOpen(false)
    router.push("/dashboard/perfis")
  }

  const handleSave = async () => {
    console.log("🚀 Iniciando atualização de perfil...")
    console.log("📋 Dados do formulário:", formData)
    console.log("📝 Profile ID:", profileId)

    // Debug detalhado do usuário
    console.log("🔍 Debug detalhado do usuário:")
    console.log("👤 Context User:", JSON.stringify(contextUser, null, 2))
    console.log("🔑 Current User:", JSON.stringify(currentUser, null, 2))
    console.log("✅ isInitialized:", isInitialized)
    console.log("⏳ isUserLoading:", isUserLoading)

    // Validações básicas - apenas campos obrigatórios
    if (!formData.fullName.trim()) {
      console.log("❌ Validação falhou: Nome completo vazio")
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Nome completo é obrigatório.",
      })
      setCurrentStep(1)
      return
    }

    if (!formData.specialty.trim()) {
      console.log("❌ Validação falhou: Especialidade vazia")
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Especialidade é obrigatória.",
      })
      setCurrentStep(1)
      return
    }

    // Validação melhorada do usuário - usar currentUser ao invés de contextUser
    const userToUse = currentUser || contextUser

    if (!userToUse?.id) {
      console.log("❌ Validação falhou: Usuário não encontrado")
      console.log("🔍 Tentando obter usuário novamente...")

      try {
        const {
          data: { user },
          error,
        } = await supabase.auth.getUser()
        if (user?.id) {
          console.log("✅ Usuário obtido na segunda tentativa:", user.id)
          setCurrentUser(user)
          // Continuar com o usuário obtido
        } else {
          console.log("❌ Usuário ainda não encontrado na segunda tentativa")
          toast({
            variant: "destructive",
            title: "Erro de Autenticação",
            description: "Usuário não autenticado. Faça login novamente.",
          })
          return
        }
      } catch (error) {
        console.error("❌ Erro ao obter usuário na segunda tentativa:", error)
        toast({
          variant: "destructive",
          title: "Erro de Autenticação",
          description: "Não foi possível verificar a autenticação. Tente novamente.",
        })
        return
      }
    }

    if (!profileId) {
      console.log("❌ Validação falhou: ID do perfil não fornecido")
      toast({
        variant: "destructive",
        title: "Erro",
        description: "ID do perfil não encontrado.",
      })
      return
    }

    const finalUser = currentUser || contextUser

    try {
      setIsSaving(true)
      console.log("💾 Atualizando perfil:", profileId, "para usuário:", finalUser.id)

      // Usar a API route para atualizar o perfil
      const response = await fetch("/api/profiles/save", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          id: profileId,
          user_id: finalUser.id,
          ...formData,
        }),
      })

      console.log("📡 Resposta da API:", response.status, response.statusText)

      if (!response.ok) {
        const errorData = await response.json()
        console.error("❌ Erro da API:", errorData)
        throw new Error(errorData.error || "Erro ao atualizar perfil")
      }

      const result = await response.json()
      console.log("✅ Perfil atualizado com sucesso:", result)

      // Preparar dados para webhook
      const webhookData = {
        id: profileId,
        user_id: finalUser.id,
        ...formData,
        updated_at: new Date().toISOString(),
      }

      // Enviar webhook após sucesso
      try {
        await sendWebhook(webhookData, "update")
      } catch (webhookError) {
        console.error("⚠️ Erro no webhook (não crítico):", webhookError)
      }

      toast({
        title: "Sucesso",
        description: "Perfil atualizado com sucesso!",
      })

      // Redirecionar para a lista de perfis
      router.push("/dashboard/perfis")
    } catch (error: any) {
      console.error("❌ Erro ao atualizar perfil:", error)
      toast({
        variant: "destructive",
        title: "Erro",
        description: error.message || "Não foi possível atualizar o perfil.",
      })
    } finally {
      setIsSaving(false)
    }
  }

  const renderStepContent = () => {
    const currentStepData = STEPS[currentStep - 1]
    const IconComponent = currentStepData.icon

    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                <IconComponent className="h-5 w-5 text-orange-600" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900">Informações Básicas</h3>
                <p className="text-sm text-gray-500">Dados pessoais e profissionais</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="fullName" className="text-sm font-medium text-gray-700">
                  Nome Completo <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="fullName"
                  value={formData.fullName}
                  onChange={(e) => handleInputChange("fullName", e.target.value)}
                  placeholder="Seu nome completo"
                  className="w-full"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="specialty" className="text-sm font-medium text-gray-700">
                  Especialidade <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="specialty"
                  value={formData.specialty}
                  onChange={(e) => handleInputChange("specialty", e.target.value)}
                  placeholder="Sua especialidade médica"
                  className="w-full"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="professionalId" className="text-sm font-medium text-gray-700">
                  Registro Profissional
                </Label>
                <Input
                  id="professionalId"
                  value={formData.professionalId}
                  onChange={(e) => handleInputChange("professionalId", e.target.value)}
                  placeholder="CRM, CRO, etc."
                  className="w-full"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="phoneNumber" className="text-sm font-medium text-gray-700">
                  Telefone
                </Label>
                <Input
                  id="phoneNumber"
                  value={formData.phoneNumber}
                  onChange={(e) => handleInputChange("phoneNumber", e.target.value)}
                  placeholder="(11) 99999-9999"
                  className="w-full"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="email" className="text-sm font-medium text-gray-700">
                E-mail
              </Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => handleInputChange("email", e.target.value)}
                placeholder="seu@email.com"
                className="w-full"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="education" className="text-sm font-medium text-gray-700">
                Formação Acadêmica
              </Label>
              <Textarea
                id="education"
                value={formData.education}
                onChange={(e) => handleInputChange("education", e.target.value)}
                placeholder="Descreva sua formação acadêmica, residência, especializações..."
                rows={4}
                className="w-full"
              />
            </div>
          </div>
        )

      case 2:
        return (
          <div className="space-y-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                <IconComponent className="h-5 w-5 text-orange-600" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900">Localização e Atendimento</h3>
                <p className="text-sm text-gray-500">Local e horários de trabalho</p>
              </div>
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="locations" className="text-sm font-medium text-gray-700">
                  Locais de Atendimento
                </Label>
                <Textarea
                  id="locations"
                  value={formData.locations}
                  onChange={(e) => handleInputChange("locations", e.target.value)}
                  placeholder="Liste os locais onde você atende (clínicas, hospitais, consultório próprio...)"
                  rows={4}
                  className="w-full"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="workingHours" className="text-sm font-medium text-gray-700">
                  Horários de Atendimento
                </Label>
                <Textarea
                  id="workingHours"
                  value={formData.workingHours}
                  onChange={(e) => handleInputChange("workingHours", e.target.value)}
                  placeholder="Ex: Segunda a Sexta: 8h às 18h, Sábado: 8h às 12h"
                  rows={3}
                  className="w-full"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="procedures" className="text-sm font-medium text-gray-700">
                  Procedimentos e Tratamentos
                </Label>
                <Textarea
                  id="procedures"
                  value={formData.procedures}
                  onChange={(e) => handleInputChange("procedures", e.target.value)}
                  placeholder="Liste os principais procedimentos e tratamentos que você realiza..."
                  rows={5}
                  className="w-full"
                />
              </div>
            </div>
          </div>
        )

      case 3:
        return (
          <div className="space-y-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                <IconComponent className="h-5 w-5 text-orange-600" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900">Planos e Pagamento</h3>
                <p className="text-sm text-gray-500">Convênios e formas de pagamento</p>
              </div>
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="healthInsurance" className="text-sm font-medium text-gray-700">
                  Convênios Aceitos
                </Label>
                <Textarea
                  id="healthInsurance"
                  value={formData.healthInsurance}
                  onChange={(e) => handleInputChange("healthInsurance", e.target.value)}
                  placeholder="Liste os convênios que você aceita (Unimed, Bradesco Saúde, SulAmérica...)"
                  rows={4}
                  className="w-full"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="paymentMethods" className="text-sm font-medium text-gray-700">
                  Formas de Pagamento
                </Label>
                <Input
                  id="paymentMethods"
                  value={formData.paymentMethods}
                  onChange={(e) => handleInputChange("paymentMethods", e.target.value)}
                  placeholder="Dinheiro, Cartão, PIX, Transferência..."
                  className="w-full"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="consultationFees" className="text-sm font-medium text-gray-700">
                  Valores de Consulta
                </Label>
                <Textarea
                  id="consultationFees"
                  value={formData.consultationFees}
                  onChange={(e) => handleInputChange("consultationFees", e.target.value)}
                  placeholder="Descreva os valores para diferentes tipos de consulta..."
                  rows={4}
                  className="w-full"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="cancellationPolicy" className="text-sm font-medium text-gray-700">
                  Política de Cancelamento
                </Label>
                <Textarea
                  id="cancellationPolicy"
                  value={formData.cancellationPolicy}
                  onChange={(e) => handleInputChange("cancellationPolicy", e.target.value)}
                  placeholder="Descreva sua política de cancelamento e reagendamento..."
                  rows={4}
                  className="w-full"
                />
              </div>
            </div>
          </div>
        )

      case 4:
        return (
          <div className="space-y-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                <IconComponent className="h-5 w-5 text-orange-600" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900">Agendamento e Políticas</h3>
                <p className="text-sm text-gray-500">Regras de agendamento</p>
              </div>
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="consultationDuration" className="text-sm font-medium text-gray-700">
                    Duração da Consulta
                  </Label>
                  <Input
                    id="consultationDuration"
                    value={formData.consultationDuration}
                    onChange={(e) => handleInputChange("consultationDuration", e.target.value)}
                    placeholder="Ex: 30 minutos, 1 hora..."
                    className="w-full"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="timeBetweenConsultations" className="text-sm font-medium text-gray-700">
                    Intervalo Entre Consultas
                  </Label>
                  <Input
                    id="timeBetweenConsultations"
                    value={formData.timeBetweenConsultations}
                    onChange={(e) => handleInputChange("timeBetweenConsultations", e.target.value)}
                    placeholder="Ex: 15 minutos, 30 minutos..."
                    className="w-full"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="reschedulingPolicy" className="text-sm font-medium text-gray-700">
                  Política de Reagendamento
                </Label>
                <Textarea
                  id="reschedulingPolicy"
                  value={formData.reschedulingPolicy}
                  onChange={(e) => handleInputChange("reschedulingPolicy", e.target.value)}
                  placeholder="Descreva as regras para reagendamento de consultas..."
                  rows={4}
                  className="w-full"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="onlineConsultations" className="text-sm font-medium text-gray-700">
                  Consultas Online
                </Label>
                <Textarea
                  id="onlineConsultations"
                  value={formData.onlineConsultations}
                  onChange={(e) => handleInputChange("onlineConsultations", e.target.value)}
                  placeholder="Descreva se oferece consultas online e como funcionam..."
                  rows={3}
                  className="w-full"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="reminderPreferences" className="text-sm font-medium text-gray-700">
                  Preferências de Lembrete
                </Label>
                <Textarea
                  id="reminderPreferences"
                  value={formData.reminderPreferences}
                  onChange={(e) => handleInputChange("reminderPreferences", e.target.value)}
                  placeholder="Como você prefere lembrar os pacientes das consultas..."
                  rows={3}
                  className="w-full"
                />
              </div>
            </div>
          </div>
        )

      case 5:
        return (
          <div className="space-y-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                <IconComponent className="h-5 w-5 text-orange-600" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900">Requisitos do Paciente</h3>
                <p className="text-sm text-gray-500">Informações necessárias</p>
              </div>
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="requiredPatientInfo" className="text-sm font-medium text-gray-700">
                  Informações Necessárias do Paciente
                </Label>
                <Textarea
                  id="requiredPatientInfo"
                  value={formData.requiredPatientInfo}
                  onChange={(e) => handleInputChange("requiredPatientInfo", e.target.value)}
                  placeholder="Que informações você precisa do paciente antes da consulta..."
                  rows={4}
                  className="w-full"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="appointmentConditions" className="text-sm font-medium text-gray-700">
                  Condições para Agendamento
                </Label>
                <Textarea
                  id="appointmentConditions"
                  value={formData.appointmentConditions}
                  onChange={(e) => handleInputChange("appointmentConditions", e.target.value)}
                  placeholder="Condições especiais ou requisitos para agendar..."
                  rows={4}
                  className="w-full"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="medicalHistoryRequirements" className="text-sm font-medium text-gray-700">
                  Requisitos de Histórico Médico
                </Label>
                <Textarea
                  id="medicalHistoryRequirements"
                  value={formData.medicalHistoryRequirements}
                  onChange={(e) => handleInputChange("medicalHistoryRequirements", e.target.value)}
                  placeholder="Que informações do histórico médico são necessárias..."
                  rows={4}
                  className="w-full"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="ageRequirements" className="text-sm font-medium text-gray-700">
                  Requisitos de Idade
                </Label>
                <Input
                  id="ageRequirements"
                  value={formData.ageRequirements}
                  onChange={(e) => handleInputChange("ageRequirements", e.target.value)}
                  placeholder="Ex: Atende crianças a partir de 2 anos, apenas adultos..."
                  className="w-full"
                />
              </div>
            </div>
          </div>
        )

      case 6:
        return (
          <div className="space-y-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                <IconComponent className="h-5 w-5 text-orange-600" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900">Comunicação e Documentos</h3>
                <p className="text-sm text-gray-500">Canais e documentos</p>
              </div>
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="communicationChannels" className="text-sm font-medium text-gray-700">
                  Canais de Comunicação
                </Label>
                <Textarea
                  id="communicationChannels"
                  value={formData.communicationChannels}
                  onChange={(e) => handleInputChange("communicationChannels", e.target.value)}
                  placeholder="Como os pacientes podem entrar em contato (WhatsApp, telefone, email...)"
                  rows={4}
                  className="w-full"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="preAppointmentInfo" className="text-sm font-medium text-gray-700">
                  Informações Pré-Consulta
                </Label>
                <Textarea
                  id="preAppointmentInfo"
                  value={formData.preAppointmentInfo}
                  onChange={(e) => handleInputChange("preAppointmentInfo", e.target.value)}
                  placeholder="Informações importantes que o paciente deve saber antes da consulta..."
                  rows={4}
                  className="w-full"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="requiredDocuments" className="text-sm font-medium text-gray-700">
                  Documentos Necessários
                </Label>
                <Textarea
                  id="requiredDocuments"
                  value={formData.requiredDocuments}
                  onChange={(e) => handleInputChange("requiredDocuments", e.target.value)}
                  placeholder="Que documentos o paciente deve trazer (RG, CPF, carteirinha do convênio...)"
                  rows={4}
                  className="w-full"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="additionalInfo" className="text-sm font-medium text-gray-700">
                  Informações Adicionais
                </Label>
                <Textarea
                  id="additionalInfo"
                  value={formData.additionalInfo}
                  onChange={(e) => handleInputChange("additionalInfo", e.target.value)}
                  placeholder="Qualquer informação adicional importante..."
                  rows={4}
                  className="w-full"
                />
              </div>
            </div>
          </div>
        )

      default:
        return null
    }
  }

  const progress = (currentStep / STEPS.length) * 100
  const isLoadingState = isLoading || isUserLoading

  if (isLoadingState) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div className="bg-white rounded-lg p-8 flex flex-col items-center gap-4">
          <Loader2 className="h-8 w-8 animate-spin text-orange-500" />
          <p className="text-gray-600">
            {isUserLoading ? "Carregando dados do usuário..." : "Carregando dados do perfil..."}
          </p>
        </div>
      </div>
    )
  }

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden p-0">
        <DialogHeader className="px-6 py-4 border-b">
          <div className="flex items-center justify-between">
            <DialogTitle className="text-xl font-semibold text-gray-900">Editar Perfil Profissional</DialogTitle>
            <Button variant="ghost" size="sm" onClick={handleClose}>
              <X className="h-4 w-4" />
            </Button>
          </div>

          {/* Progress Info */}
          <div className="mt-4">
            <div className="flex items-center justify-between text-sm text-gray-500 mb-2">
              <span>
                Etapa {currentStep} de {STEPS.length}
              </span>
              <span>{Math.round(progress)}% concluído</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className="bg-gradient-to-r from-orange-400 to-red-500 h-2 rounded-full transition-all duration-300"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>

          {/* Step Tabs */}
          <div className="mt-6">
            <div className="flex items-center justify-between">
              {STEPS.map((step, index) => {
                const isActive = step.id === currentStep
                const isCompleted = step.id < currentStep
                const IconComponent = step.icon

                return (
                  <div
                    key={step.id}
                    className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                      isActive
                        ? "bg-orange-100 text-orange-700"
                        : isCompleted
                          ? "bg-green-100 text-green-700"
                          : "text-gray-500"
                    }`}
                  >
                    <IconComponent className="h-4 w-4" />
                    <span className="hidden md:inline">{step.title}</span>
                  </div>
                )
              })}
            </div>
          </div>
        </DialogHeader>

        {/* Content */}
        <div className="px-6 py-6 overflow-y-auto max-h-[60vh]">{renderStepContent()}</div>

        {/* Footer */}
        <div className="px-6 py-4 border-t bg-gray-50 flex justify-between items-center">
          <Button
            variant="outline"
            onClick={prevStep}
            disabled={currentStep === 1 || isSaving}
            className="flex items-center gap-2 bg-transparent"
          >
            <ChevronLeft className="h-4 w-4" />
            Anterior
          </Button>

          {currentStep < STEPS.length ? (
            <Button
              onClick={nextStep}
              disabled={isSaving}
              className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white flex items-center gap-2"
            >
              Próximo
              <ChevronRight className="h-4 w-4" />
            </Button>
          ) : (
            <Button
              onClick={handleSave}
              disabled={isSaving}
              className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white"
            >
              {isSaving ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Salvando...
                </>
              ) : (
                "Salvar Alterações"
              )}
            </Button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
