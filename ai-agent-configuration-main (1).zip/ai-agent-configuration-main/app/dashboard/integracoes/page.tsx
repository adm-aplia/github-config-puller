"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/hooks/use-toast"
import {
  Loader2,
  Calendar,
  RefreshCw,
  Check,
  Trash2,
  Mail,
  User,
  Link2OffIcon as LinkOff,
  Settings,
} from "lucide-react"
import { useAuth } from "@/hooks/use-auth"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { useSupabase } from "@/contexts/supabase-context"

// Interface para as credenciais do Google
interface GoogleCredential {
  id?: string
  user_id: string
  email: string
  name?: string
  professional_profiles?: {
    id: string
    fullName: string
    specialty?: string
  }[]
}

const GOOGLE_CLIENT_ID = process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID || ""
const GOOGLE_SCOPES = [
  "https://www.googleapis.com/auth/calendar",
  "https://www.googleapis.com/auth/calendar.events",
  "https://www.googleapis.com/auth/userinfo.email",
  "https://www.googleapis.com/auth/userinfo.profile",
  "openid",
].join(" ")

export default function IntegracoesPage() {
  const [isLoading, setIsLoading] = useState(false)
  const [googleCredentials, setGoogleCredentials] = useState<GoogleCredential[]>([])
  const [loadingCredentials, setLoadingCredentials] = useState(false)
  const [disconnectingCredential, setDisconnectingCredential] = useState<string | null>(null)
  const [unlinkingProfile, setUnlinkingProfile] = useState<string | null>(null)
  const { toast } = useToast()
  const { user, isLoading: authLoading } = useAuth()
  const { supabase } = useSupabase()
  const [isMobile, setIsMobile] = useState(false)
  const hasCheckedConnection = useRef(false)
  const [selectedCredentialForProfiles, setSelectedCredentialForProfiles] = useState<GoogleCredential | null>(null)
  const [showProfilesDialog, setShowProfilesDialog] = useState(false)

  useEffect(() => {
    setIsMobile(window.innerWidth <= 768)

    // Verificar parâmetros de URL para erros ou sucesso de autenticação
    const urlParams = new URLSearchParams(window.location.search)
    const authError = urlParams.get("auth_error")
    const authSuccess = urlParams.get("auth_success")

    if (authError) {
      toast({
        variant: "destructive",
        title: "Erro na autenticação",
        description: decodeURIComponent(authError),
      })
      window.history.replaceState({}, document.title, window.location.pathname)
    }

    if (authSuccess) {
      toast({
        title: "Google Agenda conectado",
        description: "Sua conta do Google Agenda foi conectada com sucesso",
      })
      window.history.replaceState({}, document.title, window.location.pathname)
      fetchAllData()
    }

    // Configurar listener para mensagens do popup
    const messageHandler = (event: MessageEvent) => {
      if (event.origin !== window.location.origin) return

      if (event.data.type === "google-auth-success") {
        toast({
          title: "Google Agenda conectado",
          description: "Sua conta do Google Agenda foi conectada com sucesso",
        })
        fetchAllData()
      }

      if (event.data.type === "google-auth-error") {
        toast({
          variant: "destructive",
          title: "Erro na autenticação",
          description: event.data.error || "Ocorreu um erro durante a autenticação",
        })
      }
    }

    window.addEventListener("message", messageHandler)
    return () => window.removeEventListener("message", messageHandler)
  }, [toast])

  // Função para buscar todas as credenciais do Google E perfis profissionais
  const fetchAllData = async () => {
    if (!user?.id || !user?.email || !supabase) return

    try {
      setLoadingCredentials(true)
      hasCheckedConnection.current = true

      // Buscar credenciais do Google
      const { data: credentials, error: credentialsError } = await supabase
        .from("google_credentials")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })

      if (credentialsError) throw new Error(credentialsError.message)

      // Para cada credencial, buscar os perfis profissionais vinculados através da tabela google_profile_links
      const formattedCredentials = await Promise.all(
        (credentials || []).map(async (credential) => {
          // Buscar perfis vinculados a esta credencial específica
          const { data: profileLinks, error: profileLinksError } = await supabase
            .from("google_profile_links")
            .select(`
              professional_profile_id,
              professional_profiles!inner(
                id,
                fullName,
                specialty
              )
            `)
            .eq("google_credential_id", credential.id)

          if (profileLinksError) {
            console.error("❌ Erro ao buscar perfis vinculados:", profileLinksError)
          }

          // Extrair os dados dos perfis profissionais
          const professionalProfiles =
            profileLinks?.map((link) => ({
              id: link.professional_profiles.id,
              fullName: link.professional_profiles.fullName,
              specialty: link.professional_profiles.specialty,
            })) || []

          return {
            id: credential.id,
            user_id: credential.user_id,
            email: credential.email,
            name: credential.name,
            professional_profiles: professionalProfiles,
          }
        }),
      )

      setGoogleCredentials(formattedCredentials)
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Erro de conexão",
        description: "Não foi possível conectar ao servidor para buscar os dados",
      })
    } finally {
      setLoadingCredentials(false)
    }
  }

  // Buscar dados quando o usuário carrega
  useEffect(() => {
    if (user?.id && user?.email && !hasCheckedConnection.current) {
      fetchAllData()
    }
  }, [user?.id, user?.email])

  const handleGoogleCalendarConnect = () => {
    if (!user) {
      toast({
        variant: "destructive",
        title: "Erro de autenticação",
        description: "Você precisa estar logado para conectar ao Google Agenda",
      })
      return
    }

    setIsLoading(true)

    try {
      const stateObj = { user_id: user.id }
      const stateParam = encodeURIComponent(JSON.stringify(stateObj))

      if (isMobile) {
        sessionStorage.setItem("auth_return_url", window.location.pathname)
      }

      const redirectUri = `${process.env.NEXT_PUBLIC_APP_URL}/auth/google/callback`
      const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?client_id=${GOOGLE_CLIENT_ID}&redirect_uri=${encodeURIComponent(redirectUri)}&response_type=code&scope=${encodeURIComponent(GOOGLE_SCOPES)}&access_type=offline&prompt=consent&state=${stateParam}`

      if (isMobile) {
        window.location.href = authUrl
      } else {
        const width = 600
        const height = 700
        const left = window.screenX + (window.outerWidth - width) / 2
        const top = window.screenY + (window.outerHeight - height) / 2

        const authWindow = window.open(
          authUrl,
          "googleAuthPopup",
          `width=${width},height=${height},left=${left},top=${top},resizable=yes,scrollbars=yes,status=yes`,
        )

        const checkPopupClosed = setInterval(() => {
          if (authWindow?.closed) {
            clearInterval(checkPopupClosed)
            setIsLoading(false)
            setTimeout(() => fetchAllData(), 1000)
          }
        }, 500)
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Erro ao conectar",
        description: error instanceof Error ? error.message : "Ocorreu um erro ao conectar com o Google",
      })
      setIsLoading(false)
    }
  }

  const handleUnlinkProfile = async (credentialId: string, profileId: string) => {
    try {
      setUnlinkingProfile(profileId)
      if (!supabase) throw new Error("Cliente Supabase não inicializado")

      const { error } = await supabase
        .from("google_profile_links")
        .delete()
        .eq("google_credential_id", credentialId)
        .eq("professional_profile_id", profileId)

      if (error) throw new Error(error.message)

      // Atualizar os dados principais
      fetchAllData()

      // Atualizar o modal imediatamente removendo o perfil desvinculado
      if (selectedCredentialForProfiles) {
        const updatedProfiles =
          selectedCredentialForProfiles.professional_profiles?.filter((profile) => profile.id !== profileId) || []

        setSelectedCredentialForProfiles({
          ...selectedCredentialForProfiles,
          professional_profiles: updatedProfiles,
        })

        // Se não há mais perfis, fechar o modal
        if (updatedProfiles.length === 0) {
          setShowProfilesDialog(false)
        }
      }

      toast({
        title: "Perfil desvinculado",
        description: "O perfil profissional foi desvinculado com sucesso.",
      })
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Erro ao desvincular",
        description: "Não foi possível desvincular o perfil profissional.",
      })
    } finally {
      setUnlinkingProfile(null)
    }
  }

  const handleDisconnectCredential = async (credentialId: string) => {
    if (!credentialId) return

    setDisconnectingCredential(credentialId)
    try {
      const response = await fetch("/api/integrations/google-calendar/disconnect-credential", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ credentialId }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.message || "Falha ao desconectar conta do Google")
      }

      fetchAllData()
      toast({
        title: "Conta desconectada",
        description: "A conta do Google foi desconectada com sucesso",
      })
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Erro ao desconectar",
        description: error instanceof Error ? error.message : "Não foi possível desconectar a conta do Google",
      })
    } finally {
      setDisconnectingCredential(null)
    }
  }

  const handleRefreshData = () => {
    if (!user?.id) {
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Usuário não encontrado. Faça login novamente.",
      })
      return
    }

    hasCheckedConnection.current = false
    fetchAllData()
    toast({
      title: "Atualizando...",
      description: "Buscando dados mais recentes.",
    })
  }

  if (authLoading) {
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-4rem)]">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Integrações</h1>
          <p className="text-muted-foreground">Conecte-se com outros serviços e plataformas</p>
        </div>
        <Button onClick={handleGoogleCalendarConnect} disabled={isLoading}>
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Conectando...
            </>
          ) : (
            <>
              <Calendar className="mr-2 h-4 w-4" />
              Conectar Google Agenda
            </>
          )}
        </Button>
      </div>

      <div className="space-y-6">
        {/* Seção do Google Agenda */}
        <Card>
          <CardHeader>
            <CardTitle>Google Agenda</CardTitle>
            <CardDescription>Sincronize seus agendamentos com o Google Agenda automaticamente</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Lista de contas Google conectadas */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-medium">Contas Conectadas</h3>
                <Button variant="outline" size="sm" onClick={handleRefreshData} disabled={loadingCredentials}>
                  {loadingCredentials ? (
                    <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  ) : (
                    <RefreshCw className="h-4 w-4 mr-2" />
                  )}
                  Atualizar
                </Button>
              </div>

              {loadingCredentials ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin" />
                </div>
              ) : googleCredentials.length === 0 ? (
                <Alert variant="outline" className="bg-gray-50 dark:bg-gray-800 dark:border-gray-700">
                  <AlertDescription className="dark:text-gray-300">
                    Nenhuma conta do Google está conectada. Use o botão "Conectar Google Agenda" para adicionar uma
                    conta.
                  </AlertDescription>
                </Alert>
              ) : (
                <div className="border rounded-md">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Email</TableHead>
                        <TableHead>Nome</TableHead>
                        <TableHead>Perfis Vinculados</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Ações</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {googleCredentials.map((credential) => (
                        <TableRow key={credential.id || credential.user_id}>
                          <TableCell className="font-medium">
                            <div className="flex items-center gap-2">
                              <Avatar className="h-6 w-6 bg-gray-100">
                                <AvatarFallback>
                                  <Mail className="h-3 w-3 text-gray-500" />
                                </AvatarFallback>
                              </Avatar>
                              {credential.email}
                            </div>
                          </TableCell>
                          <TableCell>{credential.name || "-"}</TableCell>
                          <TableCell>
                            {credential.professional_profiles && credential.professional_profiles.length > 0 ? (
                              <Badge variant="secondary">{credential.professional_profiles.length} perfil(s)</Badge>
                            ) : (
                              <Badge variant="outline">Não vinculado</Badge>
                            )}
                          </TableCell>
                          <TableCell>
                            <Badge variant="secondary">
                              <Check className="h-3 w-3 mr-1" />
                              Conectado
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              {/* Botão para gerenciar perfis vinculados */}
                              {credential.professional_profiles && credential.professional_profiles.length > 0 && (
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => {
                                    setSelectedCredentialForProfiles(credential)
                                    setShowProfilesDialog(true)
                                  }}
                                >
                                  <Settings className="h-4 w-4 mr-1" />
                                  Gerenciar Perfis
                                </Button>
                              )}

                              {/* Botão para desconectar conta */}
                              <AlertDialog>
                                <AlertDialogTrigger asChild>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    className="text-red-500 hover:text-red-700 hover:bg-red-50"
                                  >
                                    <Trash2 className="h-4 w-4 mr-1" />
                                    Desconectar
                                  </Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent>
                                  <AlertDialogHeader>
                                    <AlertDialogTitle>Desconectar conta do Google</AlertDialogTitle>
                                    <AlertDialogDescription>
                                      Tem certeza que deseja desconectar a conta {credential.email}? Isso removerá a
                                      sincronização de agendamentos com esta conta e todos os perfis vinculados.
                                    </AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                    <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                    <AlertDialogAction
                                      onClick={() => handleDisconnectCredential(credential.id || credential.user_id)}
                                      className="bg-red-500 hover:bg-red-600"
                                    >
                                      {disconnectingCredential === (credential.id || credential.user_id) ? (
                                        <>
                                          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                                          Desconectando...
                                        </>
                                      ) : (
                                        "Sim, desconectar"
                                      )}
                                    </AlertDialogAction>
                                  </AlertDialogFooter>
                                </AlertDialogContent>
                              </AlertDialog>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </div>
            {/* Dialog for managing profiles */}
            {showProfilesDialog && selectedCredentialForProfiles && (
              <Dialog open={showProfilesDialog} onOpenChange={setShowProfilesDialog}>
                <DialogContent className="sm:max-w-md">
                  <DialogHeader>
                    <DialogTitle>Perfis Vinculados</DialogTitle>
                    <DialogDescription>
                      Gerencie os perfis profissionais vinculados à conta {selectedCredentialForProfiles.email}
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-3">
                    {selectedCredentialForProfiles.professional_profiles?.map((profile) => (
                      <div key={profile.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex items-center gap-3">
                          <Avatar className="h-8 w-8 bg-gray-100">
                            <AvatarFallback>
                              <User className="h-4 w-4 text-gray-600" />
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <div className="font-medium">{profile.fullName}</div>
                            {profile.specialty && (
                              <div className="text-sm text-muted-foreground">{profile.specialty}</div>
                            )}
                          </div>
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleUnlinkProfile(selectedCredentialForProfiles.id!, profile.id)}
                          disabled={unlinkingProfile === profile.id}
                          className="text-red-600 hover:text-red-800 hover:bg-red-50"
                        >
                          {unlinkingProfile === profile.id ? (
                            <Loader2 className="h-4 w-4 animate-spin" />
                          ) : (
                            <LinkOff className="h-4 w-4" />
                          )}
                        </Button>
                      </div>
                    ))}
                  </div>
                </DialogContent>
              </Dialog>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
