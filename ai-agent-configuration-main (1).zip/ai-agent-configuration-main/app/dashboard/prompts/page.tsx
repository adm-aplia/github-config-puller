"use client"

import { PromptManager } from "@/components/prompts/prompt-manager"

export default function PromptsPage() {
  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Prompts</h1>
        <p className="text-muted-foreground">Gerencie os prompts personalizados para seus agentes de IA</p>
      </div>

      <PromptManager />
    </div>
  )
}
