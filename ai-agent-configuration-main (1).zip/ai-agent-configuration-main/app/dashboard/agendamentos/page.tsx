"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { AppointmentCalendar } from "@/components/dashboard/appointment-calendar"
import { AppointmentStats } from "@/components/dashboard/appointment-stats"
import { Filter, RefreshCw } from "lucide-react"
import { Input } from "@/components/ui/input"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { ConversationService } from "@/lib/services/conversation-service"
import { useRouter, useSearchParams } from "next/navigation"
import { useAuth } from "@/hooks/use-auth"
import { CreateAppointmentModal } from "@/components/appointments/create-appointment-modal"

export default function AgendamentosPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const contactPhone = searchParams.get("contactPhone")
  const conversationId = searchParams.get("conversationId")
  const { isAuthenticated } = useAuth()

  const [searchTerm, setSearchTerm] = useState("")
  const [conversations, setConversations] = useState<any[]>([])
  const [selectedContact, setSelectedContact] = useState<string | null>(contactPhone)
  const [selectedConversation, setSelectedConversation] = useState<string | null>(conversationId)
  const [refreshKey, setRefreshKey] = useState(0)

  // Função para atualizar a página
  const handleRefresh = () => {
    setRefreshKey((prev) => prev + 1)
  }

  const handleAppointmentCreated = () => {
    setRefreshKey((prev) => prev + 1)
  }

  // Buscar conversas para o filtro
  useEffect(() => {
    async function fetchConversations() {
      if (!isAuthenticated) {
        return
      }

      try {
        const data = await ConversationService.getConversations()
        setConversations(data || [])
      } catch (error) {
        console.error("Erro ao buscar conversas:", error)
      }
    }

    if (isAuthenticated) {
      fetchConversations()
    }
  }, [isAuthenticated, refreshKey])

  // Função para filtrar por contato
  const filterByContact = (phone: string) => {
    setSelectedContact(phone)
    setSelectedConversation(null)
    router.push(`/dashboard/agendamentos?contactPhone=${phone}`)
  }

  // Função para filtrar por conversa
  const filterByConversation = (id: string) => {
    setSelectedConversation(id)
    setSelectedContact(null)
    router.push(`/dashboard/agendamentos?conversationId=${id}`)
  }

  // Função para limpar filtros
  const clearFilters = () => {
    setSelectedContact(null)
    setSelectedConversation(null)
    router.push("/dashboard/agendamentos")
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Agendamentos</h1>
          <p className="text-muted-foreground">
            {selectedContact
              ? `Agendamentos do contato: ${selectedContact}`
              : selectedConversation
                ? `Agendamentos da conversa selecionada`
                : `Estatísticas e calendário de agendamentos da sua clínica`}
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={handleRefresh} className="gap-2">
            <RefreshCw className="h-4 w-4" />
            Atualizar
          </Button>
          {(selectedContact || selectedConversation) && (
            <Button variant="outline" onClick={clearFilters}>
              Limpar filtros
            </Button>
          )}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="gap-2">
                <Filter className="h-4 w-4" />
                Filtrar
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <div className="p-2">
                <Input
                  placeholder="Buscar contato..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="mb-2"
                />
              </div>
              {conversations
                .filter(
                  (c) =>
                    c.contact_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                    c.contact_phone?.includes(searchTerm),
                )
                .slice(0, 10)
                .map((conversation) => (
                  <DropdownMenuItem key={conversation.id} onClick={() => filterByConversation(conversation.id)}>
                    {conversation.contact_name || "Sem nome"} ({conversation.contact_phone})
                  </DropdownMenuItem>
                ))}
            </DropdownMenuContent>
          </DropdownMenu>
          <CreateAppointmentModal onAppointmentCreated={handleAppointmentCreated} />
        </div>
      </div>

      <div className="space-y-6">
        <AppointmentStats key={`stats-${refreshKey}`} />
        <AppointmentCalendar
          key={`calendar-${refreshKey}`}
          contactPhone={selectedContact}
          conversationId={selectedConversation}
        />
      </div>
    </div>
  )
}
