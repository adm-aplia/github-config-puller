"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"
import { ArrowLeft, Calendar, Clock, User, Phone, Mail, FileText, Edit, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Loader2 } from "lucide-react"
import { useAuth } from "@/hooks/use-auth"
import { AppointmentService } from "@/lib/services/appointment-service"
import type { Appointment } from "@/lib/services/appointment-service"

type AppointmentWithDetails = Appointment & {
  professional_profiles?: {
    id: string
    fullName: string
    specialty?: string
  } | null
}

export default function AppointmentDetailsPage() {
  const params = useParams()
  const router = useRouter()
  const { isAuthenticated } = useAuth()
  const [appointment, setAppointment] = useState<AppointmentWithDetails | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const appointmentId = params.id as string

  useEffect(() => {
    async function loadAppointment() {
      if (!isAuthenticated || !appointmentId) {
        setIsLoading(false)
        return
      }

      try {
        setIsLoading(true)
        const appointmentData = await AppointmentService.getAppointment(appointmentId)
        setAppointment(appointmentData)
      } catch (error) {
        console.error("Erro ao carregar agendamento:", error)
        setError("Não foi possível carregar os detalhes do agendamento")
      } finally {
        setIsLoading(false)
      }
    }

    loadAppointment()
  }, [appointmentId, isAuthenticated])

  // Formatar status para exibição
  const formatStatus = (status: string) => {
    switch (status) {
      case "scheduled":
        return "Agendado"
      case "completed":
        return "Concluído"
      case "cancelled":
        return "Cancelado"
      case "rescheduled":
        return "Remarcado"
      case "confirmed":
        return "Confirmado"
      case "no-show":
        return "Não compareceu"
      default:
        return status
    }
  }

  // Obter variante de badge com base no status
  const getStatusVariant = (status: string) => {
    switch (status) {
      case "scheduled":
        return "default"
      case "completed":
        return "success"
      case "cancelled":
        return "destructive"
      case "rescheduled":
        return "warning"
      case "confirmed":
        return "outline"
      case "no-show":
        return "secondary"
      default:
        return "secondary"
    }
  }

  // Função para editar agendamento
  const handleEdit = () => {
    router.push(`/dashboard/agendamentos/${appointmentId}/edit`)
  }

  // Função para deletar agendamento
  const handleDelete = async () => {
    if (!confirm("Tem certeza que deseja excluir este agendamento?")) {
      return
    }

    try {
      await AppointmentService.deleteAppointment(appointmentId)
      router.push("/dashboard/agendamentos")
    } catch (error) {
      console.error("Erro ao excluir agendamento:", error)
      alert("Erro ao excluir agendamento")
    }
  }

  // Função para atualizar status
  const handleStatusUpdate = async (newStatus: string) => {
    try {
      const updatedAppointment = await AppointmentService.updateAppointmentStatus(appointmentId, newStatus)
      setAppointment(updatedAppointment)
    } catch (error) {
      console.error("Erro ao atualizar status:", error)
      alert("Erro ao atualizar status do agendamento")
    }
  }

  if (isLoading) {
    return (
      <div className="flex justify-center items-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    )
  }

  if (error || !appointment) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="outline" size="icon" onClick={() => router.back()}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <h1 className="text-3xl font-bold tracking-tight">Detalhes do Agendamento</h1>
        </div>
        <div className="text-center py-8 text-muted-foreground">
          <p>{error || "Agendamento não encontrado"}</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Cabeçalho */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="outline" size="icon" onClick={() => router.back()}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Detalhes do Agendamento</h1>
            <p className="text-muted-foreground">Agendamento #{appointment.id.slice(0, 8)}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={handleEdit}>
            <Edit className="h-4 w-4 mr-2" />
            Editar
          </Button>
          <Button variant="destructive" onClick={handleDelete}>
            <Trash2 className="h-4 w-4 mr-2" />
            Excluir
          </Button>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Informações do Paciente */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="h-5 w-5" />
              Informações do Paciente
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm font-medium text-muted-foreground">Nome</label>
              <p className="text-lg font-medium">{appointment.patient_name}</p>
            </div>

            {appointment.patient_phone && (
              <div>
                <label className="text-sm font-medium text-muted-foreground">Telefone</label>
                <div className="flex items-center gap-2">
                  <Phone className="h-4 w-4 text-muted-foreground" />
                  <p>{appointment.patient_phone}</p>
                </div>
              </div>
            )}

            {appointment.patient_email && (
              <div>
                <label className="text-sm font-medium text-muted-foreground">Email</label>
                <div className="flex items-center gap-2">
                  <Mail className="h-4 w-4 text-muted-foreground" />
                  <p>{appointment.patient_email}</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Informações do Agendamento */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5" />
              Informações do Agendamento
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm font-medium text-muted-foreground">Data e Hora</label>
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-muted-foreground" />
                <p className="text-lg">
                  {format(new Date(appointment.appointment_date), "dd 'de' MMMM 'de' yyyy 'às' HH:mm", {
                    locale: ptBR,
                  })}
                </p>
              </div>
            </div>

            <div>
              <label className="text-sm font-medium text-muted-foreground">Status</label>
              <div className="flex items-center gap-2 mt-1">
                <Badge variant={getStatusVariant(appointment.status)}>{formatStatus(appointment.status)}</Badge>
              </div>
            </div>

            {appointment.professional_profiles && (
              <div>
                <label className="text-sm font-medium text-muted-foreground">Profissional</label>
                <p className="text-lg">{appointment.professional_profiles.fullName}</p>
                {appointment.professional_profiles.specialty && (
                  <p className="text-sm text-muted-foreground">{appointment.professional_profiles.specialty}</p>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Observações */}
        {appointment.notes && (
          <Card className="md:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Observações
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="whitespace-pre-wrap">{appointment.notes}</p>
            </CardContent>
          </Card>
        )}

        {/* Ações Rápidas */}
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Ações Rápidas</CardTitle>
            <CardDescription>Atualize o status do agendamento</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {appointment.status !== "confirmed" && (
                <Button
                  variant="outline"
                  onClick={() => handleStatusUpdate("confirmed")}
                  className="text-blue-600 border-blue-600 hover:bg-blue-50"
                >
                  Confirmar
                </Button>
              )}
              {appointment.status !== "completed" && (
                <Button
                  variant="outline"
                  onClick={() => handleStatusUpdate("completed")}
                  className="text-green-600 border-green-600 hover:bg-green-50"
                >
                  Marcar como Concluído
                </Button>
              )}
              {appointment.status !== "cancelled" && (
                <Button
                  variant="outline"
                  onClick={() => handleStatusUpdate("cancelled")}
                  className="text-red-600 border-red-600 hover:bg-red-50"
                >
                  Cancelar
                </Button>
              )}
              {appointment.status !== "no-show" && (
                <Button
                  variant="outline"
                  onClick={() => handleStatusUpdate("no-show")}
                  className="text-gray-600 border-gray-600 hover:bg-gray-50"
                >
                  Não Compareceu
                </Button>
              )}
              <Button
                variant="outline"
                onClick={() => handleStatusUpdate("rescheduled")}
                className="text-amber-600 border-amber-600 hover:bg-amber-50"
              >
                Remarcar
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Informações do Sistema */}
      <Card>
        <CardHeader>
          <CardTitle>Informações do Sistema</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">ID do Agendamento:</span>
            <span className="font-mono">{appointment.id}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Criado em:</span>
            <span>{format(new Date(appointment.created_at), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}</span>
          </div>
          {appointment.updated_at && appointment.updated_at !== appointment.created_at && (
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Última atualização:</span>
              <span>{format(new Date(appointment.updated_at), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}</span>
            </div>
          )}
          {appointment.conversation_id && (
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">ID da Conversa:</span>
              <span className="font-mono">{appointment.conversation_id}</span>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
