"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { ArrowLeft, Save } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Loader2 } from "lucide-react"
import { useAuth } from "@/hooks/use-auth"
import { AppointmentService } from "@/lib/services/appointment-service"
import { ProfileService } from "@/lib/services/profile-service"
import type { Appointment } from "@/lib/services/appointment-service"

type AppointmentWithDetails = Appointment & {
  professional_profiles?: {
    id: string
    fullName: string
    specialty?: string
  } | null
}

export default function EditAppointmentPage() {
  const params = useParams()
  const router = useRouter()
  const { isAuthenticated } = useAuth()
  const [appointment, setAppointment] = useState<AppointmentWithDetails | null>(null)
  const [professionals, setProfessionals] = useState<{ id: string; name: string }[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const appointmentId = params.id as string

  // Form data
  const [formData, setFormData] = useState({
    patient_name: "",
    patient_phone: "",
    patient_email: "",
    appointment_date: "",
    status: "",
    agent_id: "",
    notes: "",
  })

  useEffect(() => {
    async function loadData() {
      if (!isAuthenticated || !appointmentId) {
        setIsLoading(false)
        return
      }

      try {
        setIsLoading(true)

        // Carregar agendamento
        const appointmentData = await AppointmentService.getAppointment(appointmentId)
        setAppointment(appointmentData)

        // Carregar profissionais
        const profiles = await ProfileService.getAllProfessionalProfiles()
        const profsData = profiles.map((profile) => ({
          id: profile.id,
          name: profile.fullName || "Profissional",
        }))
        setProfessionals(profsData)

        // Preencher formulário
        if (appointmentData) {
          setFormData({
            patient_name: appointmentData.patient_name || "",
            patient_phone: appointmentData.patient_phone || "",
            patient_email: appointmentData.patient_email || "",
            appointment_date: appointmentData.appointment_date
              ? new Date(appointmentData.appointment_date).toISOString().slice(0, 16)
              : "",
            status: appointmentData.status || "scheduled",
            agent_id: appointmentData.agent_id || "",
            notes: appointmentData.notes || "",
          })
        }
      } catch (error) {
        console.error("Erro ao carregar dados:", error)
        setError("Não foi possível carregar os dados do agendamento")
      } finally {
        setIsLoading(false)
      }
    }

    loadData()
  }, [appointmentId, isAuthenticated])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!appointment) return

    try {
      setIsSaving(true)

      const updateData = {
        patient_name: formData.patient_name,
        patient_phone: formData.patient_phone || null,
        patient_email: formData.patient_email || null,
        appointment_date: new Date(formData.appointment_date).toISOString(),
        status: formData.status,
        agent_id: formData.agent_id || null,
        notes: formData.notes || null,
      }

      await AppointmentService.updateAppointment(appointmentId, updateData)
      router.push(`/dashboard/agendamentos/${appointmentId}`)
    } catch (error) {
      console.error("Erro ao atualizar agendamento:", error)
      alert("Erro ao atualizar agendamento")
    } finally {
      setIsSaving(false)
    }
  }

  if (isLoading) {
    return (
      <div className="flex justify-center items-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    )
  }

  if (error || !appointment) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="outline" size="icon" onClick={() => router.back()}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <h1 className="text-3xl font-bold tracking-tight">Editar Agendamento</h1>
        </div>
        <div className="text-center py-8 text-muted-foreground">
          <p>{error || "Agendamento não encontrado"}</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Cabeçalho */}
      <div className="flex items-center gap-4">
        <Button variant="outline" size="icon" onClick={() => router.back()}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Editar Agendamento</h1>
          <p className="text-muted-foreground">Agendamento #{appointment.id.slice(0, 8)}</p>
        </div>
      </div>

      {/* Formulário */}
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid gap-6 md:grid-cols-2">
          {/* Informações do Paciente */}
          <Card>
            <CardHeader>
              <CardTitle>Informações do Paciente</CardTitle>
              <CardDescription>Dados do paciente para o agendamento</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="patient_name">Nome do Paciente *</Label>
                <Input
                  id="patient_name"
                  value={formData.patient_name}
                  onChange={(e) => setFormData({ ...formData, patient_name: e.target.value })}
                  required
                />
              </div>

              <div>
                <Label htmlFor="patient_phone">Telefone</Label>
                <Input
                  id="patient_phone"
                  type="tel"
                  value={formData.patient_phone}
                  onChange={(e) => setFormData({ ...formData, patient_phone: e.target.value })}
                />
              </div>

              <div>
                <Label htmlFor="patient_email">Email</Label>
                <Input
                  id="patient_email"
                  type="email"
                  value={formData.patient_email}
                  onChange={(e) => setFormData({ ...formData, patient_email: e.target.value })}
                />
              </div>
            </CardContent>
          </Card>

          {/* Informações do Agendamento */}
          <Card>
            <CardHeader>
              <CardTitle>Informações do Agendamento</CardTitle>
              <CardDescription>Detalhes da consulta</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="appointment_date">Data e Hora *</Label>
                <Input
                  id="appointment_date"
                  type="datetime-local"
                  value={formData.appointment_date}
                  onChange={(e) => setFormData({ ...formData, appointment_date: e.target.value })}
                  required
                />
              </div>

              <div>
                <Label htmlFor="status">Status</Label>
                <Select value={formData.status} onValueChange={(value) => setFormData({ ...formData, status: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="scheduled">Agendado</SelectItem>
                    <SelectItem value="confirmed">Confirmado</SelectItem>
                    <SelectItem value="completed">Concluído</SelectItem>
                    <SelectItem value="cancelled">Cancelado</SelectItem>
                    <SelectItem value="rescheduled">Remarcado</SelectItem>
                    <SelectItem value="no-show">Não compareceu</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="agent_id">Profissional</Label>
                <Select
                  value={formData.agent_id}
                  onValueChange={(value) => setFormData({ ...formData, agent_id: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o profissional" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">Nenhum profissional</SelectItem>
                    {professionals.map((professional) => (
                      <SelectItem key={professional.id} value={professional.id}>
                        {professional.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Observações */}
        <Card>
          <CardHeader>
            <CardTitle>Observações</CardTitle>
            <CardDescription>Informações adicionais sobre o agendamento</CardDescription>
          </CardHeader>
          <CardContent>
            <Textarea
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              placeholder="Digite observações sobre o agendamento..."
              rows={4}
            />
          </CardContent>
        </Card>

        {/* Botões de Ação */}
        <div className="flex justify-end gap-4">
          <Button type="button" variant="outline" onClick={() => router.back()}>
            Cancelar
          </Button>
          <Button type="submit" disabled={isSaving}>
            {isSaving ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Salvando...
              </>
            ) : (
              <>
                <Save className="h-4 w-4 mr-2" />
                Salvar Alterações
              </>
            )}
          </Button>
        </div>
      </form>
    </div>
  )
}
