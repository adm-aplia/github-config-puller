"use client"

import { useEffect, useState } from "react"
import { useParams } from "next/navigation"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Separator } from "@/components/ui/separator"
import { ConversationService } from "@/lib/services/conversation-service"
import { AppointmentService } from "@/lib/services/appointment-service"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"
import { Loader2, Send, Calendar, User, Phone, Clock, AlertCircle } from "lucide-react"

export default function ConversationDetailPage() {
  const { id } = useParams() as { id: string }
  const [conversation, setConversation] = useState<any>(null)
  const [appointments, setAppointments] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [newMessage, setNewMessage] = useState("")
  const [sendingMessage, setSendingMessage] = useState(false)

  useEffect(() => {
    async function fetchData() {
      try {
        setLoading(true)
        setError(null)

        // Buscar conversa com mensagens
        const conversationData = await ConversationService.getConversation(id)
        setConversation(conversationData)

        // Buscar agendamentos relacionados a esta conversa
        const appointmentsData = await AppointmentService.getAppointmentsByConversation(id)
        setAppointments(appointmentsData || [])
      } catch (err) {
        console.error("Erro ao buscar dados da conversa:", err)
        setError("Não foi possível carregar os dados da conversa. Tente novamente mais tarde.")
      } finally {
        setLoading(false)
      }
    }

    if (id) {
      fetchData()
    }
  }, [id])

  const handleSendMessage = async () => {
    if (!newMessage.trim() || !conversation) return

    try {
      setSendingMessage(true)

      // Adicionar mensagem à conversa
      await ConversationService.addMessage({
        conversation_id: conversation.id,
        content: newMessage,
        role: "assistant", // Assumindo que é o assistente enviando a mensagem
        type: "text",
      })

      // Atualizar a conversa para mostrar a nova mensagem
      const updatedConversation = await ConversationService.getConversation(id)
      setConversation(updatedConversation)

      // Limpar campo de mensagem
      setNewMessage("")
    } catch (err) {
      console.error("Erro ao enviar mensagem:", err)
      alert("Não foi possível enviar a mensagem. Tente novamente.")
    } finally {
      setSendingMessage(false)
    }
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center h-[calc(100vh-200px)]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  if (error) {
    return (
      <div className="text-center py-12">
        <AlertCircle className="h-12 w-12 text-destructive mx-auto mb-4" />
        <h2 className="text-xl font-semibold mb-2">Erro ao carregar conversa</h2>
        <p className="text-muted-foreground mb-6">{error}</p>
        <Button onClick={() => window.location.reload()}>Tentar novamente</Button>
      </div>
    )
  }

  if (!conversation) {
    return (
      <div className="text-center py-12">
        <h2 className="text-xl font-semibold mb-2">Conversa não encontrada</h2>
        <p className="text-muted-foreground">A conversa solicitada não existe ou foi removida.</p>
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">{conversation.contact_name || "Paciente"}</h1>
          <p className="text-muted-foreground">{conversation.contact_phone || "Sem telefone"}</p>
        </div>
        <Badge
          variant={
            conversation.status === "active"
              ? "default"
              : conversation.status === "closed"
                ? "secondary"
                : conversation.status === "flagged"
                  ? "destructive"
                  : "outline"
          }
          className="text-sm px-3 py-1"
        >
          {conversation.status === "active"
            ? "Conversa ativa"
            : conversation.status === "closed"
              ? "Conversa fechada"
              : conversation.status === "flagged"
                ? "Conversa sinalizada"
                : conversation.status}
        </Badge>
      </div>

      <Tabs defaultValue="messages" className="w-full">
        <TabsList>
          <TabsTrigger value="messages">Mensagens</TabsTrigger>
          <TabsTrigger value="appointments">Agendamentos</TabsTrigger>
          <TabsTrigger value="info">Informações</TabsTrigger>
        </TabsList>

        <TabsContent value="messages" className="space-y-4 mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Histórico de Mensagens</CardTitle>
              <CardDescription>
                Conversa iniciada em {format(new Date(conversation.created_at), "PPP 'às' HH:mm", { locale: ptBR })}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4 max-h-[500px] overflow-y-auto p-1">
                {conversation.messages && conversation.messages.length > 0 ? (
                  conversation.messages.map((message: any) => (
                    <div
                      key={message.id}
                      className={`flex ${message.role === "user" ? "justify-start" : "justify-end"}`}
                    >
                      <div
                        className={`max-w-[80%] rounded-lg p-3 ${
                          message.role === "user" ? "bg-muted text-foreground" : "bg-primary text-primary-foreground"
                        }`}
                      >
                        <p>{message.content}</p>
                        <p className="text-xs opacity-70 mt-1 text-right">
                          {format(new Date(message.created_at), "HH:mm", { locale: ptBR })}
                        </p>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-center text-muted-foreground py-8">Nenhuma mensagem nesta conversa</p>
                )}
              </div>
            </CardContent>
            <CardFooter>
              <div className="flex w-full gap-2">
                <Textarea
                  placeholder="Digite sua mensagem..."
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  className="flex-1"
                  disabled={conversation.status !== "active" || sendingMessage}
                />
                <Button
                  onClick={handleSendMessage}
                  disabled={!newMessage.trim() || conversation.status !== "active" || sendingMessage}
                >
                  {sendingMessage ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                </Button>
              </div>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="appointments" className="space-y-4 mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Agendamentos</CardTitle>
              <CardDescription>Agendamentos relacionados a esta conversa</CardDescription>
            </CardHeader>
            <CardContent>
              {appointments && appointments.length > 0 ? (
                <div className="space-y-4">
                  {appointments.map((appointment) => (
                    <div key={appointment.id} className="border rounded-lg p-4">
                      <div className="flex justify-between items-start mb-2">
                        <div className="flex items-center gap-2">
                          <Calendar className="h-5 w-5 text-primary" />
                          <h3 className="font-medium">
                            {format(new Date(appointment.scheduled_date), "PPP", { locale: ptBR })}
                          </h3>
                        </div>
                        <Badge>{appointment.status}</Badge>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
                        <div className="flex items-center gap-2">
                          <Clock className="h-4 w-4 text-muted-foreground" />
                          <span>{format(new Date(appointment.scheduled_date), "HH:mm", { locale: ptBR })}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <User className="h-4 w-4 text-muted-foreground" />
                          <span>{appointment.professional_profiles?.fullName || "Sem profissional atribuído"}</span>
                        </div>
                      </div>
                      {appointment.notes && <p className="mt-2 text-sm text-muted-foreground">{appointment.notes}</p>}
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-center text-muted-foreground py-8">Nenhum agendamento relacionado a esta conversa</p>
              )}
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full">
                Criar novo agendamento
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="info" className="space-y-4 mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Informações da Conversa</CardTitle>
              <CardDescription>Detalhes sobre esta conversa e o paciente</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground mb-1">Paciente</h3>
                  <div className="flex items-center gap-3">
                    <Avatar>
                      <AvatarImage
                        src={`/abstract-geometric-shapes.png?height=40&width=40&query=${encodeURIComponent(conversation.contact_name || "Paciente")}`}
                        alt={conversation.contact_name || "Paciente"}
                      />
                      <AvatarFallback>{(conversation.contact_name || "P").charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium">{conversation.contact_name || "Paciente sem nome"}</p>
                      <p className="text-sm text-muted-foreground flex items-center gap-1">
                        <Phone className="h-3 w-3" />
                        {conversation.contact_phone || "Sem telefone"}
                      </p>
                    </div>
                  </div>
                </div>

                <Separator />

                <div>
                  <h3 className="text-sm font-medium text-muted-foreground mb-1">Profissional</h3>
                  <p className="font-medium">
                    {conversation.professional_profiles?.fullName || "Sem profissional atribuído"}
                  </p>
                  {conversation.professional_profiles?.specialty && (
                    <p className="text-sm text-muted-foreground">{conversation.professional_profiles.specialty}</p>
                  )}
                </div>

                <Separator />

                <div>
                  <h3 className="text-sm font-medium text-muted-foreground mb-1">Instância WhatsApp</h3>
                  <p className="font-medium">
                    {conversation.whatsapp_instances?.instance_name || "Instância desconhecida"}
                  </p>
                  {conversation.whatsapp_instances?.profile_name && (
                    <p className="text-sm text-muted-foreground">{conversation.whatsapp_instances.profile_name}</p>
                  )}
                </div>

                <Separator />

                <div>
                  <h3 className="text-sm font-medium text-muted-foreground mb-1">Datas</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    <div>
                      <p className="text-sm text-muted-foreground">Criada em</p>
                      <p>{format(new Date(conversation.created_at), "PPP 'às' HH:mm", { locale: ptBR })}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Última atualização</p>
                      <p>{format(new Date(conversation.updated_at), "PPP 'às' HH:mm", { locale: ptBR })}</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" color="destructive">
                Arquivar conversa
              </Button>
              <Button>Editar informações</Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
