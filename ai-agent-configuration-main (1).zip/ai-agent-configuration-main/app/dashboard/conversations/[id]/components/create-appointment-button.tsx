"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Calendar } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"
import { AppointmentService } from "@/lib/services/appointment-service"
import { useRouter } from "next/navigation"

interface CreateAppointmentButtonProps {
  conversationId: string
  contactName?: string
  contactPhone?: string
}

export function CreateAppointmentButton({ conversationId, contactName, contactPhone }: CreateAppointmentButtonProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [appointmentDate, setAppointmentDate] = useState("")
  const [appointmentTime, setAppointmentTime] = useState("")
  const [patientName, setPatientName] = useState(contactName || "")
  const [patientPhone, setPatientPhone] = useState(contactPhone || "")
  const [notes, setNotes] = useState("")

  const { toast } = useToast()
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!appointmentDate || !appointmentTime || !patientName) {
      toast({
        title: "Campos obrigatórios",
        description: "Por favor, preencha todos os campos obrigatórios.",
        variant: "destructive",
      })
      return
    }

    try {
      setIsLoading(true)

      // Combinar data e hora
      const dateTime = new Date(`${appointmentDate}T${appointmentTime}:00`)

      // Criar o agendamento
      await AppointmentService.createAppointmentFromConversation(conversationId, {
        patient_name: patientName,
        patient_phone: patientPhone,
        appointment_date: dateTime.toISOString(),
        status: "scheduled",
        notes,
        agent_id: null, // Será preenchido automaticamente com o agent_id da conversa, se disponível
      })

      toast({
        title: "Agendamento criado",
        description: "O agendamento foi criado com sucesso.",
      })

      // Fechar o modal e redirecionar para a página de agendamentos
      setIsOpen(false)
      router.push(`/dashboard/appointments?conversationId=${conversationId}`)
    } catch (error) {
      console.error("Erro ao criar agendamento:", error)
      toast({
        title: "Erro ao criar agendamento",
        description: "Ocorreu um erro ao criar o agendamento. Por favor, tente novamente.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="gap-2">
          <Calendar className="h-4 w-4" />
          Agendar Consulta
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <form onSubmit={handleSubmit}>
          <DialogHeader>
            <DialogTitle>Agendar Consulta</DialogTitle>
            <DialogDescription>Crie um novo agendamento a partir desta conversa.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="appointment-date">Data*</Label>
                <Input
                  id="appointment-date"
                  type="date"
                  value={appointmentDate}
                  onChange={(e) => setAppointmentDate(e.target.value)}
                  required
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="appointment-time">Hora*</Label>
                <Input
                  id="appointment-time"
                  type="time"
                  value={appointmentTime}
                  onChange={(e) => setAppointmentTime(e.target.value)}
                  required
                />
              </div>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="patient-name">Nome do Paciente*</Label>
              <Input id="patient-name" value={patientName} onChange={(e) => setPatientName(e.target.value)} required />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="patient-phone">Telefone do Paciente</Label>
              <Input id="patient-phone" value={patientPhone} onChange={(e) => setPatientPhone(e.target.value)} />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="notes">Observações</Label>
              <Textarea
                id="notes"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Adicione observações sobre o agendamento..."
              />
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setIsOpen(false)}>
              Cancelar
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading ? "Agendando..." : "Agendar"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
