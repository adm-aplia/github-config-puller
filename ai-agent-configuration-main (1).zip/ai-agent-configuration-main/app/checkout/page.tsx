"use client"

import type React from "react"

import { useState, useEffect, Suspense } from "react"
import { useSearchParams, useRouter } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/hooks/use-toast"
import { useAuth } from "@/hooks/use-auth"
import {
  Loader2,
  CheckCircle,
  ArrowLeft,
  Shield,
  Lock,
  CreditCard,
  MessageSquare,
  Calendar,
  Users,
  Mail,
  BarChart3,
  Clock,
  Building2,
  Settings,
} from "lucide-react"
import { validateCPF, formatCPF } from "@/lib/utils/cpf-validator"
import { validatePhone, formatPhone, phoneToAsaasFormat } from "@/lib/utils/phone-validator"
import { Logo } from "@/components/logo"

const plans = {
  basico: {
    id: "basico",
    name: "Básico",
    price: 199,
    description: "Para profissionais individuais que buscam eficiência e baixo custo",
    features: ["1 Número de WhatsApp", "Até 300 agendamentos/mês", "1 Assistente personalizado", "Suporte por e-mail"],
  },
  profissional: {
    id: "profissional",
    name: "Profissional",
    price: 399,
    description: "Recomendado para clínicas que desejam crescer",
    features: [
      "3 Números de WhatsApp",
      "Até 1.000 agendamentos/mês",
      "3 Assistentes personalizados",
      "Suporte prioritário",
      "Relatórios Avançados",
    ],
  },
  empresarial: {
    id: "empresarial",
    name: "Empresarial",
    price: 899,
    description: "Desenvolvido para clínicas e hospitais de grande porte",
    features: [
      "+10 Números de WhatsApp",
      "Agendamentos ilimitados",
      "Assistentes ilimitados",
      "Suporte 24/7 dedicado",
      "Integração com sistemas hospitalares",
      "Personalização avançada",
    ],
  },
}

// Função para obter o ícone correto para cada feature
const getFeatureIcon = (feature: string) => {
  if (feature.includes("WhatsApp") || feature.includes("Números")) {
    return <MessageSquare className="h-4 w-4 text-red-500 flex-shrink-0" />
  }
  if (feature.includes("agendamentos")) {
    return <Calendar className="h-4 w-4 text-red-500 flex-shrink-0" />
  }
  if (feature.includes("Assistentes") || feature.includes("personalizado")) {
    return <Users className="h-4 w-4 text-red-500 flex-shrink-0" />
  }
  if (feature.includes("Suporte") || feature.includes("e-mail")) {
    return <Mail className="h-4 w-4 text-red-500 flex-shrink-0" />
  }
  if (feature.includes("Relatórios")) {
    return <BarChart3 className="h-4 w-4 text-red-500 flex-shrink-0" />
  }
  if (feature.includes("24/7") || feature.includes("dedicado")) {
    return <Clock className="h-4 w-4 text-red-500 flex-shrink-0" />
  }
  if (feature.includes("hospitalares") || feature.includes("Integração")) {
    return <Building2 className="h-4 w-4 text-red-500 flex-shrink-0" />
  }
  if (feature.includes("Personalização")) {
    return <Settings className="h-4 w-4 text-red-500 flex-shrink-0" />
  }
  return <CheckCircle className="h-4 w-4 text-red-500 flex-shrink-0" />
}

function CheckoutContent() {
  const searchParams = useSearchParams()
  const router = useRouter()
  const { user } = useAuth()
  const { toast } = useToast()

  const planId = searchParams.get("plano") as keyof typeof plans
  const plan = plans[planId]

  const [loading, setLoading] = useState(false)
  const [step, setStep] = useState<"form" | "processing" | "success">("form")
  const [formData, setFormData] = useState({
    // Dados pessoais
    nome: "",
    telefone: "",
    documento: "",
    cep: "",
    endereco: "",
    numero: "",

    // Dados do cartão
    nomeCartao: "",
    numeroCartao: "",
    mesExpiracao: "",
    anoExpiracao: "",
    cvv: "",
  })
  const [resultData, setResultData] = useState<any>(null)

  useEffect(() => {
    if (!plan) {
      router.push("/dashboard/planos")
    }
  }, [plan, router])

  useEffect(() => {
    if (!user) {
      router.push("/login")
    }
  }, [user, router])

  if (!plan || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    )
  }

  const handleDocumentChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value
    const formatted = formatCPF(value)
    setFormData({ ...formData, documento: formatted })
  }

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value
    const formatted = formatPhone(value)
    setFormData({ ...formData, telefone: formatted })
  }

  const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value
    const formatted = value
      .replace(/\D/g, "")
      .replace(/(\d{4})(\d)/, "$1 $2")
      .replace(/(\d{4})(\d)/, "$1 $2")
      .replace(/(\d{4})(\d)/, "$1 $2")
      .replace(/(\d{4})\d+?$/, "$1")
    setFormData({ ...formData, numeroCartao: formatted })
  }

  const handleCEPChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value
    const formatted = value
      .replace(/\D/g, "")
      .replace(/(\d{5})(\d)/, "$1-$2")
      .replace(/(-\d{3})\d+?$/, "$1")
    setFormData({ ...formData, cep: formatted })
  }

  const validateForm = () => {
    if (!formData.nome.trim()) {
      toast({
        variant: "destructive",
        title: "Nome obrigatório",
        description: "Digite seu nome completo",
      })
      return false
    }

    if (!validateCPF(formData.documento)) {
      toast({
        variant: "destructive",
        title: "CPF inválido",
        description: "Digite um CPF válido",
      })
      return false
    }

    if (!validatePhone(formData.telefone)) {
      toast({
        variant: "destructive",
        title: "Telefone inválido",
        description: "Digite um telefone válido (ex: (11) 99999-9999)",
      })
      return false
    }

    if (!formData.nomeCartao.trim()) {
      toast({
        variant: "destructive",
        title: "Nome do cartão obrigatório",
        description: "Digite o nome como está no cartão",
      })
      return false
    }

    if (formData.numeroCartao.replace(/\D/g, "").length < 16) {
      toast({
        variant: "destructive",
        title: "Número do cartão inválido",
        description: "Digite um número de cartão válido",
      })
      return false
    }

    const mes = Number.parseInt(formData.mesExpiracao)
    if (mes < 1 || mes > 12) {
      toast({
        variant: "destructive",
        title: "Mês inválido",
        description: "Digite um mês válido (01-12)",
      })
      return false
    }

    const ano = Number.parseInt(formData.anoExpiracao)
    const anoAtual = new Date().getFullYear()
    if (ano < anoAtual || ano > anoAtual + 20) {
      toast({
        variant: "destructive",
        title: "Ano inválido",
        description: "Digite um ano válido",
      })
      return false
    }

    if (formData.cvv.length < 3) {
      toast({
        variant: "destructive",
        title: "CVV inválido",
        description: "Digite o código de segurança do cartão",
      })
      return false
    }

    return true
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!validateForm()) return

    setLoading(true)
    setStep("processing")

    try {
      const requestData = {
        nome: formData.nome,
        email: user.email,
        telefone: phoneToAsaasFormat(formData.telefone),
        documento: formData.documento.replace(/\D/g, ""),
        cep: formData.cep.replace(/\D/g, "") || "01310100",
        endereco: formData.endereco || "Rua Teste",
        numero: formData.numero || "100",
        plano: plan.name,
        user_id: user.id,
        cobranca_imediata: true, // Sempre true
        cartao: {
          nomeCartao: formData.nomeCartao,
          numeroCartao: formData.numeroCartao.replace(/\D/g, ""),
          mesExpiracao: formData.mesExpiracao.padStart(2, "0"),
          anoExpiracao: formData.anoExpiracao,
          cvv: formData.cvv,
        },
      }

      const response = await fetch("/api/subscription/create", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(requestData),
      })

      const result = await response.json()

      if (result.success) {
        setResultData(result.data)
        setStep("success")

        toast({
          title: "🎉 Sucesso!",
          description: `Assinatura do plano ${plan.name} ativada com sucesso!`,
        })

        // Redirecionar para o dashboard após 3 segundos
        setTimeout(() => {
          router.push("/dashboard")
        }, 3000)
      } else {
        throw new Error(result.error || result.message || "Erro desconhecido ao criar assinatura")
      }
    } catch (error: any) {
      console.error("Erro ao criar assinatura:", error)

      const errorMessage = error.message.toLowerCase()
      if (
        errorMessage.includes("limite") ||
        errorMessage.includes("limit") ||
        errorMessage.includes("insufficient") ||
        errorMessage.includes("não autorizada")
      ) {
        toast({
          variant: "destructive",
          title: "💳 Transação não autorizada",
          description: "Verifique o limite disponível no seu cartão de crédito.",
        })
      } else {
        toast({
          variant: "destructive",
          title: "Erro no pagamento",
          description: error.message || "Erro ao processar pagamento",
        })
      }

      setStep("form")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900">
      <div className="container mx-auto px-4 py-8">
        {/* Header com Logo */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-8">
            <Logo />
            <Button
              variant="ghost"
              onClick={() => router.push("/dashboard/planos")}
              className="text-gray-600 hover:text-gray-900"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Voltar aos planos
            </Button>
          </div>

          <div className="text-center">
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">Finalizar Assinatura</h1>
            <p className="text-gray-600 dark:text-gray-300">Complete seus dados para ativar o plano {plan.name}</p>
          </div>
        </div>

        {step === "form" && (
          <div className="grid lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
            {/* Formulário - Coluna da Esquerda */}
            <div className="order-2 lg:order-1">
              <Card className="shadow-lg border border-gray-200 dark:border-gray-700">
                <CardHeader className="bg-red-500 text-white rounded-t-lg">
                  <CardTitle className="text-xl font-bold flex items-center gap-2">
                    <CreditCard className="h-5 w-5" />
                    Dados para Pagamento
                  </CardTitle>
                </CardHeader>

                <CardContent className="p-6">
                  <form onSubmit={handleSubmit} className="space-y-6">
                    {/* Dados Pessoais */}
                    <div className="space-y-4">
                      <h3 className="font-semibold text-lg text-gray-900 dark:text-white">Dados Pessoais</h3>

                      <div>
                        <Label htmlFor="nome" className="text-gray-700 dark:text-gray-300">
                          Nome Completo *
                        </Label>
                        <Input
                          id="nome"
                          value={formData.nome}
                          onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                          placeholder="Seu nome completo"
                          required
                          className="mt-1"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="documento" className="text-gray-700 dark:text-gray-300">
                            CPF *
                          </Label>
                          <Input
                            id="documento"
                            value={formData.documento}
                            onChange={handleDocumentChange}
                            placeholder="000.000.000-00"
                            maxLength={14}
                            required
                            className="mt-1"
                          />
                        </div>

                        <div>
                          <Label htmlFor="telefone" className="text-gray-700 dark:text-gray-300">
                            Telefone *
                          </Label>
                          <Input
                            id="telefone"
                            value={formData.telefone}
                            onChange={handlePhoneChange}
                            placeholder="(11) 99999-9999"
                            maxLength={15}
                            required
                            className="mt-1"
                          />
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="email" className="text-gray-700 dark:text-gray-300">
                          E-mail
                        </Label>
                        <Input
                          id="email"
                          value={user?.email || ""}
                          disabled
                          className="mt-1 bg-gray-100 dark:bg-gray-700 cursor-not-allowed"
                        />
                      </div>
                    </div>

                    {/* Endereço */}
                    <div className="space-y-4">
                      <h3 className="font-semibold text-lg text-gray-900 dark:text-white">Endereço</h3>

                      <div className="grid grid-cols-3 gap-4">
                        <div>
                          <Label htmlFor="cep" className="text-gray-700 dark:text-gray-300">
                            CEP
                          </Label>
                          <Input
                            id="cep"
                            value={formData.cep}
                            onChange={handleCEPChange}
                            placeholder="00000-000"
                            maxLength={9}
                            className="mt-1"
                          />
                        </div>

                        <div>
                          <Label htmlFor="endereco" className="text-gray-700 dark:text-gray-300">
                            Rua
                          </Label>
                          <Input
                            id="endereco"
                            value={formData.endereco}
                            onChange={(e) => setFormData({ ...formData, endereco: e.target.value })}
                            placeholder="Nome da rua"
                            className="mt-1"
                          />
                        </div>

                        <div>
                          <Label htmlFor="numero" className="text-gray-700 dark:text-gray-300">
                            Número
                          </Label>
                          <Input
                            id="numero"
                            value={formData.numero}
                            onChange={(e) => setFormData({ ...formData, numero: e.target.value })}
                            placeholder="123"
                            className="mt-1"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Dados do Cartão */}
                    <div className="space-y-4">
                      <h3 className="font-semibold text-lg text-gray-900 dark:text-white flex items-center gap-2">
                        <CreditCard className="h-5 w-5 text-red-500" />
                        Dados do Cartão de Crédito
                      </h3>

                      <div>
                        <Label htmlFor="nomeCartao" className="text-gray-700 dark:text-gray-300">
                          Nome no Cartão *
                        </Label>
                        <Input
                          id="nomeCartao"
                          value={formData.nomeCartao}
                          onChange={(e) => setFormData({ ...formData, nomeCartao: e.target.value })}
                          placeholder="Nome como está no cartão"
                          required
                          className="mt-1"
                        />
                      </div>

                      <div>
                        <Label htmlFor="numeroCartao" className="text-gray-700 dark:text-gray-300">
                          Número do Cartão *
                        </Label>
                        <Input
                          id="numeroCartao"
                          value={formData.numeroCartao}
                          onChange={handleCardNumberChange}
                          placeholder="0000 0000 0000 0000"
                          maxLength={19}
                          required
                          className="mt-1"
                        />
                      </div>

                      <div className="grid grid-cols-3 gap-4">
                        <div>
                          <Label htmlFor="mesExpiracao" className="text-gray-700 dark:text-gray-300">
                            Mês *
                          </Label>
                          <Input
                            id="mesExpiracao"
                            value={formData.mesExpiracao}
                            onChange={(e) => setFormData({ ...formData, mesExpiracao: e.target.value })}
                            placeholder="MM"
                            maxLength={2}
                            required
                            className="mt-1"
                          />
                        </div>

                        <div>
                          <Label htmlFor="anoExpiracao" className="text-gray-700 dark:text-gray-300">
                            Ano *
                          </Label>
                          <Input
                            id="anoExpiracao"
                            value={formData.anoExpiracao}
                            onChange={(e) => setFormData({ ...formData, anoExpiracao: e.target.value })}
                            placeholder="AAAA"
                            maxLength={4}
                            required
                            className="mt-1"
                          />
                        </div>

                        <div>
                          <Label htmlFor="cvv" className="text-gray-700 dark:text-gray-300">
                            CVV *
                          </Label>
                          <Input
                            id="cvv"
                            value={formData.cvv}
                            onChange={(e) => setFormData({ ...formData, cvv: e.target.value })}
                            placeholder="123"
                            maxLength={4}
                            required
                            className="mt-1"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Botão de Confirmação */}
                    <Button
                      type="submit"
                      disabled={loading}
                      className="w-full bg-red-500 hover:bg-red-600 text-white py-4 text-lg font-semibold h-14"
                    >
                      {loading ? (
                        <>
                          <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                          Processando Pagamento...
                        </>
                      ) : (
                        "Confirmar e Ativar Plano"
                      )}
                    </Button>

                    {/* Selos de Segurança */}
                    <div className="flex justify-center items-center gap-6 pt-4 text-xs text-gray-500 dark:text-gray-400">
                      <div className="flex items-center gap-1">
                        <Shield className="h-3 w-3 text-green-500" />
                        <span>Checkout Seguro</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Lock className="h-3 w-3 text-green-500" />
                        <span>SSL Ativado</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <CheckCircle className="h-3 w-3 text-green-500" />
                        <span>Transação Protegida</span>
                      </div>
                    </div>
                  </form>
                </CardContent>
              </Card>
            </div>

            {/* Resumo do Plano - Coluna da Direita */}
            <div className="order-1 lg:order-2">
              <Card className="shadow-lg border border-gray-200 dark:border-gray-700 sticky top-8">
                <CardHeader className="bg-aplia-blue text-white rounded-t-lg">
                  <CardTitle className="text-xl">Resumo do Pedido</CardTitle>
                </CardHeader>
                <CardContent className="p-6 space-y-6">
                  <div>
                    <h3 className="text-2xl font-bold text-gray-900 dark:text-white">{plan.name}</h3>
                    <div className="text-4xl font-bold text-red-500 mt-2">R$ {plan.price}/mês</div>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mt-2">
                      Cobrança mensal recorrente.{" "}
                      <strong className="text-gray-900 dark:text-white">Cancele quando quiser.</strong>
                    </p>
                  </div>

                  <div>
                    <h4 className="font-semibold mb-3 text-gray-900 dark:text-white">Benefícios inclusos:</h4>
                    <ul className="space-y-3">
                      {plan.features.map((feature, index) => (
                        <li key={index} className="flex items-center gap-3 text-sm">
                          {getFeatureIcon(feature)}
                          <span className="text-gray-700 dark:text-gray-300">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        )}

        {step === "processing" && (
          <div className="text-center py-16 max-w-md mx-auto">
            <div className="mx-auto w-20 h-20 bg-red-100 dark:bg-red-900 rounded-full flex items-center justify-center mb-6">
              <Loader2 className="h-12 w-12 animate-spin text-red-600" />
            </div>
            <h3 className="text-2xl font-semibold mb-4 text-gray-900 dark:text-white">Processando sua assinatura...</h3>
            <p className="text-gray-600 dark:text-gray-400">
              Processando cobrança e ativando seu serviço. Aguarde alguns instantes...
            </p>
          </div>
        )}

        {step === "success" && (
          <div className="text-center py-16 max-w-md mx-auto">
            <div className="mx-auto w-20 h-20 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center mb-6">
              <CheckCircle className="h-12 w-12 text-green-600" />
            </div>
            <h3 className="text-2xl font-semibold mb-4 text-gray-900 dark:text-white">
              🎉 Assinatura ativada com sucesso!
            </h3>

            <p className="text-gray-600 dark:text-gray-400 mb-8">
              Seu plano {plan.name} está ativo! Redirecionando para o dashboard...
            </p>

            <Button
              onClick={() => router.push("/dashboard")}
              className="bg-red-500 hover:bg-red-600 text-white px-8 py-3"
            >
              Ir para Dashboard
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}

export default function CheckoutPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin" />
        </div>
      }
    >
      <CheckoutContent />
    </Suspense>
  )
}
