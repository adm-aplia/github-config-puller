"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, RefreshCw, Database, Cloud, AlertTriangle, CheckCircle, XCircle } from "lucide-react"
import { WhatsAppService } from "@/lib/services/whatsapp-service"
import { evolutionAPI } from "@/lib/evolution-api"

interface DebugInfo {
  timestamp: string
  databaseInstances: any[]
  apiInstances: any[]
  apiConfig: {
    url: string
    apiKey: string
    useProxy: boolean
  }
  errors: string[]
  warnings: string[]
}

export default function WhatsAppDebugPage() {
  const [debugInfo, setDebugInfo] = useState<DebugInfo | null>(null)
  const [isLoading, setIsLoading] = useState(false)

  const runDebug = async () => {
    setIsLoading(true)
    const errors: string[] = []
    const warnings: string[] = []

    try {
      console.log("🔍 [DEBUG] Iniciando debug das conexões WhatsApp...")

      // 1. Obter instâncias do banco de dados
      let databaseInstances: any[] = []
      try {
        databaseInstances = await WhatsAppService.getUserInstances()
        console.log("📊 [DEBUG] Instâncias do banco:", databaseInstances)
      } catch (error) {
        errors.push(`Erro ao buscar instâncias do banco: ${error.message}`)
        console.error("❌ [DEBUG] Erro no banco:", error)
      }

      // 2. Obter instâncias da API Evolution
      let apiInstances: any[] = []
      try {
        apiInstances = await evolutionAPI.getInstances()
        console.log("🌐 [DEBUG] Instâncias da API:", apiInstances)
      } catch (error) {
        errors.push(`Erro ao buscar instâncias da API: ${error.message}`)
        console.error("❌ [DEBUG] Erro na API:", error)
      }

      // 3. Verificar configurações da API
      const apiConfig = {
        url: "https://aplia-evolution.kopfcf.easypanel.host",
        apiKey: "F9CDB41C7A534C3B58A77B219BA6F",
        useProxy: true,
      }

      // 4. Comparar instâncias
      if (databaseInstances.length > 0 && apiInstances.length === 0) {
        warnings.push("Existem instâncias no banco mas nenhuma na API - possível problema de conectividade")
      }

      if (apiInstances.length > 0 && databaseInstances.length === 0) {
        warnings.push("Existem instâncias na API mas nenhuma no banco - possível problema de sincronização")
      }

      // 5. Verificar instâncias órfãs
      const dbInstanceNames = databaseInstances.map((i) => i.instance_name.toLowerCase())
      const apiInstanceNames = apiInstances.map((i) => i.instance.instanceName.toLowerCase())

      const orphanedInDb = dbInstanceNames.filter((name) => !apiInstanceNames.includes(name))
      const orphanedInApi = apiInstanceNames.filter((name) => !dbInstanceNames.includes(name))

      if (orphanedInDb.length > 0) {
        warnings.push(`Instâncias no banco sem correspondência na API: ${orphanedInDb.join(", ")}`)
      }

      if (orphanedInApi.length > 0) {
        warnings.push(`Instâncias na API sem correspondência no banco: ${orphanedInApi.join(", ")}`)
      }

      setDebugInfo({
        timestamp: new Date().toISOString(),
        databaseInstances,
        apiInstances,
        apiConfig,
        errors,
        warnings,
      })
    } catch (error) {
      errors.push(`Erro geral no debug: ${error.message}`)
      console.error("❌ [DEBUG] Erro geral:", error)
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    runDebug()
  }, [])

  const testDirectApiCall = async () => {
    try {
      console.log("🧪 [TEST] Testando chamada direta à API...")

      const response = await fetch("https://aplia-evolution.kopfcf.easypanel.host/instance/fetchInstances", {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          apikey: "F9CDB41C7A534C3B58A77B219BA6F",
        },
      })

      console.log("📡 [TEST] Status da resposta:", response.status)
      console.log("📡 [TEST] Headers:", Object.fromEntries(response.headers.entries()))

      if (response.ok) {
        const data = await response.json()
        console.log("✅ [TEST] Dados recebidos:", data)
        alert(`Sucesso! Recebidos ${Array.isArray(data) ? data.length : "dados"} da API`)
      } else {
        const errorText = await response.text()
        console.error("❌ [TEST] Erro:", errorText)
        alert(`Erro ${response.status}: ${errorText}`)
      }
    } catch (error) {
      console.error("❌ [TEST] Erro na chamada:", error)
      alert(`Erro na chamada: ${error.message}`)
    }
  }

  if (isLoading) {
    return (
      <div className="container mx-auto py-6">
        <div className="flex items-center justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground mr-2" />
          <span>Executando debug...</span>
        </div>
      </div>
    )
  }

  if (!debugInfo) {
    return (
      <div className="container mx-auto py-6">
        <Card>
          <CardContent className="pt-6">
            <p>Erro ao carregar informações de debug</p>
            <Button onClick={runDebug} className="mt-4">
              Tentar Novamente
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Debug WhatsApp Connections</h1>
          <p className="text-muted-foreground">Última atualização: {new Date(debugInfo.timestamp).toLocaleString()}</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={runDebug} variant="outline">
            <RefreshCw className="h-4 w-4 mr-2" />
            Atualizar
          </Button>
          <Button onClick={testDirectApiCall} variant="outline">
            Testar API Direta
          </Button>
        </div>
      </div>

      {/* Alertas */}
      {debugInfo.errors.length > 0 && (
        <Alert variant="destructive">
          <XCircle className="h-4 w-4" />
          <AlertDescription>
            <strong>Erros encontrados:</strong>
            <ul className="mt-2 list-disc list-inside">
              {debugInfo.errors.map((error, index) => (
                <li key={index}>{error}</li>
              ))}
            </ul>
          </AlertDescription>
        </Alert>
      )}

      {debugInfo.warnings.length > 0 && (
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            <strong>Avisos:</strong>
            <ul className="mt-2 list-disc list-inside">
              {debugInfo.warnings.map((warning, index) => (
                <li key={index}>{warning}</li>
              ))}
            </ul>
          </AlertDescription>
        </Alert>
      )}

      {debugInfo.errors.length === 0 && debugInfo.warnings.length === 0 && (
        <Alert>
          <CheckCircle className="h-4 w-4" />
          <AlertDescription>
            <strong>Tudo funcionando corretamente!</strong> Não foram encontrados problemas.
          </AlertDescription>
        </Alert>
      )}

      {/* Configurações da API */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Cloud className="h-5 w-5" />
            Configurações da Evolution API
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <strong>URL:</strong>
              <p className="text-sm text-muted-foreground break-all">{debugInfo.apiConfig.url}</p>
            </div>
            <div>
              <strong>API Key:</strong>
              <p className="text-sm text-muted-foreground">{debugInfo.apiConfig.apiKey.substring(0, 8)}...</p>
            </div>
            <div>
              <strong>Usando Proxy:</strong>
              <Badge variant={debugInfo.apiConfig.useProxy ? "default" : "secondary"}>
                {debugInfo.apiConfig.useProxy ? "Sim" : "Não"}
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Instâncias do Banco */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="h-5 w-5" />
              Instâncias no Banco de Dados
            </CardTitle>
            <CardDescription>{debugInfo.databaseInstances.length} instância(s) encontrada(s)</CardDescription>
          </CardHeader>
          <CardContent>
            {debugInfo.databaseInstances.length === 0 ? (
              <p className="text-muted-foreground">Nenhuma instância encontrada no banco</p>
            ) : (
              <div className="space-y-3">
                {debugInfo.databaseInstances.map((instance, index) => (
                  <div key={index} className="border rounded-lg p-3">
                    <div className="flex items-center justify-between mb-2">
                      <strong>{instance.instance_name}</strong>
                      <Badge
                        variant={
                          instance.status === "connected"
                            ? "default"
                            : instance.status === "connecting"
                              ? "secondary"
                              : "outline"
                        }
                      >
                        {instance.status}
                      </Badge>
                    </div>
                    <div className="text-sm text-muted-foreground space-y-1">
                      <p>
                        <strong>Nome:</strong> {instance.profile_name || "N/A"}
                      </p>
                      <p>
                        <strong>Telefone:</strong> {instance.phone_number || "N/A"}
                      </p>
                      <p>
                        <strong>Criado:</strong> {new Date(instance.created_at).toLocaleString()}
                      </p>
                      <p>
                        <strong>Atualizado:</strong> {new Date(instance.updated_at).toLocaleString()}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Instâncias da API */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Cloud className="h-5 w-5" />
              Instâncias na Evolution API
            </CardTitle>
            <CardDescription>{debugInfo.apiInstances.length} instância(s) encontrada(s)</CardDescription>
          </CardHeader>
          <CardContent>
            {debugInfo.apiInstances.length === 0 ? (
              <p className="text-muted-foreground">Nenhuma instância encontrada na API</p>
            ) : (
              <div className="space-y-3">
                {debugInfo.apiInstances.map((instance, index) => (
                  <div key={index} className="border rounded-lg p-3">
                    <div className="flex items-center justify-between mb-2">
                      <strong>{instance.instance.instanceName}</strong>
                      <Badge
                        variant={
                          instance.instance.status === "connected"
                            ? "default"
                            : instance.instance.status === "connecting"
                              ? "secondary"
                              : "outline"
                        }
                      >
                        {instance.instance.status}
                      </Badge>
                    </div>
                    <div className="text-sm text-muted-foreground space-y-1">
                      <p>
                        <strong>Nome:</strong> {instance.instance.profileName || "N/A"}
                      </p>
                      <p>
                        <strong>Owner:</strong> {instance.instance.owner || "N/A"}
                      </p>
                      <p>
                        <strong>Número:</strong> {instance.instance.number || "N/A"}
                      </p>
                      <p>
                        <strong>WID:</strong> {instance.instance.wid || "N/A"}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Dados Raw para Debug */}
      <Card>
        <CardHeader>
          <CardTitle>Dados Raw (Para Desenvolvedores)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <strong>Banco de Dados:</strong>
              <pre className="mt-2 p-3 bg-gray-100 rounded text-xs overflow-auto max-h-40">
                {JSON.stringify(debugInfo.databaseInstances, null, 2)}
              </pre>
            </div>
            <Separator />
            <div>
              <strong>Evolution API:</strong>
              <pre className="mt-2 p-3 bg-gray-100 rounded text-xs overflow-auto max-h-40">
                {JSON.stringify(debugInfo.apiInstances, null, 2)}
              </pre>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
