import { DatabaseHealthCheck } from "@/components/debug/database-health-check"

export default function DatabaseDebugPage() {
  return (
    <div className="container mx-auto py-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-8">Debug do Banco de Dados</h1>
        <DatabaseHealthCheck />
      </div>
    </div>
  )
}
