"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { CreateUserForm } from "@/components/admin/create-user-form"
import { useAuth } from "@/components/auth-provider"

export default function CreateUserPage() {
  const { user, isLoading } = useAuth()
  const router = useRouter()

  // Verificar se o usuário atual é nathancwb@gmail.com
  useEffect(() => {
    if (!isLoading && (!user || user.email !== "nathancwb@gmail.com")) {
      router.push("/login")
    }
  }, [user, isLoading, router])

  if (isLoading) {
    return <div>Carregando...</div>
  }

  if (!user || user.email !== "nathancwb@gmail.com") {
    return null
  }

  return (
    <div className="container mx-auto py-10">
      <div className="max-w-md mx-auto">
        <Card>
          <CardHeader>
            <CardTitle>Criar Novo Usuário</CardTitle>
            <CardDescription>Crie um novo usuário para o sistema MedAI</CardDescription>
          </CardHeader>
          <CardContent>
            <CreateUserForm />
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
