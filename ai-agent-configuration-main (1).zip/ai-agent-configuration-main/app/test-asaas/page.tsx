"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2 } from "lucide-react"
import { generateValidCPF } from "@/lib/utils/cpf-validator"

export default function TestAsaasPage() {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<any>(null)
  const [error, setError] = useState<string | null>(null)

  const testConnectivity = async () => {
    setLoading(true)
    setError(null)
    setResult(null)

    try {
      console.log("🔗 Testando conectividade...")

      const response = await fetch("/api/test-asaas", {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      })

      console.log("📡 Resposta recebida:", response.status, response.statusText)

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`)
      }

      const data = await response.json()
      console.log("✅ Dados:", data)
      setResult(data)
    } catch (err: any) {
      console.error("❌ Erro:", err)
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const testCreateCustomer = async () => {
    setLoading(true)
    setError(null)
    setResult(null)

    try {
      console.log("🏢 Testando criação de cliente...")

      // Gera um CPF válido para teste
      const validCPF = generateValidCPF()
      console.log("📋 CPF gerado para teste:", validCPF)

      const testData = {
        name: "João Silva Teste",
        cpfCnpj: validCPF.replace(/\D/g, ""), // Remove formatação para enviar para API
        email: `joao.teste.${Date.now()}@email.com`, // Email único
        phone: "41995824404", // Telefone no formato correto (DDD + 9 dígitos)
        mobilePhone: "41995824404", // Celular no mesmo formato
      }

      console.log("📤 Dados enviados:", testData)

      const response = await fetch("/api/test-asaas", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(testData),
      })

      console.log("📡 Resposta recebida:", response.status, response.statusText)

      if (!response.ok) {
        const errorText = await response.text()
        console.error("❌ Erro da API:", errorText)
        throw new Error(`HTTP ${response.status}: ${errorText}`)
      }

      const data = await response.json()
      console.log("✅ Dados:", data)
      setResult(data)
    } catch (err: any) {
      console.error("❌ Erro:", err)
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const testTokenizeCard = async () => {
    setLoading(true)
    setError(null)
    setResult(null)

    try {
      console.log("💳 Testando tokenização de cartão...")

      const validCPF = generateValidCPF()
      console.log("📋 CPF gerado para teste:", validCPF)

      const testData = {
        creditCard: {
          holderName: "JOAO SILVA TESTE",
          number: "4000000000000010", // Cartão de teste Asaas
          expiryMonth: "12",
          expiryYear: "2030",
          ccv: "123",
        },
        creditCardHolderInfo: {
          name: "João Silva Teste",
          email: `joao.teste.${Date.now()}@email.com`,
          cpfCnpj: validCPF.replace(/\D/g, ""),
          postalCode: "01310100",
          addressNumber: "123",
          phone: "41995824404", // Telefone no formato correto
        },
      }

      console.log("📤 Dados enviados para tokenização:", {
        ...testData,
        creditCard: { ...testData.creditCard, number: "****", ccv: "***" },
      })

      const response = await fetch("/api/test-asaas/tokenize", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(testData),
      })

      console.log("📡 Resposta recebida:", response.status, response.statusText)

      if (!response.ok) {
        const errorText = await response.text()
        console.error("❌ Erro da API:", errorText)
        throw new Error(`HTTP ${response.status}: ${errorText}`)
      }

      const data = await response.json()
      console.log("✅ Dados:", data)
      setResult(data)
    } catch (err: any) {
      console.error("❌ Erro:", err)
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-8 max-w-4xl">
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Teste Asaas API</h1>
          <p className="text-muted-foreground">Teste a integração com a API do Asaas</p>
          <div className="mt-2 text-sm text-muted-foreground">
            <p>📋 Formato de telefone: DDD + 9 dígitos (ex: 41995824404)</p>
            <p>📋 CPF: Gerado automaticamente e válido</p>
            <p>📋 Email: Único com timestamp</p>
          </div>
        </div>

        <div className="grid gap-4">
          <Card>
            <CardHeader>
              <CardTitle>Teste de Conectividade</CardTitle>
              <CardDescription>Verifica se consegue se conectar à API do Asaas</CardDescription>
            </CardHeader>
            <CardContent>
              <Button onClick={testConnectivity} disabled={loading}>
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Testando...
                  </>
                ) : (
                  "Testar Conectividade"
                )}
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Teste de Cliente</CardTitle>
              <CardDescription>Testa a criação de um cliente no Asaas com dados válidos</CardDescription>
            </CardHeader>
            <CardContent>
              <Button onClick={testCreateCustomer} disabled={loading}>
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Criando...
                  </>
                ) : (
                  "Criar Cliente Teste"
                )}
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Teste de Tokenização</CardTitle>
              <CardDescription>Testa a tokenização de cartão de crédito</CardDescription>
            </CardHeader>
            <CardContent>
              <Button onClick={testTokenizeCard} disabled={loading}>
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Tokenizando...
                  </>
                ) : (
                  "Tokenizar Cartão"
                )}
              </Button>
            </CardContent>
          </Card>
        </div>

        {error && (
          <Alert variant="destructive">
            <AlertDescription>
              <strong>Erro:</strong> {error}
            </AlertDescription>
          </Alert>
        )}

        {result && (
          <Card>
            <CardHeader>
              <CardTitle>Resultado</CardTitle>
            </CardHeader>
            <CardContent>
              <pre className="bg-muted p-4 rounded-md overflow-auto text-sm">{JSON.stringify(result, null, 2)}</pre>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
