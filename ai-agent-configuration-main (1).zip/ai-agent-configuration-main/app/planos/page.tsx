"use client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Check, Star, Zap, Building2 } from "lucide-react"
import { useRouter } from "next/navigation"

const plans = [
  {
    id: "basico",
    name: "Básico",
    price: 199,
    description: "Ideal para consultórios pequenos e profissionais autônomos",
    icon: <Star className="h-6 w-6" />,
    features: [
      "1 número WhatsApp",
      "300 agendamentos/mês",
      "1 assistente IA",
      "Suporte por e-mail",
      "Backup automático",
      "Segurança avançada",
    ],
  },
  {
    id: "profissional",
    name: "Profissional",
    price: 399,
    description: "Perfeito para clínicas e consultórios em crescimento",
    icon: <Zap className="h-6 w-6" />,
    popular: true,
    features: [
      "3 números WhatsApp",
      "1.000 agendamentos/mês",
      "3 assistentes IA",
      "Suporte prioritário",
      "Relatórios avançados",
      "Acesso à API",
      "Backup automático",
      "Segurança avançada",
    ],
  },
  {
    id: "empresarial",
    name: "Empresarial",
    price: 899,
    description: "Solução completa para hospitais e grandes clínicas",
    icon: <Building2 className="h-6 w-6" />,
    features: [
      "10+ números WhatsApp",
      "Agendamentos ilimitados",
      "Assistentes IA ilimitados",
      "Suporte 24/7",
      "Relatórios avançados",
      "Acesso à API",
      "Integração hospitalar",
      "Marca personalizada",
      "Personalização avançada",
      "Backup automático",
      "Segurança avançada",
    ],
  },
]

export default function PlanosPage() {
  const router = useRouter()

  const handlePlanSelection = (planId: string) => {
    router.push(`/checkout?plano=${planId}`)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      {/* Header */}
      <div className="container mx-auto px-4 py-16">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight text-gray-900 mb-4">Planos Aplia</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Escolha o plano ideal para seu consultório ou clínica
          </p>
        </div>

        {/* Plans Grid */}
        <div className="grid md:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {plans.map((plan) => (
            <Card
              key={plan.id}
              className={`relative transition-all duration-300 hover:shadow-2xl hover:-translate-y-2 ${
                plan.popular
                  ? "border-blue-500 shadow-xl scale-105 bg-white"
                  : "border-gray-200 hover:border-blue-300 bg-white"
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-1 text-sm font-medium">
                    Mais Popular
                  </Badge>
                </div>
              )}

              <CardHeader className="text-center pb-8 pt-8">
                <div className="flex justify-center mb-4 text-blue-600">{plan.icon}</div>
                <CardTitle className="text-2xl font-bold text-gray-900">{plan.name}</CardTitle>
                <CardDescription className="text-gray-600 mt-2 text-base">{plan.description}</CardDescription>
                <div className="mt-6">
                  <div className="flex items-baseline justify-center">
                    <span className="text-4xl font-bold text-gray-900">R$ {plan.price}</span>
                    <span className="text-gray-600 ml-2">/mês</span>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="px-6 pb-8">
                <ul className="space-y-4">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-start gap-3">
                      <Check className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                      <span className="text-gray-700 text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>

              <CardFooter className="px-6 pb-8">
                <Button
                  onClick={() => handlePlanSelection(plan.id)}
                  className={`w-full py-3 text-base font-medium transition-all duration-200 ${
                    plan.popular
                      ? "bg-blue-600 hover:bg-blue-700 text-white shadow-lg hover:shadow-xl"
                      : "bg-gray-900 hover:bg-gray-800 text-white hover:shadow-lg"
                  }`}
                >
                  Assinar {plan.name}
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>

        {/* Additional Info */}
        <div className="mt-16 text-center">
          <div className="bg-white rounded-2xl shadow-lg p-8 max-w-4xl mx-auto">
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Todos os planos incluem:</h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm text-gray-600">
              <div className="flex items-center gap-2">
                <Check className="h-4 w-4 text-green-500" />
                <span>Backup automático</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="h-4 w-4 text-green-500" />
                <span>Atualizações gratuitas</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="h-4 w-4 text-green-500" />
                <span>Segurança avançada</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="h-4 w-4 text-green-500" />
                <span>Conformidade LGPD</span>
              </div>
            </div>
          </div>
        </div>

        {/* Trust Indicators */}
        <div className="mt-12 text-center">
          <p className="text-sm text-gray-500 mb-4">Mais de 1.000 profissionais de saúde confiam na Aplia</p>
          <div className="flex justify-center items-center gap-8 opacity-60">
            <div className="text-xs text-gray-400">🔒 Pagamento Seguro</div>
            <div className="text-xs text-gray-400">✅ Cancele Quando Quiser</div>
            <div className="text-xs text-gray-400">📞 Suporte Especializado</div>
          </div>
        </div>
      </div>
    </div>
  )
}
