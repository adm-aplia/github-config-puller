"use client"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Loader2, Eye, EyeOff, Check, Mail, ArrowRight } from "lucide-react"
import { z } from "zod"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"

import { Button } from "@/components/ui/button"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"
import { useToast } from "@/hooks/use-toast"
import { cn } from "@/lib/utils"
import { Logo } from "@/components/logo"
import { getSupabaseInstance } from "@/lib/supabase-singleton"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

const formSchema = z
  .object({
    fullName: z.string().min(2, { message: "Nome deve ter pelo menos 2 caracteres" }),
    email: z.string().email({ message: "Por favor, insira um endereço de e-mail válido" }),
    password: z.string().min(6, { message: "A senha deve ter pelo menos 6 caracteres" }),
    confirmPassword: z.string(),
    acceptTerms: z.boolean().refine((val) => val === true, {
      message: "Você deve aceitar os termos de uso",
    }),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: "As senhas não coincidem",
    path: ["confirmPassword"],
  })

export default function CadastroPage() {
  const [isLoading, setIsLoading] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const [registrationComplete, setRegistrationComplete] = useState(false)
  const [userEmail, setUserEmail] = useState("")
  const router = useRouter()
  const { toast } = useToast()

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      fullName: "",
      email: "",
      password: "",
      confirmPassword: "",
      acceptTerms: false,
    },
  })

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsLoading(true)

    try {
      const supabase = getSupabaseInstance()

      if (!supabase) {
        throw new Error("Cliente Supabase não inicializado")
      }

      // Registrar o usuário diretamente com Supabase
      // O Supabase já faz a verificação se o email existe
      const { data, error } = await supabase.auth.signUp({
        email: values.email.toLowerCase().trim(),
        password: values.password,
        options: {
          data: {
            name: values.fullName,
          },
          emailRedirectTo: `${window.location.origin}/auth/callback`,
        },
      })

      if (error) {
        // Tratar diferentes tipos de erro
        if (
          error.message.includes("User already registered") ||
          error.message.includes("already been registered") ||
          error.message.includes("email address is already registered")
        ) {
          toast({
            variant: "destructive",
            title: "Email já cadastrado",
            description: "Este endereço de e-mail já está cadastrado. Tente fazer login ou use um e-mail diferente.",
          })
        } else if (error.message.includes("Invalid email")) {
          toast({
            variant: "destructive",
            title: "Email inválido",
            description: "Por favor, insira um endereço de e-mail válido.",
          })
        } else if (error.message.includes("Password")) {
          toast({
            variant: "destructive",
            title: "Senha inválida",
            description: "A senha deve ter pelo menos 6 caracteres.",
          })
        } else {
          toast({
            variant: "destructive",
            title: "Erro ao criar conta",
            description: error.message || "Ocorreu um erro inesperado. Tente novamente.",
          })
        }
        throw error
      }

      // Verificar se o usuário foi criado com sucesso
      if (data.user) {
        // Salvar o email para exibir na tela de confirmação
        setUserEmail(values.email)

        // Mostrar a tela de confirmação
        setRegistrationComplete(true)

        toast({
          title: "Conta criada com sucesso!",
          description: "Verifique seu email para confirmar seu cadastro.",
        })
      } else {
        throw new Error("Falha ao criar usuário")
      }
    } catch (error: any) {
      console.error("Erro no cadastro:", error)
      // O erro já foi tratado acima, não precisa fazer nada aqui
    } finally {
      setIsLoading(false)
    }
  }

  // Tela de confirmação após o cadastro
  if (registrationComplete) {
    return (
      <div className="min-h-screen flex flex-col justify-center py-12 sm:px-6 lg:px-8 bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
        <div className="sm:mx-auto sm:w-full sm:max-w-md">
          <div className="flex justify-center mb-8">
            <Link href="/" className="flex items-center">
              <Logo size="large" variant="auto" />
            </Link>
          </div>

          <Card className="border-0 shadow-xl">
            <CardHeader className="text-center">
              <div className="mx-auto bg-aplia-coral/10 dark:bg-aplia-coral/20 p-3 rounded-full w-16 h-16 flex items-center justify-center mb-4">
                <Mail className="h-8 w-8 text-aplia-coral dark:text-aplia-coral" />
              </div>
              <CardTitle className="text-2xl font-bold">Verifique seu email</CardTitle>
              <CardDescription className="text-base">
                Enviamos um link de confirmação para <span className="font-medium">{userEmail}</span>
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 text-center">
              <p className="text-gray-600 dark:text-gray-400">
                Por favor, verifique sua caixa de entrada e clique no link de confirmação para ativar sua conta.
              </p>
              <p className="text-gray-600 dark:text-gray-400 text-sm">
                Se não encontrar o email, verifique sua pasta de spam.
              </p>
              <Button className="mt-6 w-full" onClick={() => router.push("/")}>
                Ir para página de login
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col justify-center py-12 sm:px-6 lg:px-8 bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        {/* Logo */}
        <div className="flex justify-center mb-8">
          <Link href="/" className="flex items-center">
            <Logo size="large" variant="auto" />
          </Link>
        </div>

        {/* Título */}
        <div className="text-center">
          <h2 className="text-3xl font-bold tracking-tight text-gray-900 dark:text-white">Criar nova conta</h2>
          <p className="mt-2 text-sm text-gray-600 dark:text-gray-400">Junte-se à plataforma de saúde mais avançada</p>
        </div>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white dark:bg-gray-800 py-8 px-4 shadow-xl sm:rounded-xl sm:px-10 border border-gray-200 dark:border-gray-700">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="fullName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-700 dark:text-gray-300 font-medium">Nome completo</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="Seu nome completo"
                        {...field}
                        className="h-11 bg-gray-50 dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:ring-aplia-coral focus:border-aplia-coral rounded-lg"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-700 dark:text-gray-300 font-medium">E-mail</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="seu@email.com"
                        type="email"
                        {...field}
                        className="h-11 bg-gray-50 dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:ring-aplia-coral focus:border-aplia-coral rounded-lg"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-700 dark:text-gray-300 font-medium">Senha</FormLabel>
                    <div className="relative">
                      <FormControl>
                        <Input
                          type={showPassword ? "text" : "password"}
                          {...field}
                          className="h-11 bg-gray-50 dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:ring-aplia-coral focus:border-aplia-coral rounded-lg pr-10"
                        />
                      </FormControl>
                      <button
                        type="button"
                        className="absolute inset-y-0 right-0 flex items-center pr-3 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        {showPassword ? (
                          <EyeOff className="h-5 w-5" aria-hidden="true" />
                        ) : (
                          <Eye className="h-5 w-5" aria-hidden="true" />
                        )}
                      </button>
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="confirmPassword"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-700 dark:text-gray-300 font-medium">Confirmar senha</FormLabel>
                    <div className="relative">
                      <FormControl>
                        <Input
                          type={showConfirmPassword ? "text" : "password"}
                          {...field}
                          className="h-11 bg-gray-50 dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:ring-aplia-coral focus:border-aplia-coral rounded-lg pr-10"
                        />
                      </FormControl>
                      <button
                        type="button"
                        className="absolute inset-y-0 right-0 flex items-center pr-3 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                        onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      >
                        {showConfirmPassword ? (
                          <EyeOff className="h-5 w-5" aria-hidden="true" />
                        ) : (
                          <Eye className="h-5 w-5" aria-hidden="true" />
                        )}
                      </button>
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="acceptTerms"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox checked={field.value} onCheckedChange={field.onChange} className="mt-1" />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel className="text-sm text-gray-700 dark:text-gray-300">
                        Aceito os{" "}
                        <Link
                          href="/termos"
                          className="text-aplia-coral hover:text-aplia-coral/80 dark:text-aplia-coral"
                        >
                          termos de uso
                        </Link>{" "}
                        e{" "}
                        <Link
                          href="/privacidade"
                          className="text-aplia-coral hover:text-aplia-coral/80 dark:text-aplia-coral"
                        >
                          política de privacidade
                        </Link>
                      </FormLabel>
                      <FormMessage />
                    </div>
                  </FormItem>
                )}
              />

              <div>
                <Button
                  type="submit"
                  className={cn(
                    "w-full h-11 flex justify-center items-center rounded-lg shadow-sm text-sm font-medium text-white",
                    "bg-aplia-coral hover:bg-aplia-coral/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-aplia-coral",
                    "disabled:opacity-50 disabled:cursor-not-allowed",
                  )}
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Criando conta...
                    </>
                  ) : (
                    <>
                      <Check className="mr-2 h-4 w-4" />
                      Criar conta
                    </>
                  )}
                </Button>
              </div>
            </form>
          </Form>

          {/* Link para login (página inicial) */}
          <div className="mt-6 text-center">
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Já tem uma conta?{" "}
              <Link
                href="/"
                className="font-medium text-aplia-coral hover:text-aplia-coral/80 dark:text-aplia-coral dark:hover:text-aplia-coral/80"
              >
                Faça login aqui
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
