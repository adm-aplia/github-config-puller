"use client"
import { BillingTestForm } from "@/components/billing/billing-test-form"

export default function BillingTestPage() {
  return (
    <div className="container py-10">
      <h1 className="text-3xl font-bold mb-6 text-center">Sistema de Cobrança Aplia</h1>
      <BillingTestForm />
    </div>
  )
}
