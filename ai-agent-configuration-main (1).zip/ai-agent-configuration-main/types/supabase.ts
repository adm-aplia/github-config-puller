export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[]

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          name: string | null
          first_name: string | null
          last_name: string | null
          email: string | null
          phone: string | null
          specialty: string | null
          notifications_email: boolean
          notifications_push: boolean
          notifications_sms: boolean
          notifications_appointments: boolean
          notifications_messages: boolean
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          name?: string | null
          first_name?: string | null
          last_name?: string | null
          email?: string | null
          phone?: string | null
          specialty?: string | null
          notifications_email?: boolean
          notifications_push?: boolean
          notifications_sms?: boolean
          notifications_appointments?: boolean
          notifications_messages?: boolean
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          name?: string | null
          first_name?: string | null
          last_name?: string | null
          email?: string | null
          phone?: string | null
          specialty?: string | null
          notifications_email?: boolean
          notifications_push?: boolean
          notifications_sms?: boolean
          notifications_appointments?: boolean
          notifications_messages?: boolean
          created_at?: string
          updated_at?: string
        }
      }
      agents: {
        Row: {
          id: string
          user_id: string
          name: string
          specialty: string | null
          description: string | null
          greeting: string | null
          model: string
          temperature: number
          // Campos de agent_settings incorporados
          appointment_response: string | null
          emergency_response: string | null
          followup_response: string | null
          medical_advice_policy: string | null
          personal_info_policy: string | null
          escalation_criteria: string | null
          // Campos de agent_instances incorporados
          instance_ids: string[]
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          name: string
          specialty?: string | null
          description?: string | null
          greeting?: string | null
          model?: string
          temperature?: number
          // Campos de agent_settings incorporados
          appointment_response?: string | null
          emergency_response?: string | null
          followup_response?: string | null
          medical_advice_policy?: string | null
          personal_info_policy?: string | null
          escalation_criteria?: string | null
          // Campos de agent_instances incorporados
          instance_ids?: string[]
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          name?: string
          specialty?: string | null
          description?: string | null
          greeting?: string | null
          model?: string
          temperature?: number
          // Campos de agent_settings incorporados
          appointment_response?: string | null
          emergency_response?: string | null
          followup_response?: string | null
          medical_advice_policy?: string | null
          personal_info_policy?: string | null
          escalation_criteria?: string | null
          // Campos de agent_instances incorporados
          instance_ids?: string[]
          created_at?: string
          updated_at?: string
        }
      }
      whatsapp_instances: {
        Row: {
          id: string
          user_id: string
          instance_name: string
          profile_name: string | null
          status: string
          created_at: string
          updated_at: string
          profile_id: string | null
          professional_profile_id: string | null
        }
        Insert: {
          id?: string
          user_id: string
          instance_name: string
          profile_name?: string | null
          status?: string
          created_at?: string
          updated_at?: string
          profile_id?: string | null
          professional_profile_id?: string | null
        }
        Update: {
          id?: string
          user_id?: string
          instance_name?: string
          profile_name?: string | null
          status?: string
          created_at?: string
          updated_at?: string
          profile_id?: string | null
          professional_profile_id?: string | null
        }
      }
      conversations: {
        Row: {
          id: string
          user_id: string
          agent_id: string | null
          instance_id: string
          contact_name: string | null
          contact_phone: string | null
          status: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          agent_id?: string | null
          instance_id: string
          contact_name?: string | null
          contact_phone?: string | null
          status?: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          agent_id?: string | null
          instance_id?: string
          contact_name?: string | null
          contact_phone?: string | null
          status?: string
          created_at?: string
          updated_at?: string
        }
      }
      messages: {
        Row: {
          id: string
          conversation_id: string
          sender: string
          content: string
          created_at: string
        }
        Insert: {
          id?: string
          conversation_id: string
          sender: string
          content: string
          created_at?: string
        }
        Update: {
          id?: string
          conversation_id?: string
          sender?: string
          content?: string
          created_at?: string
        }
      }
      user_settings: {
        Row: {
          user_id: string
          language: string
          timezone: string
          theme: string
          notifications_enabled: boolean
          api_url: string | null
          api_key: string | null
          webhook_url: string | null
          ai_provider: string
          ai_model: string
          ai_api_key: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          user_id: string
          language?: string
          timezone?: string
          theme?: string
          notifications_enabled?: boolean
          api_url?: string | null
          api_key?: string | null
          webhook_url?: string | null
          ai_provider?: string
          ai_model?: string
          ai_api_key?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          user_id?: string
          language?: string
          timezone?: string
          theme?: string
          notifications_enabled?: boolean
          api_url?: string | null
          api_key?: string | null
          webhook_url?: string | null
          ai_provider?: string
          ai_model?: string
          ai_api_key?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      appointments: {
        Row: {
          id: string
          user_id: string
          patient_name: string
          patient_phone: string | null
          appointment_date: string
          status: string
          notes: string | null
          agent_id: string | null
          conversation_id: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          patient_name: string
          patient_phone?: string | null
          appointment_date: string
          status?: string
          notes?: string | null
          agent_id?: string | null
          conversation_id?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          patient_name?: string
          patient_phone?: string | null
          appointment_date?: string
          status?: string
          notes?: string | null
          agent_id?: string | null
          conversation_id?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      dashboard_settings: {
        Row: {
          user_id: string
          visible_widgets: string[]
          default_view: string
          created_at: string
          updated_at: string
        }
        Insert: {
          user_id: string
          visible_widgets?: string[]
          default_view?: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          user_id?: string
          visible_widgets?: string[]
          default_view?: string
          created_at?: string
          updated_at?: string
        }
      }
      professional_profiles: {
        Row: {
          id: string
          user_id: string
          fullName: string | null
          specialty: string | null
          professionalId: string | null
          phoneNumber: string | null
          email: string | null
          education: string | null
          locations: string | null
          workingHours: string | null
          procedures: string | null
          healthInsurance: string | null
          paymentMethods: string | null
          consultationFees: string | null
          cancellationPolicy: string | null
          consultationDuration: string | null
          timeBetweenConsultations: string | null
          reschedulingPolicy: string | null
          onlineConsultations: string | null
          reminderPreferences: string | null
          requiredPatientInfo: string | null
          appointmentConditions: string | null
          medicalHistoryRequirements: string | null
          ageRequirements: string | null
          communicationChannels: string | null
          preAppointmentInfo: string | null
          requiredDocuments: string | null
          avatar_url: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          fullName?: string | null
          specialty?: string | null
          professionalId?: string | null
          phoneNumber?: string | null
          email?: string | null
          education?: string | null
          locations?: string | null
          workingHours?: string | null
          procedures?: string | null
          healthInsurance?: string | null
          paymentMethods?: string | null
          consultationFees?: string | null
          cancellationPolicy?: string | null
          consultationDuration?: string | null
          timeBetweenConsultations?: string | null
          reschedulingPolicy?: string | null
          onlineConsultations?: string | null
          reminderPreferences?: string | null
          requiredPatientInfo?: string | null
          appointmentConditions?: string | null
          medicalHistoryRequirements?: string | null
          ageRequirements?: string | null
          communicationChannels?: string | null
          preAppointmentInfo?: string | null
          requiredDocuments?: string | null
          avatar_url?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          fullName?: string | null
          specialty?: string | null
          professionalId?: string | null
          phoneNumber?: string | null
          email?: string | null
          education?: string | null
          locations?: string | null
          workingHours?: string | null
          procedures?: string | null
          healthInsurance?: string | null
          paymentMethods?: string | null
          consultationFees?: string | null
          cancellationPolicy?: string | null
          consultationDuration?: string | null
          timeBetweenConsultations?: string | null
          reschedulingPolicy?: string | null
          onlineConsultations?: string | null
          reminderPreferences?: string | null
          requiredPatientInfo?: string | null
          appointmentConditions?: string | null
          medicalHistoryRequirements?: string | null
          ageRequirements?: string | null
          communicationChannels?: string | null
          preAppointmentInfo?: string | null
          requiredDocuments?: string | null
          avatar_url?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      prompts: {
        Row: {
          id: string
          user_id: string
          questionnaire_id: string | null
          prompt_text: string
          prompt_type: string
          is_active: boolean
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          questionnaire_id?: string | null
          prompt_text: string
          prompt_type?: string
          is_active?: boolean
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          questionnaire_id?: string | null
          prompt_text?: string
          prompt_type?: string
          is_active?: boolean
          created_at?: string
          updated_at?: string
        }
      }
      google_credentials: {
        Row: {
          id: string
          user_id: string | null
          email: string | null
          access_token: string | null
          refresh_token: string | null
          expires_at: string | null
          name: string | null
          picture: string | null
          created_at: string
          updated_at: string
          professional_profile_id: string | null
        }
        Insert: {
          id?: string
          user_id?: string | null
          email?: string | null
          access_token?: string | null
          refresh_token?: string | null
          expires_at?: string | null
          name?: string | null
          picture?: string | null
          created_at?: string
          updated_at?: string
          professional_profile_id?: string | null
        }
        Update: {
          id?: string
          user_id?: string | null
          email?: string | null
          access_token?: string | null
          refresh_token?: string | null
          expires_at?: string | null
          name?: string | null
          picture?: string | null
          created_at?: string
          updated_at?: string
          professional_profile_id?: string | null
        }
      }
    }
  }
}
