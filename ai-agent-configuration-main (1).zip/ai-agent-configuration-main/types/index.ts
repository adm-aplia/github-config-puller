export interface Plan {
  id: string
  name: string
  price: number
  description: string
  features: {
    whatsapp_instances: number
    max_appointments: number
    assistants: number
    support_level: string
    advanced_reports?: boolean
    api_access?: boolean
    hospital_integration?: boolean
    custom_branding?: boolean
    advanced_customization?: boolean
  }
  popular?: boolean
  current?: boolean
}

export interface User {
  id: string
  email?: string
  user_metadata?: {
    name?: string
  }
}

export interface ClienteData {
  nome: string
  email: string
  telefone: string
  documento: string
  plano: string
  user_id?: string
  endereco?: string
  cidade?: string
  estado?: string
  cep?: string
  observacoes?: string
}

export interface SubscriptionData extends ClienteData {
  nome_cartao: string
  numero_cartao: string
  mes_expiracao: string
  ano_expiracao: string
  cvv: string
  remote_ip: string
  numero_endereco?: string
}
