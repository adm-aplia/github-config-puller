"use client"

import type React from "react"
import { createContext, useContext, useEffect, useState } from "react"
import { supabase } from "@/lib/supabase"
import type { SupabaseClient } from "@supabase/supabase-js"
import type { Database } from "@/types/supabase"

interface SupabaseContextType {
  supabase: SupabaseClient<Database>
  isInitialized: boolean
}

const SupabaseContext = createContext<SupabaseContextType | undefined>(undefined)

export function SupabaseProvider({ children }: { children: React.ReactNode }) {
  const [isInitialized, setIsInitialized] = useState(false)

  useEffect(() => {
    // Usar a instância única já criada
    const checkSupabase = async () => {
      try {
        await supabase.auth.getSession()
        setIsInitialized(true)
        console.log("Contexto Supabase inicializado")
      } catch (error) {
        console.error("Erro no contexto Supabase:", error)
        setIsInitialized(false)
      }
    }

    checkSupabase()
  }, [])

  return <SupabaseContext.Provider value={{ supabase, isInitialized }}>{children}</SupabaseContext.Provider>
}

export function useSupabase() {
  const context = useContext(SupabaseContext)
  if (context === undefined) {
    throw new Error("useSupabase deve ser usado dentro de um SupabaseProvider")
  }
  return context
}
