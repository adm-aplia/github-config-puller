import { type NextRequest, NextResponse } from "next/server"
import { PermissionsService } from "@/lib/services/permissions-service"
import { getSupabaseServerClient } from "@/lib/supabase-singleton"

export interface PermissionMiddlewareOptions {
  feature?: "whatsapp" | "appointment" | "assistant" | "advanced_reports" | "hospital_integration" | "api_access"
  requireActive?: boolean
}

export async function withPermissions(request: NextRequest, options: PermissionMiddlewareOptions = {}) {
  try {
    // Extrair token do header Authorization
    const authHeader = request.headers.get("authorization")
    if (!authHeader?.startsWith("Bearer ")) {
      return NextResponse.json({ error: "Token de autorização necessário" }, { status: 401 })
    }

    const token = authHeader.substring(7)
    const supabase = await getSupabaseServerClient()

    // Verificar token e obter usuário
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser(token)

    if (authError || !user) {
      return NextResponse.json({ error: "Token inválido" }, { status: 401 })
    }

    // Verificar se precisa de assinatura ativa
    if (options.requireActive !== false) {
      const hasActiveSubscription = await PermissionsService.getUserPlanLimits(user.id)

      if (!hasActiveSubscription) {
        return NextResponse.json(
          {
            error: "Assinatura ativa necessária",
            code: "SUBSCRIPTION_REQUIRED",
          },
          { status: 403 },
        )
      }
    }

    // Verificar permissão específica da funcionalidade
    if (options.feature) {
      let hasPermission = false

      switch (options.feature) {
        case "whatsapp":
          const whatsappCheck = await PermissionsService.canCreateWhatsAppInstance(user.id)
          hasPermission = whatsappCheck.allowed
          if (!hasPermission) {
            return NextResponse.json(
              {
                error: whatsappCheck.reason,
                code: "LIMIT_EXCEEDED",
                current_usage: whatsappCheck.current_usage,
                limit: whatsappCheck.limit,
              },
              { status: 403 },
            )
          }
          break

        case "appointment":
          const appointmentCheck = await PermissionsService.canCreateAppointment(user.id)
          hasPermission = appointmentCheck.allowed
          if (!hasPermission) {
            return NextResponse.json(
              {
                error: appointmentCheck.reason,
                code: "LIMIT_EXCEEDED",
                current_usage: appointmentCheck.current_usage,
                limit: appointmentCheck.limit,
              },
              { status: 403 },
            )
          }
          break

        case "assistant":
          const assistantCheck = await PermissionsService.canCreateAssistant(user.id)
          hasPermission = assistantCheck.allowed
          if (!hasPermission) {
            return NextResponse.json(
              {
                error: assistantCheck.reason,
                code: "LIMIT_EXCEEDED",
                current_usage: assistantCheck.current_usage,
                limit: assistantCheck.limit,
              },
              { status: 403 },
            )
          }
          break

        case "advanced_reports":
        case "hospital_integration":
        case "api_access":
          hasPermission = await PermissionsService.hasFeatureAccess(user.id, options.feature)
          if (!hasPermission) {
            return NextResponse.json(
              {
                error: `Funcionalidade '${options.feature}' não disponível no seu plano`,
                code: "FEATURE_NOT_AVAILABLE",
              },
              { status: 403 },
            )
          }
          break
      }
    }

    // Adicionar user ao request para uso posterior
    const response = NextResponse.next()
    response.headers.set("x-user-id", user.id)

    return response
  } catch (error) {
    console.error("Erro no middleware de permissões:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}
