import { type NextRequest, NextResponse } from "next/server"
import { getSupabaseServerClient } from "@/lib/supabase-singleton"

export interface PlanAccessOptions {
  resource?: "whatsapp" | "appointment" | "assistant"
  feature?: "advanced_reports" | "hospital_integration" | "api_access" | "custom_branding"
  requireActive?: boolean
}

export async function withPlanAccess(request: NextRequest, options: PlanAccessOptions = {}) {
  try {
    const supabase = await getSupabaseServerClient()

    // Obter usuário da sessão
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError || !user) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
    }

    // Verificar se precisa de assinatura ativa
    if (options.requireActive !== false) {
      const { data: cliente } = await supabase
        .from("clientes")
        .select("*")
        .eq("user_id", user.id)
        .eq("is_active", true)
        .eq("status", "ativo")
        .single()

      if (!cliente) {
        return NextResponse.json(
          {
            error: "Assinatura ativa necessária",
            code: "SUBSCRIPTION_REQUIRED",
          },
          { status: 403 },
        )
      }
    }

    // Verificar limite de recurso específico
    if (options.resource) {
      const { data: checkResult } = await supabase.rpc("check_user_limit", {
        p_user_id: user.id,
        p_resource_type: options.resource,
      })

      if (!checkResult?.allowed) {
        return NextResponse.json(
          {
            error: checkResult?.reason || "Limite atingido",
            code: "LIMIT_EXCEEDED",
            current_usage: checkResult?.current_usage,
            limit: checkResult?.limit,
          },
          { status: 403 },
        )
      }
    }

    // Verificar acesso a funcionalidade específica
    if (options.feature) {
      const { data: plano } = await supabase
        .from("clientes")
        .select(`
          planos!inner(${options.feature})
        `)
        .eq("user_id", user.id)
        .eq("is_active", true)
        .single()

      const hasFeature = plano?.planos?.[options.feature]

      if (!hasFeature) {
        return NextResponse.json(
          {
            error: `Funcionalidade '${options.feature}' não disponível no seu plano`,
            code: "FEATURE_NOT_AVAILABLE",
          },
          { status: 403 },
        )
      }
    }

    // Adicionar user_id ao header para uso posterior
    const response = NextResponse.next()
    response.headers.set("x-user-id", user.id)

    return response
  } catch (error) {
    console.error("Erro no middleware de planos:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}
