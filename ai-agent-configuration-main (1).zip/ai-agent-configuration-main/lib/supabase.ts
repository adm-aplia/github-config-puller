import { createBrowserClient } from "@supabase/ssr"

let supabaseInstance: any = null

export function getSupabaseBrowserClient() {
  if (supabaseInstance) {
    return supabaseInstance
  }

  supabaseInstance = createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
  )

  console.log("✅ Cliente Supabase único inicializado")
  return supabaseInstance
}

export function getSupabaseClient() {
  return getSupabaseBrowserClient()
}

export function getSupabaseInstance() {
  return getSupabaseBrowserClient()
}

// Server client function for compatibility
export async function getSupabaseServerClient() {
  // For client-side usage, return the browser client
  return getSupabaseBrowserClient()
}

// Named export
export const supabase = getSupabaseBrowserClient()

// Default export
export default supabase

// Types
export type User = {
  id: string
  email?: string
  name?: string
  role?: string
  isConfirmed: boolean
}

export type Session = {
  user: any
  access_token: string
  refresh_token: string
  expires_at?: number
  expires_in: number
  token_type: string
}
