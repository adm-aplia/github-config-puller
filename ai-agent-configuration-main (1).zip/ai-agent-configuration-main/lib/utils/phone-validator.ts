// Função para validar telefone brasileiro
export function validatePhone(phone: string): boolean {
  const cleanPhone = phone.replace(/\D/g, "")

  // Telefone deve ter 10 ou 11 dígitos (DDD + número)
  if (cleanPhone.length < 10 || cleanPhone.length > 11) return false

  // DDD deve estar entre 11 e 99
  const ddd = Number.parseInt(cleanPhone.substring(0, 2))
  if (ddd < 11 || ddd > 99) return false

  // Se tem 11 dígitos, o terceiro deve ser 9 (celular)
  if (cleanPhone.length === 11 && cleanPhone.charAt(2) !== "9") return false

  return true
}

// Função para formatar telefone
export function formatPhone(phone: string): string {
  const cleanPhone = phone.replace(/\D/g, "")

  if (cleanPhone.length <= 2) return cleanPhone
  if (cleanPhone.length <= 6) return `(${cleanPhone.slice(0, 2)}) ${cleanPhone.slice(2)}`
  if (cleanPhone.length <= 10) {
    return `(${cleanPhone.slice(0, 2)}) ${cleanPhone.slice(2, 6)}-${cleanPhone.slice(6)}`
  }

  return `(${cleanPhone.slice(0, 2)}) ${cleanPhone.slice(2, 7)}-${cleanPhone.slice(7, 11)}`
}

// Função para converter telefone para formato Asaas (apenas números)
export function phoneToAsaasFormat(phone: string): string {
  const cleanPhone = phone.replace(/\D/g, "")

  // Se tem 10 dígitos, adiciona o 9 no celular
  if (cleanPhone.length === 10) {
    const ddd = cleanPhone.substring(0, 2)
    const number = cleanPhone.substring(2)
    return `${ddd}9${number}`
  }

  return cleanPhone
}

// Função para gerar telefone válido para testes
export function generateValidPhone(): string {
  const ddds = ["11", "21", "31", "41", "51", "61", "71", "81", "85", "91"]
  const ddd = ddds[Math.floor(Math.random() * ddds.length)]
  const number = Math.floor(Math.random() * 100000000)
    .toString()
    .padStart(8, "0")

  return `${ddd}9${number}` // Formato celular com 9
}
