/**
 * Injects a MetaMask-compatible `window.ethereum` provider at runtime.
 * Useful when you already have the provider object (e.g. from WalletConnect)
 * and want libraries that expect MetaMask to work seamlessly.
 *
 * This helper is safe to call multiple times – it only defines
 * `window.ethereum` when it doesn’t exist yet.
 */

declare global {
  interface Window {
    ethereum?: unknown // Use a stricter type if you have one.
  }
}

/**
 * Adds the given provider to `window.ethereum`, if it’s not already set.
 */
export function injectMetamaskShim(provider: unknown): void {
  if (typeof window === "undefined") return // SSR guard
  if (!window.ethereum && provider) {
    Object.defineProperty(window, "ethereum", {
      value: provider,
      writable: false,
    })
  }
}

export default injectMetamaskShim
