import { getSupabaseInstance } from "./supabase-singleton"
import type { SupabaseClient } from "@supabase/supabase-js"
import type { Database } from "@/types/supabase"

/**
 * Interface para monitoramento de operações do Supabase
 */
interface OperationLog {
  operation: string
  table?: string
  startTime: number
  endTime?: number
  success: boolean
  error?: any
  duration?: number
}

// Configurações
const SLOW_OPERATION_THRESHOLD = 1000 // ms
const MAX_LOGS = 100

// Estado do monitor
let operationLogs: OperationLog[] = []
let enabled = false

/**
 * Inicializa o monitoramento de operações Supabase
 */
export function enableSupabaseMonitoring() {
  enabled = true
  console.log("Monitoramento do Supabase ativado")
}

/**
 * Desativa o monitoramento de operações Supabase
 */
export function disableSupabaseMonitoring() {
  enabled = false
  console.log("Monitoramento do Supabase desativado")
}

/**
 * Limpa os logs de operações
 */
export function clearOperationLogs() {
  operationLogs = []
}

/**
 * Obtém os logs de operações
 */
export function getOperationLogs() {
  return [...operationLogs]
}

/**
 * Monitora uma operação do Supabase
 */
export async function monitorOperation<T>(
  operation: string,
  table: string | undefined,
  func: () => Promise<T>,
): Promise<T> {
  if (!enabled) {
    return func()
  }

  const startTime = performance.now()
  const log: OperationLog = {
    operation,
    table,
    startTime,
    success: false,
  }

  try {
    const result = await func()
    log.success = true
    return result
  } catch (error) {
    log.error = error
    throw error
  } finally {
    log.endTime = performance.now()
    log.duration = log.endTime - startTime

    // Adicionar ao log
    operationLogs.unshift(log)

    // Limitar o número de logs
    if (operationLogs.length > MAX_LOGS) {
      operationLogs = operationLogs.slice(0, MAX_LOGS)
    }

    // Alertar sobre operações lentas
    if (log.duration > SLOW_OPERATION_THRESHOLD) {
      console.warn(
        `Operação Supabase lenta (${Math.round(log.duration)}ms): ${operation}${table ? ` - Tabela: ${table}` : ""}`,
      )
    }
  }
}

/**
 * Cria um cliente Supabase com monitoramento
 */
export function createMonitoredClient(): SupabaseClient<Database> {
  const supabase = getSupabaseInstance()

  // Se o monitoramento está desativado, retornar o cliente normal
  if (!enabled) {
    return supabase
  }

  // Proxies para monitorar chamadas de API
  const monitoredClient = new Proxy(supabase, {
    get(target, prop) {
      const value = target[prop as keyof typeof target]

      // Se for a função "from", monitorar a tabela
      if (prop === "from" && typeof value === "function") {
        return (table: string) => {
          const fromResult = value.call(target, table)

          // Monitorar métodos de acesso a dados
          return new Proxy(fromResult, {
            get(fromTarget, fromProp) {
              const fromValue = fromTarget[fromProp as keyof typeof fromTarget]

              if (
                typeof fromValue === "function" &&
                ["select", "insert", "update", "delete", "upsert"].includes(String(fromProp))
              ) {
                return (...args: any[]) => {
                  const operation = String(fromProp).toUpperCase()

                  return monitorOperation(operation, table, () => fromValue.apply(fromTarget, args))
                }
              }

              return fromValue
            },
          })
        }
      }

      return value
    },
  })

  return monitoredClient as SupabaseClient<Database>
}

/**
 * Hook utilitário para obter cliente monitorado
 */
export function useMonitoredSupabase() {
  return createMonitoredClient()
}
