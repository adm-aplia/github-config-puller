// Simple auth session management for the medical AI application
export const lucia = {
  createSession: async (userId: string, attributes: any) => {
    return {
      id: "mock-session-id",
      userId,
      attributes,
    }
  },

  createSessionCookie: (sessionId: string) => {
    return {
      name: "session",
      value: sessionId,
      attributes: {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "lax" as const,
        maxAge: 60 * 60 * 24 * 30, // 30 days
      },
    }
  },
}
