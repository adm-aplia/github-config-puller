// Simple Google auth interface for the medical AI application
export const google = {
  auth: {
    OAuth2: class OAuth2 {
      constructor(clientId: string, clientSecret: string, redirectUri: string) {}

      async getToken(code: string) {
        return { tokens: { access_token: "mock-token" } }
      }

      setCredentials(tokens: any) {}
    },
  },
  oauth2: (config: any) => ({
    userinfo: {
      get: async () => ({
        data: {
          email: "user@example.com",
          name: "Mock User",
          picture: "https://via.placeholder.com/150",
        },
      }),
    },
  }),
}
