// Shim de compatibilidade.
// Reexporta a instância única do Supabase criada em `lib/supabase.ts`

import supabase, {
  getSupabaseClient,
  getSupabaseBrowserClient,
  getSupabaseServerClient,
  getSupabaseInstance,
} from "@/lib/supabase"

export default supabase
export { getSupabaseClient, getSupabaseBrowserClient, getSupabaseServerClient, getSupabaseInstance }
