// Simple database interface for the medical AI application
export const db = {
  user: {
    findUnique: async (params: any) => {
      // Mock implementation for preview
      return null
    },
    create: async (params: any) => {
      // Mock implementation for preview
      return {
        id: "mock-user-id",
        email: params.data.email,
        name: params.data.name,
        avatar: params.data.avatar,
      }
    },
  },
}
