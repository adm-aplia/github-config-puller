/**
 * Serviço para integração com a Evolution API para WhatsApp
 */

// Definir URLs - usando proxy para evitar problemas de CORS
const EVOLUTION_API_URL = "https://aplia-evolution.kopfcf.easypanel.host"
const EVOLUTION_API_KEY = "F9CDB41C7A534C3B58A77B219BA6F"
const USE_PROXY = true // Definir como true para usar o proxy

/**
 * Tipos para a API
 */
export interface Instance {
  instance: {
    instanceName: string
    owner: string
    profileName: string
    profilePictureUrl: string
    profileStatus: string
    status: "connected" | "connecting" | "disconnected" | "qrcode"
    qrcode?: {
      code: string
      base64: string
    }
    number: string | null
    wid: string | null
  }
}

export interface InstancesResponse {
  instances: Instance[]
}

export interface QRCodeResponse {
  qrcode?: {
    code?: string
    base64?: string
  }
  base64?: string | { value: string }
  status?: string
}

export interface SendMessageResponse {
  key: {
    id: string
    remoteJid: string
  }
  status: string
}

/**
 * Gera um token aleatório para segurança
 */
function generateRandomToken(length = 32): string {
  const characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
  let result = ""
  const charactersLength = characters.length

  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength))
  }

  return result
}

/**
 * Classe para gerenciar a integração com a Evolution API
 */
export class EvolutionAPI {
  private baseUrl: string
  private apiKey: string
  private useProxy: boolean

  constructor() {
    this.baseUrl = EVOLUTION_API_URL
    this.apiKey = EVOLUTION_API_KEY
    this.useProxy = USE_PROXY
  }

  /**
   * Retorna os headers padrão para as requisições
   */
  private getHeaders(): HeadersInit {
    return {
      "Content-Type": "application/json",
      apikey: this.apiKey,
    }
  }

  /**
   * Retorna a URL correta com base na configuração de proxy
   */
  private getUrl(path: string): string {
    if (this.useProxy) {
      return `/api/evolution-proxy${path}`
    }
    return `${this.baseUrl}${path}`
  }

  /**
   * Função auxiliar para lidar com respostas e erros
   */
  private async handleResponse<T>(response: Response, errorMessage: string): Promise<T> {
    const contentType = response.headers.get("content-type")

    // Verificar se a resposta é JSON
    if (!contentType || !contentType.includes("application/json")) {
      let errorText = "Response is not JSON"
      try {
        errorText = await response.text()
        console.error("Non-JSON response received:", errorText.substring(0, 200))
      } catch (e) {
        console.error("Could not read response text")
      }
      throw new Error(`${errorMessage}: Expected JSON but received ${contentType || "unknown content type"}`)
    }

    if (!response.ok) {
      let errorDetail = ""
      try {
        const errorData = await response.json()
        errorDetail = JSON.stringify(errorData)
      } catch (e) {
        try {
          errorDetail = await response.text()
        } catch (e2) {
          errorDetail = "Could not read error details"
        }
      }
      throw new Error(`${errorMessage}: ${response.status} - ${errorDetail}`)
    }

    try {
      return await response.json()
    } catch (error) {
      console.error("Error parsing JSON response:", error)
      throw new Error(`${errorMessage}: Invalid JSON in response`)
    }
  }

  /**
   * Obtém todas as instâncias disponíveis
   */
  async getInstances(): Promise<Instance[]> {
    try {
      const timestamp = new Date().getTime()
      const url = this.getUrl(`/instance/fetchInstances?_=${timestamp}`)

      const response = await fetch(url, {
        method: "GET",
        headers: this.useProxy ? { "Content-Type": "application/json" } : this.getHeaders(),
        cache: "no-store",
      })

      const data = await this.handleResponse<any>(response, "Error fetching instances")

      // Verificar estrutura da resposta
      let instances = []

      // A API pode retornar os dados em diferentes formatos
      if (Array.isArray(data)) {
        instances = data
      } else if (data.instances && Array.isArray(data.instances)) {
        instances = data.instances
      } else if (data.data && Array.isArray(data.data)) {
        instances = data.data
      } else {
        console.error("Unexpected response format:", data)
        return []
      }

      // Mapear para o formato esperado
      const mappedInstances = instances.map((instance: any) => ({
        instance: {
          instanceName: instance.instanceName || instance.name || "",
          owner: instance.owner || instance.ownerJid?.split("@")[0] || "",
          profileName: instance.profileName || instance.profilePictureUrl || "",
          profilePictureUrl: instance.profilePictureUrl || instance.profilePicUrl || instance.profilePicture || "",
          profileStatus: instance.profileStatus || "",
          status: this.mapConnectionStatus(instance.connectionStatus || instance.status),
          // Adicionar o número do WhatsApp
          number: instance.number || instance.ownerJid?.split("@")[0] || instance.owner || null,
          // Adicionar o JID completo para referência
          wid: instance.ownerJid || instance.wid || null,
        },
      }))

      return mappedInstances
    } catch (error) {
      console.error("Error in getInstances:", error)
      return []
    }
  }

  // Adicionar função auxiliar para mapear status
  private mapConnectionStatus(status: string): "connected" | "connecting" | "disconnected" | "qrcode" {
    const statusMap: Record<string, "connected" | "connecting" | "disconnected" | "qrcode"> = {
      open: "connected",
      connected: "connected",
      connecting: "connecting",
      close: "disconnected",
      closed: "disconnected",
      disconnected: "disconnected",
      qrcode: "qrcode",
      qr: "qrcode",
    }

    return statusMap[status?.toLowerCase()] || "disconnected"
  }

  /**
   * Cache para evitar múltiplas chamadas simultâneas
   */
  private static instanceStatusCache = new Map<string, { data: any; timestamp: number }>()
  private static readonly CACHE_DURATION = 5000 // 5 segundos

  /**
   * Obtém o status atualizado de uma instância com cache
   */
  async getInstanceStatus(instanceName: string): Promise<any> {
    try {
      const now = Date.now()
      const cached = EvolutionAPI.instanceStatusCache.get(instanceName)

      // Se tem cache válido, usar
      if (cached && now - cached.timestamp < EvolutionAPI.CACHE_DURATION) {
        return cached.data
      }

      // Buscar todas as instâncias de uma vez
      const instances = await this.getInstances()
      const targetInstance = instances.find((i) => i.instance.instanceName.toLowerCase() === instanceName.toLowerCase())

      if (!targetInstance) {
        throw new Error(`Instância ${instanceName} não encontrada`)
      }

      const result = {
        instance: targetInstance.instance,
      }

      // Salvar no cache
      EvolutionAPI.instanceStatusCache.set(instanceName, {
        data: result,
        timestamp: now,
      })

      return result
    } catch (error) {
      console.error("Erro ao obter status da instância:", error)
      throw error
    }
  }

  /**
   * Cria uma nova instância do WhatsApp
   */
  async createInstance(instanceName: string): Promise<Instance> {
    try {
      // Validar nome da instância
      if (!/^[a-zA-Z0-9_-]+$/.test(instanceName)) {
        throw new Error("Nome da instância deve conter apenas letras, números, underscores e hífens")
      }

      // Verificar se a instância já existe
      const instances = await this.getInstances()
      const instanceExists = instances.some(
        (instance) => instance.instance.instanceName.toLowerCase() === instanceName.toLowerCase(),
      )

      if (instanceExists) {
        throw new Error(`A instância '${instanceName}' já existe`)
      }

      // Preparar dados para a requisição
      const requestBody = {
        instanceName,
        token: generateRandomToken(),
        qrcode: true,
        webhook: null,
        integration: "WHATSAPP-BAILEYS",
        events: ["connection.update", "qrcode.update"],
        webhookByEvents: false,
        useSessionIdInPath: true,
        disableWebhook: true,
        // Configurações adicionais
        groupsIgnore: true, // Ignorar mensagens de grupos
        rejectCall: true, // Rejeitar chamadas automaticamente
        msgCall: "Desculpe, não posso atender chamadas no momento. Por favor, envie uma mensagem de texto.", // Mensagem ao rejeitar chamada
      }

      // Enviar requisição
      const response = await fetch(this.getUrl(`/instance/create`), {
        method: "POST",
        headers: this.useProxy ? {} : this.getHeaders(),
        body: JSON.stringify(requestBody),
      })

      return await this.handleResponse<Instance>(response, "Erro ao criar instância")
    } catch (error) {
      console.error("Erro ao criar instância:", error)
      throw error
    }
  }

  /**
   * Conecta uma instância e gera QR code
   */
  async connectInstance(instanceName: string): Promise<QRCodeResponse> {
    try {
      const encodedInstanceName = encodeURIComponent(instanceName)

      const response = await fetch(this.getUrl(`/instance/connect/${encodedInstanceName}`), {
        method: "GET",
        headers: this.useProxy ? {} : this.getHeaders(),
        cache: "no-store",
      })

      const data = await this.handleResponse<any>(response, "Erro ao conectar instância")
      return this.normalizeQRCodeResponse(data)
    } catch (error) {
      console.error("Erro ao conectar instância:", error)
      throw error
    }
  }

  /**
   * Desconecta uma instância
   */
  async disconnectInstance(instanceName: string): Promise<any> {
    try {
      const encodedInstanceName = encodeURIComponent(instanceName)

      const response = await fetch(this.getUrl(`/instance/logout/${encodedInstanceName}`), {
        method: "DELETE",
        headers: this.useProxy ? {} : this.getHeaders(),
      })

      return await this.handleResponse<any>(response, "Erro ao desconectar instância")
    } catch (error) {
      console.error("Erro ao desconectar instância:", error)
      throw error
    }
  }

  /**
   * Exclui uma instância
   */
  async deleteInstance(instanceName: string): Promise<any> {
    try {
      const encodedInstanceName = encodeURIComponent(instanceName)

      const response = await fetch(this.getUrl(`/instance/delete/${encodedInstanceName}`), {
        method: "DELETE",
        headers: this.useProxy ? {} : this.getHeaders(),
      })

      return await this.handleResponse<any>(response, "Erro ao excluir instância")
    } catch (error) {
      console.error("Erro ao excluir instância:", error)
      throw error
    }
  }

  /**
   * Envia uma mensagem de texto
   */
  async sendTextMessage(instanceName: string, phoneNumber: string, message: string): Promise<SendMessageResponse> {
    try {
      // Formatar número de telefone (remover caracteres não numéricos)
      const formattedNumber = phoneNumber.replace(/\D/g, "")
      const encodedInstanceName = encodeURIComponent(instanceName)

      const response = await fetch(this.getUrl(`/message/sendText/${encodedInstanceName}`), {
        method: "POST",
        headers: this.useProxy ? {} : this.getHeaders(),
        body: JSON.stringify({
          number: formattedNumber,
          options: {
            delay: 1200,
          },
          textMessage: {
            text: message,
          },
        }),
      })

      return await this.handleResponse<SendMessageResponse>(response, "Erro ao enviar mensagem")
    } catch (error) {
      console.error("Erro ao enviar mensagem:", error)
      throw error
    }
  }

  /**
   * Obtém o QR code de uma instância usando uma estratégia otimizada
   */
  async getQRCode(instanceName: string): Promise<QRCodeResponse> {
    try {
      const encodedInstanceName = encodeURIComponent(instanceName)

      // Verificar primeiro se a instância já está conectada
      try {
        const statusResponse = await this.getInstanceStatus(instanceName)
        if (statusResponse.instance.status === "connected") {
          throw new Error("Esta instância já está conectada. Não é necessário escanear o QR code novamente.")
        }
      } catch (statusError) {
        if (statusError.message && statusError.message.includes("já está conectada")) {
          throw statusError
        }
        console.log("Erro ao verificar status, continuando com obtenção do QR code:", statusError)
      }

      // USAR APENAS UMA ESTRATÉGIA: endpoint de conexão que já gera QR
      const timestamp = new Date().getTime()
      const response = await fetch(this.getUrl(`/instance/connect/${encodedInstanceName}?_=${timestamp}`), {
        method: "GET",
        headers: this.useProxy ? {} : this.getHeaders(),
        cache: "no-store",
      })

      if (response.ok) {
        const data = await response.json()
        const normalized = this.normalizeQRCodeResponse(data)

        if (normalized.qrcode?.base64) {
          return normalized
        }
      }

      throw new Error("Não foi possível obter o QR code")
    } catch (error) {
      console.error("Erro ao obter QR code:", error)
      throw error
    }
  }

  /**
   * Normaliza a resposta do QR code para um formato consistente
   */
  private normalizeQRCodeResponse(data: any): QRCodeResponse {
    // Caso 1: Resposta já tem o formato esperado
    if (data.qrcode && data.qrcode.base64) {
      return data
    }

    // Caso 2: Resposta tem base64 diretamente
    if (data.base64) {
      if (typeof data.base64 === "object" && data.base64.value) {
        return {
          qrcode: {
            base64: data.base64.value,
          },
        }
      }
      return {
        qrcode: {
          base64: data.base64,
        },
      }
    }

    // Caso 3: Resposta tem outro formato
    if (data.code) {
      return {
        qrcode: {
          base64: data.code,
        },
      }
    }

    // Caso 4: Resposta tem formato diferente
    if (data.qr) {
      return {
        qrcode: {
          base64: data.qr,
        },
      }
    }

    // Caso 5: Resposta tem o QR code em outro campo
    if (data.data && data.data.base64) {
      return {
        qrcode: {
          base64: data.data.base64,
        },
      }
    }

    // Caso padrão
    return {
      qrcode: {
        base64: "",
      },
      status: "error",
    }
  }
}

// Exportar uma instância única para uso em toda a aplicação
export const evolutionAPI = new EvolutionAPI()
