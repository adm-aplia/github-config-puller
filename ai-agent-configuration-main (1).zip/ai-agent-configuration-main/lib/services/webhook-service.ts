import { getSupabaseBrowserClient } from "@/lib/supabase"

export interface WebhookPayload {
  event: string
  data: any
  timestamp: string
  user_id?: string
}

export interface AppointmentWebhookData {
  id: string
  patient_name: string
  patient_phone: string
  patient_email?: string | null
  appointment_date: string
  status: string
  notes?: string | null
  agent_id?: string | null
  conversation_id?: string | null
  user_id: string
  created_at: string
  updated_at: string
}

export class WebhookService {
  private static readonly WEBHOOK_EVENTS = {
    APPOINTMENT_CREATED: "appointment.created",
    APPOINTMENT_UPDATED: "appointment.updated",
    APPOINTMENT_CANCELLED: "appointment.cancelled",
    APPOINTMENT_COMPLETED: "appointment.completed",
    APPOINTMENT_CONFIRMED: "appointment.confirmed",
    APPOINTMENT_RESCHEDULED: "appointment.rescheduled",
    APPOINTMENT_NO_SHOW: "appointment.no_show",
  } as const

  /**
   * Send webhook for appointment creation
   */
  static async sendAppointmentCreated(appointment: AppointmentWebhookData) {
    return this.sendWebhook(this.WEBHOOK_EVENTS.APPOINTMENT_CREATED, appointment)
  }

  /**
   * Send webhook for appointment update
   */
  static async sendAppointmentUpdated(appointment: AppointmentWebhookData, previousStatus?: string) {
    const payload = {
      ...appointment,
      previous_status: previousStatus,
    }

    // Send specific event based on status change
    switch (appointment.status) {
      case "cancelled":
        return this.sendWebhook(this.WEBHOOK_EVENTS.APPOINTMENT_CANCELLED, payload)
      case "completed":
        return this.sendWebhook(this.WEBHOOK_EVENTS.APPOINTMENT_COMPLETED, payload)
      case "confirmed":
        return this.sendWebhook(this.WEBHOOK_EVENTS.APPOINTMENT_CONFIRMED, payload)
      case "rescheduled":
        return this.sendWebhook(this.WEBHOOK_EVENTS.APPOINTMENT_RESCHEDULED, payload)
      case "no-show":
        return this.sendWebhook(this.WEBHOOK_EVENTS.APPOINTMENT_NO_SHOW, payload)
      default:
        return this.sendWebhook(this.WEBHOOK_EVENTS.APPOINTMENT_UPDATED, payload)
    }
  }

  /**
   * Send webhook to configured endpoint
   */
  private static async sendWebhook(event: string, data: any) {
    try {
      const webhookUrl = process.env.WEBHOOK_URL || process.env.NEXT_PUBLIC_WEBHOOK_URL

      if (!webhookUrl) {
        console.log("⚠️ Webhook URL não configurada, pulando envio")
        return { success: false, error: "Webhook URL não configurada" }
      }

      const payload: WebhookPayload = {
        event,
        data,
        timestamp: new Date().toISOString(),
        user_id: data.user_id,
      }

      console.log("📤 Enviando webhook:", { event, url: webhookUrl })

      const response = await fetch(webhookUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "User-Agent": "Aplia-Medical-AI/1.0",
          "X-Webhook-Event": event,
        },
        body: JSON.stringify(payload),
      })

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`)
      }

      const result = await response.json().catch(() => ({}))
      console.log("✅ Webhook enviado com sucesso:", { event, status: response.status })

      return { success: true, response: result }
    } catch (error) {
      console.error("❌ Erro ao enviar webhook:", error)
      return {
        success: false,
        error: error instanceof Error ? error.message : "Erro desconhecido",
      }
    }
  }

  /**
   * Test webhook endpoint
   */
  static async testWebhook() {
    const testData = {
      id: "test-appointment-id",
      patient_name: "Teste Webhook",
      patient_phone: "+5511999999999",
      patient_email: "teste@exemplo.com",
      appointment_date: new Date().toISOString(),
      status: "scheduled",
      notes: "Teste de webhook",
      user_id: "test-user-id",
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }

    return this.sendWebhook("test.webhook", testData)
  }

  /**
   * Get webhook configuration
   */
  static getWebhookConfig() {
    return {
      url: process.env.WEBHOOK_URL || process.env.NEXT_PUBLIC_WEBHOOK_URL,
      events: Object.values(this.WEBHOOK_EVENTS),
      configured: !!(process.env.WEBHOOK_URL || process.env.NEXT_PUBLIC_WEBHOOK_URL),
    }
  }

  /**
   * Log webhook activity to database
   */
  static async logWebhookActivity(event: string, success: boolean, error?: string) {
    try {
      const supabase = getSupabaseBrowserClient()

      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user) return

      // Create webhook_logs table if it doesn't exist
      await supabase.rpc("create_webhook_logs_table_if_not_exists")

      await supabase.from("webhook_logs").insert({
        user_id: user.id,
        event,
        success,
        error_message: error,
        created_at: new Date().toISOString(),
      })
    } catch (error) {
      console.error("Erro ao registrar atividade do webhook:", error)
    }
  }
}

// SQL function to create webhook_logs table if it doesn't exist
export const createWebhookLogsTableSQL = `
CREATE OR REPLACE FUNCTION create_webhook_logs_table_if_not_exists()
RETURNS void AS $$
BEGIN
  IF NOT EXISTS (
    SELECT FROM information_schema.tables 
    WHERE table_schema = 'public' 
    AND table_name = 'webhook_logs'
  ) THEN
    CREATE TABLE webhook_logs (
      id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
      user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
      event TEXT NOT NULL,
      success BOOLEAN NOT NULL DEFAULT false,
      error_message TEXT,
      created_at TIMESTAMPTZ DEFAULT NOW()
    );
    
    -- Enable RLS
    ALTER TABLE webhook_logs ENABLE ROW LEVEL SECURITY;
    
    -- Create policy
    CREATE POLICY "Users can view own webhook logs" ON webhook_logs
      FOR SELECT USING (auth.uid() = user_id);
      
    -- Create index
    CREATE INDEX idx_webhook_logs_user_id ON webhook_logs(user_id);
    CREATE INDEX idx_webhook_logs_event ON webhook_logs(event);
    CREATE INDEX idx_webhook_logs_created_at ON webhook_logs(created_at);
  END IF;
END;
$$ LANGUAGE plpgsql;
`
