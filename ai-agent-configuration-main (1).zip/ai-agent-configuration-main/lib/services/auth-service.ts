import { getSupabaseBrowserClient } from "@/lib/supabase"

export class AuthService {
  // Criar um usuário manualmente (para uso administrativo)
  static async createUser(email: string, password: string, name: string) {
    const supabase = getSupabaseBrowserClient()

    // Criar o usuário
    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
      user_metadata: { name },
    })

    if (error) {
      console.error("Erro ao criar usuário:", error)
      throw error
    }

    // Criar o perfil do usuário
    if (data.user) {
      const { error: profileError } = await supabase.from("profiles").insert({
        id: data.user.id,
        name,
        email,
      })

      if (profileError) {
        console.error("Erro ao criar perfil:", profileError)
      }
    }

    return data
  }

  // Verificar se um usuário existe
  static async checkUserExists(email: string) {
    const supabase = getSupabaseBrowserClient()

    try {
      // Tentar fazer login com credenciais inválidas para verificar se o usuário existe
      const { error } = await supabase.auth.signInWithPassword({
        email,
        password: "check_only_not_real_password",
      })

      // Se o erro for "Invalid login credentials", o usuário existe
      if (error && error.message.includes("Invalid login credentials")) {
        return true
      }

      // Se não houver erro (improvável neste caso) ou o erro for diferente, o usuário não existe
      return false
    } catch (error) {
      console.error("Erro ao verificar usuário:", error)
      return false
    }
  }
}
