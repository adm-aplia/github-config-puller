import { supabase } from "@/lib/supabase"
import type { Database } from "@/types/supabase"

export type Conversation = Database["public"]["Tables"]["conversations"]["Row"]
export type ConversationInsert = Database["public"]["Tables"]["conversations"]["Insert"]
export type ConversationUpdate = Partial<Database["public"]["Tables"]["conversations"]["Update"]>
export type Message = Database["public"]["Tables"]["messages"]["Row"]
export type MessageInsert = Database["public"]["Tables"]["messages"]["Insert"]

export class ConversationService {
  /**
   * Get recent conversations
   * @param limit Number of conversations to return
   * @returns Array of recent conversations
   */
  static async getRecentConversations(limit = 5) {
    try {
      // Get current user
      const {
        data: { session },
      } = await supabase.auth.getSession()

      if (!session) {
        throw new Error("Usuário não autenticado")
      }

      const { data, error } = await supabase
        .from("conversations")
        .select(`
          *,
          whatsapp_instances (id, instance_name, profile_name)
        `)
        .eq("user_id", session.user.id)
        .order("updated_at", { ascending: false })
        .limit(limit)

      if (error) {
        console.error("Erro ao buscar conversas recentes:", error)
        throw error
      }

      // Se precisarmos de informações do professional_profile, buscamos separadamente
      if (data && data.length > 0) {
        const agentIds = data.map((conv) => conv.agent_id).filter((id) => id !== null) as string[]

        if (agentIds.length > 0) {
          const { data: profiles, error: profilesError } = await supabase
            .from("professional_profiles")
            .select("*")
            .in("id", agentIds)

          if (!profilesError && profiles) {
            // Adicionar os dados do professional_profile a cada conversa
            return data.map((conv) => {
              if (conv.agent_id) {
                const profile = profiles.find((p) => p.id === conv.agent_id)
                return {
                  ...conv,
                  professional_profiles: profile || null,
                }
              }
              return conv
            })
          }
        }
      }

      return data || []
    } catch (error) {
      console.error("Erro ao buscar conversas recentes:", error)
      // Retornar array vazio em caso de erro para evitar quebrar a UI
      return []
    }
  }

  /**
   * Get all conversations for the current user
   * @param filters Optional filters (status, agentId, instanceId)
   * @param pagination Optional pagination parameters
   * @returns Array of conversations
   */
  static async getUserConversations(
    filters?: { status?: string; agentId?: string; instanceId?: string; search?: string },
    pagination?: { page: number; pageSize: number },
  ) {
    // Get current user
    const {
      data: { session },
    } = await supabase.auth.getSession()

    if (!session) {
      throw new Error("Usuário não autenticado")
    }

    // Modificado para não usar relacionamentos que não existem
    let query = supabase.from("conversations").select(`
      *,
      whatsapp_instances (id, instance_name, profile_name)
    `)

    // Apply filters
    if (filters?.status) {
      query = query.eq("status", filters.status)
    }
    if (filters?.agentId) {
      query = query.eq("agent_id", filters.agentId)
    }
    if (filters?.instanceId) {
      query = query.eq("instance_id", filters.instanceId)
    }
    if (filters?.search) {
      query = query.or(`contact_name.ilike.%${filters.search}%,contact_phone.ilike.%${filters.search}%`)
    }

    // Apply pagination
    if (pagination) {
      const { page, pageSize } = pagination
      const from = (page - 1) * pageSize
      const to = from + pageSize - 1
      query = query.range(from, to)
    }

    // Order by most recent
    query = query.order("updated_at", { ascending: false })

    const { data, error, count } = await query

    if (error) {
      console.error("Erro ao buscar conversas:", error)
      throw error
    }

    // Se precisarmos de informações do professional_profile, buscamos separadamente
    if (data && data.length > 0) {
      const agentIds = data.map((conv) => conv.agent_id).filter((id) => id !== null) as string[]

      if (agentIds.length > 0) {
        const { data: profiles, error: profilesError } = await supabase
          .from("professional_profiles")
          .select("*")
          .in("id", agentIds)

        if (!profilesError && profiles) {
          // Adicionar os dados do professional_profile a cada conversa
          return {
            data: data.map((conv) => {
              if (conv.agent_id) {
                const profile = profiles.find((p) => p.id === conv.agent_id)
                return {
                  ...conv,
                  professional_profiles: profile || null,
                }
              }
              return conv
            }),
            count,
          }
        }
      }
    }

    return { data, count }
  }

  /**
   * Get all conversations for the current user
   * @returns Array of conversations
   */
  static async getConversations() {
    // Get current user
    const {
      data: { session },
    } = await supabase.auth.getSession()

    if (!session) {
      throw new Error("Usuário não autenticado")
    }

    // Modificado para não usar relacionamentos que não existem
    const { data, error } = await supabase.from("conversations").select("*")

    if (error) {
      console.error("Erro ao buscar conversas:", error)
      throw error
    }

    // Se precisarmos de informações do professional_profile, buscamos separadamente
    if (data && data.length > 0) {
      const agentIds = data.map((conv) => conv.agent_id).filter((id) => id !== null) as string[]

      if (agentIds.length > 0) {
        const { data: profiles, error: profilesError } = await supabase
          .from("professional_profiles")
          .select("*")
          .in("id", agentIds)

        if (!profilesError && profiles) {
          // Adicionar os dados do professional_profile a cada conversa
          return data.map((conv) => {
            if (conv.agent_id) {
              const profile = profiles.find((p) => p.id === conv.agent_id)
              return {
                ...conv,
                professional_profiles: profile || null,
              }
            }
            return conv
          })
        }
      }
    }

    return data || []
  }

  /**
   * Get a specific conversation with its messages
   * @param id Conversation ID
   * @param messageLimit Optional limit for number of messages
   * @returns Conversation with messages
   */
  static async getConversation(id: string, messageLimit?: number) {
    // Modificado para não usar relacionamentos que não existem
    const { data: conversation, error: conversationError } = await supabase
      .from("conversations")
      .select(`
        *,
        whatsapp_instances (id, instance_name, profile_name)
      `)
      .eq("id", id)
      .single()

    if (conversationError) {
      console.error(`Erro ao buscar conversa ${id}:`, conversationError)
      throw conversationError
    }

    // Se a conversa tiver um agent_id, buscar o professional_profile separadamente
    if (conversation && conversation.agent_id) {
      const { data: profile, error: profileError } = await supabase
        .from("professional_profiles")
        .select("*")
        .eq("id", conversation.agent_id)
        .single()

      if (!profileError && profile) {
        conversation.professional_profiles = profile
      }
    }

    let messagesQuery = supabase
      .from("messages")
      .select("*")
      .eq("conversation_id", id)
      .order("created_at", { ascending: true })

    if (messageLimit) {
      messagesQuery = messagesQuery.limit(messageLimit)
    }

    const { data: messages, error: messagesError } = await messagesQuery

    if (messagesError) {
      console.error(`Erro ao buscar mensagens da conversa ${id}:`, messagesError)
      throw messagesError
    }

    return {
      ...conversation,
      messages: messages || [],
    }
  }

  /**
   * Create a new conversation
   * @param conversation Conversation data
   * @returns Created conversation
   */
  static async createConversation(conversation: Omit<ConversationInsert, "user_id">) {
    // Get current user
    const {
      data: { session },
    } = await supabase.auth.getSession()

    if (!session) {
      throw new Error("Usuário não autenticado")
    }

    const { data, error } = await supabase
      .from("conversations")
      .insert({
        ...conversation,
        user_id: session.user.id,
      })
      .select()
      .single()

    if (error) {
      console.error("Erro ao criar conversa:", error)
      throw error
    }

    return data
  }

  /**
   * Update a conversation
   * @param id Conversation ID
   * @param updates Fields to update
   * @returns Updated conversation
   */
  static async updateConversation(id: string, updates: ConversationUpdate) {
    const { data, error } = await supabase
      .from("conversations")
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq("id", id)
      .select()
      .single()

    if (error) {
      console.error(`Erro ao atualizar conversa ${id}:`, error)
      throw error
    }

    return data
  }

  /**
   * Delete a conversation and all its messages
   * @param id Conversation ID
   * @returns Success status
   */
  static async deleteConversation(id: string) {
    // First delete all messages in the conversation
    const { error: messagesError } = await supabase.from("messages").delete().eq("conversation_id", id)

    if (messagesError) {
      console.error(`Erro ao excluir mensagens da conversa ${id}:`, messagesError)
      throw messagesError
    }

    // Then delete the conversation
    const { error } = await supabase.from("conversations").delete().eq("id", id)

    if (error) {
      console.error(`Erro ao excluir conversa ${id}:`, error)
      throw error
    }

    return true
  }

  /**
   * Add a message to a conversation
   * @param message Message data
   * @returns Created message
   */
  static async addMessage(message: Omit<MessageInsert, "id">) {
    const { data, error } = await supabase.from("messages").insert(message).select().single()

    if (error) {
      console.error("Erro ao adicionar mensagem:", error)
      throw error
    }

    // Update conversation timestamp
    await supabase
      .from("conversations")
      .update({ updated_at: new Date().toISOString() })
      .eq("id", message.conversation_id)

    return data
  }

  /**
   * Delete a message
   * @param id Message ID
   * @returns Success status
   */
  static async deleteMessage(id: string) {
    const { error } = await supabase.from("messages").delete().eq("id", id)

    if (error) {
      console.error(`Erro ao excluir mensagem ${id}:`, error)
      throw error
    }

    return true
  }

  /**
   * Get conversation statistics
   * @param filters Optional filters
   * @returns Statistics object
   */
  static async getConversationStats(filters?: {
    startDate?: string
    endDate?: string
    agentId?: string
    instanceId?: string
  }) {
    // Get current user
    const {
      data: { session },
    } = await supabase.auth.getSession()

    if (!session) {
      throw new Error("Usuário não autenticado")
    }

    let query = supabase
      .from("conversations")
      .select("id, status, created_at", { count: "exact" })
      .eq("user_id", session.user.id)

    // Apply filters
    if (filters?.startDate) {
      query = query.gte("created_at", filters.startDate)
    }
    if (filters?.endDate) {
      query = query.lte("created_at", filters.endDate)
    }
    if (filters?.agentId) {
      query = query.eq("agent_id", filters.agentId)
    }
    if (filters?.instanceId) {
      query = query.eq("instance_id", filters.instanceId)
    }

    const { data, error, count } = await query

    if (error) {
      console.error("Erro ao buscar estatísticas de conversas:", error)
      throw error
    }

    // Calculate statistics
    const total = count || 0
    const active = data?.filter((c) => c.status === "active").length || 0
    const closed = data?.filter((c) => c.status === "closed").length || 0
    const flagged = data?.filter((c) => c.status === "flagged").length || 0

    return {
      total,
      active,
      closed,
      flagged,
      conversations: data || [],
    }
  }

  /**
   * Update conversation status
   * @param id Conversation ID
   * @param status New status
   * @returns Updated conversation
   */
  static async updateConversationStatus(id: string, status: string) {
    return this.updateConversation(id, { status })
  }
}
