import { getSupabaseBrowserClient } from "@/lib/supabase"

export class StorageService {
  private static readonly BUCKETS = {
    AVATARS: "avatars",
    ATTACHMENTS: "attachments",
    MEDIA: "media",
    DOCUMENTS: "documents",
  }

  /**
   * Upload a file to storage
   * @param bucket The storage bucket to upload to
   * @param path The path within the bucket
   * @param file The file to upload
   * @param options Upload options
   * @returns The file URL if successful
   */
  static async uploadFile(
    bucket: string,
    path: string,
    file: File,
    options?: { contentType?: string; cacheControl?: string },
  ): Promise<string> {
    const supabase = getSupabaseBrowserClient()

    // Create a unique file name to avoid collisions
    const fileExt = file.name.split(".").pop()
    const fileName = `${path}/${Date.now()}-${Math.random().toString(36).substring(2, 15)}.${fileExt}`

    const { data, error } = await supabase.storage.from(bucket).upload(fileName, file, {
      cacheControl: options?.cacheControl || "3600",
      contentType: options?.contentType || file.type,
      upsert: false,
    })

    if (error) {
      console.error("Error uploading file:", error)
      throw error
    }

    // Get the public URL for the file
    const {
      data: { publicUrl },
    } = supabase.storage.from(bucket).getPublicUrl(data.path)

    return publicUrl
  }

  /**
   * Download a file from storage
   * @param bucket The storage bucket
   * @param path The file path
   * @returns The file data
   */
  static async downloadFile(bucket: string, path: string): Promise<Blob> {
    const supabase = getSupabaseBrowserClient()

    const { data, error } = await supabase.storage.from(bucket).download(path)

    if (error) {
      console.error("Error downloading file:", error)
      throw error
    }

    return data
  }

  /**
   * Delete a file from storage
   * @param bucket The storage bucket
   * @param path The file path
   */
  static async deleteFile(bucket: string, path: string): Promise<void> {
    const supabase = getSupabaseBrowserClient()

    const { error } = await supabase.storage.from(bucket).remove([path])

    if (error) {
      console.error("Error deleting file:", error)
      throw error
    }
  }

  /**
   * List files in a storage bucket
   * @param bucket The storage bucket
   * @param path Optional path prefix
   * @returns List of files
   */
  static async listFiles(
    bucket: string,
    path?: string,
  ): Promise<Array<{ name: string; size: number; created_at: string }>> {
    const supabase = getSupabaseBrowserClient()

    const { data, error } = await supabase.storage.from(bucket).list(path || "")

    if (error) {
      console.error("Error listing files:", error)
      throw error
    }

    return data || []
  }

  /**
   * Create a signed URL for temporary access to a file
   * @param bucket The storage bucket
   * @param path The file path
   * @param expiresIn Expiration time in seconds (default: 60 minutes)
   * @returns Signed URL
   */
  static async createSignedUrl(bucket: string, path: string, expiresIn = 3600): Promise<string> {
    const supabase = getSupabaseBrowserClient()

    const { data, error } = await supabase.storage.from(bucket).createSignedUrl(path, expiresIn)

    if (error) {
      console.error("Error creating signed URL:", error)
      throw error
    }

    return data.signedUrl
  }

  /**
   * Upload an avatar image
   * @param userId User ID
   * @param file Image file
   * @returns Public URL of the avatar
   */
  static async uploadAvatar(userId: string, file: File): Promise<string> {
    return this.uploadFile(this.BUCKETS.AVATARS, userId, file, { contentType: "image/jpeg", cacheControl: "3600" })
  }

  /**
   * Upload a message attachment
   * @param conversationId Conversation ID
   * @param file Attachment file
   * @returns Public URL of the attachment
   */
  static async uploadAttachment(conversationId: string, file: File): Promise<string> {
    return this.uploadFile(this.BUCKETS.ATTACHMENTS, conversationId, file)
  }

  /**
   * Upload a document
   * @param userId User ID
   * @param file Document file
   * @returns Public URL of the document
   */
  static async uploadDocument(userId: string, file: File): Promise<string> {
    return this.uploadFile(this.BUCKETS.DOCUMENTS, userId, file)
  }
}
