import { getSupabaseServerClient } from "@/lib/supabase-singleton"

export interface PlanLimits {
  whatsapp_instances: number
  max_appointments: number
  max_assistants: number
  support_level: string
  advanced_reports: boolean
  hospital_integration: boolean
  advanced_customization: boolean
  api_access: boolean
  priority_support: boolean
  custom_branding: boolean
}

export interface ClienteUsage {
  whatsapp_instances_used: number
  appointments_this_month: number
  assistants_created: number
  last_reset_date: string
}

export interface PermissionCheck {
  allowed: boolean
  reason?: string
  current_usage?: number
  limit?: number
}

export class PermissionsService {
  /**
   * Obter limites do plano de um usuário
   */
  static async getUserPlanLimits(userId: string): Promise<PlanLimits | null> {
    try {
      const supabase = await getSupabaseServerClient()

      const { data, error } = await supabase
        .from("clientes")
        .select(`
          plano,
          planos!inner(*)
        `)
        .eq("user_id", userId)
        .eq("is_active", true)
        .eq("status", "ativo")
        .single()

      if (error) {
        console.error("Erro ao buscar limites do plano:", error)
        return null
      }

      if (!data?.planos) {
        return null
      }

      const plano = Array.isArray(data.planos) ? data.planos[0] : data.planos

      return {
        whatsapp_instances: plano.whatsapp_instances,
        max_appointments: plano.max_appointments,
        max_assistants: plano.max_assistants,
        support_level: plano.support_level,
        advanced_reports: plano.advanced_reports,
        hospital_integration: plano.hospital_integration,
        advanced_customization: plano.advanced_customization,
        api_access: plano.api_access,
        priority_support: plano.priority_support,
        custom_branding: plano.custom_branding,
      }
    } catch (error) {
      console.error("Erro ao buscar limites do plano:", error)
      return null
    }
  }

  /**
   * Obter uso atual de um usuário
   */
  static async getUserUsage(userId: string): Promise<ClienteUsage | null> {
    try {
      const supabase = await getSupabaseServerClient()

      // Primeiro, resetar contadores mensais se necessário
      await supabase.rpc("reset_monthly_counters")

      const { data, error } = await supabase
        .from("cliente_usage")
        .select("*")
        .eq("cliente_id", (await supabase.from("clientes").select("id").eq("user_id", userId).single()).data?.id)
        .single()

      if (error) {
        console.error("Erro ao buscar uso do cliente:", error)
        return null
      }

      return {
        whatsapp_instances_used: data.whatsapp_instances_used || 0,
        appointments_this_month: data.appointments_this_month || 0,
        assistants_created: data.assistants_created || 0,
        last_reset_date: data.last_reset_date,
      }
    } catch (error) {
      console.error("Erro ao buscar uso do cliente:", error)
      return null
    }
  }

  /**
   * Verificar se usuário pode criar nova instância WhatsApp
   */
  static async canCreateWhatsAppInstance(userId: string): Promise<PermissionCheck> {
    try {
      const [limits, usage] = await Promise.all([this.getUserPlanLimits(userId), this.getUserUsage(userId)])

      if (!limits || !usage) {
        return {
          allowed: false,
          reason: "Não foi possível verificar os limites do seu plano",
        }
      }

      const currentUsage = usage.whatsapp_instances_used
      const limit = limits.whatsapp_instances

      if (currentUsage >= limit) {
        return {
          allowed: false,
          reason: `Limite de instâncias WhatsApp atingido (${currentUsage}/${limit})`,
          current_usage: currentUsage,
          limit,
        }
      }

      return {
        allowed: true,
        current_usage: currentUsage,
        limit,
      }
    } catch (error) {
      console.error("Erro ao verificar permissão WhatsApp:", error)
      return {
        allowed: false,
        reason: "Erro interno ao verificar permissões",
      }
    }
  }

  /**
   * Verificar se usuário pode criar novo agendamento
   */
  static async canCreateAppointment(userId: string): Promise<PermissionCheck> {
    try {
      const [limits, usage] = await Promise.all([this.getUserPlanLimits(userId), this.getUserUsage(userId)])

      if (!limits || !usage) {
        return {
          allowed: false,
          reason: "Não foi possível verificar os limites do seu plano",
        }
      }

      const currentUsage = usage.appointments_this_month
      const limit = limits.max_appointments

      // -1 significa ilimitado
      if (limit === -1) {
        return {
          allowed: true,
          current_usage: currentUsage,
          limit: -1,
        }
      }

      if (currentUsage >= limit) {
        return {
          allowed: false,
          reason: `Limite de agendamentos mensais atingido (${currentUsage}/${limit})`,
          current_usage: currentUsage,
          limit,
        }
      }

      return {
        allowed: true,
        current_usage: currentUsage,
        limit,
      }
    } catch (error) {
      console.error("Erro ao verificar permissão de agendamento:", error)
      return {
        allowed: false,
        reason: "Erro interno ao verificar permissões",
      }
    }
  }

  /**
   * Verificar se usuário pode criar novo assistente
   */
  static async canCreateAssistant(userId: string): Promise<PermissionCheck> {
    try {
      const [limits, usage] = await Promise.all([this.getUserPlanLimits(userId), this.getUserUsage(userId)])

      if (!limits || !usage) {
        return {
          allowed: false,
          reason: "Não foi possível verificar os limites do seu plano",
        }
      }

      const currentUsage = usage.assistants_created
      const limit = limits.max_assistants

      // -1 significa ilimitado
      if (limit === -1) {
        return {
          allowed: true,
          current_usage: currentUsage,
          limit: -1,
        }
      }

      if (currentUsage >= limit) {
        return {
          allowed: false,
          reason: `Limite de assistentes atingido (${currentUsage}/${limit})`,
          current_usage: currentUsage,
          limit,
        }
      }

      return {
        allowed: true,
        current_usage: currentUsage,
        limit,
      }
    } catch (error) {
      console.error("Erro ao verificar permissão de assistente:", error)
      return {
        allowed: false,
        reason: "Erro interno ao verificar permissões",
      }
    }
  }

  /**
   * Verificar se usuário tem acesso a funcionalidade específica
   */
  static async hasFeatureAccess(userId: string, feature: keyof PlanLimits): Promise<boolean> {
    try {
      const limits = await this.getUserPlanLimits(userId)

      if (!limits) {
        return false
      }

      return Boolean(limits[feature])
    } catch (error) {
      console.error(`Erro ao verificar acesso à funcionalidade ${feature}:`, error)
      return false
    }
  }

  /**
   * Incrementar uso de uma funcionalidade
   */
  static async incrementUsage(userId: string, type: "whatsapp" | "appointment" | "assistant"): Promise<boolean> {
    try {
      const supabase = await getSupabaseServerClient()

      // Buscar cliente_id
      const { data: cliente } = await supabase.from("clientes").select("id").eq("user_id", userId).single()

      if (!cliente) {
        return false
      }

      let updateField = ""
      switch (type) {
        case "whatsapp":
          updateField = "whatsapp_instances_used"
          break
        case "appointment":
          updateField = "appointments_this_month"
          break
        case "assistant":
          updateField = "assistants_created"
          break
        default:
          return false
      }

      const { error } = await supabase.rpc("increment_usage", {
        cliente_id: cliente.id,
        field_name: updateField,
      })

      if (error) {
        console.error("Erro ao incrementar uso:", error)
        return false
      }

      return true
    } catch (error) {
      console.error("Erro ao incrementar uso:", error)
      return false
    }
  }

  /**
   * Decrementar uso de uma funcionalidade (quando algo é deletado)
   */
  static async decrementUsage(userId: string, type: "whatsapp" | "appointment" | "assistant"): Promise<boolean> {
    try {
      const supabase = await getSupabaseServerClient()

      // Buscar cliente_id
      const { data: cliente } = await supabase.from("clientes").select("id").eq("user_id", userId).single()

      if (!cliente) {
        return false
      }

      let updateField = ""
      switch (type) {
        case "whatsapp":
          updateField = "whatsapp_instances_used"
          break
        case "appointment":
          updateField = "appointments_this_month"
          break
        case "assistant":
          updateField = "assistants_created"
          break
        default:
          return false
      }

      const { error } = await supabase.rpc("decrement_usage", {
        cliente_id: cliente.id,
        field_name: updateField,
      })

      if (error) {
        console.error("Erro ao decrementar uso:", error)
        return false
      }

      return true
    } catch (error) {
      console.error("Erro ao decrementar uso:", error)
      return false
    }
  }

  /**
   * Obter resumo completo de limites e uso
   */
  static async getUserLimitsAndUsage(userId: string) {
    try {
      const [limits, usage] = await Promise.all([this.getUserPlanLimits(userId), this.getUserUsage(userId)])

      if (!limits || !usage) {
        return null
      }

      return {
        limits,
        usage,
        permissions: {
          canCreateWhatsApp: await this.canCreateWhatsAppInstance(userId),
          canCreateAppointment: await this.canCreateAppointment(userId),
          canCreateAssistant: await this.canCreateAssistant(userId),
        },
        features: {
          advanced_reports: limits.advanced_reports,
          hospital_integration: limits.hospital_integration,
          advanced_customization: limits.advanced_customization,
          api_access: limits.api_access,
          priority_support: limits.priority_support,
          custom_branding: limits.custom_branding,
        },
      }
    } catch (error) {
      console.error("Erro ao obter resumo de limites:", error)
      return null
    }
  }
}
