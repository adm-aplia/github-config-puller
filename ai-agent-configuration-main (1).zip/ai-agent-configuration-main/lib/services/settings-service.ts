import { getSupabaseBrowserClient } from "@/lib/supabase"
import type { Database } from "@/types/supabase"

export type UserSettings = Database["public"]["Tables"]["user_settings"]["Row"]
export type UserSettingsInsert = Database["public"]["Tables"]["user_settings"]["Insert"]
export type UserSettingsUpdate = Database["public"]["Tables"]["user_settings"]["Update"]

export class SettingsService {
  /**
   * Get settings for the current user
   * @returns User settings
   */
  static async getUserSettings() {
    const supabase = getSupabaseBrowserClient()

    // Get current user
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      throw new Error("Usuário não autenticado")
    }

    const { data, error } = await supabase.from("user_settings").select("*").eq("user_id", user.id).single()

    if (error) {
      if (error.code === "PGRST116") {
        // Settings not found, create default
        return this.createDefaultSettings()
      }

      console.error("Erro ao buscar configurações:", error)
      throw error
    }

    return data
  }

  /**
   * Create default settings for a new user
   * @returns Created settings
   */
  static async createDefaultSettings() {
    const supabase = getSupabaseBrowserClient()

    // Get current user
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      throw new Error("Usuário não autenticado")
    }

    const defaultSettings: UserSettingsInsert = {
      user_id: user.id,
      language: "pt-BR",
      timezone: "America/Sao_Paulo",
      theme: "light",
      notifications_enabled: true,
      api_url: "https://dinastia-evolution.kpgkys.easypanel.host",
      api_key: "8C65A277A7E2A8EBC81BDDCE72949",
      ai_provider: "openai",
      ai_model: "gpt-4",
    }

    const { data, error } = await supabase.from("user_settings").insert(defaultSettings).select().single()

    if (error) {
      console.error("Erro ao criar configurações padrão:", error)
      throw error
    }

    return data
  }

  /**
   * Update user settings
   * @param settings Settings to update
   * @returns Updated settings
   */
  static async updateSettings(settings: Partial<UserSettingsUpdate>) {
    const supabase = getSupabaseBrowserClient()

    // Get current user
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      throw new Error("Usuário não autenticado")
    }

    // Check if settings exist
    const { data: existingSettings } = await supabase.from("user_settings").select("*").eq("user_id", user.id).single()

    if (!existingSettings) {
      // Create settings if they don't exist
      await this.createDefaultSettings()
    }

    // Update settings
    const { data, error } = await supabase
      .from("user_settings")
      .update({
        ...settings,
        updated_at: new Date().toISOString(),
      })
      .eq("user_id", user.id)
      .select()
      .single()

    if (error) {
      console.error("Erro ao atualizar configurações:", error)
      throw error
    }

    return data
  }

  /**
   * Reset settings to default values
   * @returns Default settings
   */
  static async resetSettings() {
    const supabase = getSupabaseBrowserClient()

    // Get current user
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      throw new Error("Usuário não autenticado")
    }

    // Delete existing settings
    await supabase.from("user_settings").delete().eq("user_id", user.id)

    // Create default settings
    return this.createDefaultSettings()
  }
}
