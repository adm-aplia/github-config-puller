import { supabase } from "@/lib/supabase"

export interface WhatsAppConnection {
  id?: string
  user_id: string
  instance_name: string
  display_name: string
  status: "connected" | "disconnected" | "connecting" | "qrcode"
  profile_name?: string
  profile_picture_url?: string
  estrategista_id?: number
  _phone_number?: string
  created_at?: string
  updated_at?: string
  last_connected_at?: string
}

export const whatsappConnectionsService = {
  // Obter todas as conexões do usuário atual
  async getUserConnections(): Promise<WhatsAppConnection[]> {
    try {
      const supabaseClient = supabase()
      const { data: session } = await supabaseClient.auth.getSession()

      if (!session?.session?.user?.id) {
        throw new Error("Usuário não autenticado")
      }

      const { data, error } = await supabaseClient
        .from("whatsapp_connections")
        .select("*")
        .eq("user_id", session.session.user.id)
        .order("created_at", { ascending: false })

      if (error) {
        console.error("Erro ao buscar conexões:", error)
        throw error
      }

      return data || []
    } catch (error) {
      console.error("Erro ao buscar conexões:", error)
      return []
    }
  },

  // Criar uma nova conexão
  async createConnection(connection: Omit<WhatsAppConnection, "user_id">): Promise<WhatsAppConnection | null> {
    try {
      const supabaseClient = supabase()
      const { data: session } = await supabaseClient.auth.getSession()

      if (!session?.session?.user?.id) {
        throw new Error("Usuário não autenticado")
      }

      const newConnection = {
        ...connection,
        user_id: session.session.user.id,
        updated_at: new Date().toISOString(),
      }

      // Remover propriedades temporárias que não existem no banco
      if ("_phone_number" in newConnection) {
        delete newConnection._phone_number
      }

      // Verificar se a instância já existe no servidor
      try {
        // Tentar criar a instância no servidor
        await fetch(`/api/whatsapp/create`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ instanceName: connection.instance_name }),
        })
      } catch (err) {
        console.error("Aviso ao criar instância no servidor:", err)
        // Continuar mesmo se falhar (pode ser que a instância já exista)
      }

      const { data, error } = await supabaseClient.from("whatsapp_connections").insert(newConnection).select().single()

      if (error) {
        console.error("Erro ao criar conexão:", error)
        throw error
      }

      return data
    } catch (error) {
      console.error("Erro ao criar conexão:", error)
      return null
    }
  },

  // Atualizar uma conexão existente
  async updateConnection(id: string, updates: Partial<WhatsAppConnection>): Promise<WhatsAppConnection | null> {
    try {
      const supabaseClient = supabase()
      const { data: session } = await supabaseClient.auth.getSession()

      if (!session?.session?.user?.id) {
        throw new Error("Usuário não autenticado")
      }

      // Remover propriedades temporárias que não existem no banco
      const updatesToSend = { ...updates }
      if ("_phone_number" in updatesToSend) {
        delete updatesToSend._phone_number
      }

      const { data, error } = await supabaseClient
        .from("whatsapp_connections")
        .update({
          ...updatesToSend,
          updated_at: new Date().toISOString(),
        })
        .eq("id", id)
        .eq("user_id", session.session.user.id) // Garantir que o usuário só atualize suas próprias conexões
        .select()
        .single()

      if (error) {
        console.error("Erro ao atualizar conexão:", error)
        throw error
      }

      return data
    } catch (error) {
      console.error("Erro ao atualizar conexão:", error)
      return null
    }
  },

  // Atualizar o estrategista associado a uma conexão
  async updateConnectionEstrategista(id: string, estrategistaId: number | null): Promise<WhatsAppConnection | null> {
    try {
      const supabaseClient = supabase()
      const { data: session } = await supabaseClient.auth.getSession()

      if (!session?.session?.user?.id) {
        throw new Error("Usuário não autenticado")
      }

      // Se o estrategistaId for fornecido, verificar se o estrategista pertence ao usuário atual
      if (estrategistaId) {
        const { data: estrategistaData, error: estrategistaError } = await supabaseClient
          .from("estrategistas")
          .select("id")
          .eq("id", estrategistaId)
          .eq("user_id", session.session.user.id)
          .single()

        if (estrategistaError || !estrategistaData) {
          throw new Error("Estrategista não encontrado ou não pertence ao usuário atual")
        }
      }

      return this.updateConnection(id, { estrategista_id: estrategistaId })
    } catch (error) {
      console.error("Erro ao atualizar estrategista da conexão:", error)
      return null
    }
  },

  // Excluir uma conexão
  async deleteConnection(id: string): Promise<boolean> {
    try {
      const supabaseClient = supabase()
      const { data: session } = await supabaseClient.auth.getSession()

      if (!session?.session?.user?.id) {
        throw new Error("Usuário não autenticado")
      }

      // Obter informações da conexão antes de excluir
      const { data: connection } = await supabaseClient
        .from("whatsapp_connections")
        .select("instance_name")
        .eq("id", id)
        .eq("user_id", session.session.user.id)
        .single()

      // Tentar excluir a instância no servidor, mas não falhar se não existir
      if (connection?.instance_name) {
        try {
          // Primeiro, tente desconectar a instância (ignorando erros)
          try {
            const disconnectResponse = await fetch(`/api/whatsapp/disconnect?instance=${connection.instance_name}`, {
              method: "DELETE",
              cache: "no-store",
            })

            // Verificar se a resposta foi bem-sucedida
            if (!disconnectResponse.ok) {
              const errorData = await disconnectResponse.json()
              console.log(`Aviso ao desconectar instância ${connection.instance_name}:`, errorData)
              // Não lançar erro, apenas registrar o aviso
            }
          } catch (disconnectErr) {
            console.log(`Aviso ao desconectar instância ${connection.instance_name}:`, disconnectErr)
            // Ignorar erros de desconexão
          }

          // Agora tente excluir a instância
          try {
            const deleteResponse = await fetch(`/api/whatsapp/delete?instance=${connection.instance_name}`, {
              method: "DELETE",
              cache: "no-store",
            })

            // Verificar se a resposta foi bem-sucedida
            if (!deleteResponse.ok) {
              const errorData = await deleteResponse.json()
              console.log(`Aviso ao excluir instância ${connection.instance_name}:`, errorData)
              // Não lançar erro, apenas registrar o aviso
            }
          } catch (deleteErr) {
            console.log(`Aviso ao excluir instância ${connection.instance_name}:`, deleteErr)
            // Ignorar erros de exclusão
          }
        } catch (err) {
          console.log(`Aviso ao excluir instância ${connection.instance_name} no servidor:`, err)
          // Continuar mesmo se falhar na API
        }
      }

      // Excluir a conexão do banco de dados independentemente do resultado da API
      const { error } = await supabaseClient
        .from("whatsapp_connections")
        .delete()
        .eq("id", id)
        .eq("user_id", session.session.user.id)

      if (error) {
        console.error("Erro ao excluir conexão do banco de dados:", error)
        throw error
      }

      return true
    } catch (error) {
      console.error("Erro ao excluir conexão:", error)
      return false
    }
  },

  // Atualizar o status de uma conexão
  async updateConnectionStatus(
    instanceName: string,
    status: WhatsAppConnection["status"],
    profileInfo?: {
      profile_name?: string
      profile_picture_url?: string
    },
  ): Promise<WhatsAppConnection | null> {
    try {
      const supabaseClient = supabase()
      const { data: session } = await supabaseClient.auth.getSession()

      if (!session?.session?.user?.id) {
        throw new Error("Usuário não autenticado")
      }

      const updates: any = {
        status,
        updated_at: new Date().toISOString(),
      }

      // Adicionar informações do perfil, se disponíveis
      if (profileInfo) {
        if (profileInfo.profile_name) updates.profile_name = profileInfo.profile_name
        if (profileInfo.profile_picture_url) updates.profile_picture_url = profileInfo.profile_picture_url
      }

      // Se o status for "connected", atualizar o timestamp de última conexão
      if (status === "connected") {
        updates.last_connected_at = new Date().toISOString()
      }

      const { data, error } = await supabaseClient
        .from("whatsapp_connections")
        .update(updates)
        .eq("instance_name", instanceName)
        .eq("user_id", session.session.user.id)
        .select()
        .single()

      if (error) {
        console.error("Erro ao atualizar status da conexão:", error)
        throw error
      }

      return data
    } catch (error) {
      console.error("Erro ao atualizar status da conexão:", error)
      return null
    }
  },

  // Forçar sincronização de status com a API
  async forceStatusSync(instanceName: string, apiStatus: any): Promise<WhatsAppConnection | null> {
    try {
      const supabaseClient = supabase()
      const { data: session } = await supabaseClient.auth.getSession()

      if (!session?.session?.user?.id) {
        throw new Error("Usuário não autenticado")
      }

      // Garantir que temos um status válido da API
      if (!apiStatus || !apiStatus.instance) {
        throw new Error("Status da API inválido")
      }

      const updates: any = {
        status: apiStatus.instance.status,
        updated_at: new Date().toISOString(),
      }

      // Adicionar informações do perfil
      if (apiStatus.instance.profileName) {
        updates.profile_name = apiStatus.instance.profileName
      }

      if (apiStatus.instance.profilePictureUrl) {
        updates.profile_picture_url = apiStatus.instance.profilePictureUrl
      }

      // Extrair número de telefone para uso temporário, mas não salvar no banco
      let phoneNumber = null
      if (apiStatus.instance.number) {
        phoneNumber = apiStatus.instance.number
      } else if (apiStatus.instance.wid) {
        // Extrair número do WID se disponível (formato: 5541912345678@s.whatsapp.net)
        const match = apiStatus.instance.wid.match(/^(\d+)@/)
        if (match && match[1]) {
          phoneNumber = match[1]
        }
      }

      // Se o status for "connected", atualizar o timestamp de última conexão
      if (updates.status === "connected") {
        updates.last_connected_at = new Date().toISOString()
      }

      console.log(`Forçando atualização de status para ${instanceName}:`, updates)

      const { data, error } = await supabaseClient
        .from("whatsapp_connections")
        .update(updates)
        .eq("instance_name", instanceName)
        .eq("user_id", session.session.user.id)
        .select()
        .single()

      if (error) {
        console.error("Erro ao forçar sincronização de status:", error)
        throw error
      }

      // Adicionar o número de telefone como propriedade temporária para uso na interface
      if (data && phoneNumber) {
        data._phone_number = phoneNumber
      }

      return data
    } catch (error) {
      console.error("Erro ao forçar sincronização de status:", error)
      return null
    }
  },

  // Sincronizar instâncias entre o banco de dados e o servidor
  async syncInstances(): Promise<boolean> {
    try {
      const supabaseClient = supabase()
      const { data: session } = await supabaseClient.auth.getSession()

      if (!session?.session?.user?.id) {
        throw new Error("Usuário não autenticado")
      }

      // Obter conexões do banco de dados
      const { data: dbConnections, error: dbError } = await supabaseClient
        .from("whatsapp_connections")
        .select("*")
        .eq("user_id", session.session.user.id)

      if (dbError) {
        console.error("Erro ao buscar conexões do banco de dados:", dbError)
        throw dbError
      }

      // Obter instâncias do servidor
      try {
        const response = await fetch(`/api/whatsapp/instances`, {
          method: "GET",
          cache: "no-store",
        })

        if (!response.ok) {
          throw new Error(`Erro ao obter instâncias: ${response.status}`)
        }

        const contentType = response.headers.get("content-type")
        if (!contentType || !contentType.includes("application/json")) {
          throw new Error(`Resposta não é JSON: ${contentType}`)
        }

        const serverInstances = await response.json()

        if (!Array.isArray(serverInstances)) {
          throw new Error("Formato de resposta inválido")
        }

        // Criar instâncias que existem no banco mas não no servidor
        for (const dbConn of dbConnections || []) {
          const serverInstance = serverInstances.find(
            (inst) => inst.name && inst.name.toLowerCase() === dbConn.instance_name.toLowerCase(),
          )

          if (!serverInstance) {
            console.log(`Instância ${dbConn.instance_name} não encontrada no servidor. Criando...`)
            try {
              await fetch(`/api/whatsapp/create`, {
                method: "POST",
                headers: {
                  "Content-Type": "application/json",
                },
                body: JSON.stringify({ instanceName: dbConn.instance_name }),
              })
            } catch (err) {
              console.error(`Erro ao criar instância ${dbConn.instance_name}:`, err)
            }
          }
        }

        return true
      } catch (err) {
        console.error("Erro ao sincronizar instâncias:", err)
        return false
      }
    } catch (error) {
      console.error("Erro ao sincronizar instâncias:", error)
      return false
    }
  },
}
