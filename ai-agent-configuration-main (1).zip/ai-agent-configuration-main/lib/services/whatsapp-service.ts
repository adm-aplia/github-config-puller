// lib/services/whatsapp-service.ts

import { getSupabaseBrowserClient } from "@/lib/supabase"
import { evolutionAPI } from "@/lib/evolution-api"
import type { Database } from "@/types/supabase"

export type WhatsAppInstance = Database["public"]["Tables"]["whatsapp_instances"]["Row"]
export type WhatsAppInstanceInsert = Database["public"]["Tables"]["whatsapp_instances"]["Insert"]
export type WhatsAppInstanceUpdate = Database["public"]["Tables"]["whatsapp_instances"]["Update"]

export class WhatsAppService {
  /**
   * Get all WhatsApp instances for the current user
   * @param filters Optional filters
   * @returns Array of WhatsApp instances
   */
  static async getUserInstances(filters?: { status?: string }) {
    const supabase = getSupabaseBrowserClient()

    let query = supabase.from("whatsapp_instances").select("*").order("created_at", { ascending: false })

    if (filters?.status) {
      query = query.eq("status", filters.status)
    }

    const { data, error } = await query

    if (error) {
      console.error("Erro ao buscar instâncias:", error)
      throw error
    }

    return data
  }

  /**
   * Get a specific WhatsApp instance
   * @param id Instance ID
   * @returns WhatsApp instance
   */
  static async getInstance(id: string) {
    const supabase = getSupabaseBrowserClient()

    const { data, error } = await supabase.from("whatsapp_instances").select("*").eq("id", id).single()

    if (error) {
      console.error(`Erro ao buscar instância ${id}:`, error)
      throw error
    }

    return data
  }

  /**
   * Create a new WhatsApp instance
   * @param instanceName Instance name
   * @returns Created instance
   */
  static async createInstance(instanceName: string) {
    const supabase = getSupabaseBrowserClient()

    // Get current user
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      throw new Error("Usuário não autenticado")
    }

    try {
      // Create instance in Evolution API
      const evolutionInstance = await evolutionAPI.createInstance(instanceName)

      // Determine initial status
      const initialStatus = evolutionInstance.instance?.status || "disconnected"

      // Save to database
      const { data, error } = await supabase
        .from("whatsapp_instances")
        .insert({
          user_id: user.id,
          instance_name: instanceName,
          profile_name: evolutionInstance.instance?.profileName || instanceName,
          status: initialStatus,
        })
        .select()
        .single()

      if (error) {
        console.error("Erro ao salvar instância no Supabase:", error)
        throw error
      }

      return data
    } catch (error) {
      console.error("Erro ao criar instância:", error)
      throw error
    }
  }

  /**
   * Update a WhatsApp instance
   * @param id Instance ID
   * @param updates Fields to update
   * @returns Updated instance
   */
  static async updateInstance(id: string, updates: WhatsAppInstanceUpdate) {
    const supabase = getSupabaseBrowserClient()

    const { data, error } = await supabase
      .from("whatsapp_instances")
      .update({
        ...updates,
        updated_at: new Date().toISOString(),
      })
      .eq("id", id)
      .select()
      .single()

    if (error) {
      console.error(`Erro ao atualizar instância ${id}:`, error)
      throw error
    }

    return data
  }

  /**
   * Update the status of a WhatsApp instance
   * @param id Instance ID
   * @param status New status
   * @param profileName Optional profile name
   * @param profilePictureUrl Optional profile picture URL
   * @param phoneNumber Optional phone number
   * @returns Updated instance
   */
  static async updateInstanceStatus(
    id: string,
    status: string,
    profileName?: string,
    profilePictureUrl?: string,
    phoneNumber?: string,
  ) {
    const updates: any = {
      status,
      profile_name: profileName || undefined,
    }

    if (profilePictureUrl !== undefined) {
      updates.profile_picture_url = profilePictureUrl === "" ? null : profilePictureUrl
    }

    if (phoneNumber !== undefined) {
      updates.phone_number = phoneNumber === "" ? null : phoneNumber
    }

    return this.updateInstance(id, updates)
  }

  /**
   * Get a WhatsApp instance by name
   * @param instanceName Instance name
   * @returns WhatsApp instance or null if not found
   */
  static async getInstanceByName(instanceName: string) {
    const supabase = getSupabaseBrowserClient()

    const { data, error } = await supabase
      .from("whatsapp_instances")
      .select("*")
      .eq("instance_name", instanceName)
      .single()

    if (error && error.code !== "PGRST116") {
      // PGRST116 is the code for "no results found"
      console.error(`Erro ao buscar instância ${instanceName}:`, error)
      throw error
    }

    return data || null
  }

  /**
   * Synchronize instances between database and Evolution API
   * @returns Updated instances
   */
  static async syncInstances() {
    try {
      // Get instances from database
      const dbInstances = await this.getUserInstances()

      // Get instances from Evolution API
      const apiInstances = await evolutionAPI.getInstances()

      // Update status of instances in database
      for (const dbInstance of dbInstances) {
        const apiInstance = apiInstances.find((i) => i.instance.instanceName === dbInstance.instance_name)

        if (apiInstance) {
          // Extract phone number if available
          let phoneNumber = null
          if (apiInstance.instance.number) {
            phoneNumber = apiInstance.instance.number
          } else if (apiInstance.instance.wid) {
            // Format: 5541912345678@s.whatsapp.net
            const match = apiInstance.instance.wid.match(/^(\d+)@/)
            if (match && match[1]) {
              phoneNumber = match[1]
            }
          }

          await this.updateInstanceStatus(
            dbInstance.id,
            apiInstance.instance.status,
            apiInstance.instance.profileName,
            apiInstance.instance.profilePictureUrl,
            phoneNumber,
          )
        } else {
          // If instance not found in API, mark as disconnected
          await this.updateInstanceStatus(dbInstance.id, "disconnected")
        }
      }

      // Add instances from API that are not in database
      const supabase = getSupabaseBrowserClient()
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (user) {
        for (const apiInstance of apiInstances) {
          const exists = dbInstances.some((db) => db.instance_name === apiInstance.instance.instanceName)

          if (!exists) {
            // Extract phone number if available
            let phoneNumber = null
            if (apiInstance.instance.number) {
              phoneNumber = apiInstance.instance.number
            } else if (apiInstance.instance.wid) {
              const match = apiInstance.instance.wid.match(/^(\d+)@/)
              if (match && match[1]) {
                phoneNumber = match[1]
              }
            }

            // Add instance to database
            await supabase.from("whatsapp_instances").insert({
              user_id: user.id,
              instance_name: apiInstance.instance.instanceName,
              profile_name: apiInstance.instance.profileName || apiInstance.instance.instanceName,
              profile_picture_url: apiInstance.instance.profilePictureUrl || null,
              phone_number: phoneNumber,
              status: apiInstance.instance.status || "disconnected",
            })
          }
        }
      }

      return await this.getUserInstances()
    } catch (error) {
      console.error("Erro ao sincronizar instâncias:", error)
      throw error
    }
  }

  /**
   * Delete a WhatsApp instance
   * @param id Instance ID
   * @returns Success status
   */
  static async deleteInstance(id: string) {
    const supabase = getSupabaseBrowserClient()

    // First, get the instance name
    const { data: instance } = await supabase.from("whatsapp_instances").select("instance_name").eq("id", id).single()

    if (!instance) {
      throw new Error(`Instância com ID ${id} não encontrada`)
    }

    try {
      // Delete from Evolution API
      await evolutionAPI.deleteInstance(instance.instance_name)
    } catch (error) {
      console.error(`Erro ao excluir instância ${instance.instance_name} da API:`, error)
      // Continue even if API deletion fails
    }

    // Delete from database
    const { error } = await supabase.from("whatsapp_instances").delete().eq("id", id)

    if (error) {
      console.error(`Erro ao excluir instância ${id}:`, error)
      throw error
    }

    return true
  }

  /**
   * Get statistics for WhatsApp instances
   * @returns Statistics object
   */
  static async getInstanceStats() {
    const instances = await this.getUserInstances()

    const total = instances.length
    const connected = instances.filter((i) => i.status === "connected").length
    const disconnected = instances.filter((i) => i.status === "disconnected").length
    const connecting = instances.filter((i) => i.status === "connecting").length
    const qrcode = instances.filter((i) => i.status === "qrcode").length

    return {
      total,
      connected,
      disconnected,
      connecting,
      qrcode,
      instances,
    }
  }

  /**
   * Send a message via WhatsApp
   * @param options Send message options
   * @returns Success status
   */
  static async sendMessage(options: { instanceId: string; to: string; message: string }) {
    try {
      const instance = await this.getInstance(options.instanceId)

      if (!instance) {
        throw new Error(`Instância com ID ${options.instanceId} não encontrada`)
      }

      // Send message via Evolution API
      await evolutionAPI.sendTextMessage(instance.instance_name, options.to, options.message)

      return true
    } catch (error) {
      console.error(`Erro ao enviar mensagem via WhatsApp:`, error)
      throw error
    }
  }

  /**
   * Get conversations for a specific WhatsApp instance
   * @param instanceId Instance ID
   * @param pagination Optional pagination parameters
   * @returns Conversations for the instance
   */
  static async getInstanceConversations(instanceId: string, pagination?: { page: number; pageSize: number }) {
    const supabase = getSupabaseBrowserClient()

    let query = supabase
      .from("conversations")
      .select(`
        *,
        agents (id, name, specialty)
      `)
      .eq("instance_id", instanceId)
      .order("updated_at", { ascending: false })

    // Apply pagination
    if (pagination) {
      const { page, pageSize } = pagination
      const from = (page - 1) * pageSize
      const to = from + pageSize - 1
      query = query.range(from, to)
    }

    const { data, error, count } = await query

    if (error) {
      console.error(`Erro ao buscar conversas da instância ${instanceId}:`, error)
      throw error
    }

    return { data, count }
  }

  /**
   * Assign a professional profile to a WhatsApp instance
   * @param instanceId Instance ID
   * @param profileId Professional profile ID
   * @returns Updated instance
   */
  static async assignProfessionalProfile(instanceId: string, profileId: string) {
    return this.updateInstance(instanceId, {
      professional_profile_id: profileId,
    })
  }

  /**
   * Remove professional profile assignment from a WhatsApp instance
   * @param instanceId Instance ID
   * @returns Updated instance
   */
  static async removeProfessionalProfile(instanceId: string) {
    const result = await this.updateInstance(instanceId, {
      professional_profile_id: null,
    })

    return result
  }

  /**
   * Get the professional profile assigned to a WhatsApp instance
   * @param instanceId Instance ID
   * @returns Professional profile data or null if not found
   */
  static async getAssignedProfessionalProfile(instanceId: string) {
    const supabase = getSupabaseBrowserClient()

    // First get the instance to check if it has a profile assigned
    const { data: instance, error: instanceError } = await supabase
      .from("whatsapp_instances")
      .select("professional_profile_id")
      .eq("id", instanceId)
      .single()

    if (instanceError) {
      console.error(`Erro ao buscar instância ${instanceId}:`, instanceError)
      return null
    }

    if (!instance?.professional_profile_id) {
      return null
    }

    // Get the profile data
    const { data: profile, error: profileError } = await supabase
      .from("professional_profiles")
      .select("*")
      .eq("id", instance.professional_profile_id)
      .single()

    if (profileError) {
      console.error(`Erro ao buscar perfil ${instance.professional_profile_id}:`, profileError)
      return null
    }

    return profile
  }

  /**
   * Get all professional profiles for the current user
   * @returns Array of professional profiles
   */
  static async getProfessionalProfiles() {
    const supabase = getSupabaseBrowserClient()

    const { data, error } = await supabase
      .from("professional_profiles")
      .select("id, fullName, specialty, created_at")
      .order("created_at", { ascending: false })

    if (error) {
      console.error("Erro ao buscar perfis profissionais:", error)
      throw error
    }

    return data || []
  }

  /**
   * Get WhatsApp instances with their assigned professional profiles
   * @returns Array of instances with profile information
   */
  static async getInstancesWithProfiles() {
    const supabase = getSupabaseBrowserClient()

    const { data, error } = await supabase
      .from("whatsapp_instances")
      .select(`
        *,
        professional_profiles:professional_profile_id (
          id, 
          fullName, 
          specialty
        )
      `)
      .order("created_at", { ascending: false })

    if (error) {
      console.error("Erro ao buscar instâncias com perfis:", error)
      throw error
    }

    return data || []
  }

  /**
   * Atualiza o status de uma instância do WhatsApp no banco de dados
   */
  async updateInstanceStatus(
    instanceId: string,
    status: "connected" | "connecting" | "disconnected" | "qrcode",
    profileName?: string,
    profilePictureUrl?: string,
    phoneNumber?: string,
  ): Promise<void> {
    try {
      const supabase = getSupabaseBrowserClient()

      const updates: any = {
        status,
        updated_at: new Date().toISOString(),
      }

      if (profileName) {
        updates.profile_name = profileName
      }

      if (profilePictureUrl) {
        updates.profile_picture_url = profilePictureUrl
      }

      if (phoneNumber) {
        updates.phone_number = phoneNumber
      }

      // Se o status for "connected", atualizar também o timestamp de última conexão
      if (status === "connected") {
        updates.last_connected_at = new Date().toISOString()
      }

      const { error } = await supabase.from("whatsapp_instances").update(updates).eq("id", instanceId)

      if (error) {
        console.error("Erro ao atualizar status da instância:", error)
        throw error
      }
    } catch (error) {
      console.error("Erro ao atualizar status da instância:", error)
      throw error
    }
  }

  /**
   * Sincroniza o status de todas as instâncias com a Evolution API
   */
  async syncInstancesWithEvolutionAPI(): Promise<void> {
    try {
      const supabase = getSupabaseBrowserClient()

      // 1. Obter todas as instâncias do banco de dados
      const { data: dbInstances, error: dbError } = await supabase.from("whatsapp_instances").select("*")

      if (dbError) {
        console.error("Erro ao buscar instâncias do banco:", dbError)
        throw dbError
      }

      if (!dbInstances || dbInstances.length === 0) {
        console.log("Nenhuma instância encontrada no banco de dados")
        return
      }

      // 2. Obter todas as instâncias da Evolution API
      const apiInstances = await evolutionAPI.getInstances()
      console.log("Instâncias da API:", apiInstances)

      // 3. Atualizar cada instância do banco com os dados da API
      for (const dbInstance of dbInstances) {
        try {
          // Encontrar a instância correspondente na API
          const apiInstance = apiInstances.find(
            (i) => i.instance.instanceName.toLowerCase() === dbInstance.instance_name.toLowerCase(),
          )

          if (apiInstance) {
            // Extrair número de telefone do WID se disponível
            let phoneNumber = null
            if (apiInstance.instance.number) {
              phoneNumber = apiInstance.instance.number
            } else if (apiInstance.instance.wid) {
              const match = apiInstance.instance.wid.match(/^(\d+)@/)
              if (match && match[1]) {
                phoneNumber = match[1]
              }
            }

            // Atualizar status no banco
            await this.updateInstanceStatus(
              dbInstance.id,
              apiInstance.instance.status as any,
              apiInstance.instance.profileName,
              apiInstance.instance.profilePictureUrl,
              phoneNumber,
            )
          } else {
            console.log(`Instância ${dbInstance.instance_name} não encontrada na API`)
            // Marcar como desconectada se não encontrada na API
            await this.updateInstanceStatus(dbInstance.id, "disconnected")
          }
        } catch (instanceError) {
          console.error(`Erro ao sincronizar instância ${dbInstance.instance_name}:`, instanceError)
          // Continuar com as próximas instâncias mesmo se houver erro
        }
      }
    } catch (error) {
      console.error("Erro ao sincronizar instâncias:", error)
      throw error
    }
  }

  /**
   * Obtém o status atualizado de uma instância específica
   */
  async getInstanceStatus(instanceName: string): Promise<any> {
    try {
      const status = await evolutionAPI.getInstanceStatus(instanceName)
      return status
    } catch (error) {
      console.error(`Erro ao obter status da instância ${instanceName}:`, error)
      throw error
    }
  }

  /**
   * Sincroniza uma instância específica com a Evolution API
   */
  async syncSingleInstance(instanceId: string, instanceName: string): Promise<void> {
    try {
      // Obter status atualizado da API
      const apiStatus = await this.getInstanceStatus(instanceName)

      if (apiStatus && apiStatus.instance) {
        // Extrair número de telefone
        let phoneNumber = null
        if (apiStatus.instance.number) {
          phoneNumber = apiStatus.instance.number
        } else if (apiStatus.instance.wid) {
          const match = apiStatus.instance.wid.match(/^(\d+)@/)
          if (match && match[1]) {
            phoneNumber = match[1]
          }
        }

        // Atualizar no banco
        await this.updateInstanceStatus(
          instanceId,
          apiStatus.instance.status,
          apiStatus.instance.profileName,
          apiStatus.instance.profilePictureUrl,
          phoneNumber,
        )
      }
    } catch (error) {
      console.error(`Erro ao sincronizar instância ${instanceName}:`, error)
      throw error
    }
  }
}

// Exportar uma instância única para uso em toda a aplicação
export const whatsappService = new WhatsAppService()
