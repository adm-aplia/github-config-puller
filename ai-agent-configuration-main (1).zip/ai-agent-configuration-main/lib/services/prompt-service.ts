import { getSupabaseBrowserClient } from "@/lib/supabase"

export type Prompt = {
  id: string
  user_id: string
  questionnaire_id?: string
  prompt_text: string
  prompt_type: string
  is_active: boolean
  created_at: string
  updated_at: string
}

export type PromptInsert = Omit<Prompt, "id" | "created_at" | "updated_at">
export type PromptUpdate = Partial<Omit<Prompt, "id" | "user_id" | "created_at" | "updated_at">>

export class PromptService {
  /**
   * Obter todos os prompts do usuário atual
   * @param filters Filtros opcionais (tipo, questionário)
   * @returns Array de prompts
   */
  static async getUserPrompts(filters?: { type?: string; questionnaireId?: string; isActive?: boolean }) {
    const supabase = getSupabaseBrowserClient()

    // Obter usuário atual
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      throw new Error("Usuário não autenticado")
    }

    let query = supabase.from("prompts").select("*").eq("user_id", user.id).order("created_at", { ascending: false })

    // Aplicar filtros
    if (filters?.type) {
      query = query.eq("prompt_type", filters.type)
    }
    if (filters?.questionnaireId) {
      query = query.eq("questionnaire_id", filters.questionnaireId)
    }
    if (filters?.isActive !== undefined) {
      query = query.eq("is_active", filters.isActive)
    }

    const { data, error } = await query

    if (error) {
      console.error("Erro ao buscar prompts:", error)
      throw error
    }

    return data || []
  }

  /**
   * Obter um prompt específico
   * @param id ID do prompt
   * @returns Prompt
   */
  static async getPrompt(id: string) {
    const supabase = getSupabaseBrowserClient()

    const { data, error } = await supabase.from("prompts").select("*").eq("id", id).single()

    if (error) {
      console.error(`Erro ao buscar prompt ${id}:`, error)
      throw error
    }

    return data
  }

  /**
   * Criar um novo prompt
   * @param prompt Dados do prompt
   * @returns Prompt criado
   */
  static async createPrompt(prompt: Omit<PromptInsert, "user_id">) {
    const supabase = getSupabaseBrowserClient()

    // Obter usuário atual
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      throw new Error("Usuário não autenticado")
    }

    const { data, error } = await supabase
      .from("prompts")
      .insert({
        ...prompt,
        user_id: user.id,
      })
      .select()
      .single()

    if (error) {
      console.error("Erro ao criar prompt:", error)
      throw error
    }

    return data
  }

  /**
   * Atualizar um prompt existente
   * @param id ID do prompt
   * @param updates Campos a atualizar
   * @returns Prompt atualizado
   */
  static async updatePrompt(id: string, updates: PromptUpdate) {
    const supabase = getSupabaseBrowserClient()

    const { data, error } = await supabase
      .from("prompts")
      .update({
        ...updates,
        updated_at: new Date().toISOString(),
      })
      .eq("id", id)
      .select()
      .single()

    if (error) {
      console.error(`Erro ao atualizar prompt ${id}:`, error)
      throw error
    }

    return data
  }

  /**
   * Excluir um prompt
   * @param id ID do prompt
   * @returns Status de sucesso
   */
  static async deletePrompt(id: string) {
    const supabase = getSupabaseBrowserClient()

    const { error } = await supabase.from("prompts").delete().eq("id", id)

    if (error) {
      console.error(`Erro ao excluir prompt ${id}:`, error)
      throw error
    }

    return true
  }

  /**
   * Ativar ou desativar um prompt
   * @param id ID do prompt
   * @param isActive Status de ativação
   * @returns Prompt atualizado
   */
  static async togglePromptActive(id: string, isActive: boolean) {
    return this.updatePrompt(id, { is_active: isActive })
  }

  /**
   * Obter prompts por tipo de questionário
   * @param questionnaireId ID do questionário
   * @param type Tipo de prompt
   * @returns Array de prompts
   */
  static async getPromptsByQuestionnaireAndType(questionnaireId: string, type: string) {
    const supabase = getSupabaseBrowserClient()

    // Obter usuário atual
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      throw new Error("Usuário não autenticado")
    }

    const { data, error } = await supabase
      .from("prompts")
      .select("*")
      .eq("user_id", user.id)
      .eq("questionnaire_id", questionnaireId)
      .eq("prompt_type", type)
      .eq("is_active", true)
      .order("created_at", { ascending: false })

    if (error) {
      console.error("Erro ao buscar prompts por questionário e tipo:", error)
      throw error
    }

    return data || []
  }
}
