import { createClient } from "../supabase/supabase-server"

export interface PlanLimits {
  whatsapp_instances: number
  max_appointments: number
  max_assistants: number
  support_level: string
  advanced_reports: boolean
  hospital_integration: boolean
  advanced_customization: boolean
  api_access: boolean
  priority_support: boolean
  custom_branding: boolean
}

export interface CurrentUsage {
  whatsapp_instances_count: number
  appointments_this_month: number
  assistants_count: number
}

export class UserSubscriptionService {
  /**
   * Verifica se um usuário tem assinatura ativa
   */
  static async hasActiveSubscription(userId: string): Promise<boolean> {
    try {
      if (!userId) return false

      const supabase = createClient()

      const { data, error } = await supabase
        .from("clientes")
        .select("id")
        .eq("user_id", userId)
        .eq("is_active", true)
        .eq("status", "ativo")
        .maybeSingle()

      if (error) {
        console.error("Erro ao verificar assinatura:", error)
        return false
      }

      return !!data
    } catch (error) {
      console.error("Erro ao verificar assinatura:", error)
      return false
    }
  }

  /**
   * Obter detalhes da assinatura de um usuário
   */
  static async getSubscriptionDetails(userId: string) {
    try {
      if (!userId) return null

      const supabase = createClient()

      const { data: cliente, error: clienteError } = await supabase
        .from("clientes")
        .select(`
          *,
          assinaturas (*)
        `)
        .eq("user_id", userId)
        .maybeSingle()

      if (clienteError) {
        console.error("Erro ao buscar detalhes da assinatura:", clienteError)
        return null
      }

      return cliente
    } catch (error) {
      console.error("Erro ao buscar detalhes da assinatura:", error)
      return null
    }
  }

  /**
   * Verificar limites do plano do usuário usando função do banco
   */
  static async getUserPlanLimits(userId: string): Promise<{ planName: string; limits: PlanLimits }> {
    try {
      if (!userId) {
        console.log("❌ UserSubscriptionService: userId não fornecido")
        return { planName: "Básico", limits: this.getBasicLimits() }
      }

      const supabase = createClient()

      console.log("🔍 UserSubscriptionService: Buscando plano para userId:", userId)

      const { data, error } = await supabase.rpc("get_user_plan_limits", {
        user_uuid: userId,
      })

      if (error) {
        console.error("❌ UserSubscriptionService: Erro ao buscar plano:", error)
        return { planName: "Básico", limits: this.getBasicLimits() }
      }

      console.log("📊 UserSubscriptionService: Dados do plano:", data)

      if (!data || data.length === 0) {
        console.log("⚠️ UserSubscriptionService: Plano não encontrado")
        return { planName: "Básico", limits: this.getBasicLimits() }
      }

      const planData = data[0]
      const limits: PlanLimits = {
        whatsapp_instances: planData.whatsapp_instances,
        max_appointments: planData.max_appointments,
        max_assistants: planData.max_assistants,
        support_level: planData.support_level,
        advanced_reports: planData.advanced_reports,
        hospital_integration: planData.hospital_integration,
        advanced_customization: planData.advanced_customization,
        api_access: planData.api_access,
        priority_support: planData.priority_support,
        custom_branding: planData.custom_branding,
      }

      console.log("✅ UserSubscriptionService: Plano encontrado:", planData.plan_name)
      return { planName: planData.plan_name, limits }
    } catch (error) {
      console.error("❌ UserSubscriptionService: Erro geral:", error)
      return { planName: "Básico", limits: this.getBasicLimits() }
    }
  }

  /**
   * Obter uso atual do usuário usando função do banco
   */
  static async getCurrentUsage(userId: string): Promise<CurrentUsage> {
    try {
      if (!userId) return this.getEmptyUsage()

      const supabase = createClient()

      console.log("📊 UserSubscriptionService: Buscando uso atual para:", userId)

      const { data, error } = await supabase.rpc("get_user_current_usage", {
        user_uuid: userId,
      })

      if (error) {
        console.error("❌ UserSubscriptionService: Erro ao buscar uso:", error)
        return this.getEmptyUsage()
      }

      if (!data || data.length === 0) {
        return this.getEmptyUsage()
      }

      const usageData = data[0]

      // Corrigir a consulta de assistentes - usar professional_profiles ao invés de profiles
      let assistants_count = 0
      try {
        const { data: profilesData, error: profilesError } = await supabase
          .from("professional_profiles")
          .select("id")
          .eq("user_id", userId)

        if (profilesError) {
          console.warn(
            "⚠️ Tabela 'professional_profiles' não encontrada ou erro na consulta, assumindo 0 assistentes:",
            profilesError,
          )
          assistants_count = 0
        } else {
          assistants_count = profilesData?.length || 0
        }
      } catch (profileError) {
        console.warn("⚠️ Erro ao consultar professional_profiles, assumindo 0 assistentes:", profileError)
        assistants_count = 0
      }

      const usage: CurrentUsage = {
        whatsapp_instances_count: Number(usageData.whatsapp_instances_count || 0),
        appointments_this_month: Number(usageData.appointments_this_month || 0),
        assistants_count: assistants_count,
      }

      console.log("📈 UserSubscriptionService: Uso atual:", usage)
      return usage
    } catch (error) {
      console.error("❌ UserSubscriptionService: Erro ao buscar uso:", error)
      return this.getEmptyUsage()
    }
  }

  /**
   * Verificar se usuário pode criar nova instância WhatsApp
   */
  static async canCreateWhatsAppInstance(userId: string): Promise<{
    allowed: boolean
    reason?: string
    current: number
    limit: number
  }> {
    try {
      const [{ limits }, usage] = await Promise.all([this.getUserPlanLimits(userId), this.getCurrentUsage(userId)])

      const current = usage.whatsapp_instances_count
      const limit = limits.whatsapp_instances

      if (current >= limit) {
        return {
          allowed: false,
          reason: `Limite de instâncias WhatsApp atingido (${current}/${limit})`,
          current,
          limit,
        }
      }

      return {
        allowed: true,
        current,
        limit,
      }
    } catch (error) {
      console.error("Erro ao verificar permissão WhatsApp:", error)
      return {
        allowed: false,
        reason: "Erro interno ao verificar permissões",
        current: 0,
        limit: 0,
      }
    }
  }

  /**
   * Verificar se usuário pode criar novo agendamento
   */
  static async canCreateAppointment(userId: string): Promise<{
    allowed: boolean
    reason?: string
    current: number
    limit: number
  }> {
    try {
      const [{ limits }, usage] = await Promise.all([this.getUserPlanLimits(userId), this.getCurrentUsage(userId)])

      const current = usage.appointments_this_month
      const limit = limits.max_appointments

      // -1 significa ilimitado
      if (limit === -1) {
        return {
          allowed: true,
          current,
          limit: -1,
        }
      }

      if (current >= limit) {
        return {
          allowed: false,
          reason: `Limite de agendamentos mensais atingido (${current}/${limit})`,
          current,
          limit,
        }
      }

      return {
        allowed: true,
        current,
        limit,
      }
    } catch (error) {
      console.error("Erro ao verificar permissão de agendamento:", error)
      return {
        allowed: false,
        reason: "Erro interno ao verificar permissões",
        current: 0,
        limit: 0,
      }
    }
  }

  /**
   * Verificar se usuário pode criar novo assistente
   */
  static async canCreateAssistant(userId: string): Promise<{
    allowed: boolean
    reason?: string
    current: number
    limit: number
  }> {
    try {
      const [{ limits }, usage] = await Promise.all([this.getUserPlanLimits(userId), this.getCurrentUsage(userId)])

      const current = usage.assistants_count
      const limit = limits.max_assistants

      // -1 significa ilimitado
      if (limit === -1) {
        return {
          allowed: true,
          current,
          limit: -1,
        }
      }

      if (current >= limit) {
        return {
          allowed: false,
          reason: `Limite de assistentes atingido (${current}/${limit})`,
          current,
          limit,
        }
      }

      return {
        allowed: true,
        current,
        limit,
      }
    } catch (error) {
      console.error("Erro ao verificar permissão de assistente:", error)
      return {
        allowed: false,
        reason: "Erro interno ao verificar permissões",
        current: 0,
        limit: 0,
      }
    }
  }

  /**
   * Obter resumo completo de limites e uso
   */
  static async getUserLimitsAndUsage(userId: string) {
    try {
      const [planData, usage] = await Promise.all([this.getUserPlanLimits(userId), this.getCurrentUsage(userId)])

      const [whatsappCheck, appointmentCheck, assistantCheck] = await Promise.all([
        this.canCreateWhatsAppInstance(userId),
        this.canCreateAppointment(userId),
        this.canCreateAssistant(userId),
      ])

      return {
        planName: planData.planName,
        limits: planData.limits,
        usage,
        permissions: {
          canCreateWhatsApp: whatsappCheck,
          canCreateAppointment: appointmentCheck,
          canCreateAssistant: assistantCheck,
        },
        features: {
          advanced_reports: planData.limits.advanced_reports,
          hospital_integration: planData.limits.hospital_integration,
          advanced_customization: planData.limits.advanced_customization,
          api_access: planData.limits.api_access,
          priority_support: planData.limits.priority_support,
          custom_branding: planData.limits.custom_branding,
        },
      }
    } catch (error) {
      console.error("Erro ao obter resumo de limites:", error)
      return null
    }
  }

  private static getEmptyUsage(): CurrentUsage {
    return {
      whatsapp_instances_count: 0,
      appointments_this_month: 0,
      assistants_count: 0,
    }
  }

  private static getBasicLimits(): PlanLimits {
    return {
      whatsapp_instances: 1,
      max_appointments: 300,
      max_assistants: 1,
      support_level: "email",
      advanced_reports: false,
      hospital_integration: false,
      advanced_customization: false,
      api_access: false,
      priority_support: false,
      custom_branding: false,
    }
  }
}
