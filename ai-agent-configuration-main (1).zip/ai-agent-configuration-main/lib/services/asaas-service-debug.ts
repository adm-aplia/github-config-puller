const ASAAS_API_URL = "https://api.asaas.com/v3"
const ASAAS_ACCESS_TOKEN =
  "$aact_prod_000MzkwODA2MWY2OGM3MWRlMDU2NWM3MzJlNzZmNGZhZGY6OmI3MDE2NTdlLTRjNjAtNDNhZS04NDVjLWQ2NDVmZjVlOGQyZTo6JGFhY2hfZDc1MGU2NTQtOTUwNS00OGI2LWJlMWUtNTJkZWRkMzFlZmM4"

interface AsaasCustomer {
  id: string
  name: string
  email: string
  phone: string
  cpfCnpj: string
}

interface CreditCardData {
  holderName: string
  number: string
  expiryMonth: string
  expiryYear: string
  ccv: string
}

interface CreditCardHolderInfo {
  name: string
  email: string
  cpfCnpj: string
  postalCode: string
  addressNumber: string
  phone: string
}

interface TokenizeCreditCardRequest {
  creditCard: CreditCardData
  creditCardHolderInfo: CreditCardHolderInfo
}

interface TokenizeCreditCardResponse {
  creditCardToken: string
}

interface CreateSubscriptionRequest {
  customer: string
  billingType: "CREDIT_CARD"
  value: number
  cycle: "MONTHLY"
  description: string
  nextDueDate: string
  creditCardToken: string
  remoteIp: string
}

interface AsaasSubscription {
  id: string
  customer: string
  billingType: string
  value: number
  cycle: string
  description: string
  status: string
  nextDueDate: string
  creditCardToken: string
}

interface CreateCustomerData {
  name: string
  cpfCnpj: string
  email: string
  phone: string
}

export class AsaasServiceDebug {
  private static getHeaders() {
    const headers = {
      "Content-Type": "application/json",
      access_token: ASAAS_ACCESS_TOKEN,
      "User-Agent": "Aplia/1.0",
    }
    console.log("🔑 Headers configurados:", {
      ...headers,
      access_token: headers.access_token.substring(0, 20) + "...",
    })
    return headers
  }

  /**
   * Testar conectividade com Asaas
   */
  static async testConnection(): Promise<boolean> {
    try {
      console.log("🔍 Testando conectividade com Asaas...")
      console.log("🌐 URL:", `${ASAAS_API_URL}/customers`)

      const response = await fetch(`${ASAAS_API_URL}/customers?limit=1`, {
        method: "GET",
        headers: this.getHeaders(),
      })

      console.log("📡 Status da resposta:", response.status)
      console.log("📡 Headers da resposta:", Object.fromEntries(response.headers.entries()))

      if (!response.ok) {
        const errorText = await response.text()
        console.error("❌ Erro na conectividade:", errorText)
        return false
      }

      const data = await response.json()
      console.log("✅ Conectividade OK:", data)
      return true
    } catch (error) {
      console.error("❌ Erro de conectividade:", error)
      return false
    }
  }

  /**
   * Criar cliente no Asaas
   */
  static async createCustomer(customerData: CreateCustomerData): Promise<AsaasCustomer> {
    try {
      console.log("🏢 Criando cliente no Asaas...")
      console.log("📝 Dados do cliente:", customerData)

      // Testar conectividade primeiro
      const isConnected = await this.testConnection()
      if (!isConnected) {
        throw new Error("Falha na conectividade com Asaas")
      }

      const response = await fetch(`${ASAAS_API_URL}/customers`, {
        method: "POST",
        headers: this.getHeaders(),
        body: JSON.stringify(customerData),
      })

      console.log("📡 Status da criação:", response.status)

      if (!response.ok) {
        const errorData = await response.json()
        console.error("❌ Erro ao criar cliente no Asaas:", errorData)
        throw new Error(`Erro ao criar cliente no Asaas: ${JSON.stringify(errorData)}`)
      }

      const data = await response.json()
      console.log("✅ Cliente criado no Asaas:", data.id)
      return data
    } catch (error) {
      console.error("❌ Erro ao criar cliente no Asaas:", error)
      throw error
    }
  }

  /**
   * Tokenizar cartão de crédito
   */
  static async tokenizeCreditCard(tokenizeData: TokenizeCreditCardRequest): Promise<TokenizeCreditCardResponse> {
    try {
      console.log("💳 Tokenizando cartão de crédito...")
      console.log("📝 Dados para tokenização:", {
        creditCard: {
          holderName: tokenizeData.creditCard.holderName,
          number: tokenizeData.creditCard.number.substring(0, 4) + "****",
          expiryMonth: tokenizeData.creditCard.expiryMonth,
          expiryYear: tokenizeData.creditCard.expiryYear,
          ccv: "***",
        },
        creditCardHolderInfo: tokenizeData.creditCardHolderInfo,
      })

      // Testar conectividade primeiro
      const isConnected = await this.testConnection()
      if (!isConnected) {
        throw new Error("Falha na conectividade com Asaas")
      }

      const response = await fetch(`${ASAAS_API_URL}/creditCard/tokenizeCreditCard`, {
        method: "POST",
        headers: this.getHeaders(),
        body: JSON.stringify(tokenizeData),
      })

      console.log("📡 Status da tokenização:", response.status)

      if (!response.ok) {
        const errorData = await response.json()
        console.error("❌ Erro ao tokenizar cartão:", errorData)
        throw new Error(`Erro ao tokenizar cartão: ${JSON.stringify(errorData)}`)
      }

      const data = await response.json()
      console.log("✅ Cartão tokenizado com sucesso")
      return data
    } catch (error) {
      console.error("❌ Erro ao tokenizar cartão:", error)
      throw error
    }
  }

  /**
   * Criar assinatura recorrente
   */
  static async createSubscription(subscriptionData: CreateSubscriptionRequest): Promise<AsaasSubscription> {
    try {
      console.log("🔄 Criando assinatura recorrente...")
      console.log("📝 Dados da assinatura:", {
        ...subscriptionData,
        creditCardToken: subscriptionData.creditCardToken.substring(0, 10) + "...",
      })

      // Testar conectividade primeiro
      const isConnected = await this.testConnection()
      if (!isConnected) {
        throw new Error("Falha na conectividade com Asaas")
      }

      const response = await fetch(`${ASAAS_API_URL}/subscriptions`, {
        method: "POST",
        headers: this.getHeaders(),
        body: JSON.stringify(subscriptionData),
      })

      console.log("📡 Status da assinatura:", response.status)

      if (!response.ok) {
        const errorData = await response.json()
        console.error("❌ Erro ao criar assinatura:", errorData)
        throw new Error(`Erro ao criar assinatura: ${JSON.stringify(errorData)}`)
      }

      const data = await response.json()
      console.log("✅ Assinatura criada:", data.id)
      return data
    } catch (error) {
      console.error("❌ Erro ao criar assinatura:", error)
      throw error
    }
  }
}
