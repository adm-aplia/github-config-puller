import { createClient } from "@supabase/supabase-js"
import { AsaasService } from "./asaas-service"

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

interface SubscriptionData {
  nome: string
  email: string
  telefone: string
  documento: string
  plano: "Básico" | "Profissional" | "Empresarial"
  user_id?: string
  endereco?: string
  cidade?: string
  estado?: string
  cep?: string
  numero_endereco?: string
  // Dados do cartão
  nome_cartao: string
  numero_cartao: string
  mes_expiracao: string
  ano_expiracao: string
  cvv: string
  // IP do cliente
  remote_ip: string
}

interface SubscriptionResult {
  success: boolean
  error?: string
  cliente?: any
  assinatura?: any
  subscription_id?: string
  status?: string
  descricao?: string
  valor?: number
  next_due_date?: string
}

export class SubscriptionService {
  /**
   * Obter configuração do plano
   */
  private static getPlanConfig(plano: string) {
    const configs = {
      Básico: {
        valor: 199.0,
        descricao: "Plano Básico Aplia – 1 número WhatsApp, até 300 agendamentos, 1 assistente, suporte por e-mail.",
      },
      Profissional: {
        valor: 399.0,
        descricao:
          "Plano Profissional Aplia – 3 números WhatsApp, até 1000 agendamentos, 3 assistentes, suporte prioritário, relatórios avançados.",
      },
      Empresarial: {
        valor: 899.0,
        descricao:
          "Plano Empresarial Aplia – +10 números WhatsApp, agendamentos ilimitados, assistentes ilimitados, suporte 24/7, integração com sistemas hospitalares, personalização avançada.",
      },
    }

    return configs[plano as keyof typeof configs]
  }

  /**
   * 1. Verificar se cliente já existe no Supabase
   */
  private static async findOrCreateCliente(data: SubscriptionData) {
    console.log("🟦 1. Verificando se cliente já existe no Supabase...")

    // Buscar por CPF ou email
    const { data: existingCliente, error: searchError } = await supabase
      .from("clientes")
      .select("*")
      .or(`cpf_cnpj.eq.${data.documento},email.eq.${data.email}`)
      .single()

    if (searchError && searchError.code !== "PGRST116") {
      throw new Error(`Erro ao buscar cliente: ${searchError.message}`)
    }

    if (existingCliente) {
      console.log("✅ Cliente já existe:", existingCliente.id)
      return existingCliente
    }

    // Criar novo cliente
    console.log("👤 Cliente não existe, criando novo...")
    const { data: newCliente, error: createError } = await supabase
      .from("clientes")
      .insert({
        nome: data.nome,
        email: data.email,
        telefone: data.telefone,
        cpf_cnpj: data.documento,
        plano: data.plano,
        data_contratacao: new Date().toISOString(),
        status: "ativo",
        user_id: data.user_id || null,
        endereco: data.endereco || null,
        cidade: data.cidade || null,
        estado: data.estado || null,
        cep: data.cep || null,
      })
      .select()
      .single()

    if (createError) {
      throw new Error(`Erro ao criar cliente: ${createError.message}`)
    }

    console.log("✅ Cliente criado:", newCliente.id)
    return newCliente
  }

  /**
   * 2. Verificar/criar cliente no Asaas
   */
  private static async ensureAsaasCustomer(cliente: any, data: SubscriptionData) {
    console.log("🟦 2. Verificando se cliente já existe no Asaas...")

    if (cliente.customer_id_asaas) {
      console.log("✅ Customer ID já existe:", cliente.customer_id_asaas)
      return cliente.customer_id_asaas
    }

    // Criar cliente no Asaas
    console.log("🏢 Criando cliente no Asaas...")
    const asaasCustomer = await AsaasService.createCustomer({
      name: data.nome,
      cpfCnpj: data.documento.replace(/\D/g, ""),
      email: data.email,
      phone: data.telefone.replace(/\D/g, ""),
    })

    // Salvar customer_id no Supabase
    const { error } = await supabase
      .from("clientes")
      .update({ customer_id_asaas: asaasCustomer.id })
      .eq("id", cliente.id)

    if (error) {
      throw new Error(`Erro ao salvar customer_id: ${error.message}`)
    }

    console.log("✅ Customer ID salvo:", asaasCustomer.id)
    return asaasCustomer.id
  }

  /**
   * 3. Tokenizar cartão de crédito
   */
  private static async tokenizeCreditCard(data: SubscriptionData) {
    console.log("🟦 3. Tokenizando cartão de crédito...")

    const tokenizeData = {
      creditCard: {
        holderName: data.nome_cartao,
        number: data.numero_cartao.replace(/\s/g, ""),
        expiryMonth: data.mes_expiracao.padStart(2, "0"),
        expiryYear: data.ano_expiracao,
        ccv: data.cvv,
      },
      creditCardHolderInfo: {
        name: data.nome_cartao,
        email: data.email,
        cpfCnpj: data.documento.replace(/\D/g, ""),
        postalCode: data.cep?.replace(/\D/g, "") || "00000000",
        addressNumber: data.numero_endereco || "S/N",
        phone: data.telefone.replace(/\D/g, ""),
      },
    }

    const tokenResponse = await AsaasService.tokenizeCreditCard(tokenizeData)
    console.log("✅ Cartão tokenizado com sucesso")
    return tokenResponse.creditCardToken
  }

  /**
   * 4. Criar assinatura recorrente
   */
  private static async createSubscription(customerId: string, creditCardToken: string, data: SubscriptionData) {
    console.log("🟦 4. Criando assinatura recorrente...")

    const planConfig = this.getPlanConfig(data.plano)
    const nextDueDate = new Date()
    nextDueDate.setMonth(nextDueDate.getMonth() + 1) // Próximo mês

    const subscriptionData = {
      customer: customerId,
      billingType: "CREDIT_CARD" as const,
      value: planConfig.valor,
      cycle: "MONTHLY" as const,
      description: planConfig.descricao,
      nextDueDate: nextDueDate.toISOString().split("T")[0],
      creditCardToken,
      remoteIp: data.remote_ip,
    }

    const subscription = await AsaasService.createSubscription(subscriptionData)
    console.log("✅ Assinatura criada:", subscription.id)
    return subscription
  }

  /**
   * 5. Registrar assinatura no Supabase
   */
  private static async saveSubscription(
    cliente: any,
    customerId: string,
    subscription: any,
    creditCardToken: string,
    data: SubscriptionData,
  ) {
    console.log("🟦 5. Registrando assinatura no Supabase...")

    const planConfig = this.getPlanConfig(data.plano)

    const { data: assinatura, error } = await supabase
      .from("assinaturas")
      .insert({
        id_cliente_supabase: cliente.id,
        customer_id_asaas: customerId,
        subscription_id: subscription.id,
        credit_card_token: creditCardToken,
        plano: data.plano,
        valor: planConfig.valor,
        descricao: planConfig.descricao,
        status: subscription.status,
        data_contratacao: new Date().toISOString(),
        next_due_date: subscription.nextDueDate,
        remote_ip: data.remote_ip,
      })
      .select()
      .single()

    if (error) {
      throw new Error(`Erro ao salvar assinatura: ${error.message}`)
    }

    console.log("✅ Assinatura salva:", assinatura.id)
    return assinatura
  }

  /**
   * Processar assinatura completa
   */
  static async processSubscription(data: SubscriptionData): Promise<SubscriptionResult> {
    console.log("🚀 Iniciando processo de assinatura recorrente...")

    try {
      // 1. Verificar/criar cliente no Supabase
      const cliente = await this.findOrCreateCliente(data)

      // 2. Verificar/criar cliente no Asaas
      const customerId = await this.ensureAsaasCustomer(cliente, data)

      // 3. Tokenizar cartão de crédito
      const creditCardToken = await this.tokenizeCreditCard(data)

      // 4. Criar assinatura recorrente
      const subscription = await this.createSubscription(customerId, creditCardToken, data)

      // 5. Registrar assinatura no Supabase
      const assinatura = await this.saveSubscription(cliente, customerId, subscription, creditCardToken, data)

      const planConfig = this.getPlanConfig(data.plano)

      console.log("🟦 6. Processo concluído com sucesso!")

      return {
        success: true,
        cliente,
        assinatura,
        subscription_id: subscription.id,
        status: subscription.status,
        descricao: planConfig.descricao,
        valor: planConfig.valor,
        next_due_date: subscription.nextDueDate,
      }
    } catch (error: any) {
      console.error("❌ Erro no processo de assinatura:", error)
      return {
        success: false,
        error: error.message || "Erro desconhecido no processo de assinatura",
      }
    }
  }

  /**
   * Buscar assinaturas de um cliente
   */
  static async getClienteSubscriptions(clienteId: string) {
    const { data, error } = await supabase
      .from("assinaturas")
      .select("*")
      .eq("id_cliente_supabase", clienteId)
      .order("created_at", { ascending: false })

    if (error) {
      throw new Error(`Erro ao buscar assinaturas: ${error.message}`)
    }

    return data
  }

  /**
   * Cancelar assinatura
   */
  static async cancelSubscription(subscriptionId: string) {
    try {
      // Cancelar no Asaas
      await AsaasService.cancelSubscription(subscriptionId)

      // Atualizar status no Supabase
      const { error } = await supabase
        .from("assinaturas")
        .update({ status: "CANCELLED", updated_at: new Date().toISOString() })
        .eq("subscription_id", subscriptionId)

      if (error) {
        throw new Error(`Erro ao atualizar status da assinatura: ${error.message}`)
      }

      console.log("✅ Assinatura cancelada com sucesso")
    } catch (error) {
      console.error("❌ Erro ao cancelar assinatura:", error)
      throw error
    }
  }
}
