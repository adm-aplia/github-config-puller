const ASAAS_API_URL = "https://api.asaas.com/v3"
const ASAAS_ACCESS_TOKEN =
  "$aact_prod_000MzkwODA2MWY2OGM3MWRlMDU2NWM3MzJlNzZmNGZhZGY6OmI3MDE2NTdlLTRjNjAtNDNhZS04NDVjLWQ2NDVmZjVlOGQyZTo6JGFhY2hfZDc1MGU2NTQtOTUwNS00OGI2LWJlMWUtNTJkZWRkMzFlZmM4"

interface AsaasCustomer {
  id: string
  name: string
  email: string
  phone: string
  cpfCnpj: string
}

interface CreditCardData {
  holderName: string
  number: string
  expiryMonth: string
  expiryYear: string
  ccv: string
}

interface CreditCardHolderInfo {
  name: string
  email: string
  cpfCnpj: string
  postalCode: string
  addressNumber: string
  addressComplement?: string
  phone: string
  mobilePhone?: string
}

interface CreateSubscriptionDirectRequest {
  customer: string
  billingType: "CREDIT_CARD"
  value: number
  cycle: "MONTHLY"
  description: string
  nextDueDate: string
  creditCard: CreditCardData
  creditCardHolderInfo: CreditCardHolderInfo
  remoteIp: string
}

interface CreatePaymentRequest {
  customer: string
  billingType: "CREDIT_CARD"
  value: number
  dueDate: string
  description: string
  creditCard: CreditCardData
  creditCardHolderInfo: CreditCardHolderInfo
  remoteIp: string
}

interface AsaasSubscription {
  id: string
  customer: string
  billingType: string
  value: number
  cycle: string
  description: string
  status: string
  nextDueDate: string
}

interface AsaasPayment {
  id: string
  customer: string
  billingType: string
  value: number
  netValue: number
  status: string
  description: string
  dueDate: string
  invoiceUrl?: string
  bankSlipUrl?: string
  pixTransaction?: any
}

interface CreateCustomerData {
  name: string
  cpfCnpj: string
  email: string
  phone: string
  mobilePhone?: string
}

export class AsaasService {
  private static getHeaders() {
    return {
      "Content-Type": "application/json",
      access_token: ASAAS_ACCESS_TOKEN,
      "User-Agent": "Aplia/1.0",
    }
  }

  /**
   * Processar resposta da API com tratamento de erro robusto
   */
  private static async processResponse(response: Response, operation: string) {
    console.log(`📡 [ASAAS] Resposta da API ${operation}:`, {
      status: response.status,
      statusText: response.statusText,
      headers: Object.fromEntries(response.headers.entries()),
    })

    // Verificar se a resposta é OK
    if (!response.ok) {
      const contentType = response.headers.get("content-type")
      let errorMessage = `Erro HTTP ${response.status}: ${response.statusText}`
      let errorDetails = null

      try {
        if (contentType && contentType.includes("application/json")) {
          const errorData = await response.json()
          console.error(`❌ [ASAAS] Erro JSON da API ${operation}:`, errorData)

          // Capturar erros específicos do Asaas
          if (errorData.errors && Array.isArray(errorData.errors)) {
            const errors = errorData.errors.map((err: any) => err.description || err.message).join("; ")
            errorMessage = errors
            errorDetails = errorData.errors
          } else if (errorData.message) {
            errorMessage = errorData.message
          } else if (errorData.error) {
            errorMessage = errorData.error
          }

          // Detectar erros específicos de limite/autorização
          const lowerError = errorMessage.toLowerCase()
          if (
            lowerError.includes("limit") ||
            lowerError.includes("insufficient") ||
            lowerError.includes("declined") ||
            lowerError.includes("not authorized") ||
            lowerError.includes("negada") ||
            lowerError.includes("recusada")
          ) {
            errorMessage = "Transação não autorizada - Verifique o limite disponível no seu cartão"
          }
        } else {
          const errorText = await response.text()
          console.error(`❌ [ASAAS] Erro de texto da API ${operation}:`, errorText)
          errorMessage = `${errorMessage} - ${errorText}`
        }
      } catch (parseError) {
        console.error(`❌ [ASAAS] Erro ao processar resposta de erro da API ${operation}:`, parseError)
      }

      // Log detalhado para debug
      console.error(`❌ [ASAAS] Erro detalhado ${operation}:`, {
        status: response.status,
        message: errorMessage,
        details: errorDetails,
        operation,
      })

      throw new Error(errorMessage)
    }

    // Processar resposta de sucesso
    const contentType = response.headers.get("content-type")

    if (!contentType || !contentType.includes("application/json")) {
      const responseText = await response.text()
      console.error(`❌ [ASAAS] Resposta não é JSON da API ${operation}:`, responseText)
      throw new Error(`API ${operation} retornou resposta não-JSON: ${responseText}`)
    }

    try {
      const data = await response.json()
      console.log(`✅ [ASAAS] Dados da API ${operation}:`, data)
      return data
    } catch (jsonError) {
      console.error(`❌ [ASAAS] Erro ao fazer parse JSON da API ${operation}:`, jsonError)
      const responseText = await response.text()
      throw new Error(`Erro ao processar JSON da API ${operation}: ${responseText}`)
    }
  }

  /**
   * Criar cliente no Asaas
   */
  static async createCustomer(customerData: CreateCustomerData): Promise<AsaasCustomer> {
    try {
      console.log("🏢 [ASAAS] Criando cliente no Asaas...")
      console.log("📝 [ASAAS] Dados do cliente:", { ...customerData, cpfCnpj: "***" })

      const response = await fetch(`${ASAAS_API_URL}/customers`, {
        method: "POST",
        headers: this.getHeaders(),
        body: JSON.stringify(customerData),
      })

      const data = await this.processResponse(response, "createCustomer")
      console.log("✅ [ASAAS] Cliente criado no Asaas:", data.id)
      return data
    } catch (error) {
      console.error("❌ [ASAAS] Erro ao criar cliente no Asaas:", error)
      throw new Error(`Falha ao criar cliente no Asaas: ${error instanceof Error ? error.message : String(error)}`)
    }
  }

  /**
   * Criar cobrança imediata no cartão de crédito
   */
  static async createCreditCardPayment(paymentData: CreatePaymentRequest): Promise<AsaasPayment> {
    try {
      console.log("💳 [ASAAS] Criando cobrança imediata no cartão...")
      console.log("📝 [ASAAS] Dados da cobrança:", {
        ...paymentData,
        creditCard: {
          ...paymentData.creditCard,
          number: `****${paymentData.creditCard.number.slice(-4)}`,
          ccv: "***",
        },
        creditCardHolderInfo: {
          ...paymentData.creditCardHolderInfo,
          cpfCnpj: "***",
        },
      })

      const response = await fetch(`${ASAAS_API_URL}/payments`, {
        method: "POST",
        headers: this.getHeaders(),
        body: JSON.stringify(paymentData),
      })

      const data = await this.processResponse(response, "createCreditCardPayment")
      console.log("✅ [ASAAS] Cobrança criada:", data.id, "Status:", data.status)
      return data
    } catch (error) {
      console.error("❌ [ASAAS] Erro ao criar cobrança:", error)
      throw new Error(`Falha ao criar cobrança: ${error instanceof Error ? error.message : String(error)}`)
    }
  }

  /**
   * Criar assinatura recorrente diretamente (sem tokenização)
   */
  static async createSubscriptionDirect(subscriptionData: CreateSubscriptionDirectRequest): Promise<AsaasSubscription> {
    try {
      console.log("🔄 [ASAAS] Criando assinatura recorrente...")
      console.log("📝 [ASAAS] Dados da assinatura:", {
        ...subscriptionData,
        creditCard: {
          ...subscriptionData.creditCard,
          number: `****${subscriptionData.creditCard.number.slice(-4)}`,
          ccv: "***",
        },
        creditCardHolderInfo: {
          ...subscriptionData.creditCardHolderInfo,
          cpfCnpj: "***",
        },
      })

      const response = await fetch(`${ASAAS_API_URL}/subscriptions`, {
        method: "POST",
        headers: this.getHeaders(),
        body: JSON.stringify(subscriptionData),
      })

      const data = await this.processResponse(response, "createSubscriptionDirect")
      console.log("✅ [ASAAS] Assinatura criada:", data.id)
      return data
    } catch (error) {
      console.error("❌ [ASAAS] Erro ao criar assinatura:", error)
      throw new Error(`Falha ao criar assinatura: ${error instanceof Error ? error.message : String(error)}`)
    }
  }

  /**
   * Criar assinatura com cobrança imediata
   * Este método cria tanto a cobrança imediata quanto a assinatura recorrente
   */
  static async createSubscriptionWithImmediateCharge(
    subscriptionData: CreateSubscriptionDirectRequest,
  ): Promise<{ subscription: AsaasSubscription; payment: AsaasPayment }> {
    try {
      console.log("🚀 [ASAAS] Criando assinatura com cobrança imediata...")

      // 1. Criar cobrança imediata (primeira mensalidade)
      const paymentData: CreatePaymentRequest = {
        customer: subscriptionData.customer,
        billingType: "CREDIT_CARD",
        value: subscriptionData.value,
        dueDate: new Date().toISOString().split("T")[0], // Hoje
        description: `${subscriptionData.description} - Primeira mensalidade`,
        creditCard: subscriptionData.creditCard,
        creditCardHolderInfo: subscriptionData.creditCardHolderInfo,
        remoteIp: subscriptionData.remoteIp,
      }

      const payment = await this.createCreditCardPayment(paymentData)
      console.log("✅ [ASAAS] Primeira cobrança criada:", payment.id)

      // 2. Criar assinatura recorrente (próximas mensalidades)
      const subscription = await this.createSubscriptionDirect(subscriptionData)
      console.log("✅ [ASAAS] Assinatura recorrente criada:", subscription.id)

      return { subscription, payment }
    } catch (error) {
      console.error("❌ [ASAAS] Erro ao criar assinatura com cobrança imediata:", error)
      throw new Error(
        `Falha ao criar assinatura com cobrança imediata: ${error instanceof Error ? error.message : String(error)}`,
      )
    }
  }

  /**
   * Validar cartão de crédito (teste de R$ 1,00)
   */
  static async validateCreditCard(
    customer: string,
    creditCard: CreditCardData,
    creditCardHolderInfo: CreditCardHolderInfo,
    remoteIp: string,
  ): Promise<{ valid: boolean; message: string }> {
    try {
      console.log("🔍 [ASAAS] Validando cartão de crédito...")

      const testPayment: CreatePaymentRequest = {
        customer,
        billingType: "CREDIT_CARD",
        value: 1.0, // Teste com R$ 1,00
        dueDate: new Date().toISOString().split("T")[0],
        description: "Teste de validação do cartão - será estornado",
        creditCard,
        creditCardHolderInfo,
        remoteIp,
      }

      const payment = await this.createCreditCardPayment(testPayment)

      if (payment.status === "CONFIRMED" || payment.status === "RECEIVED") {
        console.log("✅ [ASAAS] Cartão válido")
        return { valid: true, message: "Cartão válido" }
      } else {
        console.log("❌ [ASAAS] Cartão inválido:", payment.status)
        return { valid: false, message: `Cartão rejeitado: ${payment.status}` }
      }
    } catch (error: any) {
      console.error("❌ [ASAAS] Erro na validação do cartão:", error)

      const errorMessage = error.message.toLowerCase()
      if (
        errorMessage.includes("limit") ||
        errorMessage.includes("insufficient") ||
        errorMessage.includes("não autorizada")
      ) {
        return { valid: false, message: "Limite insuficiente no cartão" }
      }

      return { valid: false, message: `Erro na validação: ${error.message}` }
    }
  }

  /**
   * Buscar cliente no Asaas por ID
   */
  static async getCustomer(customerId: string): Promise<AsaasCustomer> {
    try {
      console.log("🔍 [ASAAS] Buscando cliente no Asaas:", customerId)

      const response = await fetch(`${ASAAS_API_URL}/customers/${customerId}`, {
        method: "GET",
        headers: this.getHeaders(),
      })

      const data = await this.processResponse(response, "getCustomer")
      return data
    } catch (error) {
      console.error("❌ [ASAAS] Erro ao buscar cliente no Asaas:", error)
      throw new Error(`Falha ao buscar cliente: ${error instanceof Error ? error.message : String(error)}`)
    }
  }

  /**
   * Buscar cobrança no Asaas por ID
   */
  static async getPayment(paymentId: string): Promise<AsaasPayment> {
    try {
      console.log("🔍 [ASAAS] Buscando cobrança no Asaas:", paymentId)

      const response = await fetch(`${ASAAS_API_URL}/payments/${paymentId}`, {
        method: "GET",
        headers: this.getHeaders(),
      })

      const data = await this.processResponse(response, "getPayment")
      return data
    } catch (error) {
      console.error("❌ [ASAAS] Erro ao buscar cobrança no Asaas:", error)
      throw new Error(`Falha ao buscar cobrança: ${error instanceof Error ? error.message : String(error)}`)
    }
  }

  /**
   * Buscar assinatura no Asaas por ID
   */
  static async getSubscription(subscriptionId: string): Promise<AsaasSubscription> {
    try {
      console.log("🔍 [ASAAS] Buscando assinatura no Asaas:", subscriptionId)

      const response = await fetch(`${ASAAS_API_URL}/subscriptions/${subscriptionId}`, {
        method: "GET",
        headers: this.getHeaders(),
      })

      const data = await this.processResponse(response, "getSubscription")
      return data
    } catch (error) {
      console.error("❌ [ASAAS] Erro ao buscar assinatura no Asaas:", error)
      throw new Error(`Falha ao buscar assinatura: ${error instanceof Error ? error.message : String(error)}`)
    }
  }

  /**
   * Cancelar assinatura
   */
  static async cancelSubscription(subscriptionId: string): Promise<void> {
    try {
      console.log("🚫 [ASAAS] Cancelando assinatura:", subscriptionId)

      const response = await fetch(`${ASAAS_API_URL}/subscriptions/${subscriptionId}`, {
        method: "DELETE",
        headers: this.getHeaders(),
      })

      await this.processResponse(response, "cancelSubscription")
      console.log("✅ [ASAAS] Assinatura cancelada com sucesso")
    } catch (error) {
      console.error("❌ [ASAAS] Erro ao cancelar assinatura:", error)
      throw new Error(`Falha ao cancelar assinatura: ${error instanceof Error ? error.message : String(error)}`)
    }
  }

  /**
   * Testar conectividade com a API
   */
  static async testConnection(): Promise<boolean> {
    try {
      console.log("🔗 [ASAAS] Testando conectividade com Asaas...")

      const response = await fetch(`${ASAAS_API_URL}/customers?limit=1`, {
        method: "GET",
        headers: this.getHeaders(),
      })

      await this.processResponse(response, "testConnection")
      console.log("✅ [ASAAS] Conectividade OK")
      return true
    } catch (error) {
      console.error("❌ [ASAAS] Erro de conectividade:", error)
      return false
    }
  }
}
