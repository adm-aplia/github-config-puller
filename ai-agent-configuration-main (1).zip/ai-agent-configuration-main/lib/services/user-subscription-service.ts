import { supabase } from "@/lib/supabase"

export class UserSubscriptionService {
  static async getUserPlanStatus(userId: string) {
    try {
      const { data, error } = await supabase
        .from("clientes")
        .select(`
          id,
          plano_id,
          planos!inner(
            id,
            nome,
            preco,
            assistants,
            whatsapp_instances,
            profiles_limit
          )
        `)
        .eq("user_id", userId)
        .single()

      if (error || !data) {
        return {
          planName: "Básico",
          planId: "basico",
          limits: {
            assistants: 1,
            whatsapp_instances: 1,
            profiles_limit: 1,
          },
        }
      }

      return {
        planName: data.planos.nome,
        planId: data.planos.id,
        limits: {
          assistants: data.planos.assistants,
          whatsapp_instances: data.planos.whatsapp_instances,
          profiles_limit: data.planos.profiles_limit,
        },
      }
    } catch (error) {
      console.error("Erro ao buscar plano do usuário:", error)
      return {
        planName: "Básico",
        planId: "basico",
        limits: {
          assistants: 1,
          whatsapp_instances: 1,
          profiles_limit: 1,
        },
      }
    }
  }

  static async isBasicPlan(userId: string): Promise<boolean> {
    const planStatus = await this.getUserPlanStatus(userId)
    return planStatus.planId === "basico"
  }
}
