import type { SupabaseClient } from "@supabase/supabase-js"
import { getSupabaseInstance } from "@/lib/supabase-singleton" // Assuming getSupabaseInstance is declared in this file

export interface ProfessionalProfile {
  id: string
  user_id: string
  // Campos básicos
  fullName: string
  fullname?: string // Campo duplicado
  specialty: string
  professionalId?: string
  professionalid?: string // Campo duplicado
  phoneNumber?: string
  phonenumber?: string // Campo duplicado
  email?: string
  education?: string
  avatar_url?: string

  // Localização e horários
  locations?: string
  workingHours?: string
  workinghours?: string // Campo duplicado

  // Procedimentos e serviços
  procedures?: string

  // Planos e pagamento
  healthInsurance?: string
  healthinsurance?: string // Campo duplicado
  paymentMethods?: string
  paymentmethods?: string // Campo duplicado
  consultationFees?: string
  consultationfees?: string // Campo duplicado
  cancellationPolicy?: string
  cancellationpolicy?: string // Campo duplicado

  // Agendamento
  consultationDuration?: string
  consultationduration?: string // Campo duplicado
  timeBetweenConsultations?: string
  timebetweenconsultations?: string // Campo duplicado
  reschedulingPolicy?: string
  reschedulingpolicy?: string // Campo duplicado
  onlineConsultations?: string
  onlineconsultations?: string // Campo duplicado
  reminderPreferences?: string
  reminderpreferences?: string // Campo duplicado

  // Requisitos do paciente
  requiredPatientInfo?: string
  requiredpatientinfo?: string // Campo duplicado
  appointmentConditions?: string
  appointmentconditions?: string // Campo duplicado
  medicalHistoryRequirements?: string
  medicalhistoryrequirements?: string // Campo duplicado
  ageRequirements?: string
  agerequirements?: string // Campo duplicado

  // Comunicação
  communicationChannels?: string
  communicationchannels?: string // Campo duplicado
  preAppointmentInfo?: string
  preappointmentinfo?: string // Campo duplicado
  requiredDocuments?: string
  requireddocuments?: string // Campo duplicado

  // Informações adicionais
  additionalInfo?: string

  created_at: string
  updated_at: string
}

export interface UpdateProfileData {
  // Etapa 1: Informações Básicas
  fullName: string
  specialty: string
  professionalId?: string
  phoneNumber?: string
  email?: string
  education?: string
  avatar_url?: string

  // Etapa 2: Localização e Atendimento
  locations?: string
  workingHours?: string
  procedures?: string

  // Etapa 3: Planos e Pagamento
  healthInsurance?: string
  paymentMethods?: string
  consultationFees?: string
  cancellationPolicy?: string

  // Etapa 4: Agendamento e Políticas
  consultationDuration?: string
  timeBetweenConsultations?: string
  reschedulingPolicy?: string
  onlineConsultations?: string
  reminderPreferences?: string

  // Etapa 5: Requisitos do Paciente
  requiredPatientInfo?: string
  appointmentConditions?: string
  medicalHistoryRequirements?: string
  ageRequirements?: string

  // Etapa 6: Comunicação e Documentos
  communicationChannels?: string
  preAppointmentInfo?: string
  requiredDocuments?: string
  additionalInfo?: string
}

export class ProfileService {
  static async getCurrentUserProfiles(supabase: SupabaseClient): Promise<ProfessionalProfile[]> {
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      throw new Error("Usuário não autenticado")
    }

    const { data, error } = await supabase
      .from("professional_profiles")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })

    if (error) {
      console.error("Erro ao buscar perfis:", error)
      throw new Error(error.message)
    }

    return data || []
  }

  /**
   * Return every professional profile in the table.
   * Used by the Appointment Calendar so the user can filter by any professional.
   * NOTE: this query is not filtered by the current user on purpose.
   * Make sure your RLS policies allow the logged-in user to read these rows.
   */
  static async getAllProfessionalProfiles(supabaseClient?: SupabaseClient): Promise<ProfessionalProfile[]> {
    try {
      const supabase = supabaseClient || getSupabaseInstance()
      if (!supabase) {
        throw new Error("Supabase não inicializado")
      }

      const { data, error } = await supabase
        .from("professional_profiles")
        .select("*")
        .order("fullName", { ascending: true })

      if (error) {
        console.error("❌ Erro ao buscar todos os perfis profissionais:", error)
        throw error
      }

      return data || []
    } catch (error) {
      console.error("❌ Erro no ProfileService.getAllProfessionalProfiles:", error)
      throw error
    }
  }

  static async getProfessionalProfile(id: string, supabase: SupabaseClient): Promise<ProfessionalProfile | null> {
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      throw new Error("Usuário não autenticado")
    }

    const { data, error } = await supabase
      .from("professional_profiles")
      .select("*")
      .eq("id", id)
      .eq("user_id", user.id)
      .single()

    if (error) {
      if (error.code === "PGRST116") {
        return null
      }
      console.error("Erro ao buscar perfil:", error)
      throw new Error(error.message)
    }

    return data
  }

  static async updateProfessionalProfile(
    id: string,
    updateData: UpdateProfileData,
    supabase: SupabaseClient,
  ): Promise<ProfessionalProfile> {
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      throw new Error("Usuário não autenticado")
    }

    console.log("🔄 Atualizando perfil:", id, updateData)

    // Mapear para os campos duplicados também (camelCase e lowercase)
    const mappedData = {
      ...updateData,
      // Mapear campos duplicados
      fullname: updateData.fullName,
      professionalid: updateData.professionalId,
      phonenumber: updateData.phoneNumber,
      workinghours: updateData.workingHours,
      healthinsurance: updateData.healthInsurance,
      paymentmethods: updateData.paymentMethods,
      consultationfees: updateData.consultationFees,
      cancellationpolicy: updateData.cancellationPolicy,
      consultationduration: updateData.consultationDuration,
      timebetweenconsultations: updateData.timeBetweenConsultations,
      reschedulingpolicy: updateData.reschedulingPolicy,
      onlineconsultations: updateData.onlineConsultations,
      reminderpreferences: updateData.reminderPreferences,
      requiredpatientinfo: updateData.requiredPatientInfo,
      appointmentconditions: updateData.appointmentConditions,
      medicalhistoryrequirements: updateData.medicalHistoryRequirements,
      agerequirements: updateData.ageRequirements,
      communicationchannels: updateData.communicationChannels,
      preappointmentinfo: updateData.preAppointmentInfo,
      requireddocuments: updateData.requiredDocuments,
      updated_at: new Date().toISOString(),
    }

    const { data, error } = await supabase
      .from("professional_profiles")
      .update(mappedData)
      .eq("id", id)
      .eq("user_id", user.id)
      .select("*")
      .single()

    if (error) {
      console.error("❌ Erro ao atualizar perfil:", error)
      throw new Error(error.message)
    }

    console.log("✅ Perfil atualizado com sucesso:", data)
    return data
  }

  static async deleteProfessionalProfile(id: string, supabase: SupabaseClient): Promise<void> {
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      throw new Error("Usuário não autenticado")
    }

    console.log("🗑️ Excluindo perfil:", id)

    try {
      // 1. Primeiro, remover todas as vinculações Google deste perfil
      const { error: linkError } = await supabase
        .from("google_profile_links")
        .delete()
        .eq("professional_profile_id", id)

      if (linkError) {
        console.error("❌ Erro ao remover vinculações Google:", linkError)
        throw new Error(`Erro ao remover vinculações Google: ${linkError.message}`)
      }

      console.log("✅ Vinculações Google removidas")

      // 2. Remover vinculações WhatsApp (se existirem)
      const { error: whatsappError } = await supabase
        .from("whatsapp_instances")
        .update({ professional_profile_id: null })
        .eq("professional_profile_id", id)

      if (whatsappError) {
        console.warn("⚠️ Aviso ao desvincular WhatsApp:", whatsappError)
        // Não falhar por causa disso, apenas avisar
      }

      console.log("✅ Vinculações WhatsApp removidas")

      // 3. Finalmente, excluir o perfil
      const { error: profileError } = await supabase
        .from("professional_profiles")
        .delete()
        .eq("id", id)
        .eq("user_id", user.id)

      if (profileError) {
        console.error("❌ Erro ao excluir perfil:", profileError)
        throw new Error(`Erro ao excluir perfil: ${profileError.message}`)
      }

      console.log("✅ Perfil excluído com sucesso")
    } catch (error: any) {
      console.error("❌ Erro durante exclusão:", error)
      throw error
    }
  }
}
