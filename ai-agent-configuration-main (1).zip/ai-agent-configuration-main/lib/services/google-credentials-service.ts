"use client"

import { useCallback } from "react"
import { getSupabaseInstance } from "@/lib/supabase-singleton"

export const useGoogleCredentialsService = () => {
  const fetchAvailableGoogleCredentials = useCallback(async () => {
    const supabase = getSupabaseInstance()
    if (!supabase) return []

    // Mock implementation for preview
    return [
      {
        id: "mock-credential-1",
        email: "user@example.com",
        name: "Mock User",
        professional_profile_id: null,
      },
    ]
  }, [])

  const sendToWebhook = useCallback(async (data: any) => {
    const webhookUrl = "https://dinastia-n8n-webhook.qhw5xb.easypanel.host/webhook/google-calendar-event-creator"

    try {
      const response = await fetch(webhookUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      })

      if (!response.ok) {
        throw new Error(`Webhook failed: ${response.status}`)
      }

      return await response.json()
    } catch (error) {
      console.error("Error sending to webhook:", error)
      throw error
    }
  }, [])

  return {
    fetchAvailableGoogleCredentials,
    sendToWebhook,
  }
}
