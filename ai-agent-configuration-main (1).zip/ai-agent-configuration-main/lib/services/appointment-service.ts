import { getSupabaseBrowserClient } from "@/lib/supabase"
import type { Database } from "@/types/supabase"

export type Appointment = Database["public"]["Tables"]["appointments"]["Row"]
export type AppointmentInsert = Omit<Database["public"]["Tables"]["appointments"]["Insert"], "patient_email"> & {
  patient_email?: string | null
}
export type AppointmentUpdate = Partial<
  Omit<Database["public"]["Tables"]["appointments"]["Update"], "patient_email">
> & { patient_email?: string | null }

export class AppointmentService {
  /**
   * Get all appointments for the current user
   * @param filters Optional filters
   * @returns Array of appointments
   */
  static async getUserAppointments(filters?: {
    status?: string
    startDate?: string
    endDate?: string
    agentId?: string
  }) {
    const supabase = getSupabaseBrowserClient()

    // Get current user
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      throw new Error("Usuário não autenticado")
    }

    // Modificado para não usar relacionamentos que não existem
    let query = supabase.from("appointments").select("*").eq("user_id", user.id)

    // Apply filters
    if (filters?.status) {
      query = query.eq("status", filters.status)
    }
    if (filters?.startDate) {
      query = query.gte("appointment_date", filters.startDate)
    }
    if (filters?.endDate) {
      query = query.lte("appointment_date", filters.endDate)
    }
    if (filters?.agentId) {
      query = query.eq("agent_id", filters.agentId)
    }

    // Order by appointment date
    query = query.order("appointment_date", { ascending: true })

    const { data, error } = await query

    if (error) {
      console.error("Erro ao buscar agendamentos:", error)
      throw error
    }

    // Se precisarmos de informações do professional_profile, buscamos separadamente
    if (data && data.length > 0) {
      const agentIds = data.map((appt) => appt.agent_id).filter((id) => id !== null) as string[]

      if (agentIds.length > 0) {
        console.log("Buscando perfis profissionais para agent_ids:", agentIds)
        const { data: profiles, error: profilesError } = await supabase
          .from("professional_profiles")
          .select("*")
          .in("id", agentIds)

        console.log("Perfis encontrados:", profiles)

        if (!profilesError && profiles) {
          // Adicionar os dados do professional_profile a cada agendamento
          return data.map((appt) => {
            if (appt.agent_id) {
              const profile = profiles.find((p) => p.id === appt.agent_id)
              console.log(`Agendamento ${appt.id} vinculado ao perfil:`, profile)
              return {
                ...appt,
                professional_profiles: profile || null,
              }
            }
            return appt
          })
        }
      }
    }

    return data || []
  }

  /**
   * Get appointments for a specific date range
   * @param startDate Start date (ISO string)
   * @param endDate End date (ISO string)
   * @returns Array of appointments
   */
  static async getAppointmentsByDateRange(startDate: string, endDate: string) {
    return this.getUserAppointments({
      startDate,
      endDate,
    })
  }

  /**
   * Get appointments for a specific contact
   * @param contactPhone Contact phone number
   * @returns Array of appointments
   */
  static async getAppointmentsByContact(contactPhone: string) {
    const supabase = getSupabaseBrowserClient()

    // Get current user
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      throw new Error("Usuário não autenticado")
    }

    // Modificado para não usar relacionamentos que não existem
    const { data, error } = await supabase
      .from("appointments")
      .select("*")
      .eq("user_id", user.id)
      .eq("patient_phone", contactPhone)
      .order("appointment_date", { ascending: true })

    if (error) {
      console.error(`Erro ao buscar agendamentos para o contato ${contactPhone}:`, error)
      throw error
    }

    // Se precisarmos de informações do professional_profile, buscamos separadamente
    if (data && data.length > 0) {
      const agentIds = data.map((appt) => appt.agent_id).filter((id) => id !== null) as string[]

      if (agentIds.length > 0) {
        console.log("Buscando perfis profissionais para agent_ids:", agentIds)
        const { data: profiles, error: profilesError } = await supabase
          .from("professional_profiles")
          .select("*")
          .in("id", agentIds)

        console.log("Perfis encontrados:", profiles)

        if (!profilesError && profiles) {
          // Adicionar os dados do professional_profile a cada agendamento
          return data.map((appt) => {
            if (appt.agent_id) {
              const profile = profiles.find((p) => p.id === appt.agent_id)
              console.log(`Agendamento ${appt.id} vinculado ao perfil:`, profile)
              return {
                ...appt,
                professional_profiles: profile || null,
              }
            }
            return appt
          })
        }
      }
    }

    return data || []
  }

  /**
   * Get appointments for a specific conversation
   * @param conversationId Conversation ID
   * @returns Array of appointments
   */
  static async getAppointmentsByConversation(conversationId: string) {
    const supabase = getSupabaseBrowserClient()

    // Get current user
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      throw new Error("Usuário não autenticado")
    }

    // Modificado para não usar relacionamentos que não existem
    const { data, error } = await supabase
      .from("appointments")
      .select("*")
      .eq("user_id", user.id)
      .eq("conversation_id", conversationId)
      .order("appointment_date", { ascending: true })

    if (error) {
      console.error(`Erro ao buscar agendamentos para a conversa ${conversationId}:`, error)
      throw error
    }

    // Se precisarmos de informações do professional_profile, buscamos separadamente
    if (data && data.length > 0) {
      const agentIds = data.map((appt) => appt.agent_id).filter((id) => id !== null) as string[]

      if (agentIds.length > 0) {
        console.log("Buscando perfis profissionais para agent_ids:", agentIds)
        const { data: profiles, error: profilesError } = await supabase
          .from("professional_profiles")
          .select("*")
          .in("id", agentIds)

        console.log("Perfis encontrados:", profiles)

        if (!profilesError && profiles) {
          // Adicionar os dados do professional_profile a cada agendamento
          return data.map((appt) => {
            if (appt.agent_id) {
              const profile = profiles.find((p) => p.id === appt.agent_id)
              console.log(`Agendamento ${appt.id} vinculado ao perfil:`, profile)
              return {
                ...appt,
                professional_profiles: profile || null,
              }
            }
            return appt
          })
        }
      }
    }

    return data || []
  }

  /**
   * Get a specific appointment
   * @param id Appointment ID
   * @returns Appointment object
   */
  static async getAppointment(id: string) {
    const supabase = getSupabaseBrowserClient()

    // Modificado para não usar relacionamentos que não existem
    const { data, error } = await supabase.from("appointments").select("*").eq("id", id).single()

    if (error) {
      console.error(`Erro ao buscar agendamento ${id}:`, error)
      throw error
    }

    // Se o agendamento tiver um agent_id, buscar o professional_profile separadamente
    if (data && data.agent_id) {
      console.log("Buscando perfil profissional para agent_id:", data.agent_id)
      const { data: profile, error: profileError } = await supabase
        .from("professional_profiles")
        .select("*")
        .eq("id", data.agent_id)
        .single()

      console.log("Perfil encontrado:", profile)

      if (!profileError && profile) {
        console.log(`Agendamento ${id} vinculado ao perfil:`, profile)
        return {
          ...data,
          professional_profiles: profile,
        }
      }
    }

    return data
  }

  /**
   * Create a new appointment
   * @param appointment Appointment data
   * @returns Created appointment
   */
  static async createAppointment(appointment: Omit<AppointmentInsert, "user_id">) {
    const supabase = getSupabaseBrowserClient()

    // Get current user
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      throw new Error("Usuário não autenticado")
    }

    const { data, error } = await supabase
      .from("appointments")
      .insert({
        ...appointment,
        user_id: user.id,
        patient_email: appointment.patient_email || null,
      })
      .select()
      .single()

    if (error) {
      console.error("Erro ao criar agendamento:", error)
      throw error
    }

    return data
  }

  /**
   * Update an appointment
   * @param id Appointment ID
   * @param updates Fields to update
   * @returns Updated appointment
   */
  static async updateAppointment(id: string, updates: AppointmentUpdate) {
    const supabase = getSupabaseBrowserClient()

    console.log("AppointmentService.updateAppointment:", { id, updates })

    const { data, error } = await supabase
      .from("appointments")
      .update({
        ...updates,
        updated_at: new Date().toISOString(),
      })
      .eq("id", id)
      .select()
      .single()

    if (error) {
      console.error(`Erro ao atualizar agendamento ${id}:`, error)
      throw error
    }

    console.log("Agendamento atualizado com sucesso:", data)
    return data
  }

  /**
   * Delete an appointment
   * @param id Appointment ID
   * @returns Success status
   */
  static async deleteAppointment(id: string) {
    const supabase = getSupabaseBrowserClient()

    const { error } = await supabase.from("appointments").delete().eq("id", id)

    if (error) {
      console.error(`Erro ao excluir agendamento ${id}:`, error)
      throw error
    }

    return true
  }

  /**
   * Get appointment statistics
   * @param filters Optional filters
   * @returns Statistics object
   */
  static async getAppointmentStats(filters?: {
    startDate?: string
    endDate?: string
    agentId?: string
  }) {
    const supabase = getSupabaseBrowserClient()

    // Get current user
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      throw new Error("Usuário não autenticado")
    }

    let query = supabase
      .from("appointments")
      .select("id, status, appointment_date", { count: "exact" })
      .eq("user_id", user.id)

    // Apply filters
    if (filters?.startDate) {
      query = query.gte("appointment_date", filters.startDate)
    }
    if (filters?.endDate) {
      query = query.lte("appointment_date", filters.endDate)
    }
    if (filters?.agentId) {
      query = query.eq("agent_id", filters.agentId)
    }

    const { data, error, count } = await query

    if (error) {
      console.error("Erro ao buscar estatísticas de agendamentos:", error)
      throw error
    }

    // Calculate statistics
    const total = count || 0
    const scheduled = data?.filter((a) => a.status === "scheduled").length || 0
    const confirmed = data?.filter((a) => a.status === "confirmed").length || 0
    const completed = data?.filter((a) => a.status === "completed").length || 0
    const cancelled = data?.filter((a) => a.status === "cancelled").length || 0
    const noShow = data?.filter((a) => a.status === "no-show").length || 0
    const rescheduled = data?.filter((a) => a.status === "rescheduled").length || 0

    return {
      total,
      scheduled,
      confirmed,
      completed,
      cancelled,
      noShow,
      rescheduled,
      appointments: data || [],
    }
  }

  /**
   * Update appointment status - FIXED VERSION
   * @param id Appointment ID
   * @param status New status
   * @returns Updated appointment
   */
  static async updateAppointmentStatus(id: string, status: string) {
    console.log("AppointmentService.updateAppointmentStatus:", { id, status })

    // Validate status
    const validStatuses = ["scheduled", "confirmed", "completed", "cancelled", "no-show", "rescheduled"]
    if (!validStatuses.includes(status)) {
      throw new Error(`Status inválido: ${status}`)
    }

    try {
      // Use the API endpoint for better error handling and logging
      const response = await fetch("/api/appointments/stats", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          appointmentId: id,
          status: status,
        }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Erro ao atualizar status")
      }

      const result = await response.json()
      console.log("Status atualizado via API:", result)

      return result.appointment
    } catch (error) {
      console.error("Erro na atualização via API, tentando método direto:", error)

      // Fallback to direct method
      return this.updateAppointment(id, { status })
    }
  }

  /**
   * Refresh appointment data - Force reload from database
   * @param id Appointment ID
   * @returns Fresh appointment data
   */
  static async refreshAppointment(id: string) {
    const supabase = getSupabaseBrowserClient()

    console.log("Refreshing appointment data for:", id)

    const { data, error } = await supabase.from("appointments").select("*").eq("id", id).single()

    if (error) {
      console.error(`Erro ao recarregar agendamento ${id}:`, error)
      throw error
    }

    console.log("Fresh appointment data:", data)
    return data
  }
}
