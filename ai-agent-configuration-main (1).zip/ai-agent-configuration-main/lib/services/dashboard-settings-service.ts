import { getSupabaseBrowserClient } from "@/lib/supabase"

export type DashboardWidget = "recent_conversations" | "whatsapp_status"

export type DashboardView = "overview" | "agents" | "whatsapp" | "conversations"

export type DashboardSettings = {
  user_id: string
  visible_widgets: DashboardWidget[]
  default_view: DashboardView
  created_at: string
  updated_at: string
}

export class DashboardSettingsService {
  /**
   * Get dashboard settings for the current user
   * @returns Dashboard settings
   */
  static async getUserDashboardSettings() {
    const supabase = getSupabaseBrowserClient()

    // Get current user
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      throw new Error("Usuário não autenticado")
    }

    try {
      const { data, error } = await supabase.from("dashboard_settings").select("*").eq("user_id", user.id).single()

      if (error) {
        // Se o erro for que a tabela não existe ou registro não encontrado, retornar configurações padrão
        if (error.code === "PGRST116" || error.message.includes("does not exist")) {
          return this.getDefaultSettings(user.id)
        }

        console.error("Erro ao buscar configurações do dashboard:", error)
        throw error
      }

      return data
    } catch (error: any) {
      // Se o erro for que a tabela não existe, retornar configurações padrão
      if (error.message && (error.message.includes("does not exist") || error.message.includes("relation"))) {
        return this.getDefaultSettings(user.id)
      }
      throw error
    }
  }

  // Adicionar um novo método para obter configurações padrão sem tentar salvar no banco
  private static getDefaultSettings(userId: string): DashboardSettings {
    return {
      user_id: userId,
      visible_widgets: ["recent_conversations", "whatsapp_status"] as DashboardWidget[],
      default_view: "overview" as DashboardView,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }
  }

  /**
   * Create default dashboard settings for a new user
   * @returns Created settings
   */
  static async createDefaultSettings() {
    const supabase = getSupabaseBrowserClient()

    // Get current user
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      throw new Error("Usuário não autenticado")
    }

    try {
      // Verificar se a tabela existe tentando fazer uma consulta
      const { error: tableCheckError } = await supabase.from("dashboard_settings").select("user_id").limit(1)

      // Se a tabela não existir, retornar configurações padrão sem salvar
      if (
        tableCheckError &&
        (tableCheckError.message.includes("does not exist") || tableCheckError.message.includes("relation"))
      ) {
        return this.getDefaultSettings(user.id)
      }

      const defaultSettings = {
        user_id: user.id,
        visible_widgets: ["recent_conversations", "whatsapp_status"] as DashboardWidget[],
        default_view: "overview" as DashboardView,
      }

      const { data, error } = await supabase.from("dashboard_settings").insert(defaultSettings).select().single()

      if (error) {
        throw error
      }

      return data
    } catch (error: any) {
      // Se o erro for que a tabela não existe, retornar configurações padrão sem salvar
      if (error.message && (error.message.includes("does not exist") || error.message.includes("relation"))) {
        return this.getDefaultSettings(user.id)
      }

      console.error("Erro ao criar configurações padrão do dashboard:", error)
      throw error
    }
  }

  /**
   * Update dashboard settings
   * @param settings Settings to update
   * @returns Updated settings
   */
  static async updateDashboardSettings(settings: {
    visible_widgets?: DashboardWidget[]
    default_view?: DashboardView
  }) {
    const supabase = getSupabaseBrowserClient()

    // Get current user
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      throw new Error("Usuário não autenticado")
    }

    try {
      // Verificar se a tabela existe tentando fazer uma consulta
      const { error: tableCheckError } = await supabase.from("dashboard_settings").select("user_id").limit(1)

      // Se a tabela não existir, retornar as configurações atualizadas sem salvar
      if (
        tableCheckError &&
        (tableCheckError.message.includes("does not exist") || tableCheckError.message.includes("relation"))
      ) {
        const defaultSettings = this.getDefaultSettings(user.id)
        return {
          ...defaultSettings,
          ...settings,
          updated_at: new Date().toISOString(),
        }
      }

      // Check if settings exist
      const { data: existingSettings, error: getError } = await supabase
        .from("dashboard_settings")
        .select("*")
        .eq("user_id", user.id)
        .single()

      // Se ocorrer um erro que não seja "registro não encontrado", lançar o erro
      if (getError && getError.code !== "PGRST116") {
        throw getError
      }

      // Se as configurações não existirem, criar novas
      if (!existingSettings) {
        const newSettings = {
          user_id: user.id,
          visible_widgets: settings.visible_widgets || ["recent_conversations", "whatsapp_status"],
          default_view: settings.default_view || "overview",
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        }

        const { data, error } = await supabase.from("dashboard_settings").insert(newSettings).select().single()

        if (error) {
          throw error
        }

        return data
      }

      // Atualizar configurações existentes
      const { data, error } = await supabase
        .from("dashboard_settings")
        .update({
          ...settings,
          updated_at: new Date().toISOString(),
        })
        .eq("user_id", user.id)
        .select()
        .single()

      if (error) {
        throw error
      }

      return data
    } catch (error: any) {
      // Se o erro for que a tabela não existe, retornar as configurações atualizadas sem salvar
      if (error.message && (error.message.includes("does not exist") || error.message.includes("relation"))) {
        const defaultSettings = this.getDefaultSettings(user.id)
        return {
          ...defaultSettings,
          ...settings,
          updated_at: new Date().toISOString(),
        }
      }

      console.error("Erro ao atualizar configurações do dashboard:", error)
      throw error
    }
  }
}
