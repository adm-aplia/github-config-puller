import { getSupabaseBrowserClient } from "@/lib/supabase"
import type { Database } from "@/types/supabase"

// Atualizando para usar profiles em vez de agents
export type Agent = Database["public"]["Tables"]["profiles"]["Row"]
export type AgentInsert = Database["public"]["Tables"]["profiles"]["Insert"]
export type AgentUpdate = Database["public"]["Tables"]["profiles"]["Update"]

export class AgentService {
  /**
   * Get all agents for the current user
   * @param filters Optional filters
   * @returns Array of agents
   */
  static async getUserAgents(filters?: { specialty?: string }) {
    const supabase = getSupabaseBrowserClient()

    let query = supabase.from("profiles").select("*").order("created_at", { ascending: false })

    if (filters?.specialty) {
      query = query.eq("specialty", filters.specialty)
    }

    const { data, error } = await query

    if (error) {
      console.error("Erro ao buscar perfis:", error)
      throw error
    }

    return data
  }

  /**
   * Get a specific agent
   * @param id Agent ID
   * @returns Agent data
   */
  static async getAgent(id: string) {
    const supabase = getSupabaseBrowserClient()

    const { data: agent, error } = await supabase.from("profiles").select("*").eq("id", id).single()

    if (error) {
      console.error(`Erro ao buscar perfil ${id}:`, error)
      throw error
    }

    return agent
  }

  /**
   * Create a new agent with settings and instance associations
   * @param agentData Agent data and settings
   * @returns Created agent
   */
  static async createAgent(
    agentData: Omit<AgentInsert, "user_id"> & {
      appointment_response?: string
      emergency_response?: string
      followup_response?: string
      medical_advice_policy?: string
      personal_info_policy?: string
      escalation_criteria?: string
      instance_ids?: string[]
    },
  ) {
    const supabase = getSupabaseBrowserClient()

    // Get current user
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      throw new Error("Usuário não autenticado")
    }

    // Extract instance IDs and settings fields
    const {
      instance_ids,
      appointment_response,
      emergency_response,
      followup_response,
      medical_advice_policy,
      personal_info_policy,
      escalation_criteria,
      ...mainAgentData
    } = agentData

    // Prepare consolidated agent data
    const consolidatedAgentData = {
      ...mainAgentData,
      user_id: user.id,
      // Include settings fields directly in the agent table
      appointment_response: appointment_response || null,
      emergency_response: emergency_response || null,
      followup_response: followup_response || null,
      medical_advice_policy: medical_advice_policy || null,
      personal_info_policy: personal_info_policy || null,
      escalation_criteria: escalation_criteria || null,
      // Include instance IDs as an array
      instance_ids: instance_ids || [],
    }

    // Create the agent with all data
    const { data, error } = await supabase.from("profiles").insert(consolidatedAgentData).select().single()

    if (error) {
      console.error("Erro ao criar perfil:", error)
      throw error
    }

    return data
  }

  /**
   * Update an existing agent
   * @param id Agent ID
   * @param agent Updated agent data
   * @returns Updated agent
   */
  static async updateAgent(
    id: string,
    agent: AgentUpdate & {
      appointment_response?: string | null
      emergency_response?: string | null
      followup_response?: string | null
      medical_advice_policy?: string | null
      personal_info_policy?: string | null
      escalation_criteria?: string | null
      instance_ids?: string[]
    },
  ) {
    const supabase = getSupabaseBrowserClient()

    const { data, error } = await supabase
      .from("profiles")
      .update({
        ...agent,
        updated_at: new Date().toISOString(),
      })
      .eq("id", id)
      .select()
      .single()

    if (error) {
      console.error(`Erro ao atualizar perfil ${id}:`, error)
      throw error
    }

    return data
  }

  /**
   * Delete an agent
   * @param id Agent ID
   * @returns Success status
   */
  static async deleteAgent(id: string) {
    const supabase = getSupabaseBrowserClient()

    // Delete agent
    const { error } = await supabase.from("profiles").delete().eq("id", id)

    if (error) {
      console.error(`Erro ao excluir perfil ${id}:`, error)
      throw error
    }

    return true
  }

  /**
   * Associate an agent with WhatsApp instances
   * @param agentId Agent ID
   * @param instanceIds Array of instance IDs
   * @returns Updated agent
   */
  static async associateAgentWithInstances(agentId: string, instanceIds: string[]) {
    const supabase = getSupabaseBrowserClient()

    console.log(`Associando perfil ${agentId} com instâncias:`, instanceIds)

    // Check if there are instances to associate
    if (!instanceIds || instanceIds.length === 0) {
      console.log("Nenhuma instância para associar")
      return null
    }

    try {
      // Get current agent
      const { data: agent } = await supabase.from("profiles").select("*").eq("id", agentId).single()

      if (!agent) {
        throw new Error(`Perfil com ID ${agentId} não encontrado`)
      }

      // Update agent with new instance IDs
      const { data, error } = await supabase
        .from("profiles")
        .update({
          instance_ids: instanceIds,
          updated_at: new Date().toISOString(),
        })
        .eq("id", agentId)
        .select()
        .single()

      if (error) {
        throw error
      }

      return data
    } catch (error) {
      console.error(`Erro ao associar perfil ${agentId} com instâncias:`, error)
      throw error
    }
  }

  /**
   * Get instances associated with an agent
   * @param agentId Agent ID
   * @returns Associated instances
   */
  static async getAgentInstances(agentId: string) {
    const supabase = getSupabaseBrowserClient()

    // Get agent with instance_ids
    const { data: agent, error } = await supabase.from("profiles").select("instance_ids").eq("id", agentId).single()

    if (error) {
      console.error(`Erro ao obter instâncias do perfil ${agentId}:`, error)
      throw error
    }

    if (!agent.instance_ids || agent.instance_ids.length === 0) {
      return []
    }

    // Get instances by IDs
    const { data: instances, error: instancesError } = await supabase
      .from("whatsapp_instances")
      .select("id, instance_name, profile_name, status")
      .in("id", agent.instance_ids)

    if (instancesError) {
      console.error(`Erro ao obter detalhes das instâncias do perfil ${agentId}:`, instancesError)
      throw instancesError
    }

    return instances.map((instance) => ({
      instance_id: instance.id,
      whatsapp_instances: instance,
    }))
  }

  /**
   * Get agent statistics
   * @returns Statistics object
   */
  static async getAgentStats() {
    const supabase = getSupabaseBrowserClient()

    // Get all agents
    const { data: agents, error } = await supabase.from("profiles").select("*")

    if (error) {
      console.error("Erro ao buscar estatísticas de perfis:", error)
      throw error
    }

    // Get conversation counts for each agent
    const agentStats = []

    for (const agent of agents) {
      const { count } = await supabase.from("conversations").select("*", { count: "exact" }).eq("agent_id", agent.id)

      agentStats.push({
        ...agent,
        conversationCount: count || 0,
      })
    }

    return {
      total: agents.length,
      agents: agentStats,
    }
  }

  /**
   * Clone an existing agent
   * @param id Agent ID to clone
   * @param newName Name for the cloned agent
   * @returns Cloned agent
   */
  static async cloneAgent(id: string, newName: string) {
    // Get original agent
    const originalAgent = await this.getAgent(id)

    if (!originalAgent) {
      throw new Error(`Perfil com ID ${id} não encontrado`)
    }

    // Create new agent with same data but new name
    const { id: originalId, created_at, updated_at, ...agentData } = originalAgent

    const newAgent = await this.createAgent({
      ...agentData,
      name: newName,
      instance_ids: originalAgent.instance_ids || [],
    })

    return newAgent
  }
}
