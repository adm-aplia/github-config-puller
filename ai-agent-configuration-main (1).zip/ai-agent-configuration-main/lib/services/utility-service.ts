import { getSupabaseBrowserClient } from "@/lib/supabase"

export class UtilityService {
  /**
   * Export data to JSON
   * @param type Data type to export
   * @param id Optional ID for specific item
   * @returns JSON data
   */
  static async exportData(type: "agents" | "conversations" | "whatsapp" | "all", id?: string) {
    const supabase = getSupabaseBrowserClient()

    // Get current user
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      throw new Error("Usuário não autenticado")
    }

    const result: Record<string, any> = {
      exportDate: new Date().toISOString(),
      exportType: type,
      userId: user.id,
    }

    // Export agents
    if (type === "agents" || type === "all") {
      let agentQuery = supabase.from("agents").select("*").eq("user_id", user.id)

      if (id && type === "agents") {
        agentQuery = agentQuery.eq("id", id)
      }

      const { data: agents, error: agentsError } = await agentQuery

      if (agentsError) {
        console.error("Erro ao exportar agentes:", agentsError)
        throw agentsError
      }

      result.agents = agents || []

      // Get agent settings
      if (agents && agents.length > 0) {
        const { data: settings, error: settingsError } = await supabase
          .from("agent_settings")
          .select("*")
          .in(
            "agent_id",
            agents.map((a) => a.id),
          )

        if (settingsError) {
          console.error("Erro ao exportar configurações de agentes:", settingsError)
        } else {
          result.agentSettings = settings || []
        }
      }
    }

    // Export WhatsApp instances
    if (type === "whatsapp" || type === "all") {
      let instanceQuery = supabase.from("whatsapp_instances").select("*").eq("user_id", user.id)

      if (id && type === "whatsapp") {
        instanceQuery = instanceQuery.eq("id", id)
      }

      const { data: instances, error: instancesError } = await instanceQuery

      if (instancesError) {
        console.error("Erro ao exportar instâncias WhatsApp:", instancesError)
        throw instancesError
      }

      result.whatsappInstances = instances || []
    }

    // Export conversations
    if (type === "conversations" || type === "all") {
      let conversationQuery = supabase.from("conversations").select("*").eq("user_id", user.id)

      if (id && type === "conversations") {
        conversationQuery = conversationQuery.eq("id", id)
      }

      const { data: conversations, error: conversationsError } = await conversationQuery

      if (conversationsError) {
        console.error("Erro ao exportar conversas:", conversationsError)
        throw conversationsError
      }

      result.conversations = conversations || []

      // Get messages for these conversations
      if (conversations && conversations.length > 0) {
        const { data: messages, error: messagesError } = await supabase
          .from("messages")
          .select("*")
          .in(
            "conversation_id",
            conversations.map((c) => c.id),
          )

        if (messagesError) {
          console.error("Erro ao exportar mensagens:", messagesError)
        } else {
          result.messages = messages || []
        }
      }
    }

    // Export agent-instance associations if exporting both or all
    if ((type === "agents" && type === "whatsapp") || type === "all") {
      const { data: agentInstances, error: agentInstancesError } = await supabase.from("agent_instances").select("*")

      if (agentInstancesError) {
        console.error("Erro ao exportar associações agente-instância:", agentInstancesError)
      } else {
        result.agentInstances = agentInstances || []
      }
    }

    return result
  }

  /**
   * Import data from JSON
   * @param data JSON data to import
   * @returns Import results
   */
  static async importData(data: Record<string, any>) {
    const supabase = getSupabaseBrowserClient()

    // Get current user
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      throw new Error("Usuário não autenticado")
    }

    const results: Record<string, any> = {
      importDate: new Date().toISOString(),
      success: true,
      imported: {},
    }

    try {
      // Import agents
      if (data.agents && Array.isArray(data.agents)) {
        const agentResults = []

        for (const agent of data.agents) {
          // Remove id and user_id to create new ones
          const { id, user_id, created_at, updated_at, ...agentData } = agent

          // Create new agent
          const { data: newAgent, error } = await supabase
            .from("agents")
            .insert({
              ...agentData,
              user_id: user.id,
            })
            .select()
            .single()

          if (error) {
            console.error("Erro ao importar agente:", error)
            agentResults.push({ original: id, error: error.message })
          } else {
            agentResults.push({ original: id, new: newAgent.id, success: true })

            // Import agent settings if available
            if (data.agentSettings && Array.isArray(data.agentSettings)) {
              const settings = data.agentSettings.find((s) => s.agent_id === id)

              if (settings) {
                const { id: settingsId, agent_id, created_at, updated_at, ...settingsData } = settings

                await supabase.from("agent_settings").insert({
                  ...settingsData,
                  agent_id: newAgent.id,
                })
              }
            }
          }
        }

        results.imported.agents = agentResults
      }

      // Import WhatsApp instances
      if (data.whatsappInstances && Array.isArray(data.whatsappInstances)) {
        const instanceResults = []

        for (const instance of data.whatsappInstances) {
          // Remove id and user_id to create new ones
          const { id, user_id, created_at, updated_at, ...instanceData } = instance

          // Create new instance
          const { data: newInstance, error } = await supabase
            .from("whatsapp_instances")
            .insert({
              ...instanceData,
              user_id: user.id,
            })
            .select()
            .single()

          if (error) {
            console.error("Erro ao importar instância WhatsApp:", error)
            instanceResults.push({ original: id, error: error.message })
          } else {
            instanceResults.push({ original: id, new: newInstance.id, success: true })
          }
        }

        results.imported.whatsappInstances = instanceResults
      }

      // Import agent-instance associations
      if (
        data.agentInstances &&
        Array.isArray(data.agentInstances) &&
        results.imported.agents &&
        results.imported.whatsappInstances
      ) {
        const associationResults = []

        for (const association of data.agentInstances) {
          // Find the new IDs for the agent and instance
          const agentMapping = results.imported.agents.find((a) => a.original === association.agent_id)
          const instanceMapping = results.imported.whatsappInstances.find((i) => i.original === association.instance_id)

          if (agentMapping?.new && instanceMapping?.new) {
            // Create new association
            const { data: newAssociation, error } = await supabase
              .from("agent_instances")
              .insert({
                agent_id: agentMapping.new,
                instance_id: instanceMapping.new,
              })
              .select()
              .single()

            if (error) {
              console.error("Erro ao importar associação agente-instância:", error)
              associationResults.push({ error: error.message })
            } else {
              associationResults.push({ success: true, id: newAssociation.id })
            }
          }
        }

        results.imported.agentInstances = associationResults
      }
    } catch (error) {
      console.error("Erro ao importar dados:", error)
      results.success = false
      results.error = error.message
    }

    return results
  }

  /**
   * Backup all user data
   * @returns Backup data
   */
  static async backupAllData() {
    return this.exportData("all")
  }

  /**
   * Generate a system report
   * @returns System report
   */
  static async generateSystemReport() {
    const supabase = getSupabaseBrowserClient()

    // Get current user
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      throw new Error("Usuário não autenticado")
    }

    // Get counts for all tables
    const { count: agentCount } = await supabase.from("agents").select("*", { count: "exact" }).eq("user_id", user.id)

    const { count: instanceCount } = await supabase
      .from("whatsapp_instances")
      .select("*", { count: "exact" })
      .eq("user_id", user.id)

    const { count: conversationCount } = await supabase
      .from("conversations")
      .select("*", { count: "exact" })
      .eq("user_id", user.id)

    const { data: conversations } = await supabase.from("conversations").select("id").eq("user_id", user.id)

    let messageCount = 0
    if (conversations && conversations.length > 0) {
      const { count } = await supabase
        .from("messages")
        .select("*", { count: "exact" })
        .in(
          "conversation_id",
          conversations.map((c) => c.id),
        )

      messageCount = count || 0
    }

    // Get system settings
    const { data: settings } = await supabase.from("user_settings").select("*").eq("user_id", user.id).single()

    return {
      generatedAt: new Date().toISOString(),
      user: {
        id: user.id,
        email: user.email,
        createdAt: user.created_at,
      },
      counts: {
        agents: agentCount || 0,
        whatsappInstances: instanceCount || 0,
        conversations: conversationCount || 0,
        messages: messageCount,
      },
      settings: settings || {},
      systemInfo: {
        version: "1.0.0",
        environment: process.env.NODE_ENV || "development",
      },
    }
  }
}
