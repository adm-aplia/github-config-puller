import { createClient } from "@supabase/supabase-js"
import { AsaasService } from "./asaas-service"

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

interface BillingData {
  nome: string
  email: string
  telefone: string
  documento: string
  plano: string
  creditCard: {
    holderName: string
    number: string
    expiryMonth: string
    expiryYear: string
    ccv: string
  }
  creditCardHolderInfo: {
    postalCode: string
    addressNumber: string
    addressComplement?: string
    mobilePhone?: string
  }
  user_id?: string
  endereco?: string
  cidade?: string
  estado?: string
  cep?: string
  observacoes?: string
}

interface BillingResult {
  success: boolean
  error?: string
  subscription?: any
  cliente?: any
}

export class BillingService {
  static async processBilling(data: BillingData, remoteIp: string): Promise<BillingResult> {
    try {
      // 1. Resolve user_id
      const finalUserId = data.user_id || (await this.findUserIdByEmail(data.email))
      if (!finalUserId) throw new Error("Usuário não encontrado. Faça login antes de comprar.")

      // 2. Cliente Supabase
      let cliente = await this.findCliente(data.email, finalUserId)
      if (!cliente) {
        cliente = await this.createCliente({ ...data, user_id: finalUserId })
      } else {
        await this.updateClienteData(cliente.id, data)
      }

      // 3. Customer Asaas
      let customerId = cliente.customer_id
      if (!customerId) {
        const asaasCustomer = await AsaasService.createCustomer({
          name: data.nome,
          cpfCnpj: data.documento.replace(/\D/g, ""),
          email: data.email,
          phone: data.telefone.replace(/\D/g, ""),
        })
        customerId = asaasCustomer.id
        await this.updateClienteCustomerId(cliente.id, customerId)
      }

      // 4. Create Subscription
      const planConfig = this.getPlanConfig(data.plano)
      const cycle = "MONTHLY"
      const nextDue = new Date()
      nextDue.setDate(nextDue.getDate() + 7) // primeira cobrança em 7 dias

      // estrutura do request
      const subscriptionRequest = {
        customer: customerId,
        billingType: "CREDIT_CARD", // ou "BOLETO", "PIX"
        value: planConfig.valor,
        cycle,
        description: planConfig.descricao,
        nextDueDate: nextDue.toISOString().split("T")[0],
        creditCard: {
          holderName: data.nome,
          number: data.creditCard.number,
          expiryMonth: data.creditCard.expiryMonth,
          expiryYear: data.creditCard.expiryYear,
          ccv: data.creditCard.ccv,
        },
        creditCardHolderInfo: {
          name: data.nome,
          email: data.email,
          cpfCnpj: data.documento.replace(/\D/g, ""),
          postalCode: data.cep?.replace(/\D/g, "") || "",
          addressNumber: data.endereco || "",
          phone: data.telefone.replace(/\D/g, ""),
        },
        remoteIp, // capture no frontend ou no middleware
      }

      const subscription = await AsaasService.createSubscriptionDirect(subscriptionRequest)
      console.log("✅ Assinatura recorrente criada:", subscription.id)

      // 5. Salvando no Supabase - estrutura atualizada
      await supabase.from("assinaturas").insert({
        id_cliente_supabase: cliente.id, // usar nome correto da coluna
        subscription_id: subscription.id,
        customer_id_asaas: customerId,
        status: subscription.status,
        next_due_date: subscription.nextDueDate,
        plano: data.plano,
        valor: planConfig.valor,
        descricao: planConfig.descricao,
        data_contratacao: new Date().toISOString(),
        created_at: new Date().toISOString(),
      })

      console.log("✅ Assinatura salva no Supabase")

      // 6. Ativar cliente (será confirmado via webhook)
      await this.activateClient(cliente.id)

      return { success: true, subscription, cliente }
    } catch (error: any) {
      console.error("❌ Erro no BillingService:", error)
      return {
        success: false,
        error: error.message || "Erro interno no serviço de cobrança",
      }
    }
  }

  // -- Métodos auxiliares mantidos --

  private static async findUserIdByEmail(email: string): Promise<string | null> {
    const { data, error } = await supabase
      .from("auth.users")
      .select("id")
      .eq("email", email.toLowerCase().trim())
      .single()
    return data?.id || null
  }

  private static async findCliente(email: string, userId: string) {
    const { data: cliente } = await supabase.from("clientes").select("*").eq("user_id", userId).single()
    if (cliente) return cliente

    const { data: byEmail } = await supabase
      .from("clientes")
      .select("*")
      .eq("email", email.toLowerCase().trim())
      .single()
    return byEmail || null
  }

  private static async createCliente(data: BillingData & { user_id: string }) {
    const { data: cliente, error } = await supabase
      .from("clientes")
      .insert({
        nome: data.nome,
        email: data.email.toLowerCase().trim(),
        telefone: data.telefone,
        cpf_cnpj: data.documento,
        plano: data.plano,
        user_id: data.user_id,
        endereco: data.endereco || null,
        cidade: data.cidade || null,
        estado: data.estado || null,
        cep: data.cep || null,
        observacoes: data.observacoes || null,
        status: "aguardando_pagamento",
        is_active: false,
        data_contratacao: new Date().toISOString(),
      })
      .select()
      .single()

    if (error) throw new Error(`Erro ao criar cliente: ${error.message}`)
    return cliente
  }

  private static async updateClienteData(id: string, data: BillingData) {
    const { error } = await supabase
      .from("clientes")
      .update({
        nome: data.nome,
        telefone: data.telefone,
        plano: data.plano,
        endereco: data.endereco || null,
        cidade: data.cidade || null,
        estado: data.estado || null,
        cep: data.cep || null,
        observacoes: data.observacoes || null,
        updated_at: new Date().toISOString(),
      })
      .eq("id", id)

    if (error) throw new Error(`Erro ao atualizar cliente: ${error.message}`)
  }

  private static async updateClienteCustomerId(clienteId: string, customerId: string) {
    const { error } = await supabase
      .from("clientes")
      .update({
        customer_id: customerId,
        updated_at: new Date().toISOString(),
      })
      .eq("id", clienteId)

    if (error) throw new Error(`Erro ao atualizar customer_id: ${error.message}`)
  }

  private static getPlanConfig(plano: string) {
    const configs: Record<string, { valor: number; descricao: string }> = {
      Básico: {
        valor: 199,
        descricao: "Plano Básico Aplia - 1 número WhatsApp, até 300 agendamentos, 1 assistente, suporte por e-mail.",
      },
      Profissional: {
        valor: 399,
        descricao:
          "Plano Profissional Aplia - 3 números WhatsApp, até 1000 agendamentos, 3 assistentes, suporte prioritário, relatórios avançados.",
      },
      Empresarial: {
        valor: 899,
        descricao:
          "Plano Empresarial Aplia - +10 números WhatsApp, agendamentos ilimitados, assistentes ilimitados, suporte 24/7, integração com sistemas hospitalares, personalização avançada.",
      },
    }
    return configs[plano] || configs.Básico
  }

  /**
   * Ativar cliente após pagamento confirmado
   */
  static async activateClient(clienteId: string) {
    const { error } = await supabase
      .from("clientes")
      .update({
        status: "ativo",
        is_active: true,
        updated_at: new Date().toISOString(),
      })
      .eq("id", clienteId)

    if (error) {
      throw new Error(`Erro ao ativar cliente: ${error.message}`)
    }
  }

  /**
   * Cancelar assinatura
   */
  static async cancelSubscription(subscriptionId: string) {
    try {
      // Cancelar no Asaas
      await AsaasService.cancelSubscription(subscriptionId)

      // Atualizar no Supabase
      const { error } = await supabase
        .from("assinaturas")
        .update({
          status: "CANCELED",
          updated_at: new Date().toISOString(),
        })
        .eq("subscription_id", subscriptionId)

      if (error) throw error

      console.log(`✅ Assinatura ${subscriptionId} cancelada com sucesso`)
    } catch (error: any) {
      console.error("❌ Erro ao cancelar assinatura:", error)
      throw new Error(`Erro ao cancelar assinatura: ${error.message}`)
    }
  }
}
