import { getSupabaseBrowserClient } from "@/lib/supabase"

export class StatsService {
  /**
   * Get dashboard statistics
   * @param timeframe Optional timeframe filter (day, week, month, year)
   * @param compareWithPrevious Whether to include previous period data for comparison
   * @returns Dashboard statistics
   */
  static async getDashboardStats(timeframe?: "day" | "week" | "month" | "year", compareWithPrevious = false) {
    try {
      const supabase = getSupabaseBrowserClient()

      // Get current user
      const {
        data: { user },
        error: userError,
      } = await supabase.auth.getUser()

      // Se não houver usuário autenticado, retornar dados vazios em vez de lançar erro
      if (userError || !user) {
        console.warn("Usuário não autenticado ou erro ao obter usuário:", userError?.message)
        return {
          totalConversations: 0,
          activeConversations: 0,
          profileCount: 0,
          instanceCount: 0,
          connectedInstanceCount: 0,
          messageCount: 0,
          appointmentCount: 0,
          chartData: [],
          isAuthenticated: false,
        }
      }

      // Calculate date range based on timeframe
      const now = new Date()
      let startDate: Date
      let previousStartDate: Date
      let previousEndDate: Date

      switch (timeframe) {
        case "day":
          startDate = new Date(now)
          startDate.setHours(0, 0, 0, 0)

          previousStartDate = new Date(startDate)
          previousStartDate.setDate(previousStartDate.getDate() - 1)
          previousEndDate = new Date(startDate)
          previousEndDate.setMilliseconds(-1)
          break
        case "week":
          startDate = new Date(now)
          startDate.setDate(now.getDate() - 7)

          previousStartDate = new Date(startDate)
          previousStartDate.setDate(previousStartDate.getDate() - 7)
          previousEndDate = new Date(startDate)
          previousEndDate.setMilliseconds(-1)
          break
        case "month":
          startDate = new Date(now)
          startDate.setMonth(now.getMonth() - 1)

          previousStartDate = new Date(startDate)
          previousStartDate.setMonth(previousStartDate.getMonth() - 1)
          previousEndDate = new Date(startDate)
          previousEndDate.setMilliseconds(-1)
          break
        case "year":
          startDate = new Date(now)
          startDate.setFullYear(now.getFullYear() - 1)

          previousStartDate = new Date(startDate)
          previousStartDate.setFullYear(previousStartDate.getFullYear() - 1)
          previousEndDate = new Date(startDate)
          previousEndDate.setMilliseconds(-1)
          break
        default:
          // Default to 30 days
          startDate = new Date(now)
          startDate.setDate(now.getDate() - 30)

          previousStartDate = new Date(startDate)
          previousStartDate.setDate(previousStartDate.getDate() - 30)
          previousEndDate = new Date(startDate)
          previousEndDate.setMilliseconds(-1)
      }

      const startDateStr = startDate.toISOString()
      const previousStartDateStr = previousStartDate.toISOString()
      const previousEndDateStr = previousEndDate.toISOString()

      // Get current period conversation stats
      const { data: conversations, count: totalConversations } = await supabase
        .from("conversations")
        .select("*", { count: "exact" })
        .eq("user_id", user.id)
        .gte("created_at", startDateStr)

      // Get active conversations
      const { count: activeConversations } = await supabase
        .from("conversations")
        .select("*", { count: "exact" })
        .eq("user_id", user.id)
        .eq("status", "active")

      // Get professional profile count (antes era agent count)
      const { count: profileCount } = await supabase
        .from("professional_profiles")
        .select("*", { count: "exact" })
        .eq("user_id", user.id)

      // Get WhatsApp instance count
      const { count: instanceCount } = await supabase
        .from("whatsapp_instances")
        .select("*", { count: "exact" })
        .eq("user_id", user.id)

      // Get connected WhatsApp instances
      const { count: connectedInstanceCount } = await supabase
        .from("whatsapp_instances")
        .select("*", { count: "exact" })
        .eq("user_id", user.id)
        .eq("status", "connected")

      // Get message count
      let messageCount = 0
      if (conversations && conversations.length > 0) {
        const { count: msgCount } = await supabase
          .from("messages")
          .select("id", { count: "exact" })
          .in(
            "conversation_id",
            conversations.map((c) => c.id),
          )

        messageCount = msgCount || 0
      }

      // Get appointment count from appointments table
      const { count: appointmentCount } = await supabase
        .from("appointments")
        .select("*", { count: "exact" })
        .eq("user_id", user.id)
        .gte("created_at", startDateStr)

      // Get previous period data for comparison if requested
      let previousPeriodData = null
      if (compareWithPrevious) {
        // Get previous period conversation stats
        const { count: prevTotalConversations } = await supabase
          .from("conversations")
          .select("*", { count: "exact" })
          .eq("user_id", user.id)
          .gte("created_at", previousStartDateStr)
          .lte("created_at", previousEndDateStr)

        // Get previous period appointment count
        const { count: prevAppointmentCount } = await supabase
          .from("appointments")
          .select("*", { count: "exact" })
          .eq("user_id", user.id)
          .gte("created_at", previousStartDateStr)
          .lte("created_at", previousEndDateStr)

        // Get previous period message count
        let prevMessageCount = 0
        const { data: prevConversations } = await supabase
          .from("conversations")
          .select("id")
          .eq("user_id", user.id)
          .gte("created_at", previousStartDateStr)
          .lte("created_at", previousEndDateStr)

        if (prevConversations && prevConversations.length > 0) {
          const { count: prevMsgCount } = await supabase
            .from("messages")
            .select("id", { count: "exact" })
            .in(
              "conversation_id",
              prevConversations.map((c) => c.id),
            )

          prevMessageCount = prevMsgCount || 0
        }

        previousPeriodData = {
          totalConversations: prevTotalConversations || 0,
          messageCount: prevMessageCount,
          appointmentCount: prevAppointmentCount || 0,
        }
      }

      // Group conversations by date for chart data
      const conversationsByDate: Record<string, number> = {}

      // Inicializar com zeros para todos os dias no período
      const days = Math.ceil((now.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24))
      for (let i = 0; i < days; i++) {
        const date = new Date(startDate)
        date.setDate(date.getDate() + i)
        const dateStr = date.toISOString().split("T")[0]
        conversationsByDate[dateStr] = 0
      }

      // Preencher com dados reais
      conversations?.forEach((conversation) => {
        const date = new Date(conversation.created_at).toISOString().split("T")[0]
        conversationsByDate[date] = (conversationsByDate[date] || 0) + 1
      })

      // Convert to array format for charts
      const chartData = Object.entries(conversationsByDate).map(([date, count]) => {
        // Formatar a data para exibição
        const formattedDate = new Date(date).toLocaleDateString("pt-BR", {
          day: "2-digit",
          month: "2-digit",
        })

        return {
          date: formattedDate,
          conversations: count,
        }
      })

      // Sort chart data by date
      chartData.sort((a, b) => {
        const dateA = new Date(a.date.split("/").reverse().join("-"))
        const dateB = new Date(b.date.split("/").reverse().join("-"))
        return dateA.getTime() - dateB.getTime()
      })

      const result = {
        totalConversations: totalConversations || 0,
        activeConversations: activeConversations || 0,
        profileCount: profileCount || 0,
        instanceCount: instanceCount || 0,
        connectedInstanceCount: connectedInstanceCount || 0,
        messageCount: messageCount || 0,
        appointmentCount: appointmentCount || 0,
        chartData,
        isAuthenticated: true,
      }

      if (compareWithPrevious) {
        return {
          ...result,
          previousPeriod: previousPeriodData,
        }
      }

      return result
    } catch (error) {
      console.error("Erro ao carregar estatísticas:", error)
      // Retornar dados vazios em caso de erro
      return {
        totalConversations: 0,
        activeConversations: 0,
        profileCount: 0,
        instanceCount: 0,
        connectedInstanceCount: 0,
        messageCount: 0,
        appointmentCount: 0,
        chartData: [],
        isAuthenticated: false,
        error: error instanceof Error ? error.message : "Erro desconhecido",
      }
    }
  }

  // Outros métodos existentes...
}
