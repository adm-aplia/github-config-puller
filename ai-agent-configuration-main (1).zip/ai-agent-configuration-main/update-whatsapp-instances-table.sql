-- Adicionar colunas para armazenar foto do perfil e número de telefone
ALTER TABLE whatsapp_instances
ADD COLUMN IF NOT EXISTS profile_picture_url TEXT,
ADD COLUMN IF NOT EXISTS phone_number TEXT;

-- Criar índice para melhorar performance de busca por número
CREATE INDEX IF NOT EXISTS idx_whatsapp_instances_phone_number 
ON whatsapp_instances(phone_number);
