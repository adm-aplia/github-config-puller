-- Testar se conseguimos buscar diretamente as credenciais Google
-- para o user_id específico

-- TESTE 1: Busca direta sem RLS
SET role postgres;
SELECT 
  'DIRECT QUERY WITHOUT RLS' as test_type,
  id,
  user_id,
  email,
  name,
  created_at
FROM google_credentials 
WHERE user_id = 'ab30e7c4-40e8-4a4a-9ef7-cff0bbf00122';

-- TESTE 2: Verificar se RLS está habilitado
SELECT 
  'RLS STATUS' as test_type,
  schemaname,
  tablename,
  rowsecurity as rls_enabled,
  forcerowsecurity as force_rls
FROM pg_tables t
JOIN pg_class c ON c.relname = t.tablename
WHERE tablename = 'google_credentials';

-- TESTE 3: Listar políticas RLS da tabela
SELECT 
  'RLS POLICIES' as test_type,
  schemaname,
  tablename,
  policyname,
  permissive,
  roles,
  cmd,
  qual,
  with_check
FROM pg_policies 
WHERE tablename = 'google_credentials';

-- TESTE 4: Simular query como usuário autenticado
-- (isso pode falhar se não tivermos o contexto de auth correto)
SELECT 
  'AUTHENTICATED USER QUERY' as test_type,
  id,
  user_id,
  email,
  name,
  created_at
FROM google_credentials 
WHERE user_id = 'ab30e7c4-40e8-4a4a-9ef7-cff0bbf00122';

-- TESTE 5: Verificar se a tabela professional_profiles também tem dados
SELECT 
  'PROFESSIONAL PROFILES CHECK' as test_type,
  id,
  user_id,
  "fullName",
  specialty,
  created_at
FROM professional_profiles 
WHERE user_id = 'ab30e7c4-40e8-4a4a-9ef7-cff0bbf00122';
