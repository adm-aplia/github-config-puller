-- Debug script para investigar problemas de atualização de status de agendamentos
-- Removido pg_log que não existe no Supabase

-- 1. Verificar estrutura da tabela appointments
SELECT 
    column_name,
    data_type,
    is_nullable,
    column_default
FROM information_schema.columns 
WHERE table_name = 'appointments' 
    AND table_schema = 'public'
ORDER BY ordinal_position;

-- 2. Verificar constraint de status
SELECT 
    conname as constraint_name,
    pg_get_constraintdef(oid) as constraint_definition
FROM pg_constraint 
WHERE conrelid = 'public.appointments'::regclass
    AND contype = 'c';

-- 3. Verificar todos os status atuais
SELECT 
    status,
    COUNT(*) as count,
    MIN(created_at) as first_created,
    MAX(updated_at) as last_updated
FROM appointments 
GROUP BY status 
ORDER BY count DESC;

-- 4. Verificar agendamentos recentes e suas atualizações
SELECT 
    id,
    patient_name,
    status,
    created_at,
    updated_at,
    (updated_at - created_at) as time_since_creation
FROM appointments 
ORDER BY updated_at DESC 
LIMIT 10;

-- 5. Verificar se há triggers na tabela
SELECT 
    trigger_name,
    event_manipulation,
    action_timing,
    action_statement
FROM information_schema.triggers 
WHERE event_object_table = 'appointments';

-- 6. Verificar políticas RLS
SELECT 
    schemaname,
    tablename,
    policyname,
    permissive,
    roles,
    cmd,
    qual,
    with_check
FROM pg_policies 
WHERE tablename = 'appointments';

-- 7. Verificar se RLS está habilitado
SELECT 
    schemaname,
    tablename,
    rowsecurity,
    forcerowsecurity
FROM pg_tables 
WHERE tablename = 'appointments';

-- 8. Testar inserção de status válidos
DO $$
DECLARE
    test_statuses text[] := ARRAY['scheduled', 'confirmed', 'completed', 'cancelled', 'no-show', 'rescheduled'];
    status_val text;
BEGIN
    FOREACH status_val IN ARRAY test_statuses
    LOOP
        BEGIN
            -- Tentar inserir um registro de teste
            INSERT INTO appointments (
                user_id,
                patient_name,
                patient_phone,
                appointment_date,
                status,
                notes
            ) VALUES (
                '00000000-0000-0000-0000-000000000000', -- UUID de teste
                'Teste Status ' || status_val,
                '+5511999999999',
                NOW() + INTERVAL '1 day',
                status_val,
                'Teste de validação de status'
            );
            
            RAISE NOTICE 'Status % - VÁLIDO', status_val;
            
            -- Remover o registro de teste
            DELETE FROM appointments 
            WHERE patient_name = 'Teste Status ' || status_val 
                AND user_id = '00000000-0000-0000-0000-000000000000';
                
        EXCEPTION WHEN OTHERS THEN
            RAISE NOTICE 'Status % - ERRO: %', status_val, SQLERRM;
        END;
    END LOOP;
END $$;

-- 9. Verificar índices na tabela
SELECT 
    indexname,
    indexdef
FROM pg_indexes 
WHERE tablename = 'appointments'
    AND schemaname = 'public';

-- 10. Verificar estatísticas da tabela
SELECT 
    schemaname,
    tablename,
    n_tup_ins as inserts,
    n_tup_upd as updates,
    n_tup_del as deletes,
    n_live_tup as live_rows,
    n_dead_tup as dead_rows,
    last_vacuum,
    last_autovacuum,
    last_analyze,
    last_autoanalyze
FROM pg_stat_user_tables 
WHERE tablename = 'appointments';
