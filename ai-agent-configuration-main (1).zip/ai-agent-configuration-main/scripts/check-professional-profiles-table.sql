-- Verificar se a tabela professional_profiles existe
SELECT EXISTS (
  SELECT FROM information_schema.tables 
  WHERE table_schema = 'public' 
  AND table_name = 'professional_profiles'
) AS table_exists;

-- Verificar a estrutura da tabela
SELECT column_name, data_type, is_nullable
FROM information_schema.columns
WHERE table_schema = 'public'
AND table_name = 'professional_profiles'
ORDER BY ordinal_position;

-- Verificar políticas RLS
SELECT *
FROM pg_policies
WHERE tablename = 'professional_profiles';

-- Verificar permissões
SELECT grantee, privilege_type
FROM information_schema.role_table_grants
WHERE table_name = 'professional_profiles'
AND table_schema = 'public';

-- Verificar se há registros na tabela
SELECT COUNT(*) AS total_profiles
FROM professional_profiles;

-- Verificar se há restrições de chave estrangeira
SELECT
    tc.constraint_name,
    tc.table_name,
    kcu.column_name,
    ccu.table_name AS foreign_table_name,
    ccu.column_name AS foreign_column_name
FROM
    information_schema.table_constraints AS tc
    JOIN information_schema.key_column_usage AS kcu
      ON tc.constraint_name = kcu.constraint_name
      AND tc.table_schema = kcu.table_schema
    JOIN information_schema.constraint_column_usage AS ccu
      ON ccu.constraint_name = tc.constraint_name
      AND ccu.table_schema = tc.table_schema
WHERE tc.constraint_type = 'FOREIGN KEY'
AND tc.table_name = 'professional_profiles';
