-- Script para verificar e corrigir RLS da tabela professional_profiles
-- Este script resolve problemas de acesso aos perfis profissionais

-- 1. Verificar usuário atual e sessão
SELECT 
    'Informações da sessão atual:' as info,
    auth.uid() as current_user_id,
    auth.role() as current_role;

-- 2. Verificar se a tabela existe e mostrar alguns registros
SELECT 
    'Registros na tabela professional_profiles:' as info,
    id,
    user_id,
    "fullName",
    specialty,
    created_at
FROM professional_profiles
ORDER BY created_at DESC
LIMIT 5;

-- 3. Verificar status do RLS
SELECT 
    'Status RLS da tabela:' as info,
    schemaname,
    tablename,
    rowsecurity as rls_enabled,
    CASE 
        WHEN rowsecurity THEN 'RLS ATIVO ✅'
        ELSE 'RLS INATIVO ❌'
    END as status
FROM pg_tables 
WHERE tablename = 'professional_profiles';

-- 4. Mostrar políticas existentes
SELECT 
    'Políticas RLS existentes:' as info,
    policyname,
    cmd as comando,
    roles,
    qual as condicao,
    with_check
FROM pg_policies 
WHERE tablename = 'professional_profiles'
ORDER BY policyname;

-- 5. Remover todas as políticas existentes
DO $$
DECLARE
    policy_record RECORD;
BEGIN
    -- Listar e remover todas as políticas existentes
    FOR policy_record IN 
        SELECT policyname 
        FROM pg_policies 
        WHERE tablename = 'professional_profiles'
    LOOP
        EXECUTE format('DROP POLICY IF EXISTS %I ON professional_profiles', policy_record.policyname);
        RAISE NOTICE 'Política removida: %', policy_record.policyname;
    END LOOP;
    
    RAISE NOTICE 'Todas as políticas antigas foram removidas';
    
EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Erro ao remover políticas: %', SQLERRM;
END $$;

-- 6. Habilitar RLS na tabela
ALTER TABLE professional_profiles ENABLE ROW LEVEL SECURITY;

-- 7. Criar políticas RLS corretas
-- Política SELECT: Usuários podem ver apenas seus próprios perfis
CREATE POLICY "professional_profiles_select_own" ON professional_profiles
    FOR SELECT
    TO authenticated
    USING (auth.uid() = user_id);

-- Política INSERT: Usuários podem criar apenas seus próprios perfis
CREATE POLICY "professional_profiles_insert_own" ON professional_profiles
    FOR INSERT
    TO authenticated
    WITH CHECK (auth.uid() = user_id);

-- Política UPDATE: Usuários podem atualizar apenas seus próprios perfis
CREATE POLICY "professional_profiles_update_own" ON professional_profiles
    FOR UPDATE
    TO authenticated
    USING (auth.uid() = user_id)
    WITH CHECK (auth.uid() = user_id);

-- Política DELETE: Usuários podem deletar apenas seus próprios perfis
CREATE POLICY "professional_profiles_delete_own" ON professional_profiles
    FOR DELETE
    TO authenticated
    USING (auth.uid() = user_id);

-- 8. Verificar se as políticas foram criadas corretamente
SELECT 
    'Novas políticas criadas:' as info,
    policyname,
    cmd,
    roles,
    qual,
    with_check
FROM pg_policies 
WHERE tablename = 'professional_profiles'
ORDER BY policyname;

-- 9. Testar acesso com usuário específico
-- Simular a query que a aplicação faz
SELECT 
    'Teste de acesso aos perfis:' as info,
    'Tentando buscar perfis para o usuário atual' as descricao;

-- Tentar buscar perfis do usuário atual
SELECT 
    'Perfis acessíveis pelo usuário atual:' as resultado,
    id,
    user_id,
    "fullName",
    specialty,
    created_at
FROM professional_profiles
WHERE user_id = auth.uid()
ORDER BY created_at DESC;

-- 10. Verificar se há perfis órfãos (sem user_id válido)
SELECT 
    'Verificação de integridade:' as info,
    COUNT(*) as total_perfis,
    COUNT(CASE WHEN user_id IS NOT NULL THEN 1 END) as perfis_com_user_id,
    COUNT(CASE WHEN user_id IS NULL THEN 1 END) as perfis_sem_user_id
FROM professional_profiles;

-- 11. Mostrar resumo final
SELECT 
    'RESUMO FINAL:' as info,
    'RLS configurado corretamente para professional_profiles' as status,
    'Usuários agora podem acessar apenas seus próprios perfis' as resultado;
