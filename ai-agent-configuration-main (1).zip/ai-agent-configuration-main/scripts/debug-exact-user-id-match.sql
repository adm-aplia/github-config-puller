-- Debug: Verificar exatamente qual é o user_id correto
-- Comparar o que está na aplicação vs o que está no banco

-- PASSO 1: Mostrar todos os user_ids que começam com 'ab30e7c4'
SELECT 
    'USERS STARTING WITH ab30e7c4' as tipo,
    id as user_id,
    email,
    created_at
FROM auth.users 
WHERE id::text LIKE 'ab30e7c4%'
ORDER BY created_at DESC;

-- PASSO 2: Mostrar todas as credenciais Google com user_id similar
SELECT 
    'GOOGLE CREDENTIALS SIMILAR USER_ID' as tipo,
    id as credential_id,
    user_id,
    email,
    name,
    created_at
FROM google_credentials 
WHERE user_id::text LIKE 'ab30e7c4%'
ORDER BY created_at DESC;

-- PASSO 3: Verificar se existe o user_id exato da aplicação
SELECT 
    'EXACT USER_ID CHECK' as tipo,
    id as user_id,
    email,
    'EXISTS IN AUTH.USERS' as status
FROM auth.users 
WHERE id = 'ab30e7c4-40e8-4a4a-9ef7-cff0bbf00122';

-- PASSO 4: Verificar credenciais para o user_id exato da aplicação
SELECT 
    'EXACT USER_ID CREDENTIALS' as tipo,
    id as credential_id,
    user_id,
    email,
    'EXISTS IN GOOGLE_CREDENTIALS' as status
FROM google_credentials 
WHERE user_id = 'ab30e7c4-40e8-4a4a-9ef7-cff0bbf00122';

-- PASSO 5: Buscar por email nathancwb@gmail.com em ambas as tabelas
SELECT 
    'NATHAN EMAIL IN AUTH' as tipo,
    id as user_id,
    email,
    created_at
FROM auth.users 
WHERE email = 'nathancwb@gmail.com';

SELECT 
    'NATHAN EMAIL IN GOOGLE_CREDENTIALS' as tipo,
    id as credential_id,
    user_id,
    email,
    created_at
FROM google_credentials 
WHERE email = 'nathancwb@gmail.com';

-- PASSO 6: Verificar se há múltiplos usuários com o mesmo email
SELECT 
    'DUPLICATE EMAIL CHECK' as tipo,
    email,
    COUNT(*) as count,
    array_agg(id::text) as user_ids
FROM auth.users 
WHERE email = 'nathancwb@gmail.com'
GROUP BY email;
