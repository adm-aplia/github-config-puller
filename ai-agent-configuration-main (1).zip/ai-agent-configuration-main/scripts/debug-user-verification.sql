-- Script para verificar se os usuários estão sendo salvos corretamente
-- Execute este script para entender o que está acontecendo

-- 1. Verificar usuários na tabela auth.users
SELECT 
  id,
  email,
  created_at,
  email_confirmed_at,
  raw_user_meta_data
FROM auth.users 
WHERE email ILIKE '%nathancwb@gmail.com%'
ORDER BY created_at DESC;

-- 2. Verificar perfis na tabela profiles
SELECT 
  id,
  name,
  email,
  created_at,
  updated_at
FROM public.profiles 
WHERE email ILIKE '%nathancwb@gmail.com%'
ORDER BY created_at DESC;

-- 3. Verificar se o trigger existe e está ativo
SELECT 
  trigger_name,
  event_manipulation,
  action_statement,
  action_timing
FROM information_schema.triggers 
WHERE trigger_name = 'on_auth_user_created';

-- 4. Verificar se a função handle_new_user existe
SELECT 
  routine_name,
  routine_type,
  routine_definition
FROM information_schema.routines 
WHERE routine_name = 'handle_new_user';

-- 5. Contar total de usuários em cada tabela
SELECT 
  'auth.users' as tabela,
  COUNT(*) as total
FROM auth.users
UNION ALL
SELECT 
  'public.profiles' as tabela,
  COUNT(*) as total
FROM public.profiles;
