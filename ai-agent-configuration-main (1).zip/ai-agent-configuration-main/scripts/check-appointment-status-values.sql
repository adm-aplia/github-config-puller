-- Script para verificar todos os valores de status de agendamentos

-- 1. Verificar todos os status únicos na tabela
SELECT 
    status,
    COUNT(*) as quantidade,
    ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER(), 2) as percentual
FROM appointments 
GROUP BY status 
ORDER BY quantidade DESC;

-- 2. Verificar constraint de status
SELECT 
    conname as nome_constraint,
    pg_get_constraintdef(oid) as definicao_constraint
FROM pg_constraint 
WHERE conrelid = 'public.appointments'::regclass
    AND contype = 'c'
    AND conname LIKE '%status%';

-- 3. Status por usuário
SELECT 
    user_id,
    status,
    COUNT(*) as quantidade
FROM appointments 
GROUP BY user_id, status 
ORDER BY user_id, quantidade DESC;

-- 4. Agendamentos por data e status
SELECT 
    DATE(appointment_date) as data_agendamento,
    status,
    COUNT(*) as quantidade
FROM appointments 
WHERE appointment_date >= CURRENT_DATE - INTERVAL '30 days'
GROUP BY DATE(appointment_date), status 
ORDER BY data_agendamento DESC, quantidade DESC;

-- 5. Verificar se há status inválidos
WITH valid_statuses AS (
    SELECT unnest(ARRAY['scheduled', 'confirmed', 'completed', 'cancelled', 'no-show', 'rescheduled']) as valid_status
),
current_statuses AS (
    SELECT DISTINCT status FROM appointments
)
SELECT 
    cs.status as status_atual,
    CASE 
        WHEN vs.valid_status IS NULL THEN 'INVÁLIDO' 
        ELSE 'VÁLIDO' 
    END as validacao
FROM current_statuses cs
LEFT JOIN valid_statuses vs ON cs.status = vs.valid_status
ORDER BY validacao DESC, status_atual;

-- 6. Últimas atualizações de status
SELECT 
    id,
    patient_name,
    status,
    created_at,
    updated_at,
    CASE 
        WHEN updated_at > created_at THEN 'ATUALIZADO'
        ELSE 'NUNCA ATUALIZADO'
    END as status_atualizacao
FROM appointments 
ORDER BY updated_at DESC 
LIMIT 20;

-- 7. Estatísticas gerais
SELECT 
    COUNT(*) as total_agendamentos,
    COUNT(DISTINCT user_id) as usuarios_unicos,
    COUNT(DISTINCT status) as status_unicos,
    MIN(created_at) as primeiro_agendamento,
    MAX(updated_at) as ultima_atualizacao
FROM appointments;

-- 8. Verificar se RLS está funcionando
SELECT 
    tablename,
    rowsecurity as rls_habilitado,
    (SELECT COUNT(*) FROM pg_policies WHERE tablename = 'appointments') as politicas_ativas
FROM pg_tables 
WHERE tablename = 'appointments';
