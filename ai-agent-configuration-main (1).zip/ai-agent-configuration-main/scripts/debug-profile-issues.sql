-- Debug completo dos problemas de perfil
-- Execute este script para identificar problemas

-- 1. Verificar se a tabela existe e tem as colunas corretas
SELECT 
    table_name,
    column_name,
    data_type,
    is_nullable
FROM information_schema.columns 
WHERE table_name = 'professional_profiles'
ORDER BY ordinal_position;

-- 2. Verificar políticas RLS
SELECT 
    schemaname,
    tablename,
    policyname,
    permissive,
    roles,
    cmd,
    qual,
    with_check
FROM pg_policies 
WHERE tablename = 'professional_profiles';

-- 3. Verificar se RLS está habilitado
SELECT 
    schemaname,
    tablename,
    rowsecurity
FROM pg_tables 
WHERE tablename = 'professional_profiles';

-- 4. Testar acesso direto (execute como usuário autenticado)
SELECT COUNT(*) as total_profiles FROM professional_profiles;

-- 5. Verificar usuário atual
SELECT auth.uid() as current_user_id;

-- 6. Verificar perfis do usuário atual
SELECT 
    id,
    user_id,
    "fullName",
    specialty,
    created_at
FROM professional_profiles 
WHERE user_id = auth.uid();
