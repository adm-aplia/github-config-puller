-- Criar/atualizar tabela de assinaturas completa
-- Esta tabela gerencia assinaturas recorrentes do Asaas

-- Verificar se a tabela existe e criar/atualizar conforme necessário
DO $$
BEGIN
    -- Criar tabela se não existir
    IF NOT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'assinaturas') THEN
        CREATE TABLE assinaturas (
            id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
            cliente_id UUID REFERENCES clientes(id) ON DELETE CASCADE,
            subscription_id VARCHAR(255) UNIQUE NOT NULL, -- ID da assinatura no Asaas
            customer_id_asaas VARCHAR(255), -- ID do customer no Asaas
            plano VARCHAR(50) NOT NULL,
            valor DECIMAL(10,2) NOT NULL,
            descricao TEXT,
            status VARCHAR(50) NOT NULL DEFAULT 'PENDING', -- ACTIVE, INACTIVE, CANCELED, etc.
            next_due_date DATE, -- Próxima data de cobrança
            data_contratacao TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
            created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        );
        
        RAISE NOTICE 'Tabela assinaturas criada com sucesso';
    END IF;

    -- Adicionar colunas que podem estar faltando
    BEGIN
        ALTER TABLE assinaturas ADD COLUMN IF NOT EXISTS subscription_id VARCHAR(255);
        ALTER TABLE assinaturas ADD COLUMN IF NOT EXISTS customer_id_asaas VARCHAR(255);
        ALTER TABLE assinaturas ADD COLUMN IF NOT EXISTS next_due_date DATE;
        ALTER TABLE assinaturas ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW();
        
        RAISE NOTICE 'Colunas adicionais verificadas/adicionadas';
    EXCEPTION
        WHEN duplicate_column THEN
            RAISE NOTICE 'Colunas já existem, continuando...';
    END;

    -- Criar índices para performance
    CREATE INDEX IF NOT EXISTS idx_assinaturas_cliente_id ON assinaturas(cliente_id);
    CREATE INDEX IF NOT EXISTS idx_assinaturas_subscription_id ON assinaturas(subscription_id);
    CREATE INDEX IF NOT EXISTS idx_assinaturas_status ON assinaturas(status);
    CREATE INDEX IF NOT EXISTS idx_assinaturas_next_due_date ON assinaturas(next_due_date);

    -- Criar constraint única se não existir
    BEGIN
        ALTER TABLE assinaturas ADD CONSTRAINT unique_subscription_id UNIQUE (subscription_id);
        RAISE NOTICE 'Constraint única criada para subscription_id';
    EXCEPTION
        WHEN duplicate_table THEN
            RAISE NOTICE 'Constraint única já existe';
    END;

    RAISE NOTICE 'Tabela assinaturas configurada com sucesso!';
END $$;

-- Verificar estrutura final
SELECT 
    'ESTRUTURA DA TABELA ASSINATURAS' as info,
    column_name,
    data_type,
    is_nullable,
    column_default
FROM information_schema.columns 
WHERE table_name = 'assinaturas' 
ORDER BY ordinal_position;
