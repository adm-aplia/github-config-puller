-- Remover constraint antiga e limpar dados duplicados
BEGIN;

-- 1. Remover a constraint de foreign key antiga
ALTER TABLE google_credentials 
DROP CONSTRAINT IF EXISTS google_credentials_professional_profile_id_fkey;

-- 2. Limpar os dados antigos da coluna professional_profile_id
UPDATE google_credentials 
SET professional_profile_id = NULL;

-- 3. Opcionalmente, remover a coluna (descomente se quiser remover completamente)
-- ALTER TABLE google_credentials DROP COLUMN IF EXISTS professional_profile_id;

COMMIT;
