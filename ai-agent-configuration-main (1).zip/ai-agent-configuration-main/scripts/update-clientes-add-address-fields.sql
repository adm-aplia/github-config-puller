-- Adicionar campos de endereço e observações à tabela clientes
ALTER TABLE clientes 
ADD COLUMN IF NOT EXISTS endereco TEXT,
ADD COLUMN IF NOT EXISTS cidade VARCHAR(100),
ADD COLUMN IF NOT EXISTS estado VARCHAR(2),
ADD COLUMN IF NOT EXISTS cep VARCHAR(10),
ADD COLUMN IF NOT EXISTS observacoes TEXT;

-- Adicionar comentários para documentação
COMMENT ON COLUMN clientes.endereco IS 'Endereço completo do cliente';
COMMENT ON COLUMN clientes.cidade IS 'Cidade do cliente';
COMMENT ON COLUMN clientes.estado IS 'Estado (UF) do cliente';
COMMENT ON COLUMN clientes.cep IS 'CEP do cliente';
COMMENT ON COLUMN clientes.observacoes IS 'Observações sobre o cliente ou contratação';
