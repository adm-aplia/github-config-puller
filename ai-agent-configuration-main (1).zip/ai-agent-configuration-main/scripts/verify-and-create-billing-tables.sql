-- Verificar se as tabelas existem e criar se necessário

-- Tabela clientes
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'clientes') THEN
        CREATE TABLE clientes (
            id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
            user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
            nome VARCHAR(255) NOT NULL,
            email VARCHAR(255) NOT NULL UNIQUE,
            telefone VARCHAR(20),
            cpf_cnpj VARCHAR(20),
            plano VARCHAR(50),
            customer_id VARCHAR(100), -- ID do cliente no Asaas
            data_contratacao TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
            status VARCHAR(50) DEFAULT 'aguardando_pagamento',
            is_active BOOLEAN DEFAULT FALSE,
            endereco TEXT,
            cidade VARCHAR(100),
            estado VARCHAR(2),
            cep VARCHAR(10),
            observacoes TEXT,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        );

        -- Índices
        CREATE INDEX idx_clientes_email ON clientes(email);
        CREATE INDEX idx_clientes_user_id ON clientes(user_id);
        CREATE INDEX idx_clientes_customer_id ON clientes(customer_id);

        -- RLS
        ALTER TABLE clientes ENABLE ROW LEVEL SECURITY;
        
        -- Política para usuários verem apenas seus próprios dados
        CREATE POLICY "Users can view own client data" ON clientes
            FOR SELECT USING (auth.uid() = user_id);
            
        -- Política para inserção (qualquer usuário autenticado pode criar)
        CREATE POLICY "Users can insert client data" ON clientes
            FOR INSERT WITH CHECK (auth.uid() = user_id);
            
        -- Política para atualização (apenas próprios dados)
        CREATE POLICY "Users can update own client data" ON clientes
            FOR UPDATE USING (auth.uid() = user_id);

        RAISE NOTICE 'Tabela clientes criada com sucesso';
    ELSE
        RAISE NOTICE 'Tabela clientes já existe';
    END IF;
END
$$;

-- Tabela cobrancas
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'cobrancas') THEN
        CREATE TABLE cobrancas (
            id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
            cliente_id UUID REFERENCES clientes(id) ON DELETE CASCADE,
            customer_id VARCHAR(100), -- ID do cliente no Asaas
            id_cobranca VARCHAR(100) NOT NULL, -- ID da cobrança no Asaas
            status VARCHAR(50) DEFAULT 'PENDING',
            valor DECIMAL(10,2) NOT NULL,
            descricao TEXT,
            payment_link TEXT,
            invoice_url TEXT,
            due_date DATE,
            data_criacao TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
            data_pagamento TIMESTAMP WITH TIME ZONE,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        );

        -- Índices
        CREATE INDEX idx_cobrancas_cliente_id ON cobrancas(cliente_id);
        CREATE INDEX idx_cobrancas_id_cobranca ON cobrancas(id_cobranca);
        CREATE INDEX idx_cobrancas_status ON cobrancas(status);

        -- RLS
        ALTER TABLE cobrancas ENABLE ROW LEVEL SECURITY;
        
        -- Política para usuários verem apenas suas próprias cobranças
        CREATE POLICY "Users can view own charges" ON cobrancas
            FOR SELECT USING (
                EXISTS (
                    SELECT 1 FROM clientes 
                    WHERE clientes.id = cobrancas.cliente_id 
                    AND clientes.user_id = auth.uid()
                )
            );

        RAISE NOTICE 'Tabela cobrancas criada com sucesso';
    ELSE
        RAISE NOTICE 'Tabela cobrancas já existe';
    END IF;
END
$$;

-- Verificar se as colunas de endereço existem na tabela clientes
DO $$
BEGIN
    -- Adicionar colunas de endereço se não existirem
    IF NOT EXISTS (SELECT FROM information_schema.columns WHERE table_name = 'clientes' AND column_name = 'endereco') THEN
        ALTER TABLE clientes ADD COLUMN endereco TEXT;
        RAISE NOTICE 'Coluna endereco adicionada';
    END IF;
    
    IF NOT EXISTS (SELECT FROM information_schema.columns WHERE table_name = 'clientes' AND column_name = 'cidade') THEN
        ALTER TABLE clientes ADD COLUMN cidade VARCHAR(100);
        RAISE NOTICE 'Coluna cidade adicionada';
    END IF;
    
    IF NOT EXISTS (SELECT FROM information_schema.columns WHERE table_name = 'clientes' AND column_name = 'estado') THEN
        ALTER TABLE clientes ADD COLUMN estado VARCHAR(2);
        RAISE NOTICE 'Coluna estado adicionada';
    END IF;
    
    IF NOT EXISTS (SELECT FROM information_schema.columns WHERE table_name = 'clientes' AND column_name = 'cep') THEN
        ALTER TABLE clientes ADD COLUMN cep VARCHAR(10);
        RAISE NOTICE 'Coluna cep adicionada';
    END IF;
    
    IF NOT EXISTS (SELECT FROM information_schema.columns WHERE table_name = 'clientes' AND column_name = 'observacoes') THEN
        ALTER TABLE clientes ADD COLUMN observacoes TEXT;
        RAISE NOTICE 'Coluna observacoes adicionada';
    END IF;
END
$$;

-- Verificar estrutura final
SELECT 'clientes' as tabela, column_name, data_type 
FROM information_schema.columns 
WHERE table_name = 'clientes'
ORDER BY ordinal_position;

SELECT 'cobrancas' as tabela, column_name, data_type 
FROM information_schema.columns 
WHERE table_name = 'cobrancas'
ORDER BY ordinal_position;
