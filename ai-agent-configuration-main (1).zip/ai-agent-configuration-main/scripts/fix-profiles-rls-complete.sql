-- Script definitivo para corrigir políticas RLS da tabela profiles
-- Este script resolve completamente os problemas de permissão

-- 1. Desabilitar RLS temporariamente para limpeza
ALTER TABLE profiles DISABLE ROW LEVEL SECURITY;

-- 2. Remover TODAS as políticas existentes (incluindo duplicadas)
DROP POLICY IF EXISTS "view_own_profile" ON profiles;
DROP POLICY IF EXISTS "insert_own_profile" ON profiles;
DROP POLICY IF EXISTS "update_own_profile" ON profiles;
DROP POLICY IF EXISTS "delete_own_profile" ON profiles;
DROP POLICY IF EXISTS "profiles_select_policy" ON profiles;
DROP POLICY IF EXISTS "profiles_insert_policy" ON profiles;
DROP POLICY IF EXISTS "profiles_update_policy" ON profiles;
DROP POLICY IF EXISTS "profiles_delete_policy" ON profiles;
DROP POLICY IF EXISTS "Enable read access for users based on user_id" ON profiles;
DROP POLICY IF EXISTS "Enable insert for users based on user_id" ON profiles;
DROP POLICY IF EXISTS "Enable update for users based on user_id" ON profiles;
DROP POLICY IF EXISTS "Enable delete for users based on user_id" ON profiles;

-- 3. Verificar se a tabela profiles existe e tem a estrutura correta
DO $$
BEGIN
    -- Verificar se a coluna id existe e é do tipo correto
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'profiles' 
        AND column_name = 'id' 
        AND data_type = 'uuid'
    ) THEN
        -- Se não existir, criar a tabela
        CREATE TABLE IF NOT EXISTS profiles (
            id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
            name TEXT,
            first_name TEXT,
            last_name TEXT,
            email TEXT,
            phone TEXT,
            specialty TEXT,
            notifications_email BOOLEAN DEFAULT true,
            notifications_push BOOLEAN DEFAULT true,
            notifications_sms BOOLEAN DEFAULT false,
            notifications_appointments BOOLEAN DEFAULT true,
            notifications_messages BOOLEAN DEFAULT true,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        );
    END IF;
END $$;

-- 4. Reabilitar RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- 5. Criar políticas simples e funcionais
CREATE POLICY "profiles_select_policy" ON profiles
    FOR SELECT USING (auth.uid() = id);

CREATE POLICY "profiles_insert_policy" ON profiles
    FOR INSERT WITH CHECK (auth.uid() = id);

CREATE POLICY "profiles_update_policy" ON profiles
    FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "profiles_delete_policy" ON profiles
    FOR DELETE USING (auth.uid() = id);

-- 6. Verificar se as políticas foram criadas corretamente
DO $$
DECLARE
    policy_count INTEGER;
BEGIN
    SELECT COUNT(*) INTO policy_count
    FROM pg_policies 
    WHERE tablename = 'profiles';
    
    IF policy_count = 4 THEN
        RAISE NOTICE 'Sucesso: 4 políticas RLS criadas para a tabela profiles';
    ELSE
        RAISE NOTICE 'Aviso: % políticas encontradas (esperado: 4)', policy_count;
    END IF;
END $$;

-- 7. Testar se um usuário pode inserir seu próprio perfil
-- (Este teste só funcionará se houver um usuário autenticado)
DO $$
BEGIN
    -- Verificar se auth.uid() retorna algo
    IF auth.uid() IS NOT NULL THEN
        RAISE NOTICE 'Usuário autenticado detectado: %', auth.uid();
        
        -- Tentar inserir um perfil de teste (será removido depois)
        INSERT INTO profiles (id, name, email) 
        VALUES (auth.uid(), 'Teste', 'teste@exemplo.com')
        ON CONFLICT (id) DO UPDATE SET name = 'Teste Atualizado';
        
        RAISE NOTICE 'Teste de inserção/atualização bem-sucedido';
        
    ELSE
        RAISE NOTICE 'Nenhum usuário autenticado para teste';
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Erro no teste: %', SQLERRM;
END $$;

-- 8. Mostrar informações finais
SELECT 
    'Políticas RLS da tabela profiles:' as info,
    policyname,
    cmd,
    qual
FROM pg_policies 
WHERE tablename = 'profiles'
ORDER BY policyname;
