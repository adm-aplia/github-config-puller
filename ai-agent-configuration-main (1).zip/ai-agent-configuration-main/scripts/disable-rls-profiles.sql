-- Script para desabilitar completamente RLS na tabela profiles
-- Isso resolve o problema de acesso aos dados existentes

-- 1. Verificar estado atual
SELECT 
    'Estado atual da tabela profiles:' as info,
    schemaname,
    tablename,
    rowsecurity as rls_enabled
FROM pg_tables 
WHERE tablename = 'profiles';

-- 2. Mostrar políticas existentes antes de remover
SELECT 
    'Políticas existentes:' as info,
    policyname,
    cmd,
    qual
FROM pg_policies 
WHERE tablename = 'profiles';

-- 3. Remover TODAS as políticas RLS
DROP POLICY IF EXISTS "profiles_select_own" ON profiles;
DROP POLICY IF EXISTS "profiles_insert_own" ON profiles;
DROP POLICY IF EXISTS "profiles_update_own" ON profiles;
DROP POLICY IF EXISTS "profiles_delete_own" ON profiles;
DROP POLICY IF EXISTS "profiles_select_policy" ON profiles;
DROP POLICY IF EXISTS "profiles_insert_policy" ON profiles;
DROP POLICY IF EXISTS "profiles_update_policy" ON profiles;
DROP POLICY IF EXISTS "profiles_delete_policy" ON profiles;
DROP POLICY IF EXISTS "Enable read access for users based on user_id" ON profiles;
DROP POLICY IF EXISTS "Enable insert for users based on user_id" ON profiles;
DROP POLICY IF EXISTS "Enable update for users based on user_id" ON profiles;
DROP POLICY IF EXISTS "Enable delete for users based on user_id" ON profiles;

-- 4. Desabilitar RLS completamente
ALTER TABLE profiles DISABLE ROW LEVEL SECURITY;

-- 5. Verificar se RLS foi desabilitado
SELECT 
    'Estado após desabilitar RLS:' as info,
    schemaname,
    tablename,
    rowsecurity as rls_enabled,
    CASE 
        WHEN rowsecurity THEN 'RLS AINDA ATIVO ❌'
        ELSE 'RLS DESABILITADO ✅'
    END as status
FROM pg_tables 
WHERE tablename = 'profiles';

-- 6. Verificar se ainda existem políticas
SELECT 
    'Políticas restantes:' as info,
    COUNT(*) as total_policies
FROM pg_policies 
WHERE tablename = 'profiles';

-- 7. Testar acesso aos dados
SELECT 
    'Teste de acesso aos dados:' as info,
    COUNT(*) as total_profiles,
    'Perfis acessíveis após desabilitar RLS' as descricao
FROM profiles;

-- 8. Mostrar alguns perfis para confirmar acesso
SELECT 
    'Primeiros 5 perfis:' as info,
    id,
    name,
    email,
    created_at
FROM profiles
ORDER BY created_at DESC
LIMIT 5;

-- 9. Verificar perfil específico do Nathan
SELECT 
    'Perfil do Nathan:' as info,
    id,
    name,
    email,
    first_name,
    last_name,
    phone,
    notifications_email,
    notifications_push,
    created_at
FROM profiles 
WHERE id = 'ab30e7c4-40e8-4a4a-9ef7-cff0bbf00122'
   OR email = 'nathancwb@gmail.com';

-- 10. Resumo final
SELECT 
    'RESUMO FINAL:' as info,
    'RLS desabilitado na tabela profiles' as status,
    'Aplicação agora deve conseguir acessar todos os dados' as resultado,
    'Sem restrições de segurança por linha' as observacao;
