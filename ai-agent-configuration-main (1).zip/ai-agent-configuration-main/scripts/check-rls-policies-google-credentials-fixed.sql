-- Verificar se RLS está habilitado na tabela google_credentials
SELECT 
    schemaname,
    tablename,
    rowsecurity as rls_enabled
FROM pg_tables 
WHERE tablename = 'google_credentials';

-- Verificar todas as políticas RLS da tabela google_credentials
SELECT 
    schemaname,
    tablename,
    policyname,
    permissive,
    roles,
    cmd as command,
    qual as policy_expression
FROM pg_policies 
WHERE tablename = 'google_credentials'
ORDER BY policyname;

-- Testar se auth.uid() está funcionando
SELECT 
    auth.uid() as current_auth_uid,
    auth.role() as current_auth_role;

-- Verificar se existem dados na tabela (sem filtro RLS)
SELECT 
    COUNT(*) as total_records,
    COUNT(DISTINCT user_id) as unique_users
FROM google_credentials;

-- Verificar estrutura da tabela
SELECT 
    column_name,
    data_type,
    is_nullable
FROM information_schema.columns 
WHERE table_name = 'google_credentials'
ORDER BY ordinal_position;

-- Verificar dados específicos do usuário atual (se auth.uid() funcionar)
SELECT 
    id,
    user_id,
    profile_id,
    email,
    created_at
FROM google_credentials 
WHERE user_id = auth.uid()
LIMIT 5;
