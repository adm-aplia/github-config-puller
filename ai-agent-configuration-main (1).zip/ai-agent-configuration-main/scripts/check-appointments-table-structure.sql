-- Verificar estrutura da tabela appointments
SELECT 
    column_name,
    data_type,
    is_nullable,
    column_default
FROM information_schema.columns 
WHERE table_name = 'appointments' 
AND table_schema = 'public'
ORDER BY ordinal_position;

-- Verificar dados existentes
SELECT 
    id,
    patient_name,
    patient_phone,
    patient_email,
    appointment_date,
    status,
    agent_id,
    user_id
FROM appointments 
LIMIT 5;
