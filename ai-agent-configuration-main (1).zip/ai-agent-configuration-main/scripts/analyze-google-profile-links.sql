-- Verificar estrutura da tabela google_profile_links
SELECT 
  column_name,
  data_type,
  is_nullable,
  column_default
FROM information_schema.columns 
WHERE table_name = 'google_profile_links'
ORDER BY ordinal_position;

-- Verificar dados existentes
SELECT 
  gpl.*,
  gc.email as google_email,
  gc.name as google_name,
  pp.fullName as profile_name,
  pp.specialty as profile_specialty
FROM google_profile_links gpl
LEFT JOIN google_credentials gc ON gpl.google_credential_id = gc.id
LEFT JOIN professional_profiles pp ON gpl.professional_profile_id = pp.id
ORDER BY gpl.created_at DESC;

-- Verificar se existem credenciais não vinculadas
SELECT 
  gc.id,
  gc.email,
  gc.name,
  gc.user_id,
  CASE 
    WHEN gpl.google_credential_id IS NOT NULL THEN 'Vinculado'
    ELSE 'Não vinculado'
  END as status_vinculacao
FROM google_credentials gc
LEFT JOIN google_profile_links gpl ON gc.id = gpl.google_credential_id
WHERE gc.user_id = 'ab30e7c4-40e8-4a4a-9ef7-cff0bbf00122'
ORDER BY gc.created_at;
