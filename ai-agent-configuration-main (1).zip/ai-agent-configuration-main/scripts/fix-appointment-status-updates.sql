-- Script para corrigir problemas de atualização de status de agendamentos

-- 1. Garantir que a constraint de status existe e está correta
DO $$
BEGIN
    -- Remover constraint existente se houver
    IF EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'appointments_status_check' 
            AND conrelid = 'public.appointments'::regclass
    ) THEN
        ALTER TABLE appointments DROP CONSTRAINT appointments_status_check;
        RAISE NOTICE 'Constraint appointments_status_check removida';
    END IF;
    
    -- Adicionar nova constraint com todos os status válidos
    ALTER TABLE appointments ADD CONSTRAINT appointments_status_check 
    CHECK (status IN ('scheduled', 'confirmed', 'completed', 'cancelled', 'no-show', 'rescheduled'));
    
    RAISE NOTICE 'Nova constraint appointments_status_check adicionada';
END $$;

-- 2. Garantir que a coluna updated_at existe
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'appointments' 
            AND column_name = 'updated_at'
            AND table_schema = 'public'
    ) THEN
        ALTER TABLE appointments ADD COLUMN updated_at TIMESTAMPTZ DEFAULT NOW();
        RAISE NOTICE 'Coluna updated_at adicionada';
    END IF;
END $$;

-- 3. Criar ou atualizar trigger para updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Remover trigger existente se houver
DROP TRIGGER IF EXISTS update_appointments_updated_at ON appointments;

-- Criar novo trigger
CREATE TRIGGER update_appointments_updated_at
    BEFORE UPDATE ON appointments
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

RAISE NOTICE 'Trigger update_appointments_updated_at criado';

-- 4. Garantir que as políticas RLS estão corretas
-- Habilitar RLS se não estiver habilitado
ALTER TABLE appointments ENABLE ROW LEVEL SECURITY;

-- Remover políticas existentes
DROP POLICY IF EXISTS "Users can view own appointments" ON appointments;
DROP POLICY IF EXISTS "Users can insert own appointments" ON appointments;
DROP POLICY IF EXISTS "Users can update own appointments" ON appointments;
DROP POLICY IF EXISTS "Users can delete own appointments" ON appointments;

-- Criar políticas RLS corretas
CREATE POLICY "Users can view own appointments" ON appointments
    FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own appointments" ON appointments
    FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own appointments" ON appointments
    FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own appointments" ON appointments
    FOR DELETE USING (auth.uid() = user_id);

RAISE NOTICE 'Políticas RLS atualizadas';

-- 5. Criar índices para performance
CREATE INDEX IF NOT EXISTS idx_appointments_user_id ON appointments(user_id);
CREATE INDEX IF NOT EXISTS idx_appointments_status ON appointments(status);
CREATE INDEX IF NOT EXISTS idx_appointments_date ON appointments(appointment_date);
CREATE INDEX IF NOT EXISTS idx_appointments_user_status ON appointments(user_id, status);
CREATE INDEX IF NOT EXISTS idx_appointments_user_date ON appointments(user_id, appointment_date);

RAISE NOTICE 'Índices criados/verificados';

-- 6. Atualizar registros com status inválidos para 'scheduled'
UPDATE appointments 
SET status = 'scheduled', updated_at = NOW()
WHERE status NOT IN ('scheduled', 'confirmed', 'completed', 'cancelled', 'no-show', 'rescheduled');

-- 7. Verificar se há registros órfãos (sem user_id válido)
DO $$
DECLARE
    orphan_count INTEGER;
BEGIN
    SELECT COUNT(*) INTO orphan_count
    FROM appointments a
    LEFT JOIN auth.users u ON a.user_id = u.id
    WHERE u.id IS NULL;
    
    IF orphan_count > 0 THEN
        RAISE NOTICE 'Encontrados % registros órfãos (sem user_id válido)', orphan_count;
        -- Opcional: remover registros órfãos
        -- DELETE FROM appointments WHERE user_id NOT IN (SELECT id FROM auth.users);
    ELSE
        RAISE NOTICE 'Nenhum registro órfão encontrado';
    END IF;
END $$;

-- 8. Atualizar estatísticas da tabela
ANALYZE appointments;

RAISE NOTICE 'Script de correção executado com sucesso!';

-- 9. Verificação final
SELECT 
    'Status válidos:' as info,
    string_agg(DISTINCT status, ', ') as status_list,
    COUNT(*) as total_appointments
FROM appointments;
