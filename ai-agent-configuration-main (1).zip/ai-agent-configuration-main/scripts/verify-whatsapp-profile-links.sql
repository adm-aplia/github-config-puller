-- Verificar vinculações entre WhatsApp e perfis profissionais
SELECT 
    pp.id as profile_id,
    pp.fullName as profile_name,
    pp.specialty,
    wi.id as whatsapp_id,
    wi.instance_name,
    wi.profile_name as whatsapp_profile_name,
    wi.status,
    wi.professional_profile_id,
    wi.created_at as whatsapp_created
FROM professional_profiles pp
LEFT JOIN whatsapp_instances wi ON wi.professional_profile_id = pp.id
ORDER BY pp.created_at DESC;

-- Verificar instâncias sem perfil vinculado
SELECT 
    id,
    instance_name,
    profile_name,
    status,
    professional_profile_id,
    created_at
FROM whatsapp_instances 
WHERE professional_profile_id IS NULL
ORDER BY created_at DESC;

-- Verificar perfis sem WhatsApp vinculado
SELECT 
    pp.id,
    pp.fullName,
    pp.specialty,
    pp.created_at
FROM professional_profiles pp
LEFT JOIN whatsapp_instances wi ON wi.professional_profile_id = pp.id
WHERE wi.id IS NULL
ORDER BY pp.created_at DESC;
