-- Fix appointments status constraint to allow all valid statuses
-- This script fixes the constraint violation error when updating appointment status

-- First, drop the existing constraint
ALTER TABLE appointments DROP CONSTRAINT IF EXISTS appointments_status_check;

-- Add the new constraint with all valid statuses
ALTER TABLE appointments ADD CONSTRAINT appointments_status_check 
CHECK (status IN ('scheduled', 'confirmed', 'completed', 'cancelled', 'rescheduled', 'no-show'));

-- Verify the constraint was added correctly
SELECT conname, consrc 
FROM pg_constraint 
WHERE conrelid = 'appointments'::regclass 
AND conname = 'appointments_status_check';

-- Show current appointments and their statuses
SELECT id, patient_name, appointment_date, status, created_at
FROM appointments 
ORDER BY appointment_date DESC
LIMIT 10;
