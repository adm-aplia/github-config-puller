-- Verificar usuários na tabela auth.users com email nathancwb@gmail.com
SELECT 
    id as auth_user_id,
    email,
    created_at as auth_created_at,
    email_confirmed_at,
    last_sign_in_at
FROM auth.users 
WHERE email = 'nathancwb@gmail.com';

-- Comparar com google_credentials
SELECT 
    'google_credentials' as source,
    user_id,
    email,
    created_at
FROM google_credentials 
WHERE email = 'nathancwb@gmail.com'

UNION ALL

SELECT 
    'auth.users' as source,
    id as user_id,
    email,
    created_at
FROM auth.users 
WHERE email = 'nathancwb@gmail.com'
ORDER BY source;
