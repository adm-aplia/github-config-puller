-- Adicionar coluna user_id à tabela clientes
ALTER TABLE clientes 
ADD COLUMN IF NOT EXISTS user_id UUID REFERENCES auth.users(id);

-- Adicionar índice para melhorar performance de consultas
CREATE INDEX IF NOT EXISTS idx_clientes_user_id ON clientes(user_id);

-- Adicionar coluna para status de ativação
ALTER TABLE clientes
ADD COLUMN IF NOT EXISTS is_active BOOLEAN DEFAULT false;
