-- Tabela de planos disponíveis
CREATE TABLE IF NOT EXISTS public.planos (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  nome VARCHAR(50) NOT NULL UNIQUE,
  preco DECIMAL(10,2) NOT NULL,
  descricao TEXT,
  whatsapp_instances INTEGER NOT NULL DEFAULT 1,
  max_appointments INTEGER NOT NULL DEFAULT 300, -- -1 para ilimitado
  max_assistants INTEGER NOT NULL DEFAULT 1, -- -1 para ilimitado
  support_level VARCHAR(20) NOT NULL DEFAULT 'email',
  advanced_reports BOOLEAN DEFAULT FALSE,
  hospital_integration BOOLEAN DEFAULT FALSE,
  advanced_customization BOOLEAN DEFAULT FALSE,
  api_access BOOLEAN DEFAULT FALSE,
  priority_support BOOLEAN DEFAULT FALSE,
  custom_branding BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabela para rastrear uso atual de cada cliente
CREATE TABLE IF NOT EXISTS public.cliente_usage (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  cliente_id UUID NOT NULL REFERENCES public.clientes(id) ON DELETE CASCADE,
  whatsapp_instances_used INTEGER DEFAULT 0,
  appointments_this_month INTEGER DEFAULT 0,
  assistants_created INTEGER DEFAULT 0,
  last_reset_date DATE DEFAULT CURRENT_DATE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(cliente_id)
);

-- Inserir planos padrão
INSERT INTO public.planos (nome, preco, descricao, whatsapp_instances, max_appointments, max_assistants, support_level, advanced_reports, hospital_integration, advanced_customization, api_access, priority_support, custom_branding) VALUES
('Básico', 199.00, 'Plano Básico Aplia - 1 número WhatsApp, até 300 agendamentos, 1 assistente, suporte por e-mail.', 1, 300, 1, 'email', FALSE, FALSE, FALSE, FALSE, FALSE, FALSE),
('Profissional', 399.00, 'Plano Profissional Aplia - 3 números WhatsApp, até 1000 agendamentos, 3 assistentes, suporte prioritário, relatórios avançados.', 3, 1000, 3, 'priority', TRUE, FALSE, FALSE, TRUE, TRUE, FALSE),
('Empresarial', 899.00, 'Plano Empresarial Aplia - +10 números WhatsApp, agendamentos ilimitados, assistentes ilimitados, suporte 24/7, integração com sistemas hospitalares, personalização avançada.', 10, -1, -1, '24/7', TRUE, TRUE, TRUE, TRUE, TRUE, TRUE)
ON CONFLICT (nome) DO UPDATE SET
  preco = EXCLUDED.preco,
  descricao = EXCLUDED.descricao,
  whatsapp_instances = EXCLUDED.whatsapp_instances,
  max_appointments = EXCLUDED.max_appointments,
  max_assistants = EXCLUDED.max_assistants,
  support_level = EXCLUDED.support_level,
  advanced_reports = EXCLUDED.advanced_reports,
  hospital_integration = EXCLUDED.hospital_integration,
  advanced_customization = EXCLUDED.advanced_customization,
  api_access = EXCLUDED.api_access,
  priority_support = EXCLUDED.priority_support,
  custom_branding = EXCLUDED.custom_branding,
  updated_at = NOW();

-- Função para resetar contadores mensais
CREATE OR REPLACE FUNCTION reset_monthly_counters()
RETURNS void AS $$
BEGIN
  UPDATE public.cliente_usage 
  SET 
    appointments_this_month = 0,
    last_reset_date = CURRENT_DATE,
    updated_at = NOW()
  WHERE last_reset_date < DATE_TRUNC('month', CURRENT_DATE);
END;
$$ LANGUAGE plpgsql;

-- Trigger para criar usage automaticamente quando cliente é criado
CREATE OR REPLACE FUNCTION create_cliente_usage()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.cliente_usage (cliente_id)
  VALUES (NEW.id)
  ON CONFLICT (cliente_id) DO NOTHING;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_create_cliente_usage ON public.clientes;
CREATE TRIGGER trigger_create_cliente_usage
  AFTER INSERT ON public.clientes
  FOR EACH ROW
  EXECUTE FUNCTION create_cliente_usage();

-- Políticas RLS
ALTER TABLE public.planos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.cliente_usage ENABLE ROW LEVEL SECURITY;

-- Política para planos (todos podem ver)
CREATE POLICY "Planos são públicos" ON public.planos FOR SELECT USING (true);

-- Política para usage (apenas o próprio cliente)
CREATE POLICY "Clientes podem ver seu próprio usage" ON public.cliente_usage 
  FOR SELECT USING (
    cliente_id IN (
      SELECT id FROM public.clientes WHERE user_id = auth.uid()
    )
  );

-- Política para admins verem tudo
CREATE POLICY "Admins podem ver todo usage" ON public.cliente_usage 
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM auth.users 
      WHERE id = auth.uid() 
      AND raw_user_meta_data->>'role' = 'admin'
    )
  );

-- Índices para performance
CREATE INDEX IF NOT EXISTS idx_cliente_usage_cliente_id ON public.cliente_usage(cliente_id);
CREATE INDEX IF NOT EXISTS idx_planos_nome ON public.planos(nome);
