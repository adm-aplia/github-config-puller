-- Função para incrementar uso
CREATE OR REPLACE FUNCTION increment_usage(cliente_id UUID, field_name TEXT)
RETURNS void AS $$
BEGIN
  CASE field_name
    WHEN 'whatsapp_instances_used' THEN
      UPDATE public.cliente_usage 
      SET whatsapp_instances_used = whatsapp_instances_used + 1,
          updated_at = NOW()
      WHERE cliente_usage.cliente_id = increment_usage.cliente_id;
    WHEN 'appointments_this_month' THEN
      UPDATE public.cliente_usage 
      SET appointments_this_month = appointments_this_month + 1,
          updated_at = NOW()
      WHERE cliente_usage.cliente_id = increment_usage.cliente_id;
    WHEN 'assistants_created' THEN
      UPDATE public.cliente_usage 
      SET assistants_created = assistants_created + 1,
          updated_at = NOW()
      WHERE cliente_usage.cliente_id = increment_usage.cliente_id;
  END CASE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Função para decrementar uso
CREATE OR REPLACE FUNCTION decrement_usage(cliente_id UUID, field_name TEXT)
RETURNS void AS $$
BEGIN
  CASE field_name
    WHEN 'whatsapp_instances_used' THEN
      UPDATE public.cliente_usage 
      SET whatsapp_instances_used = GREATEST(0, whatsapp_instances_used - 1),
          updated_at = NOW()
      WHERE cliente_usage.cliente_id = decrement_usage.cliente_id;
    WHEN 'appointments_this_month' THEN
      UPDATE public.cliente_usage 
      SET appointments_this_month = GREATEST(0, appointments_this_month - 1),
          updated_at = NOW()
      WHERE cliente_usage.cliente_id = decrement_usage.cliente_id;
    WHEN 'assistants_created' THEN
      UPDATE public.cliente_usage 
      SET assistants_created = GREATEST(0, assistants_created - 1),
          updated_at = NOW()
      WHERE cliente_usage.cliente_id = decrement_usage.cliente_id;
  END CASE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Função para obter limites e uso de um usuário
CREATE OR REPLACE FUNCTION get_user_limits_and_usage(user_id UUID)
RETURNS TABLE(
  plano_nome VARCHAR,
  whatsapp_limit INTEGER,
  whatsapp_used INTEGER,
  appointments_limit INTEGER,
  appointments_used INTEGER,
  assistants_limit INTEGER,
  assistants_used INTEGER,
  advanced_reports BOOLEAN,
  hospital_integration BOOLEAN,
  advanced_customization BOOLEAN,
  api_access BOOLEAN,
  priority_support BOOLEAN,
  custom_branding BOOLEAN
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    p.nome,
    p.whatsapp_instances,
    COALESCE(cu.whatsapp_instances_used, 0),
    p.max_appointments,
    COALESCE(cu.appointments_this_month, 0),
    p.max_assistants,
    COALESCE(cu.assistants_created, 0),
    p.advanced_reports,
    p.hospital_integration,
    p.advanced_customization,
    p.api_access,
    p.priority_support,
    p.custom_branding
  FROM public.clientes c
  JOIN public.planos p ON p.nome = c.plano
  LEFT JOIN public.cliente_usage cu ON cu.cliente_id = c.id
  WHERE c.user_id = get_user_limits_and_usage.user_id
    AND c.is_active = true
    AND c.status = 'ativo';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
