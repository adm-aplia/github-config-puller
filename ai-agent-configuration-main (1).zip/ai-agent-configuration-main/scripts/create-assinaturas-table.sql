-- Criar tabela de assinaturas
CREATE TABLE IF NOT EXISTS assinaturas (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  id_cliente_supabase UUID REFERENCES clientes(id) ON DELETE CASCADE,
  customer_id_asaas VARCHAR(255) NOT NULL,
  subscription_id VARCHAR(255) NOT NULL UNIQUE,
  credit_card_token VARCHAR(255),
  plano VARCHAR(50) NOT NULL,
  valor DECIMAL(10,2) NOT NULL,
  descricao TEXT,
  status VARCHAR(50) DEFAULT 'ACTIVE',
  data_contratacao TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  next_due_date DATE,
  remote_ip INET,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Criar índices para melhor performance
CREATE INDEX IF NOT EXISTS idx_assinaturas_cliente ON assinaturas(id_cliente_supabase);
CREATE INDEX IF NOT EXISTS idx_assinaturas_customer_id ON assinaturas(customer_id_asaas);
CREATE INDEX IF NOT EXISTS idx_assinaturas_subscription_id ON assinaturas(subscription_id);
CREATE INDEX IF NOT EXISTS idx_assinaturas_status ON assinaturas(status);

-- Habilitar RLS
ALTER TABLE assinaturas ENABLE ROW LEVEL SECURITY;

-- Criar política RLS
CREATE POLICY "Allow all operations on assinaturas" ON assinaturas FOR ALL USING (true);

-- Atualizar tabela clientes para incluir customer_id_asaas se não existir
DO $$ 
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                   WHERE table_name = 'clientes' AND column_name = 'customer_id_asaas') THEN
        ALTER TABLE clientes ADD COLUMN customer_id_asaas VARCHAR(255);
        CREATE INDEX IF NOT EXISTS idx_clientes_customer_id_asaas ON clientes(customer_id_asaas);
    END IF;
END $$;

-- Comentários para documentação
COMMENT ON TABLE assinaturas IS 'Tabela para armazenar assinaturas recorrentes do Asaas';
COMMENT ON COLUMN assinaturas.subscription_id IS 'ID da assinatura no Asaas';
COMMENT ON COLUMN assinaturas.credit_card_token IS 'Token do cartão de crédito tokenizado';
COMMENT ON COLUMN assinaturas.next_due_date IS 'Data do próximo vencimento';
COMMENT ON COLUMN assinaturas.remote_ip IS 'IP do cliente no momento da contratação';
