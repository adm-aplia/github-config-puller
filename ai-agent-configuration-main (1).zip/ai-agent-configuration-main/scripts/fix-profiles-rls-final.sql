-- Script FINAL para corrigir RLS da tabela profiles
-- Este script resolve o problema da política INSERT com condição NULL

-- 1. Desabilitar RLS temporariamente
ALTER TABLE profiles DISABLE ROW LEVEL SECURITY;

-- 2. Limpar TODAS as políticas existentes
DO $$
DECLARE
    policy_record RECORD;
BEGIN
    FOR policy_record IN 
        SELECT policyname FROM pg_policies WHERE tablename = 'profiles'
    LOOP
        EXECUTE 'DROP POLICY IF EXISTS ' || quote_ident(policy_record.policyname) || ' ON profiles';
        RAISE NOTICE 'Removida política: %', policy_record.policyname;
    END LOOP;
END $$;

-- 3. Verificar e limpar dados duplicados
DO $$
DECLARE
    duplicate_count INTEGER;
BEGIN
    -- Contar duplicatas
    SELECT COUNT(*) - COUNT(DISTINCT id) INTO duplicate_count FROM profiles;
    
    IF duplicate_count > 0 THEN
        RAISE NOTICE 'Encontradas % linhas duplicadas, removendo...', duplicate_count;
        
        -- Remover duplicatas mantendo apenas a mais recente
        DELETE FROM profiles 
        WHERE ctid NOT IN (
            SELECT DISTINCT ON (id) ctid 
            FROM profiles 
            ORDER BY id, created_at DESC NULLS LAST
        );
        
        RAISE NOTICE 'Duplicatas removidas com sucesso';
    ELSE
        RAISE NOTICE 'Nenhuma duplicata encontrada';
    END IF;
END $$;

-- 4. Reabilitar RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- 5. Criar políticas com sintaxe explícita e correta
CREATE POLICY "profiles_select_policy" ON profiles
    FOR SELECT 
    TO authenticated
    USING (auth.uid() = id);

CREATE POLICY "profiles_insert_policy" ON profiles
    FOR INSERT 
    TO authenticated
    WITH CHECK (auth.uid() = id);

CREATE POLICY "profiles_update_policy" ON profiles
    FOR UPDATE 
    TO authenticated
    USING (auth.uid() = id)
    WITH CHECK (auth.uid() = id);

CREATE POLICY "profiles_delete_policy" ON profiles
    FOR DELETE 
    TO authenticated
    USING (auth.uid() = id);

-- 6. Verificar se as políticas foram criadas corretamente
DO $$
DECLARE
    policy_count INTEGER;
    policy_record RECORD;
BEGIN
    SELECT COUNT(*) INTO policy_count FROM pg_policies WHERE tablename = 'profiles';
    
    RAISE NOTICE 'Total de políticas criadas: %', policy_count;
    
    -- Mostrar detalhes de cada política
    FOR policy_record IN 
        SELECT policyname, cmd, qual, with_check 
        FROM pg_policies 
        WHERE tablename = 'profiles' 
        ORDER BY policyname
    LOOP
        RAISE NOTICE 'Política: % | Comando: % | Condição: % | Check: %', 
            policy_record.policyname, 
            policy_record.cmd, 
            COALESCE(policy_record.qual, 'NULL'),
            COALESCE(policy_record.with_check, 'NULL');
    END LOOP;
END $$;

-- 7. Teste de funcionamento (se houver usuário autenticado)
DO $$
DECLARE
    current_user_id UUID;
    test_result TEXT;
BEGIN
    -- Tentar obter o ID do usuário atual
    SELECT auth.uid() INTO current_user_id;
    
    IF current_user_id IS NOT NULL THEN
        RAISE NOTICE 'Usuário autenticado encontrado: %', current_user_id;
        
        -- Teste de INSERT/UPDATE
        BEGIN
            INSERT INTO profiles (id, name, email) 
            VALUES (current_user_id, 'Teste RLS', 'teste@exemplo.com')
            ON CONFLICT (id) DO UPDATE SET 
                name = 'Teste RLS Atualizado',
                updated_at = NOW();
            
            test_result := 'SUCESSO';
        EXCEPTION
            WHEN OTHERS THEN
                test_result := 'ERRO: ' || SQLERRM;
        END;
        
        RAISE NOTICE 'Resultado do teste: %', test_result;
    ELSE
        RAISE NOTICE 'Nenhum usuário autenticado para teste';
    END IF;
END $$;

-- 8. Mostrar estrutura final da tabela
SELECT 
    column_name,
    data_type,
    is_nullable,
    column_default
FROM information_schema.columns 
WHERE table_name = 'profiles' 
ORDER BY ordinal_position;
