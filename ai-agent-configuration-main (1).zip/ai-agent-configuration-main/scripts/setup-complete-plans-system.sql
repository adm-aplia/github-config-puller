-- =====================================================
-- SISTEMA COMPLETO DE PLANOS E CONTROLE DE ACESSO
-- =====================================================

-- 1. ATUALIZAR PLANOS COM LIMITES CORRETOS
UPDATE planos SET 
  whatsapp_instances = 1,
  max_appointments = 300,
  max_assistants = 1,
  support_level = 'email',
  advanced_reports = false,
  hospital_integration = false,
  advanced_customization = false,
  api_access = false,
  priority_support = false,
  custom_branding = false
WHERE nome = 'Básico';

UPDATE planos SET 
  whatsapp_instances = 3,
  max_appointments = 1000,
  max_assistants = 5, -- 5 atendentes como solicitado
  support_level = 'priority',
  advanced_reports = true,
  hospital_integration = false,
  advanced_customization = true,
  api_access = true,
  priority_support = true,
  custom_branding = false
WHERE nome = 'Profissional';

UPDATE planos SET 
  whatsapp_instances = 10,
  max_appointments = -1, -- ilimitado
  max_assistants = -1, -- ilimitado
  support_level = '24/7',
  advanced_reports = true,
  hospital_integration = true,
  advanced_customization = true,
  api_access = true,
  priority_support = true,
  custom_branding = true
WHERE nome = 'Empresarial';

-- 2. CRIAR FUNÇÃO PARA VERIFICAR LIMITES
CREATE OR REPLACE FUNCTION check_user_limit(
  p_user_id UUID,
  p_resource_type TEXT
) RETURNS JSONB AS $$
DECLARE
  v_cliente_id UUID;
  v_plano_nome TEXT;
  v_limit INTEGER;
  v_current_usage INTEGER;
  v_result JSONB;
BEGIN
  -- Buscar cliente e plano
  SELECT c.id, c.plano INTO v_cliente_id, v_plano_nome
  FROM clientes c 
  WHERE c.user_id = p_user_id 
    AND c.is_active = true 
    AND c.status = 'ativo';
    
  IF v_cliente_id IS NULL THEN
    RETURN jsonb_build_object(
      'allowed', false,
      'reason', 'Usuário não possui assinatura ativa'
    );
  END IF;
  
  -- Buscar limite do plano
  CASE p_resource_type
    WHEN 'whatsapp' THEN
      SELECT whatsapp_instances INTO v_limit FROM planos WHERE nome = v_plano_nome;
      SELECT COALESCE(whatsapp_instances_used, 0) INTO v_current_usage 
      FROM cliente_usage WHERE cliente_id = v_cliente_id;
      
    WHEN 'appointment' THEN
      SELECT max_appointments INTO v_limit FROM planos WHERE nome = v_plano_nome;
      SELECT COALESCE(appointments_this_month, 0) INTO v_current_usage 
      FROM cliente_usage WHERE cliente_id = v_cliente_id;
      
    WHEN 'assistant' THEN
      SELECT max_assistants INTO v_limit FROM planos WHERE nome = v_plano_nome;
      SELECT COALESCE(assistants_created, 0) INTO v_current_usage 
      FROM cliente_usage WHERE cliente_id = v_cliente_id;
      
    ELSE
      RETURN jsonb_build_object(
        'allowed', false,
        'reason', 'Tipo de recurso inválido'
      );
  END CASE;
  
  -- Verificar se pode criar
  IF v_limit = -1 THEN -- Ilimitado
    RETURN jsonb_build_object(
      'allowed', true,
      'current_usage', v_current_usage,
      'limit', -1
    );
  END IF;
  
  IF v_current_usage >= v_limit THEN
    RETURN jsonb_build_object(
      'allowed', false,
      'reason', format('Limite de %s atingido (%s/%s)', p_resource_type, v_current_usage, v_limit),
      'current_usage', v_current_usage,
      'limit', v_limit
    );
  END IF;
  
  RETURN jsonb_build_object(
    'allowed', true,
    'current_usage', v_current_usage,
    'limit', v_limit
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 3. CRIAR FUNÇÃO PARA INCREMENTAR USO
CREATE OR REPLACE FUNCTION increment_resource_usage(
  p_user_id UUID,
  p_resource_type TEXT
) RETURNS BOOLEAN AS $$
DECLARE
  v_cliente_id UUID;
BEGIN
  -- Buscar cliente
  SELECT id INTO v_cliente_id
  FROM clientes 
  WHERE user_id = p_user_id 
    AND is_active = true 
    AND status = 'ativo';
    
  IF v_cliente_id IS NULL THEN
    RETURN false;
  END IF;
  
  -- Incrementar uso
  CASE p_resource_type
    WHEN 'whatsapp' THEN
      INSERT INTO cliente_usage (cliente_id, whatsapp_instances_used)
      VALUES (v_cliente_id, 1)
      ON CONFLICT (cliente_id) 
      DO UPDATE SET whatsapp_instances_used = cliente_usage.whatsapp_instances_used + 1;
      
    WHEN 'appointment' THEN
      INSERT INTO cliente_usage (cliente_id, appointments_this_month)
      VALUES (v_cliente_id, 1)
      ON CONFLICT (cliente_id) 
      DO UPDATE SET appointments_this_month = cliente_usage.appointments_this_month + 1;
      
    WHEN 'assistant' THEN
      INSERT INTO cliente_usage (cliente_id, assistants_created)
      VALUES (v_cliente_id, 1)
      ON CONFLICT (cliente_id) 
      DO UPDATE SET assistants_created = cliente_usage.assistants_created + 1;
      
    ELSE
      RETURN false;
  END CASE;
  
  RETURN true;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 4. CRIAR FUNÇÃO PARA DECREMENTAR USO
CREATE OR REPLACE FUNCTION decrement_resource_usage(
  p_user_id UUID,
  p_resource_type TEXT
) RETURNS BOOLEAN AS $$
DECLARE
  v_cliente_id UUID;
BEGIN
  -- Buscar cliente
  SELECT id INTO v_cliente_id
  FROM clientes 
  WHERE user_id = p_user_id 
    AND is_active = true 
    AND status = 'ativo';
    
  IF v_cliente_id IS NULL THEN
    RETURN false;
  END IF;
  
  -- Decrementar uso (não deixar negativo)
  CASE p_resource_type
    WHEN 'whatsapp' THEN
      UPDATE cliente_usage 
      SET whatsapp_instances_used = GREATEST(0, whatsapp_instances_used - 1)
      WHERE cliente_id = v_cliente_id;
      
    WHEN 'appointment' THEN
      UPDATE cliente_usage 
      SET appointments_this_month = GREATEST(0, appointments_this_month - 1)
      WHERE cliente_id = v_cliente_id;
      
    WHEN 'assistant' THEN
      UPDATE cliente_usage 
      SET assistants_created = GREATEST(0, assistants_created - 1)
      WHERE cliente_id = v_cliente_id;
      
    ELSE
      RETURN false;
  END CASE;
  
  RETURN true;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 5. GARANTIR QUE TODOS OS CLIENTES TENHAM USAGE
INSERT INTO cliente_usage (cliente_id, whatsapp_instances_used, appointments_this_month, assistants_created)
SELECT id, 0, 0, 0 
FROM clientes 
WHERE id NOT IN (SELECT cliente_id FROM cliente_usage)
ON CONFLICT (cliente_id) DO NOTHING;

-- 6. CRIAR POLÍTICAS RLS PARA CONTROLE DE ACESSO
-- Política para professional_profiles (assistentes)
DROP POLICY IF EXISTS "Users can only create profiles within their plan limits" ON professional_profiles;
CREATE POLICY "Users can only create profiles within their plan limits" ON professional_profiles
FOR INSERT WITH CHECK (
  (SELECT (check_user_limit(auth.uid(), 'assistant')->'allowed')::boolean) = true
);

-- 7. CRIAR TRIGGER PARA INCREMENTAR USO AUTOMATICAMENTE
CREATE OR REPLACE FUNCTION trigger_increment_usage() RETURNS TRIGGER AS $$
BEGIN
  -- Incrementar uso baseado na tabela
  CASE TG_TABLE_NAME
    WHEN 'professional_profiles' THEN
      PERFORM increment_resource_usage(NEW.user_id, 'assistant');
    WHEN 'whatsapp_instances' THEN
      PERFORM increment_resource_usage(NEW.user_id, 'whatsapp');
    -- Adicionar outras tabelas conforme necessário
  END CASE;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Aplicar trigger em professional_profiles
DROP TRIGGER IF EXISTS increment_assistant_usage ON professional_profiles;
CREATE TRIGGER increment_assistant_usage
  AFTER INSERT ON professional_profiles
  FOR EACH ROW EXECUTE FUNCTION trigger_increment_usage();

-- 8. CRIAR TRIGGER PARA DECREMENTAR USO AUTOMATICAMENTE
CREATE OR REPLACE FUNCTION trigger_decrement_usage() RETURNS TRIGGER AS $$
BEGIN
  -- Decrementar uso baseado na tabela
  CASE TG_TABLE_NAME
    WHEN 'professional_profiles' THEN
      PERFORM decrement_resource_usage(OLD.user_id, 'assistant');
    WHEN 'whatsapp_instances' THEN
      PERFORM decrement_resource_usage(OLD.user_id, 'whatsapp');
    -- Adicionar outras tabelas conforme necessário
  END CASE;
  
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;

-- Aplicar trigger em professional_profiles
DROP TRIGGER IF EXISTS decrement_assistant_usage ON professional_profiles;
CREATE TRIGGER decrement_assistant_usage
  AFTER DELETE ON professional_profiles
  FOR EACH ROW EXECUTE FUNCTION trigger_decrement_usage();

COMMIT;
