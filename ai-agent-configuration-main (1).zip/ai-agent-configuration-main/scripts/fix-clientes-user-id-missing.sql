-- Script para corrigir clientes sem user_id
DO $$
DECLARE
    cliente_record RECORD;
    auth_user_id UUID;
BEGIN
    RAISE NOTICE '🔍 Iniciando correção de clientes sem user_id...';
    
    -- Buscar todos os clientes sem user_id
    FOR cliente_record IN 
        SELECT id, nome, email 
        FROM clientes 
        WHERE user_id IS NULL
    LOOP
        RAISE NOTICE '👤 Processando cliente: % (email: %)', cliente_record.nome, cliente_record.email;
        
        -- Buscar o user_id correspondente na tabela auth.users
        SELECT id INTO auth_user_id 
        FROM auth.users 
        WHERE email = cliente_record.email;
        
        IF auth_user_id IS NOT NULL THEN
            -- Atualizar o cliente com o user_id correto
            UPDATE clientes 
            SET user_id = auth_user_id,
                updated_at = NOW()
            WHERE id = cliente_record.id;
            
            RAISE NOTICE '✅ Cliente % atualizado com user_id: %', cliente_record.nome, auth_user_id;
        ELSE
            RAISE NOTICE '⚠️ Usuário não encontrado para email: %', cliente_record.email;
        END IF;
    END LOOP;
    
    -- Relatório final
    RAISE NOTICE '📊 === RELATÓRIO FINAL ===';
    RAISE NOTICE 'Clientes com user_id: %', (SELECT COUNT(*) FROM clientes WHERE user_id IS NOT NULL);
    RAISE NOTICE 'Clientes sem user_id: %', (SELECT COUNT(*) FROM clientes WHERE user_id IS NULL);
    
    -- Mostrar clientes corrigidos
    FOR cliente_record IN 
        SELECT c.id, c.nome, c.email, c.user_id, u.email as auth_email
        FROM clientes c
        LEFT JOIN auth.users u ON c.user_id = u.id
        WHERE c.email = 'nathancwb@gmail.com'
    LOOP
        RAISE NOTICE '✅ Cliente nathancwb@gmail.com: ID=%, user_id=%, auth_email=%', 
                     cliente_record.id, cliente_record.user_id, cliente_record.auth_email;
    END LOOP;
    
END $$;
