-- Verificar a estrutura da tabela google_credentials
SELECT 
    column_name,
    data_type,
    is_nullable,
    column_default
FROM information_schema.columns 
WHERE table_name = 'google_credentials' 
ORDER BY ordinal_position;
