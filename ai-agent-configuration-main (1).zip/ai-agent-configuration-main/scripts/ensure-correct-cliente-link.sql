-- Script para garantir que o cliente correto existe e corrigir as cobranças

DO $$
DECLARE
    target_email TEXT := 'nathancwb@gmail.com';
    correct_auth_user_id UUID;
    correct_cliente_id UUID;
    temp_cliente_id UUID;
    -- Variáveis para capturar os resultados da consulta final
    r RECORD;
BEGIN
    RAISE NOTICE '--- INICIANDO CORREÇÃO DE IDS PARA % ---', target_email;

    -- 1. Obter o user_id correto de auth.users para o email
    SELECT id INTO correct_auth_user_id FROM auth.users WHERE email = target_email;

    IF correct_auth_user_id IS NULL THEN
        RAISE EXCEPTION 'Erro: Usuário com email % não encontrado em auth.users. Verifique o email.', target_email;
    END IF;
    RAISE NOTICE '✅ user_id correto para % é %', target_email, correct_auth_user_id;

    -- 2. Tentar encontrar um cliente existente vinculado a este user_id
    SELECT id INTO correct_cliente_id FROM clientes WHERE user_id = correct_auth_user_id;

    IF correct_cliente_id IS NULL THEN
        RAISE NOTICE '🔍 Nenhum cliente encontrado para user_id %. Verificando se existe cliente com o email % sem user_id.', correct_auth_user_id, target_email;
        -- Se não encontrou por user_id, tenta encontrar por email (para casos legados ou sem user_id)
        SELECT id INTO correct_cliente_id FROM clientes WHERE email = target_email AND user_id IS NULL;

        IF correct_cliente_id IS NOT NULL THEN
            RAISE NOTICE '✅ Cliente encontrado por email (%) sem user_id. Atualizando user_id para %.', target_email, correct_auth_user_id;
            UPDATE clientes SET user_id = correct_auth_user_id, updated_at = NOW() WHERE id = correct_cliente_id;
        ELSE
            RAISE NOTICE '❌ Nenhum cliente existente para % encontrado. Criando novo cliente.', target_email;
            -- Criar um novo cliente e vincular ao user_id
            INSERT INTO clientes (nome, email, telefone, cpf_cnpj, plano, data_contratacao, status, user_id)
            VALUES ('Nathan CWB', target_email, '5541999999999', '12345678900', 'Básico', NOW(), 'ativo', correct_auth_user_id)
            RETURNING id INTO correct_cliente_id;
            RAISE NOTICE '✅ Novo cliente criado com ID % e user_id %.', correct_cliente_id, correct_auth_user_id;
        END IF;
    ELSE
        RAISE NOTICE '✅ Cliente existente encontrado com ID % e user_id %.', correct_cliente_id, correct_auth_user_id;
    END IF;

    -- 3. Verificar se há clientes duplicados para o mesmo user_id ou email (exceto o correto)
    FOR temp_cliente_id IN
        SELECT id FROM clientes
        WHERE (user_id = correct_auth_user_id OR email = target_email)
          AND id != correct_cliente_id
    LOOP
        RAISE NOTICE '⚠️ Cliente duplicado encontrado com ID %. Re-apontando suas cobranças para o cliente correto (%).', temp_cliente_id, correct_cliente_id;
        UPDATE cobrancas
        SET cliente_id = correct_cliente_id, updated_at = NOW()
        WHERE cliente_id = temp_cliente_id;

        RAISE NOTICE '🗑️ Deletando cliente duplicado com ID %.', temp_cliente_id;
        DELETE FROM clientes WHERE id = temp_cliente_id;
    END LOOP;
    RAISE NOTICE '✅ Clientes duplicados tratados.';

    -- 4. Corrigir todas as cobranças que possam estar apontando para IDs incorretos ou duplicados
    RAISE NOTICE '🔄 Corrigindo cobranças para apontar para o cliente correto (%).', correct_cliente_id;
    UPDATE cobrancas
    SET cliente_id = correct_cliente_id, updated_at = NOW()
    WHERE id IN (
        SELECT c.id
        FROM cobrancas c
        LEFT JOIN clientes cl ON c.cliente_id = cl.id
        WHERE cl.id IS NULL OR cl.user_id != correct_auth_user_id OR cl.email != target_email
    );
    RAISE NOTICE '✅ Cobranças atualizadas para apontar para o cliente correto.';

    -- 5. Verificar o estado final das cobranças para o email e imprimir
    RAISE NOTICE '--- VERIFICANDO ESTADO FINAL DAS COBRANÇAS PARA % ---', target_email;
    FOR r IN
        SELECT
            c.id as cobranca_id,
            c.cliente_id,
            cl.id as cliente_id_associado,
            cl.user_id as cliente_user_id,
            cl.email as cliente_email,
            c.valor,
            c.status,
            c.data_criacao
        FROM cobrancas c
        JOIN clientes cl ON c.cliente_id = cl.id
        WHERE cl.email = target_email
        ORDER BY c.data_criacao DESC
    LOOP
        RAISE NOTICE 'Cobranca ID: %, Cliente ID: %, Cliente User ID: %, Cliente Email: %, Valor: %, Status: %, Data Criação: %',
            r.cobranca_id, r.cliente_id, r.cliente_user_id, r.cliente_email, r.valor, r.status, r.data_criacao;
    END LOOP;

    RAISE NOTICE '--- CORREÇÃO CONCLUÍDA PARA % ---', target_email;
END $$;
