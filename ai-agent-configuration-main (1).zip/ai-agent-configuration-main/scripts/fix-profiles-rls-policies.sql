-- Script para corrigir políticas RLS da tabela profiles
-- Remove políticas existentes e cria novas políticas corretas

DO $$
DECLARE
    policy_record RECORD;
BEGIN
    -- Listar e remover todas as políticas existentes da tabela profiles
    FOR policy_record IN 
        SELECT policyname 
        FROM pg_policies 
        WHERE tablename = 'profiles'
    LOOP
        EXECUTE format('DROP POLICY IF EXISTS %I ON profiles', policy_record.policyname);
        RAISE NOTICE 'Política removida: %', policy_record.policyname;
    END LOOP;
    
    -- Habilitar RLS se não estiver habilitado
    ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
    RAISE NOTICE 'RLS habilitado na tabela profiles';
    
    -- Criar políticas com nomes únicos e timestamp
    EXECUTE format('CREATE POLICY "view_own_profile_%s" ON profiles FOR SELECT USING (auth.uid() = id)', 
                   extract(epoch from now())::bigint);
    
    EXECUTE format('CREATE POLICY "insert_own_profile_%s" ON profiles FOR INSERT WITH CHECK (auth.uid() = id)', 
                   extract(epoch from now())::bigint);
    
    EXECUTE format('CREATE POLICY "update_own_profile_%s" ON profiles FOR UPDATE USING (auth.uid() = id)', 
                   extract(epoch from now())::bigint);
    
    EXECUTE format('CREATE POLICY "delete_own_profile_%s" ON profiles FOR DELETE USING (auth.uid() = id)', 
                   extract(epoch from now())::bigint);
    
    RAISE NOTICE 'Novas políticas RLS criadas com sucesso para tabela profiles';
    
EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Erro ao configurar políticas: %', SQLERRM;
        -- Continuar mesmo com erro
END $$;

-- Verificar políticas criadas
SELECT 
    schemaname,
    tablename,
    policyname,
    permissive,
    cmd,
    qual,
    with_check
FROM pg_policies 
WHERE tablename = 'profiles'
ORDER BY policyname;

-- Verificar se RLS está habilitado
SELECT 
    schemaname,
    tablename,
    rowsecurity
FROM pg_tables 
WHERE tablename = 'profiles';

-- Testar se as políticas estão funcionando
DO $$
BEGIN
    -- Verificar se conseguimos acessar a tabela
    PERFORM 1 FROM profiles LIMIT 1;
    RAISE NOTICE 'Teste de acesso à tabela profiles: SUCESSO';
EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Teste de acesso à tabela profiles: ERRO - %', SQLERRM;
END $$;
