-- Verificar todos os campos da tabela professional_profiles
SELECT column_name, data_type, is_nullable, column_default
FROM information_schema.columns 
WHERE table_name = 'professional_profiles' 
  AND table_schema = 'public'
ORDER BY ordinal_position;

-- Verificar se há dados em campos que não estão no modal
SELECT 
  id,
  fullname,
  specialty,
  professionalid,
  email,
  phonenumber,
  education,
  procedures,
  -- Verificar se há outros campos com dados
  *
FROM professional_profiles 
WHERE user_id = auth.uid()
LIMIT 5;
