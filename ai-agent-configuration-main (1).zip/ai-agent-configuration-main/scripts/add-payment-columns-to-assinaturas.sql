-- Adicionar colunas para armazenar dados da cobrança imediata
ALTER TABLE assinaturas 
ADD COLUMN IF NOT EXISTS first_payment_id VARCHAR(255),
ADD COLUMN IF NOT EXISTS first_payment_status VARCHAR(50);

-- Comentários para documentar as colunas
COMMENT ON COLUMN assinaturas.first_payment_id IS 'ID da primeira cobrança no Asaas (cobrança imediata)';
COMMENT ON COLUMN assinaturas.first_payment_status IS 'Status da primeira cobrança (PENDING, CONFIRMED, RECEIVED, etc.)';

-- Verificar estrutura da tabela
SELECT column_name, data_type, is_nullable, column_default 
FROM information_schema.columns 
WHERE table_name = 'assinaturas' 
ORDER BY ordinal_position;
