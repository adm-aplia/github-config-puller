-- Verificar se auth.uid() funciona no contexto da aplicação
SELECT 
  'Teste de auth.uid()' as teste,
  auth.uid() as current_auth_uid,
  auth.role() as current_auth_role;

-- Verificar se há sessões ativas
SELECT 
  'Sessões ativas' as teste,
  COUNT(*) as total_sessions
FROM auth.sessions 
WHERE expires_at > NOW();

-- Testar acesso direto com user_id específico (sem RLS)
SET row_security = off;
SELECT 
  'Dados sem RLS' as teste,
  COUNT(*) as total_records,
  user_id
FROM google_credentials 
WHERE user_id = 'ab30e7c4-40e8-4a4a-9ef7-cff0bbf00122'
GROUP BY user_id;

-- Reativar RLS
SET row_security = on;

-- Testar com RLS ativo
SELECT 
  'Dados com RLS' as teste,
  COUNT(*) as total_records
FROM google_credentials;
