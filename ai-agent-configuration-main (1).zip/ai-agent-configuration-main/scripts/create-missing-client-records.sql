-- Criar registros de clientes para usuários que não têm
INSERT INTO clientes (user_id, email, nome, plano, is_active, status)
SELECT 
  u.id,
  u.email,
  COALESCE(u.raw_user_meta_data->>'full_name', split_part(u.email, '@', 1)),
  'Básico', -- Plano padrão
  true,
  'ativo'
FROM auth.users u
LEFT JOIN clientes c ON c.user_id = u.id
WHERE c.id IS NULL
AND u.email IS NOT NULL;

-- Criar registros de uso para clientes que não têm
INSERT INTO cliente_usage (cliente_id, whatsapp_instances_used, appointments_this_month, assistants_created)
SELECT 
  c.id,
  COALESCE((SELECT COUNT(*) FROM whatsapp_instances w WHERE w.user_id = c.user_id), 0),
  0,
  COALESCE((SELECT COUNT(*) FROM professional_profiles p WHERE p.user_id = c.user_id), 0)
FROM clientes c
LEFT JOIN cliente_usage cu ON cu.cliente_id = c.id
WHERE cu.id IS NULL;

-- Atualizar contagem atual de WhatsApp para usuários existentes
UPDATE cliente_usage 
SET whatsapp_instances_used = (
  SELECT COUNT(*) 
  FROM whatsapp_instances w 
  JOIN clientes c ON c.user_id = w.user_id 
  WHERE c.id = cliente_usage.cliente_id
);
