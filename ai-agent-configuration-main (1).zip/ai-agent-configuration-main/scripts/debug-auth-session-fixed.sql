-- Verificar se auth.uid() funciona
SELECT 
  'Teste de auth.uid()' as teste,
  auth.uid() as current_auth_uid,
  auth.role() as current_auth_role;

-- Testar acesso direto com user_id específico (sem RLS)
ALTER TABLE google_credentials DISABLE ROW LEVEL SECURITY;

SELECT 
  'Dados sem RLS' as teste,
  COUNT(*) as total_records,
  user_id
FROM google_credentials 
WHERE user_id = 'ab30e7c4-40e8-4a4a-9ef7-cff0bbf00122'
GROUP BY user_id;

-- Testar com RLS ativo novamente
ALTER TABLE google_credentials ENABLE ROW LEVEL SECURITY;

SELECT 
  'Dados com RLS ativo' as teste,
  COUNT(*) as total_records
FROM google_credentials;

-- Desabilitar RLS temporariamente para a aplicação funcionar
ALTER TABLE google_credentials DISABLE ROW LEVEL SECURITY;

SELECT 'RLS desabilitado temporariamente' as status;
