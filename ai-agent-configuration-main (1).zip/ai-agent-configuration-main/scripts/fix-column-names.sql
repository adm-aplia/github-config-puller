-- Verificar e corrigir nomes das colunas se necessário
DO $$
BEGIN
    -- Verificar se existe full_name em vez de fullName
    IF EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'professional_profiles' 
        AND column_name = 'full_name'
        AND table_schema = 'public'
    ) AND NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'professional_profiles' 
        AND column_name = 'fullName'
        AND table_schema = 'public'
    ) THEN
        ALTER TABLE professional_profiles RENAME COLUMN full_name TO "fullName";
        RAISE NOTICE 'Coluna full_name renomeada para fullName';
    END IF;

    -- Verificar se existe professional_id em vez de professionalId
    IF EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'professional_profiles' 
        AND column_name = 'professional_id'
        AND table_schema = 'public'
    ) AND NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'professional_profiles' 
        AND column_name = 'professionalId'
        AND table_schema = 'public'
    ) THEN
        ALTER TABLE professional_profiles RENAME COLUMN professional_id TO "professionalId";
        RAISE NOTICE 'Coluna professional_id renomeada para professionalId';
    END IF;

    -- Verificar se existe phone_number em vez de phoneNumber
    IF EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'professional_profiles' 
        AND column_name = 'phone_number'
        AND table_schema = 'public'
    ) AND NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'professional_profiles' 
        AND column_name = 'phoneNumber'
        AND table_schema = 'public'
    ) THEN
        ALTER TABLE professional_profiles RENAME COLUMN phone_number TO "phoneNumber";
        RAISE NOTICE 'Coluna phone_number renomeada para phoneNumber';
    END IF;

    -- Adicionar colunas que podem estar faltando
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'professional_profiles' 
        AND column_name = 'fullName'
        AND table_schema = 'public'
    ) THEN
        ALTER TABLE professional_profiles ADD COLUMN "fullName" TEXT;
        RAISE NOTICE 'Coluna fullName adicionada';
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'professional_profiles' 
        AND column_name = 'professionalId'
        AND table_schema = 'public'
    ) THEN
        ALTER TABLE professional_profiles ADD COLUMN "professionalId" TEXT;
        RAISE NOTICE 'Coluna professionalId adicionada';
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'professional_profiles' 
        AND column_name = 'phoneNumber'
        AND table_schema = 'public'
    ) THEN
        ALTER TABLE professional_profiles ADD COLUMN "phoneNumber" TEXT;
        RAISE NOTICE 'Coluna phoneNumber adicionada';
    END IF;

END $$;

-- Verificar a estrutura final
SELECT 
    column_name,
    data_type,
    is_nullable
FROM information_schema.columns 
WHERE table_name = 'professional_profiles' 
    AND table_schema = 'public'
ORDER BY ordinal_position;
