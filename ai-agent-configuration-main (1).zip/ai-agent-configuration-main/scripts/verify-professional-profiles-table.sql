-- Verificar se a tabela professional_profiles existe e sua estrutura
SELECT 
    table_name,
    column_name,
    data_type,
    is_nullable,
    column_default
FROM information_schema.columns 
WHERE table_name = 'professional_profiles' 
ORDER BY ordinal_position;

-- Verificar políticas RLS
SELECT 
    schemaname,
    tablename,
    policyname,
    permissive,
    roles,
    cmd,
    qual,
    with_check
FROM pg_policies 
WHERE tablename = 'professional_profiles';

-- Verificar se RLS está habilitado (versão corrigida)
SELECT 
    schemaname,
    tablename,
    rowsecurity
FROM pg_tables 
WHERE tablename = 'professional_profiles';

-- Verificar permissões da tabela
SELECT 
    grantee,
    privilege_type,
    is_grantable
FROM information_schema.table_privileges 
WHERE table_name = 'professional_profiles';

-- Contar registros existentes
SELECT COUNT(*) as total_profiles FROM professional_profiles;

-- Verificar últimos registros (se existirem)
SELECT 
    id,
    user_id,
    fullName,
    specialty,
    created_at
FROM professional_profiles 
ORDER BY created_at DESC 
LIMIT 5;
