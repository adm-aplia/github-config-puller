-- Remove todas as funções e triggers relacionados aos perfis que não são mais necessários

-- Remove triggers se existirem
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

-- Remove funções relacionadas aos perfis
DROP FUNCTION IF EXISTS public.handle_new_user();
DROP FUNCTION IF EXISTS public.create_profile_for_user(uuid);

-- Limpa dados de teste se existirem
DELETE FROM professional_profiles WHERE fullName LIKE '%Teste%' OR fullName LIKE '%Debug%';

-- Comentário para confirmar limpeza
SELECT 'Limpeza de funções de perfil concluída' as status;
