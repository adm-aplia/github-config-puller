-- Configurar políticas RLS corretas para todas as tabelas

-- 1. Limpar políticas existentes
DROP POLICY IF EXISTS "Users can view own professional profiles" ON public.professional_profiles;
DROP POLICY IF EXISTS "Users can insert own professional profiles" ON public.professional_profiles;
DROP POLICY IF EXISTS "Users can update own professional profiles" ON public.professional_profiles;
DROP POLICY IF EXISTS "Users can delete own professional profiles" ON public.professional_profiles;

DROP POLICY IF EXISTS "Users can view own google credentials" ON public.google_credentials;
DROP POLICY IF EXISTS "Users can insert own google credentials" ON public.google_credentials;
DROP POLICY IF EXISTS "Users can update own google credentials" ON public.google_credentials;
DROP POLICY IF EXISTS "Users can delete own google credentials" ON public.google_credentials;

-- 2. Habilitar RLS
ALTER TABLE public.professional_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.google_credentials ENABLE ROW LEVEL SECURITY;

-- 3. Criar políticas para professional_profiles
CREATE POLICY "Users can view own professional profiles"
    ON public.professional_profiles FOR SELECT
    USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own professional profiles"
    ON public.professional_profiles FOR INSERT
    WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own professional profiles"
    ON public.professional_profiles FOR UPDATE
    USING (auth.uid() = user_id)
    WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own professional profiles"
    ON public.professional_profiles FOR DELETE
    USING (auth.uid() = user_id);

-- 4. Criar políticas para google_credentials
CREATE POLICY "Users can view own google credentials"
    ON public.google_credentials FOR SELECT
    USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own google credentials"
    ON public.google_credentials FOR INSERT
    WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own google credentials"
    ON public.google_credentials FOR UPDATE
    USING (auth.uid() = user_id)
    WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own google credentials"
    ON public.google_credentials FOR DELETE
    USING (auth.uid() = user_id);
