-- Opção 1: Criar tabela de relacionamento many-to-many
-- Esta é a abordagem mais limpa e flexível

-- Criar tabela de relacionamento entre google_credentials e professional_profiles
CREATE TABLE IF NOT EXISTS public.google_profile_links (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    google_credential_id UUID NOT NULL REFERENCES public.google_credentials(id) ON DELETE CASCADE,
    professional_profile_id UUID NOT NULL REFERENCES public.professional_profiles(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    
    -- Evitar duplicatas da mesma vinculação
    UNIQUE(google_credential_id, professional_profile_id)
);

-- Migrar dados existentes da tabela google_credentials
INSERT INTO public.google_profile_links (google_credential_id, professional_profile_id, created_at)
SELECT id, professional_profile_id, created_at
FROM public.google_credentials 
WHERE professional_profile_id IS NOT NULL;

-- Remover a coluna professional_profile_id da tabela google_credentials
-- (comentado para não quebrar o sistema atual - execute apenas após testar)
-- ALTER TABLE public.google_credentials DROP COLUMN IF EXISTS professional_profile_id;

-- Habilitar RLS na nova tabela
ALTER TABLE public.google_profile_links ENABLE ROW LEVEL SECURITY;

-- Políticas RLS para a nova tabela
CREATE POLICY "Users can view own profile links" ON public.google_profile_links
    FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM public.professional_profiles pp 
            WHERE pp.id = professional_profile_id 
            AND pp.user_id = auth.uid()
        )
    );

CREATE POLICY "Users can create own profile links" ON public.google_profile_links
    FOR INSERT WITH CHECK (
        EXISTS (
            SELECT 1 FROM public.professional_profiles pp 
            WHERE pp.id = professional_profile_id 
            AND pp.user_id = auth.uid()
        )
    );

CREATE POLICY "Users can delete own profile links" ON public.google_profile_links
    FOR DELETE USING (
        EXISTS (
            SELECT 1 FROM public.professional_profiles pp 
            WHERE pp.id = professional_profile_id 
            AND pp.user_id = auth.uid()
        )
    );

-- Verificar a estrutura criada
SELECT 
    table_name,
    column_name,
    data_type,
    is_nullable
FROM information_schema.columns 
WHERE table_name = 'google_profile_links' 
AND table_schema = 'public'
ORDER BY ordinal_position;

-- Verificar dados migrados
SELECT 
    gpl.id,
    gc.email,
    pp.fullName as profile_name,
    gpl.created_at
FROM public.google_profile_links gpl
JOIN public.google_credentials gc ON gc.id = gpl.google_credential_id
JOIN public.professional_profiles pp ON pp.id = gpl.professional_profile_id
LIMIT 10;
