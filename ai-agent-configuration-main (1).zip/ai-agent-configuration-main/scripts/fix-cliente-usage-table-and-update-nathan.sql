-- Primeiro, verificar e corrigir a estrutura da tabela cliente_usage
DO $$
BEGIN
    -- Verificar se a tabela cliente_usage existe
    IF NOT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'cliente_usage') THEN
        -- Criar a tabela se não existir
        CREATE TABLE cliente_usage (
            id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
            cliente_id UUID REFERENCES clientes(id) ON DELETE CASCADE,
            whatsapp_instances_used INTEGER DEFAULT 0,
            appointments_used INTEGER DEFAULT 0,
            assistants_used INTEGER DEFAULT 0,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
            UNIQUE(cliente_id)
        );
        
        -- RLS
        ALTER TABLE cliente_usage ENABLE ROW LEVEL SECURITY;
        
        -- Política para usuários verem apenas seus próprios dados
        CREATE POLICY "Users can view own usage" ON cliente_usage
            FOR SELECT USING (
                EXISTS (
                    SELECT 1 FROM clientes 
                    WHERE clientes.id = cliente_usage.cliente_id 
                    AND clientes.user_id = auth.uid()
                )
            );
            
        RAISE NOTICE 'Tabela cliente_usage criada com sucesso';
    ELSE
        -- Se a tabela existe, verificar e adicionar colunas faltantes
        IF NOT EXISTS (SELECT FROM information_schema.columns WHERE table_name = 'cliente_usage' AND column_name = 'appointments_used') THEN
            ALTER TABLE cliente_usage ADD COLUMN appointments_used INTEGER DEFAULT 0;
            RAISE NOTICE 'Coluna appointments_used adicionada';
        END IF;
        
        IF NOT EXISTS (SELECT FROM information_schema.columns WHERE table_name = 'cliente_usage' AND column_name = 'assistants_used') THEN
            ALTER TABLE cliente_usage ADD COLUMN assistants_used INTEGER DEFAULT 0;
            RAISE NOTICE 'Coluna assistants_used adicionada';
        END IF;
        
        IF NOT EXISTS (SELECT FROM information_schema.columns WHERE table_name = 'cliente_usage' AND column_name = 'whatsapp_instances_used') THEN
            ALTER TABLE cliente_usage ADD COLUMN whatsapp_instances_used INTEGER DEFAULT 0;
            RAISE NOTICE 'Coluna whatsapp_instances_used adicionada';
        END IF;
    END IF;
END
$$;

-- Agora atualizar Nathan para Plano Profissional
UPDATE clientes 
SET 
  plano = 'Profissional',
  is_active = true,
  status = 'ativo',
  updated_at = NOW()
WHERE email = 'nathancwb@gmail.com';

-- Criar ou atualizar registro de uso para Nathan
INSERT INTO cliente_usage (cliente_id, whatsapp_instances_used, appointments_used, assistants_used)
SELECT 
  c.id,
  0, -- whatsapp_instances_used
  0, -- appointments_used
  0  -- assistants_used
FROM clientes c
WHERE c.email = 'nathancwb@gmail.com'
ON CONFLICT (cliente_id) 
DO UPDATE SET
  updated_at = NOW();

-- Verificar se a atualização funcionou
SELECT 
  '✅ Nathan atualizado para Plano Profissional!' as resultado,
  c.email,
  c.nome,
  c.plano,
  c.is_active,
  c.status,
  c.data_contratacao,
  c.updated_at
FROM clientes c
WHERE c.email = 'nathancwb@gmail.com';

-- Verificar os limites disponíveis
SELECT 
  'Limites do Plano Profissional:' as info,
  c.email,
  c.plano,
  COALESCE(p.whatsapp_instances, 3) as limite_whatsapp,
  COALESCE(p.max_appointments, 1000) as limite_agendamentos,
  COALESCE(p.assistants, 3) as limite_assistentes,
  COALESCE(cu.whatsapp_instances_used, 0) as whatsapp_usado,
  COALESCE(cu.appointments_used, 0) as agendamentos_usado,
  COALESCE(cu.assistants_used, 0) as assistentes_usado
FROM clientes c
LEFT JOIN planos p ON c.plano = p.nome
LEFT JOIN cliente_usage cu ON cu.cliente_id = c.id
WHERE c.email = 'nathancwb@gmail.com';
