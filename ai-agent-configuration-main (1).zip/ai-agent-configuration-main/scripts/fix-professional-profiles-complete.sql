-- Correção completa da tabela professional_profiles
-- Execute este script para corrigir todos os problemas

-- 1. Desabilitar RLS temporariamente para correções
ALTER TABLE professional_profiles DISABLE ROW LEVEL SECURITY;

-- 2. Garantir que todas as colunas existam
DO $$ 
BEGIN
    -- Verificar e adicionar colunas que podem estar faltando
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'fullName') THEN
        ALTER TABLE professional_profiles ADD COLUMN "fullName" TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'specialty') THEN
        ALTER TABLE professional_profiles ADD COLUMN specialty TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'professionalId') THEN
        ALTER TABLE professional_profiles ADD COLUMN "professionalId" TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'email') THEN
        ALTER TABLE professional_profiles ADD COLUMN email TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'phoneNumber') THEN
        ALTER TABLE professional_profiles ADD COLUMN "phoneNumber" TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'education') THEN
        ALTER TABLE professional_profiles ADD COLUMN education TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'procedures') THEN
        ALTER TABLE professional_profiles ADD COLUMN procedures TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'locations') THEN
        ALTER TABLE professional_profiles ADD COLUMN locations TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'workingHours') THEN
        ALTER TABLE professional_profiles ADD COLUMN "workingHours" TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'consultationFees') THEN
        ALTER TABLE professional_profiles ADD COLUMN "consultationFees" TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'paymentMethods') THEN
        ALTER TABLE professional_profiles ADD COLUMN "paymentMethods" TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'cancellationPolicy') THEN
        ALTER TABLE professional_profiles ADD COLUMN "cancellationPolicy" TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'consultationDuration') THEN
        ALTER TABLE professional_profiles ADD COLUMN "consultationDuration" TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'timeBetweenConsultations') THEN
        ALTER TABLE professional_profiles ADD COLUMN "timeBetweenConsultations" TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'reschedulingPolicy') THEN
        ALTER TABLE professional_profiles ADD COLUMN "reschedulingPolicy" TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'onlineConsultations') THEN
        ALTER TABLE professional_profiles ADD COLUMN "onlineConsultations" TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'reminderPreferences') THEN
        ALTER TABLE professional_profiles ADD COLUMN "reminderPreferences" TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'requiredPatientInfo') THEN
        ALTER TABLE professional_profiles ADD COLUMN "requiredPatientInfo" TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'appointmentConditions') THEN
        ALTER TABLE professional_profiles ADD COLUMN "appointmentConditions" TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'medicalHistoryRequirements') THEN
        ALTER TABLE professional_profiles ADD COLUMN "medicalHistoryRequirements" TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'ageRequirements') THEN
        ALTER TABLE professional_profiles ADD COLUMN "ageRequirements" TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'healthInsurance') THEN
        ALTER TABLE professional_profiles ADD COLUMN "healthInsurance" TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'communicationChannels') THEN
        ALTER TABLE professional_profiles ADD COLUMN "communicationChannels" TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'preAppointmentInfo') THEN
        ALTER TABLE professional_profiles ADD COLUMN "preAppointmentInfo" TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'requiredDocuments') THEN
        ALTER TABLE professional_profiles ADD COLUMN "requiredDocuments" TEXT;
    END IF;
END $$;

-- 3. Remover todas as políticas RLS existentes
DROP POLICY IF EXISTS "Users can view own profiles" ON professional_profiles;
DROP POLICY IF EXISTS "Users can insert own profiles" ON professional_profiles;
DROP POLICY IF EXISTS "Users can update own profiles" ON professional_profiles;
DROP POLICY IF EXISTS "Users can delete own profiles" ON professional_profiles;
DROP POLICY IF EXISTS "Enable read access for own profiles" ON professional_profiles;
DROP POLICY IF EXISTS "Enable insert access for own profiles" ON professional_profiles;
DROP POLICY IF EXISTS "Enable update access for own profiles" ON professional_profiles;
DROP POLICY IF EXISTS "Enable delete access for own profiles" ON professional_profiles;

-- 4. Reabilitar RLS
ALTER TABLE professional_profiles ENABLE ROW LEVEL SECURITY;

-- 5. Criar políticas RLS simples e funcionais
CREATE POLICY "Enable all access for authenticated users on own profiles" ON professional_profiles
    FOR ALL USING (auth.uid() = user_id);

-- 6. Garantir que a tabela tenha as permissões corretas
GRANT ALL ON professional_profiles TO authenticated;
GRANT ALL ON professional_profiles TO anon;

-- 7. Verificar se funcionou
SELECT 'Setup completed successfully' as status;
