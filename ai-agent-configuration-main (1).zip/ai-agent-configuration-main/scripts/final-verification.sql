-- Verificação final da configuração da tabela e políticas

-- 1. Verificar se a tabela existe e sua estrutura
SELECT 'Verificando estrutura da tabela...' as status;

SELECT 
    column_name,
    data_type,
    is_nullable,
    column_default
FROM information_schema.columns 
WHERE table_name = 'professional_profiles' 
    AND table_schema = 'public'
ORDER BY ordinal_position;

-- 2. Verificar se RLS está habilitado
SELECT 'Verificando RLS...' as status;

SELECT 
    schemaname,
    tablename,
    rowsecurity as rls_enabled
FROM pg_tables 
WHERE tablename = 'professional_profiles';

-- 3. Listar todas as políticas ativas
SELECT 'Verificando políticas...' as status;

SELECT 
    policyname,
    cmd as command,
    permissive,
    qual as using_expression,
    with_check
FROM pg_policies 
WHERE tablename = 'professional_profiles'
ORDER BY policyname;

-- 4. Contar registros existentes
SELECT 'Contando registros existentes...' as status;

SELECT COUNT(*) as total_profiles
FROM professional_profiles;

-- 5. Verificar usuário atual (se autenticado)
SELECT 'Verificando usuário atual...' as status;

SELECT 
    CASE 
        WHEN auth.uid() IS NOT NULL THEN 'Usuário autenticado: ' || auth.uid()::text
        ELSE 'Usuário não autenticado'
    END as auth_status;
