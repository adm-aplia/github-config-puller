-- 1. Primeiro, vamos testar se conseguimos acessar dados sem RLS
SELECT 
    'Teste sem RLS' as teste,
    id,
    user_id,
    email,
    name
FROM google_credentials 
LIMIT 3;

-- 2. Verificar se existe alguma sessão ativa
SELECT 
    'Verificação de sessão' as teste,
    auth.uid() as current_user_id,
    auth.role() as current_role,
    current_setting('request.jwt.claims', true) as jwt_claims;

-- 3. Tentar buscar dados de um usuário específico
SELECT 
    'Teste com user_id específico' as teste,
    id,
    user_id,
    email,
    name
FROM google_credentials 
WHERE user_id = 'ab30e7c4-40e8-4a4a-9ef7-cff0bbf00122';

-- 4. Reabilitar RLS na tabela
ALTER TABLE google_credentials ENABLE ROW LEVEL SECURITY;

-- 5. Verificar se RLS foi habilitado
SELECT 
    'Status RLS após habilitar' as teste,
    schemaname,
    tablename,
    rowsecurity as rls_enabled
FROM pg_tables 
WHERE tablename = 'google_credentials';

-- 6. Limpar políticas duplicadas (manter apenas as em inglês)
DROP POLICY IF EXISTS "Usuários podem ver suas próprias credenciais" ON google_credentials;
DROP POLICY IF EXISTS "Usuários podem atualizar suas próprias credenciais" ON google_credentials;
DROP POLICY IF EXISTS "Usuários podem excluir suas próprias credenciais" ON google_credentials;
DROP POLICY IF EXISTS "Permitir inserções sem usuário" ON google_credentials;

-- 7. Verificar políticas restantes
SELECT 
    'Políticas após limpeza' as teste,
    policyname,
    cmd as command,
    qual as policy_expression
FROM pg_policies 
WHERE tablename = 'google_credentials'
ORDER BY policyname;

-- 8. Testar acesso com RLS habilitado (deve falhar se auth.uid() for null)
SELECT 
    'Teste com RLS habilitado' as teste,
    COUNT(*) as registros_acessiveis
FROM google_credentials;
