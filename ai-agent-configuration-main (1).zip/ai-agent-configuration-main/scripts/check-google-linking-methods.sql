-- Verificar os dois métodos de vinculação de credenciais Google

-- 1. Método antigo: professional_profile_id na tabela google_credentials
SELECT 
  'google_credentials_direct' as method,
  gc.id,
  gc.email,
  gc.name,
  gc.professional_profile_id,
  pp.fullName as profile_name
FROM google_credentials gc
LEFT JOIN professional_profiles pp ON gc.professional_profile_id = pp.id
WHERE gc.user_id = 'ab30e7c4-40e8-4a4a-9ef7-cff0bbf00122';

-- 2. Método novo: tabela google_profile_links
SELECT 
  'google_profile_links' as method,
  gpl.google_credential_id,
  gpl.professional_profile_id,
  gc.email,
  gc.name,
  pp.fullName as profile_name
FROM google_profile_links gpl
JOIN google_credentials gc ON gpl.google_credential_id = gc.id
LEFT JOIN professional_profiles pp ON gpl.professional_profile_id = pp.id
WHERE gc.user_id = 'ab30e7c4-40e8-4a4a-9ef7-cff0bbf00122';

-- 3. Verificar se a tabela google_profile_links existe
SELECT EXISTS (
  SELECT FROM information_schema.tables 
  WHERE table_name = 'google_profile_links'
) as google_profile_links_exists;
