-- Primeiro, vamos ver os status atuais
SELECT DISTINCT status FROM appointments;

-- Atualizar os status existentes para os valores corretos em inglês
UPDATE appointments SET status = 'scheduled' WHERE status = 'agendado';
UPDATE appointments SET status = 'confirmed' WHERE status = 'confirmado';
UPDATE appointments SET status = 'completed' WHERE status = 'concluido' OR status = 'concluído';
UPDATE appointments SET status = 'cancelled' WHERE status = 'cancelado';
UPDATE appointments SET status = 'no-show' WHERE status = 'faltou' OR status = 'nao-compareceu';

-- Remover o constraint antigo se existir
ALTER TABLE appointments DROP CONSTRAINT IF EXISTS appointments_status_check;

-- Adicionar o novo constraint com os valores corretos
ALTER TABLE appointments ADD CONSTRAINT appointments_status_check 
CHECK (status IN ('scheduled', 'confirmed', 'completed', 'cancelled', 'no-show'));

-- Verificar se tudo está correto
SELECT status, COUNT(*) as count FROM appointments GROUP BY status;
