-- Configurar Nathan Almeida com Plano Profissional para testes
-- Este script configura a conta com plano profissional ativo

BEGIN;

-- 1. Primeiro, vamos verificar se o usuário Nathan existe
DO $$
DECLARE
    nathan_user_id UUID;
    nathan_cliente_id UUID;
BEGIN
    -- Buscar o user_id do Nathan
    SELECT id INTO nathan_user_id 
    FROM auth.users 
    WHERE email = 'nathancwb@gmail.com';
    
    IF nathan_user_id IS NULL THEN
        RAISE EXCEPTION 'Usuário Nathan não encontrado';
    END IF;
    
    RAISE NOTICE 'Nathan User ID encontrado: %', nathan_user_id;
    
    -- 2. Verificar/Criar cliente na tabela clientes
    SELECT id INTO nathan_cliente_id 
    FROM clientes 
    WHERE user_id = nathan_user_id;
    
    IF nathan_cliente_id IS NULL THEN
        -- Criar cliente se não existir
        INSERT INTO clientes (
            nome,
            email,
            telefone,
            cpf_cnpj,
            plano,
            data_contratacao,
            status,
            user_id,
            is_active
        ) VALUES (
            'Nathan Almeida',
            'nathancwb@gmail.com',
            '41995824404',
            '12345678901', -- CPF fictício para testes
            'Profissional',
            NOW(),
            'ativo',
            nathan_user_id,
            true
        ) RETURNING id INTO nathan_cliente_id;
        
        RAISE NOTICE 'Cliente criado com ID: %', nathan_cliente_id;
    ELSE
        -- Atualizar cliente existente para plano Profissional
        UPDATE clientes SET
            plano = 'Profissional',
            status = 'ativo',
            is_active = true,
            data_contratacao = NOW()
        WHERE id = nathan_cliente_id;
        
        RAISE NOTICE 'Cliente atualizado com ID: %', nathan_cliente_id;
    END IF;
    
    -- 3. Criar/Atualizar assinatura ativa
    INSERT INTO assinaturas (
        id_cliente_supabase,
        customer_id_asaas,
        subscription_id,
        plano,
        valor,
        descricao,
        status,
        data_contratacao,
        next_due_date
    ) VALUES (
        nathan_cliente_id,
        'cus_test_nathan', -- ID fictício para testes
        'sub_test_nathan', -- ID fictício para testes
        'Profissional',
        399.00,
        'Plano Profissional Aplia – 3 números WhatsApp, até 1000 agendamentos, 3 assistentes, suporte prioritário, relatórios avançados.',
        'ACTIVE',
        NOW(),
        NOW() + INTERVAL '1 month'
    )
    ON CONFLICT (id_cliente_supabase) 
    DO UPDATE SET
        plano = 'Profissional',
        valor = 399.00,
        status = 'ACTIVE',
        next_due_date = NOW() + INTERVAL '1 month';
    
    RAISE NOTICE 'Assinatura configurada para plano Profissional';
    
    -- 4. Configurar/Resetar contadores de uso
    INSERT INTO cliente_usage (
        cliente_id,
        whatsapp_instances_used,
        appointments_this_month,
        assistants_created,
        last_reset_date
    ) VALUES (
        nathan_cliente_id,
        0, -- Resetar para 0 para permitir testes
        0, -- Resetar para 0 para permitir testes
        0, -- Resetar para 0 para permitir testes
        NOW()
    )
    ON CONFLICT (cliente_id)
    DO UPDATE SET
        whatsapp_instances_used = 0,
        appointments_this_month = 0,
        assistants_created = 0,
        last_reset_date = NOW();
    
    RAISE NOTICE 'Contadores de uso resetados';
    
END $$;

-- 5. Verificar configuração final
SELECT 
    c.nome,
    c.email,
    c.plano,
    c.status,
    c.is_active,
    a.valor,
    a.status as assinatura_status,
    u.whatsapp_instances_used,
    u.appointments_this_month,
    u.assistants_created
FROM clientes c
LEFT JOIN assinaturas a ON c.id = a.id_cliente_supabase
LEFT JOIN cliente_usage u ON c.id = u.cliente_id
WHERE c.email = 'nathancwb@gmail.com';

COMMIT;
