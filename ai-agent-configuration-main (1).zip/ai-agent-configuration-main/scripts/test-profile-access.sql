-- Script para testar acesso ao perfil específico do usuário

-- 1. Verificar se conseguimos acessar o perfil do Nathan
SELECT 
    'Testando acesso ao perfil do Nathan:' as teste,
    id,
    name,
    email,
    first_name,
    last_name,
    created_at
FROM profiles 
WHERE id = 'ab30e7c4-40e8-4a4a-9ef7-cff0bbf00122'
   OR email = 'nathancwb@gmail.com';

-- 2. Verificar políticas ativas
SELECT 
    'Políticas ativas:' as info,
    policyname,
    cmd,
    qual
FROM pg_policies 
WHERE tablename = 'profiles';

-- 3. Simular o que a aplicação faz
-- (Este comando só funcionará se executado com o contexto do usuário correto)
SELECT 
    'Simulando busca da aplicação:' as info,
    'auth.uid() atual:' as contexto,
    auth.uid() as user_id;

-- 4. Contar perfis acessíveis
SELECT 
    'Perfis acessíveis:' as info,
    COUNT(*) as total_profiles
FROM profiles;
