-- Corrigir conta do Nathan para testes
-- 1. Ativar temporariamente o plano para teste
UPDATE clientes 
SET 
  is_active = true,
  status = 'ativo',
  updated_at = NOW()
WHERE email = 'nathancwb@gmail.com';

-- 2. Sincronizar uso real de WhatsApp
UPDATE cliente_usage 
SET 
  whatsapp_instances_used = (
    SELECT COUNT(*) 
    FROM whatsapp_instances w 
    INNER JOIN clientes c ON w.user_id = c.user_id 
    WHERE c.email = 'nathancwb@gmail.com'
  ),
  updated_at = NOW()
WHERE cliente_id = (
  SELECT id FROM clientes WHERE email = 'nathancwb@gmail.com'
);

-- 3. Verificar se a correção funcionou
SELECT 
  'Verificação pós-correção:' as status,
  c.email,
  c.is_active,
  c.status,
  c.plano,
  p.whatsapp_instances as limite,
  cu.whatsapp_instances_used as uso_atual,
  (SELECT COUNT(*) FROM whatsapp_instances w WHERE w.user_id = c.user_id) as instancias_reais
FROM clientes c
LEFT JOIN planos p ON c.plano = p.nome
LEFT JOIN cliente_usage cu ON cu.cliente_id = c.id
WHERE c.email = 'nathancwb@gmail.com';
