-- Verificar status do usuário nathancwb@gmail.com
DO $$
DECLARE
    user_record RECORD;
    cliente_record RECORD;
    usage_record RECORD;
BEGIN
    -- Buscar usuário
    SELECT * INTO user_record 
    FROM auth.users 
    WHERE email = 'nathancwb@gmail.com';
    
    IF user_record.id IS NULL THEN
        RAISE NOTICE 'Usuário não encontrado!';
        RETURN;
    END IF;
    
    RAISE NOTICE 'Usuário encontrado: % (ID: %)', user_record.email, user_record.id;
    
    -- Buscar cliente
    SELECT * INTO cliente_record 
    FROM clientes 
    WHERE user_id = user_record.id;
    
    IF cliente_record.id IS NULL THEN
        RAISE NOTICE 'PROBLEMA: Cliente não encontrado para este usuário!';
        RAISE NOTICE 'Criando cliente automaticamente...';
        
        INSERT INTO clientes (
            user_id,
            nome,
            email,
            plano,
            status,
            is_active,
            created_at,
            updated_at
        ) VALUES (
            user_record.id,
            COALESCE(user_record.raw_user_meta_data->>'name', split_part(user_record.email, '@', 1)),
            user_record.email,
            'trial', -- Plano trial por padrão
            'ativo',
            true,
            NOW(),
            NOW()
        );
        
        RAISE NOTICE 'Cliente criado com plano trial!';
    ELSE
        RAISE NOTICE 'Cliente encontrado: % (Plano: %, Status: %, Ativo: %)', 
                     cliente_record.nome, cliente_record.plano, cliente_record.status, cliente_record.is_active;
    END IF;
    
    -- Verificar uso atual
    SELECT * INTO usage_record 
    FROM cliente_usage 
    WHERE cliente_id = cliente_record.id;
    
    IF usage_record.id IS NULL THEN
        RAISE NOTICE 'Registro de uso não encontrado, criando...';
        INSERT INTO cliente_usage (cliente_id) VALUES (cliente_record.id);
        RAISE NOTICE 'Registro de uso criado!';
    ELSE
        RAISE NOTICE 'Uso atual - WhatsApp: %, Agendamentos: %, Assistentes: %',
                     usage_record.whatsapp_instances_used,
                     usage_record.appointments_this_month,
                     usage_record.assistants_created;
    END IF;
    
    -- Mostrar limites do plano
    DECLARE
        plano_record RECORD;
    BEGIN
        SELECT * INTO plano_record 
        FROM planos 
        WHERE nome = COALESCE(cliente_record.plano, 'trial');
        
        IF plano_record.id IS NOT NULL THEN
            RAISE NOTICE 'Limites do plano % - WhatsApp: %, Agendamentos: %, Assistentes: %',
                         plano_record.nome,
                         plano_record.whatsapp_instances,
                         plano_record.max_appointments,
                         plano_record.max_assistants;
        END IF;
    END;
END $$;
