-- Criar tabelas e colunas que estão faltando

-- 1. Garantir que a tabela google_credentials existe
CREATE TABLE IF NOT EXISTS public.google_credentials (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT,
    access_token TEXT,
    refresh_token TEXT,
    expires_at TIMESTAMPTZ,
    name TEXT,
    picture TEXT,
    professional_profile_id UUID REFERENCES public.professional_profiles(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Verificar e adicionar colunas faltantes na tabela professional_profiles
DO $$ 
BEGIN
    -- Verificar se todas as colunas necessárias existem
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'fullname') THEN
        ALTER TABLE public.professional_profiles ADD COLUMN fullName TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'specialty') THEN
        ALTER TABLE public.professional_profiles ADD COLUMN specialty TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'professionalid') THEN
        ALTER TABLE public.professional_profiles ADD COLUMN professionalId TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'phonenumber') THEN
        ALTER TABLE public.professional_profiles ADD COLUMN phoneNumber TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'email') THEN
        ALTER TABLE public.professional_profiles ADD COLUMN email TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'education') THEN
        ALTER TABLE public.professional_profiles ADD COLUMN education TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'locations') THEN
        ALTER TABLE public.professional_profiles ADD COLUMN locations TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'workinghours') THEN
        ALTER TABLE public.professional_profiles ADD COLUMN workingHours TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'procedures') THEN
        ALTER TABLE public.professional_profiles ADD COLUMN procedures TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'healthinsurance') THEN
        ALTER TABLE public.professional_profiles ADD COLUMN healthInsurance TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'paymentmethods') THEN
        ALTER TABLE public.professional_profiles ADD COLUMN paymentMethods TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'consultationfees') THEN
        ALTER TABLE public.professional_profiles ADD COLUMN consultationFees TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'cancellationpolicy') THEN
        ALTER TABLE public.professional_profiles ADD COLUMN cancellationPolicy TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'consultationduration') THEN
        ALTER TABLE public.professional_profiles ADD COLUMN consultationDuration TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'timebetweenconsultations') THEN
        ALTER TABLE public.professional_profiles ADD COLUMN timeBetweenConsultations TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'reschedulingpolicy') THEN
        ALTER TABLE public.professional_profiles ADD COLUMN reschedulingPolicy TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'onlineconsultations') THEN
        ALTER TABLE public.professional_profiles ADD COLUMN onlineConsultations TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'reminderpreferences') THEN
        ALTER TABLE public.professional_profiles ADD COLUMN reminderPreferences TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'requiredpatientinfo') THEN
        ALTER TABLE public.professional_profiles ADD COLUMN requiredPatientInfo TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'appointmentconditions') THEN
        ALTER TABLE public.professional_profiles ADD COLUMN appointmentConditions TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'medicalhistoryrequirements') THEN
        ALTER TABLE public.professional_profiles ADD COLUMN medicalHistoryRequirements TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'agerequirements') THEN
        ALTER TABLE public.professional_profiles ADD COLUMN ageRequirements TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'communicationchannels') THEN
        ALTER TABLE public.professional_profiles ADD COLUMN communicationChannels TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'preappointmentinfo') THEN
        ALTER TABLE public.professional_profiles ADD COLUMN preAppointmentInfo TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'requireddocuments') THEN
        ALTER TABLE public.professional_profiles ADD COLUMN requiredDocuments TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'avatar_url') THEN
        ALTER TABLE public.professional_profiles ADD COLUMN avatar_url TEXT;
    END IF;
END $$;
