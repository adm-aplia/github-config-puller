-- Verificar se há usuários autenticados
SELECT 'Verificando usuários na tabela auth.users:' as debug_step;
SELECT id, email, created_at FROM auth.users LIMIT 5;

-- Verificar se há clientes cadastrados
SELECT 'Verificando tabela clientes (todos os registros):' as debug_step;
SELECT * FROM clientes LIMIT 10;

-- Verificar se há instâncias WhatsApp criadas
SELECT 'Verificando instâncias WhatsApp existentes:' as debug_step;
SELECT * FROM whatsapp_instances LIMIT 10;

-- Verificar se a tabela cliente_usage existe e tem dados
SELECT 'Verificando estrutura da tabela cliente_usage:' as debug_step;
SELECT column_name, data_type, is_nullable 
FROM information_schema.columns 
WHERE table_name = 'cliente_usage';

-- Verificar todos os registros de cliente_usage
SELECT 'Verificando todos os registros de cliente_usage:' as debug_step;
SELECT * FROM cliente_usage;
