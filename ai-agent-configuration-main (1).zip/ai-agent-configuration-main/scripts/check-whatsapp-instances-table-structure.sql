-- Verificar a estrutura da tabela whatsapp_instances
SELECT 
    column_name,
    data_type,
    is_nullable,
    column_default
FROM information_schema.columns 
WHERE table_name = 'whatsapp_instances' 
    AND table_schema = 'public'
ORDER BY ordinal_position;

-- Verificar se existem registros na tabela
SELECT 
    COUNT(*) as total_records,
    COUNT(CASE WHEN status = 'connected' THEN 1 END) as connected_count,
    COUNT(CASE WHEN status = 'disconnected' THEN 1 END) as disconnected_count,
    COUNT(DISTINCT user_id) as unique_users
FROM whatsapp_instances;

-- Verificar registros por usuário
SELECT 
    user_id,
    COUNT(*) as instance_count,
    COUNT(CASE WHEN status = 'connected' THEN 1 END) as connected_count,
    array_agg(instance_name) as instance_names,
    array_agg(status) as statuses
FROM whatsapp_instances 
GROUP BY user_id
ORDER BY instance_count DESC;

-- Verificar se a tabela permite múltiplas instâncias por usuário
SELECT 
    user_id,
    instance_name,
    status,
    profile_name,
    phone_number,
    created_at
FROM whatsapp_instances 
ORDER BY user_id, created_at DESC
LIMIT 20;
