-- Debug completo da tabela professional_profiles
DO $$
DECLARE
    rec RECORD;
    count_result INTEGER;
BEGIN
    -- Verificar se a tabela existe
    IF EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'professional_profiles') THEN
        RAISE NOTICE 'Tabela professional_profiles existe';
        
        -- Verificar estrutura da tabela
        RAISE NOTICE 'Estrutura da tabela:';
        FOR rec IN 
            SELECT column_name, data_type, is_nullable 
            FROM information_schema.columns 
            WHERE table_name = 'professional_profiles' 
            ORDER BY ordinal_position
        LOOP
            RAISE NOTICE 'Coluna: % | Tipo: % | Nullable: %', rec.column_name, rec.data_type, rec.is_nullable;
        END LOOP;
        
        -- Contar registros totais
        SELECT COUNT(*) INTO count_result FROM professional_profiles;
        RAISE NOTICE 'Total de registros: %', count_result;
        
        -- Verificar registros por usuário
        FOR rec IN 
            SELECT user_id, COUNT(*) as count 
            FROM professional_profiles 
            GROUP BY user_id
        LOOP
            RAISE NOTICE 'User ID: % | Perfis: %', rec.user_id, rec.count;
        END LOOP;
        
        -- Mostrar alguns registros de exemplo (usando "fullName" correto)
        RAISE NOTICE 'Primeiros 3 registros:';
        FOR rec IN 
            SELECT id, user_id, 
                   COALESCE("fullName", 'SEM_NOME') as nome,
                   COALESCE(specialty, 'SEM_ESPECIALIDADE') as especialidade,
                   created_at
            FROM professional_profiles 
            ORDER BY created_at DESC 
            LIMIT 3
        LOOP
            RAISE NOTICE 'ID: % | User: % | Nome: % | Especialidade: % | Criado: %', 
                         rec.id, rec.user_id, rec.nome, rec.especialidade, rec.created_at;
        END LOOP;
        
    ELSE
        RAISE NOTICE 'Tabela professional_profiles NÃO existe!';
        
        -- Criar a tabela se não existir (usando "fullName" correto)
        CREATE TABLE professional_profiles (
            id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
            user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
            "fullName" TEXT,
            specialty TEXT,
            "professionalId" TEXT,
            email TEXT,
            "phoneNumber" TEXT,
            education TEXT,
            procedures TEXT,
            created_at TIMESTAMPTZ DEFAULT NOW(),
            updated_at TIMESTAMPTZ DEFAULT NOW()
        );
        
        -- Habilitar RLS
        ALTER TABLE professional_profiles ENABLE ROW LEVEL SECURITY;
        
        -- Criar políticas básicas
        DROP POLICY IF EXISTS "Users can view own profiles" ON professional_profiles;
        DROP POLICY IF EXISTS "Users can insert own profiles" ON professional_profiles;
        DROP POLICY IF EXISTS "Users can update own profiles" ON professional_profiles;
        DROP POLICY IF EXISTS "Users can delete own profiles" ON professional_profiles;
        
        CREATE POLICY "Users can view own profiles" ON professional_profiles
            FOR SELECT USING (auth.uid() = user_id);
            
        CREATE POLICY "Users can insert own profiles" ON professional_profiles
            FOR INSERT WITH CHECK (auth.uid() = user_id);
            
        CREATE POLICY "Users can update own profiles" ON professional_profiles
            FOR UPDATE USING (auth.uid() = user_id);
            
        CREATE POLICY "Users can delete own profiles" ON professional_profiles
            FOR DELETE USING (auth.uid() = user_id);
        
        RAISE NOTICE 'Tabela professional_profiles criada com sucesso!';
    END IF;
    
    -- Verificar usuário atual
    IF auth.uid() IS NOT NULL THEN
        RAISE NOTICE 'Usuário atual autenticado: %', auth.uid();
        
        -- Verificar perfis do usuário atual
        SELECT COUNT(*) INTO count_result 
        FROM professional_profiles 
        WHERE user_id = auth.uid();
        RAISE NOTICE 'Perfis do usuário atual: %', count_result;
        
        -- Se não há perfis, criar um de exemplo (usando "fullName" correto)
        IF count_result = 0 THEN
            INSERT INTO professional_profiles (
                user_id, 
                "fullName", 
                specialty, 
                email,
                created_at
            ) VALUES (
                auth.uid(),
                'Dr. Exemplo',
                'Clínico Geral',
                'exemplo@email.com',
                NOW()
            );
            RAISE NOTICE 'Perfil de exemplo criado para o usuário atual';
        END IF;
        
    ELSE
        RAISE NOTICE 'Nenhum usuário autenticado no momento';
    END IF;
    
END $$;
