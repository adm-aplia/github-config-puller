-- Verificação simples da tabela professional_profiles
SELECT 'Verificando tabela professional_profiles...' as status;

-- Verificar se a tabela existe
SELECT 
    CASE 
        WHEN EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'professional_profiles') 
        THEN 'Tabela EXISTS' 
        ELSE 'Tabela NÃO EXISTE' 
    END as table_status;

-- Se a tabela existe, mostrar informações
SELECT 
    COUNT(*) as total_records,
    COUNT(DISTINCT user_id) as unique_users
FROM professional_profiles;

-- Mostrar estrutura das colunas
SELECT 
    column_name,
    data_type,
    is_nullable
FROM information_schema.columns 
WHERE table_name = 'professional_profiles' 
ORDER BY ordinal_position;

-- Mostrar alguns registros (usando "fullName" correto)
SELECT 
    id,
    user_id,
    "fullName",
    specialty,
    created_at
FROM professional_profiles 
ORDER BY created_at DESC 
LIMIT 5;

-- Verificar usuário atual
SELECT 
    auth.uid() as current_user_id,
    CASE 
        WHEN auth.uid() IS NOT NULL THEN 'AUTENTICADO' 
        ELSE 'NÃO AUTENTICADO' 
    END as auth_status;

-- Contar perfis do usuário atual
SELECT 
    COUNT(*) as my_profiles_count
FROM professional_profiles 
WHERE user_id = auth.uid();
