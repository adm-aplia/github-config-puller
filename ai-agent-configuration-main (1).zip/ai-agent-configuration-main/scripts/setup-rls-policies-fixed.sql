-- Script para configurar políticas RLS de forma segura
-- Remove e recria todas as políticas para evitar conflitos

DO $$
DECLARE
    policy_record RECORD;
BEGIN
    -- Listar e remover todas as políticas existentes da tabela
    FOR policy_record IN 
        SELECT policyname 
        FROM pg_policies 
        WHERE tablename = 'professional_profiles'
    LOOP
        EXECUTE format('DROP POLICY IF EXISTS %I ON professional_profiles', policy_record.policyname);
        RAISE NOTICE 'Política removida: %', policy_record.policyname;
    END LOOP;
    
    -- Habilitar RLS se não estiver habilitado
    ALTER TABLE professional_profiles ENABLE ROW LEVEL SECURITY;
    RAISE NOTICE 'RLS habilitado na tabela professional_profiles';
    
    -- Criar políticas com nomes únicos e timestamp
    EXECUTE format('CREATE POLICY "view_profiles_%s" ON professional_profiles FOR SELECT USING (auth.uid() = user_id)', 
                   extract(epoch from now())::bigint);
    
    EXECUTE format('CREATE POLICY "insert_profiles_%s" ON professional_profiles FOR INSERT WITH CHECK (auth.uid() = user_id)', 
                   extract(epoch from now())::bigint);
    
    EXECUTE format('CREATE POLICY "update_profiles_%s" ON professional_profiles FOR UPDATE USING (auth.uid() = user_id)', 
                   extract(epoch from now())::bigint);
    
    EXECUTE format('CREATE POLICY "delete_profiles_%s" ON professional_profiles FOR DELETE USING (auth.uid() = user_id)', 
                   extract(epoch from now())::bigint);
    
    RAISE NOTICE 'Novas políticas RLS criadas com sucesso';
    
EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Erro ao configurar políticas: %', SQLERRM;
        -- Continuar mesmo com erro
END $$;

-- Verificar políticas criadas
SELECT 
    schemaname,
    tablename,
    policyname,
    permissive,
    cmd,
    qual,
    with_check
FROM pg_policies 
WHERE tablename = 'professional_profiles'
ORDER BY policyname;

-- Verificar se RLS está habilitado
SELECT 
    schemaname,
    tablename,
    rowsecurity
FROM pg_tables 
WHERE tablename = 'professional_profiles';
