-- Script para corrigir incompatibilidade de user_id
-- Este script atualiza o user_id na tabela google_credentials para corresponder ao ID atual do usuário

-- Primeiro, vamos verificar o estado atual
SELECT 
  'ANTES DA CORREÇÃO' as status,
  gc.id,
  gc.user_id as current_user_id,
  gc.email,
  au.id as auth_user_id
FROM google_credentials gc
LEFT JOIN auth.users au ON au.email = gc.email
WHERE gc.email = 'nathancwb@gmail.com';

-- Atualizar o user_id na tabela google_credentials para corresponder ao auth.users
UPDATE google_credentials 
SET user_id = (
  SELECT id 
  FROM auth.users 
  WHERE email = google_credentials.email
)
WHERE email = 'nathancwb@gmail.com'
AND user_id != (
  SELECT id 
  FROM auth.users 
  WHERE email = google_credentials.email
);

-- Verificar o resultado após a correção
SELECT 
  'APÓS A CORREÇÃO' as status,
  gc.id,
  gc.user_id as updated_user_id,
  gc.email,
  au.id as auth_user_id,
  CASE 
    WHEN gc.user_id = au.id THEN 'MATCH ✓'
    ELSE 'MISMATCH ✗'
  END as id_status
FROM google_credentials gc
LEFT JOIN auth.users au ON au.email = gc.email
WHERE gc.email = 'nathancwb@gmail.com';
