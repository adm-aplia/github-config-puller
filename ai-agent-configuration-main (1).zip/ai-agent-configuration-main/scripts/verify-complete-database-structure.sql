-- Verificar estrutura completa do banco de dados
-- Este script verifica todas as tabelas necessárias e suas colunas

-- 1. Verificar tabela professional_profiles
SELECT 
    'professional_profiles' as table_name,
    column_name,
    data_type,
    is_nullable,
    column_default
FROM information_schema.columns 
WHERE table_name = 'professional_profiles' 
    AND table_schema = 'public'
ORDER BY ordinal_position;

-- 2. Verificar tabela google_credentials
SELECT 
    'google_credentials' as table_name,
    column_name,
    data_type,
    is_nullable,
    column_default
FROM information_schema.columns 
WHERE table_name = 'google_credentials' 
    AND table_schema = 'public'
ORDER BY ordinal_position;

-- 3. Verificar tabela profiles (básica)
SELECT 
    'profiles' as table_name,
    column_name,
    data_type,
    is_nullable,
    column_default
FROM information_schema.columns 
WHERE table_name = 'profiles' 
    AND table_schema = 'public'
ORDER BY ordinal_position;

-- 4. Verificar políticas RLS
SELECT 
    schemaname,
    tablename,
    policyname,
    permissive,
    roles,
    cmd,
    qual,
    with_check
FROM pg_policies 
WHERE tablename IN ('professional_profiles', 'google_credentials', 'profiles')
ORDER BY tablename, policyname;

-- 5. Verificar se RLS está habilitado
SELECT 
    schemaname,
    tablename,
    rowsecurity
FROM pg_tables 
WHERE tablename IN ('professional_profiles', 'google_credentials', 'profiles')
    AND schemaname = 'public';
