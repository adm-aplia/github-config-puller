-- Testar se conseguimos buscar diretamente as credenciais Google
-- para o user_id específico

-- TESTE 1: Busca direta sem RLS
SELECT 
  'DIRECT QUERY WITHOUT RLS' as test_type,
  id,
  user_id,
  email,
  name,
  created_at
FROM google_credentials 
WHERE user_id = 'ab30e7c4-40e8-4a4a-9ef7-cff0bbf00122';

-- TESTE 2: Verificar se RLS está habilitado (versão corrigida)
SELECT 
  'RLS STATUS' as test_type,
  schemaname,
  tablename,
  rowsecurity as rls_enabled
FROM pg_tables t
JOIN pg_class c ON c.relname = t.tablename
WHERE tablename = 'google_credentials';

-- TESTE 3: Listar políticas RLS da tabela
SELECT 
  'RLS POLICIES' as test_type,
  schemaname,
  tablename,
  policyname,
  permissive,
  roles,
  cmd,
  qual,
  with_check
FROM pg_policies 
WHERE tablename = 'google_credentials';

-- TESTE 4: Buscar TODAS as credenciais (para ver se a tabela responde)
SELECT 
  'ALL CREDENTIALS' as test_type,
  id,
  user_id,
  email,
  name,
  created_at
FROM google_credentials 
ORDER BY created_at DESC
LIMIT 5;

-- TESTE 5: Verificar se a tabela professional_profiles também tem dados
SELECT 
  'PROFESSIONAL PROFILES CHECK' as test_type,
  id,
  user_id,
  "fullName",
  specialty,
  created_at
FROM professional_profiles 
WHERE user_id = 'ab30e7c4-40e8-4a4a-9ef7-cff0bbf00122';

-- TESTE 6: Verificar todas as tabelas relacionadas
SELECT 
  'TABLE EXISTS CHECK' as test_type,
  table_name,
  table_schema
FROM information_schema.tables 
WHERE table_name IN ('google_credentials', 'professional_profiles', 'google_profile_links')
ORDER BY table_name;

-- TESTE 7: Verificar estrutura da tabela google_credentials
SELECT 
  'GOOGLE_CREDENTIALS STRUCTURE' as test_type,
  column_name,
  data_type,
  is_nullable
FROM information_schema.columns 
WHERE table_name = 'google_credentials'
ORDER BY ordinal_position;
