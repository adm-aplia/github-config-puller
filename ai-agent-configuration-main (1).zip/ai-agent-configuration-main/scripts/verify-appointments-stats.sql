-- Script para verificar as estatísticas de agendamentos
-- Execute este script para verificar se os dados estão corretos

-- 1. Verificar estrutura da tabela appointments
SELECT 
    column_name,
    data_type,
    is_nullable,
    column_default
FROM information_schema.columns 
WHERE table_name = 'appointments'
ORDER BY ordinal_position;

-- 2. Contar total de agendamentos por usuário
SELECT 
    user_id,
    COUNT(*) as total_agendamentos
FROM appointments 
GROUP BY user_id
ORDER BY total_agendamentos DESC;

-- 3. Estatísticas por status (geral)
SELECT 
    status,
    COUNT(*) as quantidade,
    ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER (), 2) as percentual
FROM appointments 
GROUP BY status
ORDER BY quantidade DESC;

-- 4. Estatísticas por mês
SELECT 
    DATE_TRUNC('month', appointment_date) as mes,
    COUNT(*) as total,
    COUNT(CASE WHEN status = 'scheduled' THEN 1 END) as pendentes,
    COUNT(CASE WHEN status = 'confirmed' THEN 1 END) as confirmados,
    COUNT(CASE WHEN status = 'completed' THEN 1 END) as concluidos,
    COUNT(CASE WHEN status = 'cancelled' THEN 1 END) as cancelados,
    COUNT(CASE WHEN status = 'no-show' THEN 1 END) as faltas
FROM appointments 
GROUP BY DATE_TRUNC('month', appointment_date)
ORDER BY mes DESC
LIMIT 6;

-- 5. Agendamentos por dia da semana
SELECT 
    EXTRACT(DOW FROM appointment_date) as dia_semana,
    CASE EXTRACT(DOW FROM appointment_date)
        WHEN 0 THEN 'Domingo'
        WHEN 1 THEN 'Segunda'
        WHEN 2 THEN 'Terça'
        WHEN 3 THEN 'Quarta'
        WHEN 4 THEN 'Quinta'
        WHEN 5 THEN 'Sexta'
        WHEN 6 THEN 'Sábado'
    END as nome_dia,
    COUNT(*) as total_agendamentos
FROM appointments 
GROUP BY EXTRACT(DOW FROM appointment_date)
ORDER BY dia_semana;

-- 6. Agendamentos por horário
SELECT 
    appointment_time,
    COUNT(*) as quantidade
FROM appointments 
GROUP BY appointment_time
ORDER BY appointment_time;

-- 7. Verificar dados de teste específicos
SELECT 
    patient_name,
    appointment_date,
    appointment_time,
    status,
    created_at
FROM appointments 
WHERE patient_name LIKE 'Paciente Teste%'
ORDER BY appointment_date DESC;

-- 8. Estatísticas do mês atual
SELECT 
    'Mês Atual' as periodo,
    COUNT(*) as total,
    COUNT(CASE WHEN status = 'scheduled' THEN 1 END) as pendentes,
    COUNT(CASE WHEN status = 'confirmed' THEN 1 END) as confirmados,
    COUNT(CASE WHEN status = 'completed' THEN 1 END) as concluidos,
    COUNT(CASE WHEN status = 'cancelled' THEN 1 END) as cancelados,
    COUNT(CASE WHEN status = 'no-show' THEN 1 END) as faltas
FROM appointments 
WHERE appointment_date >= DATE_TRUNC('month', CURRENT_DATE)
  AND appointment_date < DATE_TRUNC('month', CURRENT_DATE) + INTERVAL '1 month';

-- 9. Verificar se há dados suficientes para teste
SELECT 
    CASE 
        WHEN COUNT(*) = 0 THEN 'ERRO: Nenhum agendamento encontrado'
        WHEN COUNT(*) < 10 THEN 'AVISO: Poucos agendamentos para teste'
        ELSE 'OK: Dados suficientes para teste'
    END as status_dados,
    COUNT(*) as total_agendamentos
FROM appointments;

-- 10. Últimos agendamentos criados
SELECT 
    patient_name,
    appointment_date,
    status,
    created_at
FROM appointments 
ORDER BY created_at DESC
LIMIT 10;
