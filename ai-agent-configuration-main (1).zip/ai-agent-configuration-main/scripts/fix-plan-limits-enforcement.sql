-- Corrigir dados dos planos se necessário
INSERT INTO planos (nome, preco, whatsapp_instances, max_appointments, max_assistants, support_level, advanced_reports, hospital_integration, advanced_customization, api_access, priority_support, custom_branding)
VALUES 
  ('Básico', 29.90, 1, 300, 1, 'email', false, false, false, false, false, false),
  ('Profissional', 79.90, 3, 1000, 3, 'priority', true, false, false, false, true, false),
  ('Empresarial', 199.90, 10, -1, -1, '24/7', true, true, true, true, true, true)
ON CONFLICT (nome) DO UPDATE SET
  whatsapp_instances = EXCLUDED.whatsapp_instances,
  max_appointments = EXCLUDED.max_appointments,
  max_assistants = EXCLUDED.max_assistants,
  support_level = EXCLUDED.support_level,
  advanced_reports = EXCLUDED.advanced_reports,
  hospital_integration = EXCLUDED.hospital_integration,
  advanced_customization = EXCLUDED.advanced_customization,
  api_access = EXCLUDED.api_access,
  priority_support = EXCLUDED.priority_support,
  custom_branding = EXCLUDED.custom_branding;

-- Criar ou atualizar registros de uso para todos os clientes ativos
INSERT INTO cliente_usage (cliente_id, whatsapp_instances_used, appointments_this_month, assistants_created)
SELECT 
  c.id,
  COALESCE((SELECT COUNT(*) FROM whatsapp_instances w WHERE w.user_id = c.user_id), 0),
  0, -- appointments serão contados separadamente
  COALESCE((SELECT COUNT(*) FROM professional_profiles p WHERE p.user_id = c.user_id), 0)
FROM clientes c
WHERE c.is_active = true
ON CONFLICT (cliente_id) DO UPDATE SET
  whatsapp_instances_used = EXCLUDED.whatsapp_instances_used,
  assistants_created = EXCLUDED.assistants_created;
