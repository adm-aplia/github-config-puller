-- Testar se auth.uid() está retornando o valor correto

-- TESTE 1: Verificar se auth.uid() retorna algo
SELECT 
  'AUTH UID TEST' as test_type,
  auth.uid() as current_auth_uid,
  CASE 
    WHEN auth.uid() IS NULL THEN 'NULL - Usuário não autenticado'
    ELSE 'AUTHENTICATED - Usuário logado'
  END as auth_status;

-- TESTE 2: Comparar auth.uid() com o user_id esperado
SELECT 
  'AUTH UID COMPARISON' as test_type,
  auth.uid() as current_auth_uid,
  'ab30e7c4-40e8-4a4a-9ef7-cff0bbf00122' as expected_user_id,
  CASE 
    WHEN auth.uid() = 'ab30e7c4-40e8-4a4a-9ef7-cff0bbf00122' THEN 'MATCH - RLS permitirá acesso'
    WHEN auth.uid() IS NULL THEN 'NULL - Usuário não autenticado'
    ELSE 'DIFFERENT - RLS bloqueará acesso'
  END as comparison_result;

-- TESTE 3: Tentar buscar credenciais com RLS ativo (simulando a aplicação)
SELECT 
  'RLS QUERY TEST' as test_type,
  COUNT(*) as credentials_found,
  CASE 
    WHEN COUNT(*) > 0 THEN 'SUCCESS - RLS permitiu acesso'
    ELSE 'BLOCKED - RLS bloqueou acesso'
  END as rls_result
FROM google_credentials 
WHERE user_id = 'ab30e7c4-40e8-4a4a-9ef7-cff0bbf00122';

-- TESTE 4: Verificar sessão atual
SELECT 
  'SESSION INFO' as test_type,
  current_setting('request.jwt.claims', true) as jwt_claims;
