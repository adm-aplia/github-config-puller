-- Verificar estrutura completa da tabela professional_profiles (Versão Final)

-- 1. Verificar se a tabela existe
SELECT 
    schemaname,
    tablename,
    tableowner,
    hasindexes,
    hasrules,
    hastriggers
FROM pg_tables 
WHERE tablename = 'professional_profiles';

-- 2. Verificar estrutura das colunas
SELECT 
    column_name,
    data_type,
    character_maximum_length,
    is_nullable,
    column_default,
    ordinal_position
FROM information_schema.columns 
WHERE table_name = 'professional_profiles' 
    AND table_schema = 'public'
ORDER BY ordinal_position;

-- 3. Verificar constraints (chaves primárias, estrangeiras, etc.)
SELECT 
    tc.constraint_name,
    tc.constraint_type,
    kcu.column_name,
    ccu.table_name AS foreign_table_name,
    ccu.column_name AS foreign_column_name
FROM information_schema.table_constraints AS tc 
JOIN information_schema.key_column_usage AS kcu
    ON tc.constraint_name = kcu.constraint_name
    AND tc.table_schema = kcu.table_schema
LEFT JOIN information_schema.constraint_column_usage AS ccu
    ON ccu.constraint_name = tc.constraint_name
    AND ccu.table_schema = tc.table_schema
WHERE tc.table_name = 'professional_profiles'
    AND tc.table_schema = 'public';

-- 4. Verificar índices
SELECT 
    indexname,
    indexdef
FROM pg_indexes 
WHERE tablename = 'professional_profiles'
    AND schemaname = 'public';

-- 5. Verificar RLS (Row Level Security)
SELECT 
    schemaname,
    tablename,
    rowsecurity
FROM pg_tables 
WHERE tablename = 'professional_profiles';

-- 6. Verificar policies RLS
SELECT 
    policyname,
    permissive,
    roles,
    cmd,
    qual,
    with_check
FROM pg_policies 
WHERE tablename = 'professional_profiles'
    AND schemaname = 'public';

-- 7. Verificar triggers
SELECT 
    trigger_name,
    event_manipulation,
    action_timing,
    action_statement
FROM information_schema.triggers 
WHERE event_object_table = 'professional_profiles'
    AND event_object_schema = 'public';

-- 8. Contar registros existentes
SELECT COUNT(*) as total_profiles FROM professional_profiles;

-- 9. Verificar alguns registros de exemplo (se existirem)
SELECT 
    id,
    user_id,
    "fullName",
    specialty,
    email,
    created_at,
    updated_at
FROM professional_profiles 
ORDER BY created_at DESC 
LIMIT 5;

-- 10. Verificar se há registros órfãos (corrigido para tipos compatíveis)
SELECT 
    pp.id,
    pp.user_id,
    pp."fullName",
    CASE 
        WHEN au.id IS NULL THEN 'ÓRFÃO - usuário não existe'
        ELSE 'OK'
    END as status_usuario
FROM professional_profiles pp
LEFT JOIN auth.users au ON pp.user_id = au.id::text
WHERE pp.user_id IS NOT NULL
ORDER BY pp.created_at DESC;

-- 11. Verificar permissões da tabela
SELECT 
    grantee,
    privilege_type,
    is_grantable
FROM information_schema.role_table_grants 
WHERE table_name = 'professional_profiles'
    AND table_schema = 'public';

-- 12. Verificar se a tabela existe mesmo
SELECT EXISTS (
    SELECT FROM information_schema.tables 
    WHERE table_schema = 'public' 
    AND table_name = 'professional_profiles'
) as tabela_existe;

-- 13. Se não existir, verificar outras variações do nome
SELECT table_name 
FROM information_schema.tables 
WHERE table_schema = 'public' 
    AND table_name LIKE '%profile%'
ORDER BY table_name;

-- 14. Verificar tipo da coluna user_id especificamente
SELECT 
    column_name,
    data_type,
    udt_name
FROM information_schema.columns 
WHERE table_name = 'professional_profiles' 
    AND column_name = 'user_id'
    AND table_schema = 'public';

-- 15. Verificar tipo da coluna id em auth.users
SELECT 
    column_name,
    data_type,
    udt_name
FROM information_schema.columns 
WHERE table_name = 'users' 
    AND column_name = 'id'
    AND table_schema = 'auth';
