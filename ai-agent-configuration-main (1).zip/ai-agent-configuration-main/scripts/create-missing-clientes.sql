-- Script para criar clientes faltantes para usuários existentes
-- Este script deve ser executado para garantir que todos os usuários tenham um cliente

DO $$
DECLARE
    user_record RECORD;
    cliente_exists BOOLEAN;
BEGIN
    -- Loop através de todos os usuários autenticados
    FOR user_record IN 
        SELECT 
            id as user_id,
            email,
            raw_user_meta_data->>'name' as nome,
            created_at
        FROM auth.users 
        WHERE email IS NOT NULL
    LOOP
        -- Verificar se já existe um cliente para este usuário
        SELECT EXISTS(
            SELECT 1 FROM clientes 
            WHERE user_id = user_record.user_id 
            OR email = user_record.email
        ) INTO cliente_exists;
        
        -- Se não existir cliente, criar um
        IF NOT cliente_exists THEN
            INSERT INTO clientes (
                user_id,
                nome,
                email,
                telefone,
                cpf_cnpj,
                plano,
                data_contratacao,
                status
            ) VALUES (
                user_record.user_id,
                COALESCE(user_record.nome, 'Usuário'),
                user_record.email,
                '',
                '',
                'Básico',
                user_record.created_at,
                'aguardando_pagamento'
            );
            
            RAISE NOTICE 'Cliente criado para usuário: % (%)', user_record.email, user_record.user_id;
        ELSE
            RAISE NOTICE 'Cliente já existe para usuário: %', user_record.email;
        END IF;
    END LOOP;
    
    RAISE NOTICE 'Processo de criação de clientes concluído!';
END $$;

-- Verificar resultado
SELECT 
    COUNT(*) as total_usuarios,
    (SELECT COUNT(*) FROM clientes) as total_clientes
FROM auth.users;
