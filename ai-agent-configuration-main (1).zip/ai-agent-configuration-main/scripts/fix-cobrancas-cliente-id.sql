-- Script para corrigir o cliente_id na tabela cobrancas

-- 1. Primeiro, vamos verificar a situação atual
SELECT 
    'SITUAÇÃO ATUAL' as status,
    c.id as cobranca_id,
    c.cliente_id as cliente_id_atual,
    c.customer_id,
    cl.id as cliente_correto_id,
    cl.nome,
    cl.email
FROM cobrancas c
LEFT JOIN clientes cl ON c.cliente_id = cl.id
WHERE cl.email = 'nathancwb@gmail.com' OR c.cliente_id = '7b7efec5-f148-430f-8c7c-3ee44af0c5f7';

-- 2. Buscar o cliente correto pelo email
SELECT 
    'CLIENTE CORRETO' as status,
    id as cliente_id_correto,
    nome,
    email,
    customer_id_asaas
FROM clientes 
WHERE email = 'nathancwb@gmail.com';

-- 3. Verificar se existe cobrança com ID incorreto
SELECT 
    'COBRANÇA COM ID INCORRETO' as status,
    id as cobranca_id,
    cliente_id as cliente_id_incorreto,
    customer_id,
    valor,
    status,
    created_at
FROM cobrancas 
WHERE cliente_id = '7b7efec5-f148-430f-8c7c-3ee44af0c5f7';

-- 4. CORREÇÃO: Atualizar o cliente_id para o ID correto
UPDATE cobrancas 
SET 
    cliente_id = 'ab30e7c4-40e8-4a4a-9ef7-cff0bbf00122',
    updated_at = NOW()
WHERE cliente_id = '7b7efec5-f148-430f-8c7c-3ee44af0c5f7';

-- 5. Verificar se a correção foi aplicada
SELECT 
    'APÓS CORREÇÃO' as status,
    c.id as cobranca_id,
    c.cliente_id as cliente_id_corrigido,
    c.customer_id,
    c.valor,
    c.status,
    cl.nome,
    cl.email
FROM cobrancas c
JOIN clientes cl ON c.cliente_id = cl.id
WHERE cl.email = 'nathancwb@gmail.com';

-- 6. Verificar se não há mais registros órfãos
SELECT 
    'REGISTROS ÓRFÃOS' as status,
    c.id as cobranca_id,
    c.cliente_id,
    c.customer_id,
    'Cliente não encontrado' as problema
FROM cobrancas c
LEFT JOIN clientes cl ON c.cliente_id = cl.id
WHERE cl.id IS NULL;

-- 7. Resumo final
SELECT 
    'RESUMO FINAL' as status,
    COUNT(*) as total_cobrancas,
    COUNT(CASE WHEN cl.id IS NOT NULL THEN 1 END) as cobrancas_com_cliente_valido,
    COUNT(CASE WHEN cl.id IS NULL THEN 1 END) as cobrancas_orfas
FROM cobrancas c
LEFT JOIN clientes cl ON c.cliente_id = cl.id;
