-- Atualizar perfis existentes que têm 'name' mas não têm first_name/last_name
UPDATE profiles 
SET 
  first_name = CASE 
    WHEN name IS NOT NULL AND first_name IS NULL THEN 
      TRIM(SPLIT_PART(name, ' ', 1))
    ELSE first_name 
  END,
  last_name = CASE 
    WHEN name IS NOT NULL AND last_name IS NULL THEN 
      TRIM(SUBSTRING(name FROM POSITION(' ' IN name) + 1))
    ELSE last_name 
  END,
  updated_at = NOW()
WHERE 
  name IS NOT NULL 
  AND (first_name IS NULL OR last_name IS NULL);

-- Verificar os resultados
SELECT id, name, first_name, last_name, email 
FROM profiles 
ORDER BY created_at DESC;
