-- Verificar o usuário atual e seus limites
SELECT 'Dados do usuário atual:' as debug_step;
SELECT 
  c.user_id,
  c.email,
  c.nome,
  c.plano,
  c.is_active,
  c.status,
  p.whatsapp_instances as limite_whatsapp,
  cu.whatsapp_instances_used as uso_atual,
  (SELECT COUNT(*) FROM whatsapp_instances w WHERE w.user_id = c.user_id) as contagem_real_whatsapp
FROM clientes c
LEFT JOIN planos p ON c.plano = p.nome
LEFT JOIN cliente_usage cu ON cu.cliente_id = c.id
WHERE c.user_id = auth.uid()
OR c.email LIKE '%nathancwb%';

-- Verificar todas as instâncias WhatsApp do usuário
SELECT 'Instâncias WhatsApp do usuário:' as debug_step;
SELECT * FROM whatsapp_instances 
WHERE user_id IN (
  SELECT user_id FROM clientes 
  WHERE email LIKE '%nathancwb%'
);
