-- Verificar estrutura e dados dos planos
SELECT 'Verificando tabela planos:' as debug_step;
SELECT * FROM planos ORDER BY nome;

SELECT 'Verificando clientes e seus planos:' as debug_step;
SELECT 
  c.id,
  c.user_id,
  c.email,
  c.plano,
  c.is_active,
  c.status,
  p.whatsapp_instances as limite_whatsapp,
  p.max_appointments as limite_agendamentos,
  p.max_assistants as limite_assistentes
FROM clientes c
LEFT JOIN planos p ON c.plano = p.nome
WHERE c.is_active = true;

SELECT 'Verificando uso atual de WhatsApp por cliente:' as debug_step;
SELECT 
  c.user_id,
  c.email,
  c.plano,
  COUNT(w.id) as whatsapp_instances_em_uso
FROM clientes c
LEFT JOIN whatsapp_instances w ON c.user_id = w.user_id
WHERE c.is_active = true
GROUP BY c.user_id, c.email, c.plano;

SELECT 'Verificando tabela cliente_usage:' as debug_step;
SELECT 
  cu.*,
  c.email,
  c.plano
FROM cliente_usage cu
JOIN clientes c ON cu.cliente_id = c.id
WHERE c.is_active = true;
