-- Script definitivo para corrigir políticas RLS da tabela profiles
-- Este script resolve o problema onde perfis existem mas não podem ser acessados

-- 1. Verificar usuário atual e sessão
SELECT 
    'Usuário atual:' as info,
    auth.uid() as current_user_id,
    auth.role() as current_role;

-- 2. Mostrar perfis existentes (sem RLS)
SELECT 
    'Perfis existentes na tabela:' as info,
    id,
    name,
    email,
    created_at
FROM profiles
ORDER BY created_at DESC
LIMIT 5;

-- 3. Desabilitar RLS temporariamente para limpeza
ALTER TABLE profiles DISABLE ROW LEVEL SECURITY;

-- 4. Remover TODAS as políticas existentes
DROP POLICY IF EXISTS "profiles_select_policy" ON profiles;
DROP POLICY IF EXISTS "profiles_insert_policy" ON profiles;
DROP POLICY IF EXISTS "profiles_update_policy" ON profiles;
DROP POLICY IF EXISTS "profiles_delete_policy" ON profiles;
DROP POLICY IF EXISTS "Enable read access for users based on user_id" ON profiles;
DROP POLICY IF EXISTS "Enable insert for users based on user_id" ON profiles;
DROP POLICY IF EXISTS "Enable update for users based on user_id" ON profiles;
DROP POLICY IF EXISTS "Enable delete for users based on user_id" ON profiles;

-- 5. Reabilitar RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- 6. Criar políticas simples e funcionais
-- Política SELECT: Usuários podem ver apenas seus próprios perfis
CREATE POLICY "profiles_select_own" ON profiles
    FOR SELECT
    TO authenticated
    USING (auth.uid() = id);

-- Política INSERT: Usuários podem criar apenas seus próprios perfis
CREATE POLICY "profiles_insert_own" ON profiles
    FOR INSERT
    TO authenticated
    WITH CHECK (auth.uid() = id);

-- Política UPDATE: Usuários podem atualizar apenas seus próprios perfis
CREATE POLICY "profiles_update_own" ON profiles
    FOR UPDATE
    TO authenticated
    USING (auth.uid() = id)
    WITH CHECK (auth.uid() = id);

-- Política DELETE: Usuários podem deletar apenas seus próprios perfis
CREATE POLICY "profiles_delete_own" ON profiles
    FOR DELETE
    TO authenticated
    USING (auth.uid() = id);

-- 7. Verificar se as políticas foram criadas corretamente
SELECT 
    'Políticas criadas:' as info,
    policyname,
    cmd,
    roles,
    qual,
    with_check
FROM pg_policies 
WHERE tablename = 'profiles'
ORDER BY policyname;

-- 8. Testar acesso com usuário específico (substitua pelo seu ID)
-- Simular busca que a aplicação faz
SELECT 
    'Teste de acesso:' as info,
    'Tentando buscar perfil para usuário ab30e7c4-40e8-4a4a-9ef7-cff0bbf00122' as descricao;

-- 9. Verificar se RLS está funcionando
SELECT 
    'Status RLS:' as info,
    schemaname,
    tablename,
    rowsecurity as rls_enabled,
    CASE 
        WHEN rowsecurity THEN 'RLS ATIVO ✅'
        ELSE 'RLS INATIVO ❌'
    END as status
FROM pg_tables 
WHERE tablename = 'profiles';

-- 10. Mostrar resumo final
SELECT 
    'RESUMO FINAL:' as info,
    'Políticas RLS recriadas com sucesso' as status,
    'Agora a aplicação deve conseguir acessar os perfis' as resultado;
