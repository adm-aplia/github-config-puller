-- Verificar se RLS está habilitado
SELECT 
    'Status RLS' as teste,
    schemaname,
    tablename,
    rowsecurity as rls_enabled
FROM pg_tables 
WHERE tablename = 'google_credentials';

-- Verificar políticas ativas
SELECT 
    'Políticas ativas' as teste,
    policyname,
    cmd as command,
    qual as policy_expression
FROM pg_policies 
WHERE tablename = 'google_credentials'
ORDER BY cmd;

-- Simular contexto de aplicação (isso não vai funcionar no SQL direto)
-- Mas mostra como deveria ser
SELECT 
    'Simulação de acesso da app' as teste,
    'auth.uid() deveria retornar: ab30e7c4-40e8-4a4a-9ef7-cff0bbf00122' as observacao;
