-- Script para testar se a criação de perfis está funcionando
-- Este script simula o que acontece quando um perfil é criado

DO $$
DECLARE
    test_user_id UUID;
    profile_count INTEGER;
BEGIN
    -- Obter o ID do usuário atual (se autenticado)
    SELECT auth.uid() INTO test_user_id;
    
    IF test_user_id IS NULL THEN
        RAISE NOTICE 'Usuário não autenticado - não é possível testar criação de perfil';
        RETURN;
    END IF;
    
    RAISE NOTICE 'Testando criação de perfil para usuário: %', test_user_id;
    
    -- Verificar quantos perfis o usuário já tem
    SELECT COUNT(*) INTO profile_count
    FROM professional_profiles 
    WHERE user_id = test_user_id;
    
    RAISE NOTICE 'Usuário possui % perfis existentes', profile_count;
    
    -- Tentar inserir um perfil de teste
    BEGIN
        INSERT INTO professional_profiles (
            user_id,
            fullname,
            specialty,
            email,
            created_at,
            updated_at
        ) VALUES (
            test_user_id,
            'Perfil de Teste',
            'Medicina Geral',
            'teste@exemplo.com',
            NOW(),
            NOW()
        );
        
        RAISE NOTICE 'Perfil de teste criado com sucesso!';
        
        -- Remover o perfil de teste
        DELETE FROM professional_profiles 
        WHERE user_id = test_user_id 
        AND fullname = 'Perfil de Teste';
        
        RAISE NOTICE 'Perfil de teste removido';
        
    EXCEPTION
        WHEN OTHERS THEN
            RAISE NOTICE 'Erro ao criar perfil de teste: %', SQLERRM;
    END;
    
END $$;
