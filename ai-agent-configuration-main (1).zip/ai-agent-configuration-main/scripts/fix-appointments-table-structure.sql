-- Script para corrigir a estrutura da tabela appointments
-- e garantir que os status estejam padronizados

-- Primeiro, vamos verificar se a tabela existe e sua estrutura atual
DO $$
BEGIN
    -- Verificar se a tabela appointments existe
    IF NOT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'appointments') THEN
        -- Criar a tabela appointments se não existir
        CREATE TABLE appointments (
            id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
            user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
            agent_id UUID REFERENCES profiles(id) ON DELETE SET NULL,
            conversation_id UUID REFERENCES conversations(id) ON DELETE SET NULL,
            
            -- Patient information
            patient_name TEXT NOT NULL,
            patient_phone TEXT NOT NULL,
            patient_email TEXT,
            
            -- Appointment details
            appointment_date TIMESTAMP WITH TIME ZONE NOT NULL,
            duration_minutes INTEGER DEFAULT 60,
            status TEXT DEFAULT 'scheduled',
            appointment_type TEXT,
            notes TEXT,
            
            created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        );
    END IF;
END $$;

-- Verificar se as colunas essenciais existem
DO $$
BEGIN
    -- Verificar appointment_date
    IF NOT EXISTS (
        SELECT FROM information_schema.columns 
        WHERE table_name = 'appointments' AND column_name = 'appointment_date'
    ) THEN
        ALTER TABLE appointments ADD COLUMN appointment_date TIMESTAMP WITH TIME ZONE DEFAULT NOW();
    END IF;
    
    -- Verificar patient_name
    IF NOT EXISTS (
        SELECT FROM information_schema.columns 
        WHERE table_name = 'appointments' AND column_name = 'patient_name'
    ) THEN
        ALTER TABLE appointments ADD COLUMN patient_name TEXT DEFAULT 'Nome não informado';
    END IF;
    
    -- Verificar patient_phone
    IF NOT EXISTS (
        SELECT FROM information_schema.columns 
        WHERE table_name = 'appointments' AND column_name = 'patient_phone'
    ) THEN
        ALTER TABLE appointments ADD COLUMN patient_phone TEXT DEFAULT '';
    END IF;
    
    -- Verificar status
    IF NOT EXISTS (
        SELECT FROM information_schema.columns 
        WHERE table_name = 'appointments' AND column_name = 'status'
    ) THEN
        ALTER TABLE appointments ADD COLUMN status TEXT DEFAULT 'scheduled';
    END IF;
    
    -- Verificar created_at
    IF NOT EXISTS (
        SELECT FROM information_schema.columns 
        WHERE table_name = 'appointments' AND column_name = 'created_at'
    ) THEN
        ALTER TABLE appointments ADD COLUMN created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW();
    END IF;
    
    -- Verificar updated_at
    IF NOT EXISTS (
        SELECT FROM information_schema.columns 
        WHERE table_name = 'appointments' AND column_name = 'updated_at'
    ) THEN
        ALTER TABLE appointments ADD COLUMN updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW();
    END IF;
END $$;

-- Primeiro, vamos ver quais status existem atualmente
SELECT DISTINCT status, COUNT(*) as count 
FROM appointments 
WHERE status IS NOT NULL 
GROUP BY status;

-- Padronizar status existentes ANTES de aplicar a constraint
-- Atualizar status inválidos para valores válidos
UPDATE appointments SET status = 'scheduled' 
WHERE status IS NULL OR status = '' OR status IN ('pending', 'agendado', 'pendente', 'novo', 'new');

UPDATE appointments SET status = 'confirmed' 
WHERE status IN ('confirmado', 'confirm', 'aceito', 'accepted');

UPDATE appointments SET status = 'completed' 
WHERE status IN ('concluido', 'concluído', 'finalizado', 'complete', 'done', 'finished');

UPDATE appointments SET status = 'cancelled' 
WHERE status IN ('cancelado', 'cancel', 'rejected', 'rejeitado');

-- Qualquer status que não se encaixe nas categorias acima, definir como 'scheduled'
UPDATE appointments SET status = 'scheduled' 
WHERE status NOT IN ('scheduled', 'confirmed', 'completed', 'cancelled', 'no-show');

-- Agora remover constraint antigo se existir
DO $$
BEGIN
    IF EXISTS (
        SELECT FROM information_schema.table_constraints 
        WHERE table_name = 'appointments' AND constraint_name = 'appointments_status_check'
    ) THEN
        ALTER TABLE appointments DROP CONSTRAINT appointments_status_check;
    END IF;
END $$;

-- Aplicar a nova constraint DEPOIS de padronizar os dados
ALTER TABLE appointments ADD CONSTRAINT appointments_status_check 
CHECK (status IN ('scheduled', 'confirmed', 'completed', 'cancelled', 'no-show'));

-- Criar índices para melhor performance
CREATE INDEX IF NOT EXISTS idx_appointments_user_id ON appointments(user_id);
CREATE INDEX IF NOT EXISTS idx_appointments_status ON appointments(status);
CREATE INDEX IF NOT EXISTS idx_appointments_date ON appointments(appointment_date);
CREATE INDEX IF NOT EXISTS idx_appointments_created_at ON appointments(created_at);

-- Habilitar RLS (Row Level Security)
ALTER TABLE appointments ENABLE ROW LEVEL SECURITY;

-- Remover políticas existentes se houver
DROP POLICY IF EXISTS "Users can view own appointments" ON appointments;
DROP POLICY IF EXISTS "Users can insert own appointments" ON appointments;
DROP POLICY IF EXISTS "Users can update own appointments" ON appointments;
DROP POLICY IF EXISTS "Users can delete own appointments" ON appointments;

-- Criar políticas RLS
CREATE POLICY "Users can view own appointments" ON appointments
    FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own appointments" ON appointments
    FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own appointments" ON appointments
    FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own appointments" ON appointments
    FOR DELETE USING (auth.uid() = user_id);

-- Verificação final - mostrar a distribuição de status após a correção
SELECT 
    'appointments' as table_name,
    COUNT(*) as total_records,
    COUNT(CASE WHEN status = 'scheduled' THEN 1 END) as scheduled,
    COUNT(CASE WHEN status = 'confirmed' THEN 1 END) as confirmed,
    COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed,
    COUNT(CASE WHEN status = 'cancelled' THEN 1 END) as cancelled,
    COUNT(CASE WHEN status = 'no-show' THEN 1 END) as no_show
FROM appointments;

-- Mostrar alguns exemplos de registros
SELECT id, status, patient_name, appointment_date, created_at 
FROM appointments 
ORDER BY created_at DESC 
LIMIT 5;
