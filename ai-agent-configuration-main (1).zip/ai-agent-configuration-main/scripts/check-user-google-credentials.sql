-- Primeiro, vamos ver todos os registros na tabela google_credentials
SELECT 
    id,
    user_id,
    email,
    name,
    professional_profile_id,
    created_at,
    updated_at
FROM google_credentials 
ORDER BY created_at DESC;
