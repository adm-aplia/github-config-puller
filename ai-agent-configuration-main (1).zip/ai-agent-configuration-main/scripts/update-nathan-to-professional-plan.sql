-- Atualizar Nathan Almeida para Plano Profissional
-- Email: nathancwb@gmail.com

-- 1. Atualizar o plano do cliente para Profissional
UPDATE clientes 
SET 
  plano = 'Profissional',
  is_active = true,
  status = 'ativo',
  updated_at = NOW()
WHERE email = 'nathancwb@gmail.com';

-- 2. Verificar se a atualização funcionou
SELECT 
  'Verificação pós-atualização:' as status,
  c.email,
  c.nome,
  c.plano,
  c.is_active,
  c.status,
  c.data_contratacao,
  c.updated_at
FROM clientes c
WHERE c.email = 'nathancwb@gmail.com';

-- 3. Atualizar os limites de uso para o plano Profissional
INSERT INTO cliente_usage (cliente_id, whatsapp_instances_used, appointments_used, assistants_used)
SELECT 
  c.id,
  COALESCE(cu.whatsapp_instances_used, 0),
  COALESCE(cu.appointments_used, 0), 
  COALESCE(cu.assistants_used, 0)
FROM clientes c
LEFT JOIN cliente_usage cu ON cu.cliente_id = c.id
WHERE c.email = 'nathancwb@gmail.com'
ON CONFLICT (cliente_id) 
DO UPDATE SET
  updated_at = NOW();

-- 4. Verificar os novos limites do plano Profissional
SELECT 
  'Limites do Plano Profissional:' as info,
  c.email,
  c.plano,
  p.whatsapp_instances as limite_whatsapp,
  p.max_appointments as limite_agendamentos,
  p.assistants as limite_assistentes,
  cu.whatsapp_instances_used as whatsapp_usado,
  cu.appointments_used as agendamentos_usado,
  cu.assistants_used as assistentes_usado
FROM clientes c
LEFT JOIN planos p ON c.plano = p.nome
LEFT JOIN cliente_usage cu ON cu.cliente_id = c.id
WHERE c.email = 'nathancwb@gmail.com';

-- 5. Confirmar que tudo está correto
SELECT 
  '✅ Nathan agora tem Plano Profissional!' as resultado,
  email,
  nome,
  plano,
  status,
  is_active
FROM clientes 
WHERE email = 'nathancwb@gmail.com';
