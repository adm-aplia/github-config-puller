-- Debug: Verificar correspondência entre usuário logado e credenciais Google
-- Este script ajuda a identificar problemas de correspondência de user_id

-- PASSO 1: Verificar todos os usuários na tabela auth.users
SELECT 
    'AUTH USERS' as tabela,
    id as user_id,
    email,
    created_at,
    email_confirmed_at,
    last_sign_in_at
FROM auth.users 
ORDER BY created_at DESC
LIMIT 10;

-- PASSO 2: Verificar todas as credenciais Google
SELECT 
    'GOOGLE CREDENTIALS' as tabela,
    id as credential_id,
    user_id,
    email,
    name,
    created_at
FROM google_credentials 
ORDER BY created_at DESC;

-- PASSO 3: Verificar se há correspondência entre auth.users e google_credentials
SELECT 
    'MATCH CHECK' as tipo,
    au.email as auth_email,
    au.id as auth_user_id,
    gc.email as google_email,
    gc.user_id as google_user_id,
    gc.id as credential_id,
    CASE 
        WHEN au.id = gc.user_id THEN 'MATCH ✅'
        ELSE 'NO MATCH ❌'
    END as status
FROM auth.users au
FULL OUTER JOIN google_credentials gc ON au.id = gc.user_id
WHERE au.email IS NOT NULL OR gc.email IS NOT NULL
ORDER BY au.created_at DESC NULLS LAST;

-- PASSO 4: Verificar especificamente o usuário nathancwb@gmail.com
SELECT 
    'NATHAN USER CHECK' as tipo,
    au.id as auth_user_id,
    au.email as auth_email,
    au.created_at as auth_created_at
FROM auth.users au
WHERE au.email = 'nathancwb@gmail.com';

-- PASSO 5: Verificar credenciais Google para nathancwb@gmail.com
SELECT 
    'NATHAN CREDENTIALS CHECK' as tipo,
    gc.id as credential_id,
    gc.user_id as google_user_id,
    gc.email as google_email,
    gc.name,
    gc.created_at as credential_created_at
FROM google_credentials gc
WHERE gc.email = 'nathancwb@gmail.com';

-- PASSO 6: Verificar perfis profissionais
SELECT 
    'PROFESSIONAL PROFILES' as tabela,
    id as profile_id,
    user_id,
    "fullName",
    specialty,
    created_at
FROM professional_profiles
ORDER BY created_at DESC
LIMIT 10;

-- PASSO 7: Verificar vinculações Google-Profile
SELECT 
    'GOOGLE PROFILE LINKS' as tabela,
    gpl.id as link_id,
    gpl.google_credential_id,
    gpl.professional_profile_id,
    gc.email as google_email,
    pp."fullName" as profile_name,
    gpl.created_at
FROM google_profile_links gpl
LEFT JOIN google_credentials gc ON gpl.google_credential_id = gc.id
LEFT JOIN professional_profiles pp ON gpl.professional_profile_id = pp.id
ORDER BY gpl.created_at DESC;
