-- Testar funcionalidade completa do banco de dados

-- 1. Testar inserção em professional_profiles
DO $$
DECLARE
    test_user_id UUID := '00000000-0000-0000-0000-000000000001'; -- ID de teste
    test_profile_id UUID;
BEGIN
    -- Simular inserção (não vai funcionar sem usuário real, mas testa a estrutura)
    BEGIN
        INSERT INTO public.professional_profiles (
            user_id,
            fullName,
            specialty,
            professionalId,
            phoneNumber,
            email,
            education,
            locations,
            workingHours,
            procedures,
            healthInsurance,
            paymentMethods,
            consultationFees,
            cancellationPolicy,
            consultationDuration,
            timeBetweenConsultations,
            reschedulingPolicy,
            onlineConsultations,
            reminderPreferences,
            requiredPatientInfo,
            appointmentConditions,
            medicalHistoryRequirements,
            ageRequirements,
            communicationChannels,
            preAppointmentInfo,
            requiredDocuments
        ) VALUES (
            test_user_id,
            'Dr. Teste',
            'Cardiologia',
            'CRM 12345',
            '(11) 99999-9999',
            'teste@teste.com',
            'Medicina UFMG',
            'Consultório Teste',
            '8h às 18h',
            'Ecocardiograma',
            'Unimed, Amil',
            'Cartão, PIX',
            'R$ 200',
            '24h antecedência',
            '30 minutos',
            '15 minutos',
            'Até 12h antes',
            'Sim, disponível',
            'WhatsApp',
            'Nome, idade, plano',
            'Exames recentes',
            'Histórico completo',
            'Adultos',
            'WhatsApp, Email',
            'Preparação necessária',
            'RG, CPF, Carteirinha'
        ) RETURNING id INTO test_profile_id;
        
        RAISE NOTICE 'Teste de inserção: SUCESSO - ID: %', test_profile_id;
        
        -- Limpar teste
        DELETE FROM public.professional_profiles WHERE id = test_profile_id;
        
    EXCEPTION WHEN OTHERS THEN
        RAISE NOTICE 'Teste de inserção: ERRO - %', SQLERRM;
    END;
END $$;

-- 2. Verificar se todas as colunas estão presentes
SELECT 
    COUNT(*) as total_columns,
    COUNT(CASE WHEN column_name = 'fullname' THEN 1 END) as has_fullname,
    COUNT(CASE WHEN column_name = 'specialty' THEN 1 END) as has_specialty,
    COUNT(CASE WHEN column_name = 'professionalid' THEN 1 END) as has_professionalid,
    COUNT(CASE WHEN column_name = 'communicationchannels' THEN 1 END) as has_communication
FROM information_schema.columns 
WHERE table_name = 'professional_profiles' 
    AND table_schema = 'public';
