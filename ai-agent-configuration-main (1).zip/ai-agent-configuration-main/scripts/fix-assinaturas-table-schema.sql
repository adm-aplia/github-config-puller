-- Verificar se a tabela assinaturas existe e corrigir a estrutura
DO $$ 
BEGIN
    -- Verificar se a coluna creditCardToken existe, se não, adicionar
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                   WHERE table_name = 'assinaturas' AND column_name = 'credit_card_token') THEN
        ALTER TABLE assinaturas ADD COLUMN credit_card_token VARCHAR(255);
        COMMENT ON COLUMN assinaturas.credit_card_token IS 'Token do cartão de crédito (opcional)';
    END IF;

    -- Verificar se a coluna next_due_date existe com o nome correto
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                   WHERE table_name = 'assinaturas' AND column_name = 'next_due_date') THEN
        -- Se existe nextDueDate, renomear para next_due_date
        IF EXISTS (SELECT 1 FROM information_schema.columns 
                   WHERE table_name = 'assinaturas' AND column_name = 'nextduedate') THEN
            ALTER TABLE assinaturas RENAME COLUMN nextduedate TO next_due_date;
        ELSE
            ALTER TABLE assinaturas ADD COLUMN next_due_date DATE;
        END IF;
    END IF;

    -- Verificar se a coluna remote_ip existe com o nome correto
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                   WHERE table_name = 'assinaturas' AND column_name = 'remote_ip') THEN
        -- Se existe remoteIp, renomear para remote_ip
        IF EXISTS (SELECT 1 FROM information_schema.columns 
                   WHERE table_name = 'assinaturas' AND column_name = 'remoteip') THEN
            ALTER TABLE assinaturas RENAME COLUMN remoteip TO remote_ip;
        ELSE
            ALTER TABLE assinaturas ADD COLUMN remote_ip INET;
        END IF;
    END IF;

    RAISE NOTICE 'Estrutura da tabela assinaturas corrigida com sucesso!';
END $$;

-- Verificar a estrutura final da tabela
SELECT 
    column_name,
    data_type,
    is_nullable,
    column_default
FROM information_schema.columns 
WHERE table_name = 'assinaturas' 
ORDER BY ordinal_position;
