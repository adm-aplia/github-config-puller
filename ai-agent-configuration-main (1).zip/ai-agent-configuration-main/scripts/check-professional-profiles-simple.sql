-- Verificar estrutura da tabela professional_profiles (Versão Simples - Sem JOINs problemáticos)

-- 1. Verificar se a tabela existe
SELECT 
    schemaname,
    tablename,
    tableowner,
    hasindexes,
    hasrules,
    hastriggers
FROM pg_tables 
WHERE tablename = 'professional_profiles';

-- 2. Verificar estrutura das colunas
SELECT 
    column_name,
    data_type,
    character_maximum_length,
    is_nullable,
    column_default,
    ordinal_position
FROM information_schema.columns 
WHERE table_name = 'professional_profiles' 
    AND table_schema = 'public'
ORDER BY ordinal_position;

-- 3. Verificar constraints
SELECT 
    tc.constraint_name,
    tc.constraint_type,
    kcu.column_name
FROM information_schema.table_constraints AS tc 
JOIN information_schema.key_column_usage AS kcu
    ON tc.constraint_name = kcu.constraint_name
WHERE tc.table_name = 'professional_profiles'
    AND tc.table_schema = 'public';

-- 4. Verificar RLS
SELECT 
    schemaname,
    tablename,
    rowsecurity
FROM pg_tables 
WHERE tablename = 'professional_profiles';

-- 5. Verificar policies RLS
SELECT 
    policyname,
    permissive,
    roles,
    cmd
FROM pg_policies 
WHERE tablename = 'professional_profiles'
    AND schemaname = 'public';

-- 6. Contar registros
SELECT COUNT(*) as total_profiles FROM professional_profiles;

-- 7. Ver alguns registros (se existirem)
SELECT 
    id,
    user_id,
    "fullName",
    specialty,
    created_at
FROM professional_profiles 
ORDER BY created_at DESC 
LIMIT 3;

-- 8. Verificar se a tabela existe
SELECT EXISTS (
    SELECT FROM information_schema.tables 
    WHERE table_schema = 'public' 
    AND table_name = 'professional_profiles'
) as tabela_existe;

-- 9. Listar todas as tabelas com 'profile' no nome
SELECT table_name 
FROM information_schema.tables 
WHERE table_schema = 'public' 
    AND table_name LIKE '%profile%'
ORDER BY table_name;

-- 10. Verificar tipo específico da coluna user_id
SELECT 
    column_name,
    data_type,
    udt_name,
    is_nullable
FROM information_schema.columns 
WHERE table_name = 'professional_profiles' 
    AND column_name = 'user_id'
    AND table_schema = 'public';
