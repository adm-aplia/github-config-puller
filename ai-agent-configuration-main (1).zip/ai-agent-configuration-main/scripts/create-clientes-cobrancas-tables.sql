-- Criar tabela de clientes
CREATE TABLE IF NOT EXISTS clientes (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  nome VARCHAR(255) NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  telefone VARCHAR(20),
  cpf_cnpj VARCHAR(18),
  plano VARCHAR(50) NOT NULL,
  customer_id VARCHAR(255), -- ID do cliente no Asaas
  data_contratacao TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  status VARCHAR(50) DEFAULT 'aguardando pagamento',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Criar tabela de cobranças
CREATE TABLE IF NOT EXISTS cobrancas (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  cliente_id UUID REFERENCES clientes(id) ON DELETE CASCADE,
  customer_id VARCHAR(255) NOT NULL, -- ID do cliente no Asaas
  id_cobranca VARCHAR(255) NOT NULL, -- ID da cobrança no Asaas
  status VARCHAR(50) DEFAULT 'PENDING',
  valor DECIMAL(10,2) NOT NULL,
  descricao TEXT,
  payment_link TEXT,
  invoice_url TEXT,
  due_date DATE,
  data_criacao TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Criar índices para melhor performance
CREATE INDEX IF NOT EXISTS idx_clientes_email ON clientes(email);
CREATE INDEX IF NOT EXISTS idx_clientes_cpf_cnpj ON clientes(cpf_cnpj);
CREATE INDEX IF NOT EXISTS idx_cobrancas_cliente_id ON cobrancas(cliente_id);
CREATE INDEX IF NOT EXISTS idx_cobrancas_id_cobranca ON cobrancas(id_cobranca);

-- Habilitar RLS (Row Level Security)
ALTER TABLE clientes ENABLE ROW LEVEL SECURITY;
ALTER TABLE cobrancas ENABLE ROW LEVEL SECURITY;

-- Criar políticas RLS básicas (permitir todas as operações por enquanto)
CREATE POLICY "Allow all operations on clientes" ON clientes FOR ALL USING (true);
CREATE POLICY "Allow all operations on cobrancas" ON cobrancas FOR ALL USING (true);
