-- Verificar a estrutura real da tabela professional_profiles
SELECT 
    column_name,
    data_type,
    is_nullable,
    column_default
FROM information_schema.columns 
WHERE table_name = 'professional_profiles' 
    AND table_schema = 'public'
ORDER BY ordinal_position;

-- Verificar se a tabela existe
SELECT EXISTS (
    SELECT FROM information_schema.tables 
    WHERE table_schema = 'public' 
    AND table_name = 'professional_profiles'
) as table_exists;

-- Se a tabela não existir, vamos criá-la
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_schema = 'public' 
        AND table_name = 'professional_profiles'
    ) THEN
        CREATE TABLE professional_profiles (
            id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
            user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
            fullName TEXT,
            specialty TEXT,
            professionalId TEXT,
            phoneNumber TEXT,
            email TEXT,
            education TEXT,
            procedures TEXT,
            locations JSONB DEFAULT '[]'::jsonb,
            workingHours JSONB DEFAULT '{}'::jsonb,
            healthInsurance JSONB DEFAULT '[]'::jsonb,
            paymentMethods JSONB DEFAULT '[]'::jsonb,
            consultationFees JSONB DEFAULT '{}'::jsonb,
            cancellationPolicy TEXT,
            consultationDuration INTEGER DEFAULT 30,
            timeBetweenConsultations INTEGER DEFAULT 15,
            reschedulingPolicy TEXT,
            onlineConsultations BOOLEAN DEFAULT false,
            reminderPreferences JSONB DEFAULT '{}'::jsonb,
            requiredPatientInfo JSONB DEFAULT '[]'::jsonb,
            appointmentConditions TEXT,
            medicalHistoryRequirements TEXT,
            ageRequirements TEXT,
            communicationChannels JSONB DEFAULT '[]'::jsonb,
            preAppointmentInfo TEXT,
            requiredDocuments JSONB DEFAULT '[]'::jsonb,
            avatar_path TEXT,
            created_at TIMESTAMPTZ DEFAULT NOW(),
            updated_at TIMESTAMPTZ DEFAULT NOW()
        );
        
        RAISE NOTICE 'Tabela professional_profiles criada com sucesso';
    ELSE
        RAISE NOTICE 'Tabela professional_profiles já existe';
    END IF;
END $$;
