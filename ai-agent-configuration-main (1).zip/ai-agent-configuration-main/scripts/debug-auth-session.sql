-- Script para debugar problemas de autenticação e sessão

-- 1. Verificar função auth.uid()
DO $$
DECLARE
    current_uid UUID;
BEGIN
    SELECT auth.uid() INTO current_uid;
    
    IF current_uid IS NOT NULL THEN
        RAISE NOTICE 'auth.uid() retorna: %', current_uid;
    ELSE
        RAISE NOTICE 'auth.uid() retorna NULL - usuário não autenticado';
    END IF;
END $$;

-- 2. Verificar tabela auth.users
SELECT 
    'Total de usuários na auth.users:' as info,
    COUNT(*) as count
FROM auth.users;

-- 3. Verificar se existe perfil para usuários
SELECT 
    u.id as user_id,
    u.email,
    u.created_at as user_created,
    p.id as profile_id,
    p.name as profile_name,
    p.created_at as profile_created
FROM auth.users u
LEFT JOIN profiles p ON u.id = p.id
ORDER BY u.created_at DESC
LIMIT 10;

-- 4. Verificar políticas RLS ativas
SELECT 
    schemaname,
    tablename,
    policyname,
    permissive,
    roles,
    cmd,
    qual,
    with_check
FROM pg_policies 
WHERE tablename = 'profiles';

-- 5. Verificar se RLS está habilitado
SELECT 
    schemaname,
    tablename,
    rowsecurity,
    forcerowsecurity
FROM pg_tables 
WHERE tablename = 'profiles';
