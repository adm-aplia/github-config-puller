-- Script para adicionar dados de exemplo na tabela appointments
-- Execute este script para ter dados para testar as estatísticas

-- Primeiro, vamos verificar se a tabela existe
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'appointments') THEN
        RAISE EXCEPTION 'Tabela appointments não existe. Execute primeiro o script de criação da tabela.';
    END IF;
END $$;

-- Limpar dados existentes (opcional - remova se quiser manter dados existentes)
-- DELETE FROM appointments WHERE patient_name LIKE 'Paciente Teste%';

-- Inserir dados de exemplo para o usuário atual
-- Substitua 'USER_ID_AQUI' pelo ID real do usuário
INSERT INTO appointments (
    user_id,
    patient_name,
    patient_phone,
    appointment_date,
    appointment_time,
    status,
    notes,
    created_at,
    updated_at
) VALUES 
-- Agendamentos do mês atual
('USER_ID_AQUI', 'Paciente Teste 1', '(11) 99999-0001', CURRENT_DATE, '09:00', 'scheduled', 'Consulta de rotina', NOW(), NOW()),
('USER_ID_AQUI', 'Paciente Teste 2', '(11) 99999-0002', CURRENT_DATE + INTERVAL '1 day', '10:30', 'confirmed', 'Retorno', NOW(), NOW()),
('USER_ID_AQUI', 'Paciente Teste 3', '(11) 99999-0003', CURRENT_DATE + INTERVAL '2 days', '14:00', 'completed', 'Consulta realizada', NOW(), NOW()),
('USER_ID_AQUI', 'Paciente Teste 4', '(11) 99999-0004', CURRENT_DATE + INTERVAL '3 days', '15:30', 'cancelled', 'Cancelado pelo paciente', NOW(), NOW()),
('USER_ID_AQUI', 'Paciente Teste 5', '(11) 99999-0005', CURRENT_DATE + INTERVAL '4 days', '16:00', 'no-show', 'Paciente não compareceu', NOW(), NOW()),

-- Mais agendamentos para estatísticas mais interessantes
('USER_ID_AQUI', 'Paciente Teste 6', '(11) 99999-0006', CURRENT_DATE - INTERVAL '5 days', '08:00', 'completed', 'Consulta realizada', NOW(), NOW()),
('USER_ID_AQUI', 'Paciente Teste 7', '(11) 99999-0007', CURRENT_DATE - INTERVAL '4 days', '09:30', 'completed', 'Consulta realizada', NOW(), NOW()),
('USER_ID_AQUI', 'Paciente Teste 8', '(11) 99999-0008', CURRENT_DATE - INTERVAL '3 days', '11:00', 'confirmed', 'Confirmado', NOW(), NOW()),
('USER_ID_AQUI', 'Paciente Teste 9', '(11) 99999-0009', CURRENT_DATE - INTERVAL '2 days', '13:30', 'scheduled', 'Agendado', NOW(), NOW()),
('USER_ID_AQUI', 'Paciente Teste 10', '(11) 99999-0010', CURRENT_DATE - INTERVAL '1 day', '17:00', 'cancelled', 'Cancelado', NOW(), NOW()),

-- Agendamentos do mês passado
('USER_ID_AQUI', 'Paciente Teste 11', '(11) 99999-0011', CURRENT_DATE - INTERVAL '30 days', '10:00', 'completed', 'Consulta do mês passado', NOW(), NOW()),
('USER_ID_AQUI', 'Paciente Teste 12', '(11) 99999-0012', CURRENT_DATE - INTERVAL '25 days', '11:30', 'completed', 'Consulta do mês passado', NOW(), NOW()),
('USER_ID_AQUI', 'Paciente Teste 13', '(11) 99999-0013', CURRENT_DATE - INTERVAL '20 days', '14:30', 'no-show', 'Falta do mês passado', NOW(), NOW()),

-- Agendamentos futuros
('USER_ID_AQUI', 'Paciente Teste 14', '(11) 99999-0014', CURRENT_DATE + INTERVAL '7 days', '09:00', 'scheduled', 'Agendamento futuro', NOW(), NOW()),
('USER_ID_AQUI', 'Paciente Teste 15', '(11) 99999-0015', CURRENT_DATE + INTERVAL '14 days', '10:30', 'confirmed', 'Agendamento futuro confirmado', NOW(), NOW());

-- Verificar os dados inseridos
SELECT 
    status,
    COUNT(*) as quantidade,
    MIN(appointment_date) as primeira_data,
    MAX(appointment_date) as ultima_data
FROM appointments 
WHERE patient_name LIKE 'Paciente Teste%'
GROUP BY status
ORDER BY status;

-- Mostrar total por mês
SELECT 
    DATE_TRUNC('month', appointment_date) as mes,
    COUNT(*) as total_agendamentos,
    COUNT(CASE WHEN status = 'scheduled' THEN 1 END) as pendentes,
    COUNT(CASE WHEN status = 'confirmed' THEN 1 END) as confirmados,
    COUNT(CASE WHEN status = 'completed' THEN 1 END) as concluidos,
    COUNT(CASE WHEN status = 'cancelled' THEN 1 END) as cancelados,
    COUNT(CASE WHEN status = 'no-show' THEN 1 END) as faltas
FROM appointments 
WHERE patient_name LIKE 'Paciente Teste%'
GROUP BY DATE_TRUNC('month', appointment_date)
ORDER BY mes DESC;

COMMIT;
