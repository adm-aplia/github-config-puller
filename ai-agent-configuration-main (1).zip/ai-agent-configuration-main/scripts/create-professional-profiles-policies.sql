-- Habilitar RLS na tabela professional_profiles
ALTER TABLE professional_profiles ENABLE ROW LEVEL SECURITY;

-- Política para permitir que usuários vejam seus próprios perfis
CREATE POLICY "Users can view own profiles" ON professional_profiles
    FOR SELECT USING (auth.uid() = user_id);

-- Política para permitir que usuários criem seus próprios perfis
CREATE POLICY "Users can create own profiles" ON professional_profiles
    FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Política para permitir que usuários atualizem seus próprios perfis
CREATE POLICY "Users can update own profiles" ON professional_profiles
    FOR UPDATE USING (auth.uid() = user_id);

-- Política para permitir que usuários excluam seus próprios perfis
CREATE POLICY "Users can delete own profiles" ON professional_profiles
    FOR DELETE USING (auth.uid() = user_id);

-- Verificar as políticas criadas
SELECT 
    schemaname,
    tablename,
    policyname,
    permissive,
    roles,
    cmd,
    qual,
    with_check
FROM pg_policies 
WHERE tablename = 'professional_profiles';
