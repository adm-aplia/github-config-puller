-- Remover políticas existentes se houver conflito e recriar
DO $$
BEGIN
    -- Remover políticas existentes
    DROP POLICY IF EXISTS "Users can view own profiles" ON professional_profiles;
    DROP POLICY IF EXISTS "Users can create own profiles" ON professional_profiles;
    DROP POLICY IF EXISTS "Users can update own profiles" ON professional_profiles;
    DROP POLICY IF EXISTS "Users can delete own profiles" ON professional_profiles;
    
    RAISE NOTICE 'Políticas antigas removidas';
END $$;

-- Habilitar RLS
ALTER TABLE professional_profiles ENABLE ROW LEVEL SECURITY;

-- Criar políticas atualizadas
CREATE POLICY "view_own_profiles" ON professional_profiles
    FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "create_own_profiles" ON professional_profiles
    FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "update_own_profiles" ON professional_profiles
    FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "delete_own_profiles" ON professional_profiles
    FOR DELETE USING (auth.uid() = user_id);

-- Verificar políticas criadas
SELECT 
    policyname,
    cmd,
    permissive,
    qual,
    with_check
FROM pg_policies 
WHERE tablename = 'professional_profiles'
ORDER BY policyname;
