-- Adicionar campos necessários na tabela profiles
ALTER TABLE profiles 
ADD COLUMN IF NOT EXISTS first_name TEXT,
ADD COLUMN IF NOT EXISTS last_name TEXT,
ADD COLUMN IF NOT EXISTS phone TEXT,
ADD COLUMN IF NOT EXISTS specialty TEXT,
ADD COLUMN IF NOT EXISTS notifications_email BOOLEAN DEFAULT true,
ADD COLUMN IF NOT EXISTS notifications_push BOOLEAN DEFAULT true,
ADD COLUMN IF NOT EXISTS notifications_sms BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS notifications_appointments BOOLEAN DEFAULT true,
ADD COLUMN IF NOT EXISTS notifications_messages BOOLEAN DEFAULT true;

-- Verificar a estrutura atualizada
SELECT column_name, data_type, is_nullable, column_default 
FROM information_schema.columns 
WHERE table_name = 'profiles' 
AND table_schema = 'public'
ORDER BY ordinal_position;

-- Mostrar alguns registros para verificar
SELECT id, name, first_name, last_name, email, phone, specialty 
FROM profiles 
LIMIT 5;
