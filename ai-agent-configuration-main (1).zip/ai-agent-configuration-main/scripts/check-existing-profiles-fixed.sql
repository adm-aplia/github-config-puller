-- Verificar perfis existentes e estrutura da tabela profiles

-- 1. Verificar se a tabela profiles existe e sua estrutura
SELECT 
    table_name,
    column_name,
    data_type,
    is_nullable,
    column_default
FROM information_schema.columns 
WHERE table_name = 'profiles' 
ORDER BY ordinal_position;

-- 2. Verificar perfis existentes
SELECT 
    id,
    name,
    first_name,
    last_name,
    email,
    phone,
    created_at,
    updated_at
FROM profiles
ORDER BY created_at DESC;

-- 3. Verificar usuários na auth.users
SELECT 
    id,
    email,
    created_at,
    email_confirmed_at,
    last_sign_in_at
FROM auth.users
ORDER BY created_at DESC
LIMIT 5;

-- 4. Verificar correspondência entre auth.users e profiles
SELECT 
    u.id as user_id,
    u.email as user_email,
    u.created_at as user_created,
    p.id as profile_id,
    p.email as profile_email,
    p.name as profile_name,
    p.created_at as profile_created,
    CASE 
        WHEN p.id IS NULL THEN 'SEM PERFIL'
        WHEN u.id = p.id THEN 'MATCH'
        ELSE 'MISMATCH'
    END as status
FROM auth.users u
LEFT JOIN profiles p ON u.id = p.id
ORDER BY u.created_at DESC;

-- 5. Verificar políticas RLS atuais
SELECT 
    policyname,
    cmd,
    qual,
    with_check
FROM pg_policies 
WHERE tablename = 'profiles'
ORDER BY policyname;

-- 6. Verificar se RLS está habilitado (versão corrigida)
SELECT 
    schemaname,
    tablename,
    rowsecurity as rls_enabled
FROM pg_tables 
WHERE tablename = 'profiles';

-- 7. Contar perfis por usuário para detectar duplicatas
SELECT 
    id as user_id,
    COUNT(*) as profile_count
FROM profiles
GROUP BY id
HAVING COUNT(*) > 1
ORDER BY profile_count DESC;

-- 8. Verificar sessão atual do usuário (se executado via RLS)
SELECT 
    auth.uid() as current_user_id,
    auth.role() as current_role;
