-- Verificar se existem dados na tabela google_credentials
SELECT 
  'Total de registros na tabela' as info,
  COUNT(*) as count
FROM google_credentials;

-- Verificar registros por user_id
SELECT 
  user_id,
  email,
  name,
  created_at,
  COUNT(*) as count
FROM google_credentials 
GROUP BY user_id, email, name, created_at
ORDER BY created_at DESC;

-- Verificar se existe o user_id específico
SELECT 
  'Registros para user_id específico' as info,
  COUNT(*) as count
FROM google_credentials 
WHERE user_id = 'ab30e7c4-40e8-4a4a-9ef7-cff0bbf00122';

-- Mostrar todos os dados para debug
SELECT 
  id,
  user_id,
  email,
  name,
  created_at,
  updated_at
FROM google_credentials 
WHERE user_id = 'ab30e7c4-40e8-4a4a-9ef7-cff0bbf00122'
ORDER BY created_at DESC;

-- Verificar se RLS está ativo
SELECT 
  schemaname,
  tablename,
  rowsecurity
FROM pg_tables 
WHERE tablename = 'google_credentials';

-- Verificar políticas RLS
SELECT 
  schemaname,
  tablename,
  policyname,
  permissive,
  roles,
  cmd,
  qual,
  with_check
FROM pg_policies 
WHERE tablename = 'google_credentials';
