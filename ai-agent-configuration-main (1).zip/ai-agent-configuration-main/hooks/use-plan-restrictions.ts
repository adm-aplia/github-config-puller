"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/hooks/use-auth"

interface PlanLimits {
  profiles_limit: number
  whatsapp_instances_limit: number
  appointments_limit: number
  assistants_limit: number
}

interface PlanUsage {
  profiles_count: number
  whatsapp_instances_count: number
  appointments_count: number
  assistants_count: number
}

interface PlanStatus {
  planName: string
  plan_name: string
  limits: PlanLimits
  usage: PlanUsage
  isActive: boolean
  error?: string
}

export function usePlanRestrictions() {
  const [planStatus, setPlanStatus] = useState<PlanStatus | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const { user } = useAuth()

  useEffect(() => {
    if (user?.id) {
      console.log("🔍 usePlanRestrictions: user.id encontrado:", user.id)
      fetchPlanStatus()
    } else {
      console.log("⚠️ usePlanRestrictions: user.id não encontrado:", user)
      setLoading(false)
    }
  }, [user]) // Updated dependency to user

  const fetchPlanStatus = async () => {
    if (!user?.id) {
      console.log("❌ fetchPlanStatus: user.id não disponível")
      setLoading(false)
      return
    }

    try {
      setLoading(true)
      setError(null)

      console.log("🔍 Buscando status do plano para usuário:", user.id)

      const response = await fetch(`/api/user/plan-status?user_id=${user.id}`)

      if (!response.ok) {
        const errorText = await response.text()
        console.error("❌ Erro na resposta da API:", response.status, errorText)
        throw new Error(`Erro ao buscar status do plano: ${response.status} - ${response.statusText}`)
      }

      const data = await response.json()
      console.log("📊 Status do plano recebido:", data)

      if (data.error) {
        console.warn("⚠️ API retornou erro:", data.error)
        setError(data.error)
      }

      setPlanStatus(data)
    } catch (err) {
      console.error("❌ Erro ao buscar status do plano:", err)
      setError(err instanceof Error ? err.message : "Erro desconhecido")

      // Definir um estado padrão em caso de erro
      setPlanStatus({
        planName: "Básico",
        plan_name: "Básico",
        limits: {
          profiles_limit: 0,
          whatsapp_instances_limit: 1,
          appointments_limit: 300,
          assistants_limit: 1,
        },
        usage: {
          profiles_count: 0,
          whatsapp_instances_count: 0,
          appointments_count: 0,
          assistants_count: 0,
        },
        isActive: false,
      })
    } finally {
      setLoading(false)
    }
  }

  // Verificar se pode criar perfil
  const canCreateProfile = planStatus ? planStatus.usage.profiles_count < planStatus.limits.profiles_limit : false

  // Calcular perfis restantes
  const remainingProfiles = planStatus
    ? Math.max(0, planStatus.limits.profiles_limit - planStatus.usage.profiles_count)
    : 0

  // Verificar se pode criar instância WhatsApp
  const canCreateWhatsAppInstance = planStatus
    ? planStatus.usage.whatsapp_instances_count < planStatus.limits.whatsapp_instances_limit
    : false

  // Calcular instâncias WhatsApp restantes
  const remainingWhatsAppInstances = planStatus
    ? Math.max(0, planStatus.limits.whatsapp_instances_limit - planStatus.usage.whatsapp_instances_count)
    : 0

  // Verificar se pode criar agendamento
  const canCreateAppointment = planStatus
    ? planStatus.usage.appointments_count < planStatus.limits.appointments_limit
    : false

  // Verificar se pode criar assistente
  const canCreateAssistant = planStatus ? planStatus.usage.assistants_count < planStatus.limits.assistants_limit : false

  return {
    planStatus,
    loading,
    error,
    canCreateProfile,
    remainingProfiles,
    canCreateWhatsAppInstance,
    remainingWhatsAppInstances,
    canCreateAppointment,
    canCreateAssistant,
    refetch: fetchPlanStatus,
  }
}
