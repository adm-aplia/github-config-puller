"use client"

import { useState, useEffect } from "react"

export function useMobile(): boolean {
  // Inicializar com null para evitar hidratação incorreta
  const [isMobile, setIsMobile] = useState<boolean | null>(null)

  useEffect(() => {
    // Função para verificar se é dispositivo móvel
    const checkMobile = () => {
      const userAgent = navigator.userAgent || navigator.vendor || (window as any).opera
      const mobileRegex = /android|webos|iphone|ipad|ipod|blackberry|iemobile|opera mini/i

      setIsMobile(mobileRegex.test(userAgent.toLowerCase()))
    }

    // Verificar apenas uma vez na montagem do componente
    checkMobile()

    // Não adicionar listener para resize para evitar mudanças durante o uso
  }, [])

  // Retornar false até que a detecção do lado do cliente seja concluída
  return isMobile === null ? false : isMobile
}

// Alias so callers can import either name
export const useIsMobile = useMobile
