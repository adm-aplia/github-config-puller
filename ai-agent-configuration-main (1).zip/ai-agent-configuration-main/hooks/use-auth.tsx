"use client"

import { useContext } from "react"
import { AuthContext } from "@/components/auth-provider"

/**
 * Hook de conveniência que expõe o contexto de autenticação.
 * Mantemos o nome e o caminho originais para não quebrar imports existentes.
 */
export function useAuth() {
  const context = useContext(AuthContext)

  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider")
  }

  return context
}
