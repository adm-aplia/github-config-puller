"use client"

import { useState, useEffect } from "react"
import { useAuth } from "./use-auth"

// ---- Valores-padrão para evitar undefined -----------------
const DEFAULT_LIMITS = {
  whatsapp_instances: 0,
  max_appointments: 0,
  max_assistants: 0,
  profiles_limit: 0, // ✅ CORRIGIDO: Backend usa "profiles_limit"
  support_level: "",
  advanced_reports: false,
  hospital_integration: false,
  advanced_customization: false,
  api_access: false,
  priority_support: false,
  custom_branding: false,
} as const

const DEFAULT_USAGE = {
  whatsapp_instances_count: 0,
  appointments_this_month: 0,
  assistants_count: 0,
  profiles_count: 0, // ✅ CORRIGIDO: Backend usa "profiles_count"
} as const

interface PlanLimits {
  whatsapp_instances: number
  max_appointments: number
  max_assistants: number
  profiles_limit: number // ✅ CORRIGIDO: Backend usa "profiles_limit"
  support_level: string
  advanced_reports: boolean
  hospital_integration: boolean
  advanced_customization: boolean
  api_access: boolean
  priority_support: boolean
  custom_branding: boolean
}

interface CurrentUsage {
  whatsapp_instances_count: number
  appointments_this_month: number
  assistants_count: number
  profiles_count: number // ✅ CORRIGIDO: Backend usa "profiles_count"
}

interface PlanStatus {
  planName: string
  limits: PlanLimits
  usage: CurrentUsage
}

interface PermissionCheck {
  allowed: boolean
  reason: string
}

export function usePermissions() {
  const { user } = useAuth()
  const [planStatus, setPlanStatus] = useState<PlanStatus | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (user?.id) {
      fetchPlanStatus()
    }
  }, [user?.id])

  const fetchPlanStatus = async () => {
    if (!user?.id) return

    try {
      setLoading(true)
      setError(null)

      console.log("🔍 Permissions: Buscando status do plano para:", user.id)

      const response = await fetch(`/api/user/plan-status?userId=${user.id}`)

      if (!response.ok) {
        throw new Error(`Erro ${response.status}: ${response.statusText}`)
      }

      const data = await response.json()
      console.log("📊 Permissions: Status do plano recebido:", data)

      // ✅ CORRIGIDO: Mapear corretamente os limites da API
      const mappedLimits: PlanLimits = {
        whatsapp_instances: data.limits?.whatsapp_instances_limit || data.limits?.whatsapp_instances || 0,
        max_appointments: data.limits?.appointments_limit || data.limits?.max_appointments || 0,
        max_assistants: data.limits?.assistants_limit || data.limits?.max_assistants || 0,
        profiles_limit: data.limits?.profiles_limit || 0, // ✅ CORRIGIDO: Usar profiles_limit
        support_level: data.limits?.support_level || "",
        advanced_reports: data.limits?.advanced_reports || false,
        hospital_integration: data.limits?.hospital_integration || false,
        advanced_customization: data.limits?.advanced_customization || false,
        api_access: data.limits?.api_access || false,
        priority_support: data.limits?.priority_support || false,
        custom_branding: data.limits?.custom_branding || false,
      }

      const mappedUsage: CurrentUsage = {
        whatsapp_instances_count: data.usage?.whatsapp_instances_count || 0,
        appointments_this_month: data.usage?.appointments_count || data.usage?.appointments_this_month || 0,
        assistants_count: data.usage?.assistants_count || 0,
        profiles_count: data.usage?.profiles_count || 0, // ✅ CORRIGIDO: Usar profiles_count
      }

      setPlanStatus({
        planName: data.planName ?? data.plan_name ?? "Básico",
        limits: mappedLimits,
        usage: mappedUsage,
      })

      console.log("📊 Permissions: Status mapeado:", {
        planName: data.planName ?? data.plan_name ?? "Básico",
        limits: mappedLimits,
        usage: mappedUsage,
      })
    } catch (error) {
      console.error("❌ Permissions: Erro ao buscar plano:", error)
      setError(error instanceof Error ? error.message : "Erro desconhecido")
    } finally {
      setLoading(false)
    }
  }

  const canCreateWhatsAppInstance = (): boolean => {
    if (!planStatus || !planStatus.limits) return false
    const { limits, usage = DEFAULT_USAGE } = planStatus

    // -1 significa ilimitado
    if (limits.whatsapp_instances === -1) return true

    return usage.whatsapp_instances_count < limits.whatsapp_instances
  }

  const canCreateAppointment = (): boolean => {
    if (!planStatus || !planStatus.limits) return false
    const { limits, usage = DEFAULT_USAGE } = planStatus

    // -1 significa ilimitado
    if (limits.max_appointments === -1) return true

    return usage.appointments_this_month < limits.max_appointments
  }

  const canCreateAssistant = (): boolean => {
    if (!planStatus || !planStatus.limits) return false
    const { limits, usage = DEFAULT_USAGE } = planStatus

    console.log("🤖 Permissions: Verificando assistente:", {
      planName: planStatus.planName,
      maxAssistants: limits.max_assistants,
      currentUsage: usage.assistants_count,
      canCreate: limits.max_assistants === -1 || usage.assistants_count < limits.max_assistants,
    })

    // -1 significa ilimitado
    if (limits.max_assistants === -1) return true

    return usage.assistants_count < limits.max_assistants
  }

  // ✅ CORRIGIDO: Agora verifica corretamente os limites de perfis
  const canCreateProfile = (): boolean => {
    if (!planStatus || !planStatus.limits) {
      console.log("👤 Permissions: planStatus ou limits não disponível")
      return false
    }

    const { limits, usage = DEFAULT_USAGE } = planStatus

    console.log("👤 Permissions: Verificando perfil:", {
      planName: planStatus.planName,
      maxProfiles: limits.profiles_limit,
      currentUsage: usage.profiles_count,
      canCreate: limits.profiles_limit === -1 || usage.profiles_count < limits.profiles_limit,
    })

    // -1 significa ilimitado
    if (limits.profiles_limit === -1) return true

    // Verifica se ainda há limite disponível
    return usage.profiles_count < limits.profiles_limit
  }

  const getRemainingWhatsAppInstances = (): number => {
    if (!planStatus || !planStatus.limits) return 0
    const { limits, usage = DEFAULT_USAGE } = planStatus

    if (limits.whatsapp_instances === -1) return 999 // Ilimitado

    return Math.max(0, limits.whatsapp_instances - usage.whatsapp_instances_count)
  }

  const getRemainingAppointments = (): number => {
    if (!planStatus || !planStatus.limits) return 0
    const { limits, usage = DEFAULT_USAGE } = planStatus

    if (limits.max_appointments === -1) return 999 // Ilimitado

    return Math.max(0, limits.max_appointments - usage.appointments_this_month)
  }

  const getRemainingAssistants = (): number => {
    if (!planStatus || !planStatus.limits) return 0
    const { limits, usage = DEFAULT_USAGE } = planStatus

    if (limits.max_assistants === -1) return 999 // Ilimitado

    return Math.max(0, limits.max_assistants - usage.assistants_count)
  }

  // ✅ CORRIGIDO: Função para verificar perfis restantes
  const getRemainingProfiles = (): number => {
    if (!planStatus || !planStatus.limits) return 0
    const { limits, usage = DEFAULT_USAGE } = planStatus

    if (limits.profiles_limit === -1) return 999 // Ilimitado

    return Math.max(0, limits.profiles_limit - usage.profiles_count)
  }

  const permissions = {
    canCreateWhatsApp: {
      allowed: canCreateWhatsAppInstance(),
      reason: canCreateWhatsAppInstance()
        ? ""
        : `Limite de ${planStatus?.limits.whatsapp_instances || 0} instâncias WhatsApp atingido`,
    },
    canCreateAppointment: {
      allowed: canCreateAppointment(),
      reason: canCreateAppointment()
        ? ""
        : `Limite de ${planStatus?.limits.max_appointments || 0} agendamentos mensais atingido`,
    },
    canCreateAssistant: {
      allowed: canCreateAssistant(),
      reason: canCreateAssistant() ? "" : `Limite de ${planStatus?.limits.max_assistants || 0} assistentes atingido`,
    },
    // ✅ CORRIGIDO: Agora mostra a mensagem correta
    canCreateProfile: {
      allowed: canCreateProfile(),
      reason: canCreateProfile()
        ? ""
        : planStatus?.limits.profiles_limit === 0
          ? "Perfis profissionais disponíveis apenas em planos pagos"
          : `Limite de ${planStatus?.limits.profiles_limit || 0} perfis atingido`,
    },
  }

  const features = {
    advanced_reports: planStatus?.limits.advanced_reports || false,
    hospital_integration: planStatus?.limits.hospital_integration || false,
    api_access: planStatus?.limits.api_access || false,
    advanced_customization: planStatus?.limits.advanced_customization || false,
    priority_support: planStatus?.limits.priority_support || false,
    custom_branding: planStatus?.limits.custom_branding || false,
  }

  return {
    planStatus,
    loading,
    error,
    permissions,
    features,
    limits: planStatus?.limits,
    usage: planStatus?.usage,
    canCreateWhatsAppInstance,
    canCreateAppointment,
    canCreateAssistant,
    canCreateProfile,
    getRemainingWhatsAppInstances,
    getRemainingAppointments,
    getRemainingAssistants,
    getRemainingProfiles, // ✅ ADICIONADO
    refetch: fetchPlanStatus,
  }
}
