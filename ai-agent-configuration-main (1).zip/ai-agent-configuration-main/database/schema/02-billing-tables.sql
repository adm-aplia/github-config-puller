-- Billing and subscription tables
-- Used by BillingService and UserSubscriptionService

-- Plans table (defines available subscription plans)
CREATE TABLE IF NOT EXISTS planos (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nome TEXT NOT NULL UNIQUE,
    descricao TEXT,
    valor DECIMAL(10,2) NOT NULL,
    
    -- Plan limits
    whatsapp_instances INTEGER NOT NULL DEFAULT 1,
    max_appointments INTEGER NOT NULL DEFAULT 300, -- -1 for unlimited
    max_assistants INTEGER NOT NULL DEFAULT 1, -- -1 for unlimited
    
    -- Plan features
    support_level TEXT DEFAULT 'email',
    advanced_reports BOOLEAN DEFAULT false,
    hospital_integration BOOLEAN DEFAULT false,
    advanced_customization BOOLEAN DEFAULT false,
    api_access BOOLEAN DEFAULT false,
    priority_support BOOLEAN DEFAULT false,
    custom_branding BOOLEAN DEFAULT false,
    
    ativo BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Clients table (used by BillingService)
CREATE TABLE IF NOT EXISTS clientes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    
    -- Client information
    nome TEXT NOT NULL,
    email TEXT NOT NULL,
    telefone TEXT,
    cpf_cnpj TEXT,
    
    -- Address information
    endereco TEXT,
    cidade TEXT,
    estado TEXT,
    cep TEXT,
    
    -- Subscription information
    plano TEXT NOT NULL DEFAULT 'Básico',
    customer_id_asaas TEXT, -- Asaas customer ID
    status TEXT DEFAULT 'ativo',
    is_active BOOLEAN DEFAULT true,
    data_contratacao TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    observacoes TEXT,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    UNIQUE(email),
    UNIQUE(cpf_cnpj)
);

-- Subscriptions table (used by BillingService)
CREATE TABLE IF NOT EXISTS assinaturas (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    id_cliente_supabase UUID NOT NULL REFERENCES clientes(id) ON DELETE CASCADE,
    
    -- Asaas integration
    customer_id_asaas TEXT NOT NULL,
    subscription_id TEXT NOT NULL UNIQUE,
    credit_card_token TEXT,
    
    -- Subscription details
    plano TEXT NOT NULL,
    valor DECIMAL(10,2) NOT NULL,
    descricao TEXT,
    status TEXT DEFAULT 'ACTIVE',
    
    -- Dates
    data_contratacao TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    next_due_date DATE,
    
    -- Metadata
    remote_ip INET,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
