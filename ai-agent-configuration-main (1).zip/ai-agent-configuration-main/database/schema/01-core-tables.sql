-- Core tables for the medical AI application
-- Only includes tables that are actively used in the codebase

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Professional profiles table (used by ProfileService)
CREATE TABLE IF NOT EXISTS professional_profiles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    
    -- Basic information
    fullName TEXT NOT NULL,
    fullname TEXT, -- duplicate field for compatibility
    specialty TEXT NOT NULL,
    professionalId TEXT,
    professionalid TEXT, -- duplicate field for compatibility
    phoneNumber TEXT,
    phonenumber TEXT, -- duplicate field for compatibility
    email TEXT,
    education TEXT,
    avatar_url TEXT,
    
    -- Location and schedule
    locations TEXT,
    workingHours TEXT,
    workinghours TEXT, -- duplicate field for compatibility
    procedures TEXT,
    
    -- Payment and insurance
    healthInsurance TEXT,
    healthinsurance TEXT, -- duplicate field for compatibility
    paymentMethods TEXT,
    paymentmethods TEXT, -- duplicate field for compatibility
    consultationFees TEXT,
    consultationfees TEXT, -- duplicate field for compatibility
    cancellationPolicy TEXT,
    cancellationpolicy TEXT, -- duplicate field for compatibility
    
    -- Appointment settings
    consultationDuration TEXT,
    consultationduration TEXT, -- duplicate field for compatibility
    timeBetweenConsultations TEXT,
    timebetweenconsultations TEXT, -- duplicate field for compatibility
    reschedulingPolicy TEXT,
    reschedulingpolicy TEXT, -- duplicate field for compatibility
    onlineConsultations TEXT,
    onlineconsultations TEXT, -- duplicate field for compatibility
    reminderPreferences TEXT,
    reminderpreferences TEXT, -- duplicate field for compatibility
    
    -- Patient requirements
    requiredPatientInfo TEXT,
    requiredpatientinfo TEXT, -- duplicate field for compatibility
    appointmentConditions TEXT,
    appointmentconditions TEXT, -- duplicate field for compatibility
    medicalHistoryRequirements TEXT,
    medicalhistoryrequirements TEXT, -- duplicate field for compatibility
    ageRequirements TEXT,
    agerequirements TEXT, -- duplicate field for compatibility
    
    -- Communication
    communicationChannels TEXT,
    communicationchannels TEXT, -- duplicate field for compatibility
    preAppointmentInfo TEXT,
    preappointmentinfo TEXT, -- duplicate field for compatibility
    requiredDocuments TEXT,
    requireddocuments TEXT, -- duplicate field for compatibility
    additionalInfo TEXT,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Profiles table (used by AgentService - consolidated agents)
CREATE TABLE IF NOT EXISTS profiles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    specialty TEXT,
    description TEXT,
    
    -- Settings fields (consolidated from agent_settings)
    appointment_response TEXT,
    emergency_response TEXT,
    followup_response TEXT,
    medical_advice_policy TEXT,
    personal_info_policy TEXT,
    escalation_criteria TEXT,
    
    -- WhatsApp instance associations
    instance_ids TEXT[] DEFAULT '{}',
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- WhatsApp instances table (used by WhatsAppService)
CREATE TABLE IF NOT EXISTS whatsapp_instances (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    instance_name TEXT NOT NULL UNIQUE,
    profile_name TEXT,
    profile_picture_url TEXT,
    phone_number TEXT,
    status TEXT DEFAULT 'disconnected',
    professional_profile_id UUID REFERENCES professional_profiles(id) ON DELETE SET NULL,
    last_connected_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Conversations table (used by ConversationService)
CREATE TABLE IF NOT EXISTS conversations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    instance_id UUID REFERENCES whatsapp_instances(id) ON DELETE CASCADE,
    agent_id UUID REFERENCES profiles(id) ON DELETE SET NULL,
    contact_name TEXT,
    contact_phone TEXT NOT NULL,
    status TEXT DEFAULT 'active',
    last_message_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Messages table (used by ConversationService)
CREATE TABLE IF NOT EXISTS messages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    conversation_id UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
    sender_type TEXT NOT NULL CHECK (sender_type IN ('user', 'agent', 'system')),
    content TEXT NOT NULL,
    message_type TEXT DEFAULT 'text',
    metadata JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Appointments table (used by AppointmentService)
CREATE TABLE IF NOT EXISTS appointments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    agent_id UUID REFERENCES profiles(id) ON DELETE SET NULL,
    conversation_id UUID REFERENCES conversations(id) ON DELETE SET NULL,
    
    -- Patient information
    patient_name TEXT NOT NULL,
    patient_phone TEXT NOT NULL,
    patient_email TEXT,
    
    -- Appointment details
    appointment_date TIMESTAMP WITH TIME ZONE NOT NULL,
    duration_minutes INTEGER DEFAULT 60,
    status TEXT DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'confirmed', 'completed', 'cancelled', 'no-show')),
    appointment_type TEXT,
    notes TEXT,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- User settings table (used by SettingsService)
CREATE TABLE IF NOT EXISTS user_settings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE UNIQUE,
    
    -- General settings
    language TEXT DEFAULT 'pt-BR',
    timezone TEXT DEFAULT 'America/Sao_Paulo',
    theme TEXT DEFAULT 'light',
    notifications_enabled BOOLEAN DEFAULT true,
    
    -- API settings
    api_url TEXT DEFAULT 'https://dinastia-evolution.kpgkys.easypanel.host',
    api_key TEXT DEFAULT '8C65A277A7E2A8EBC81BDDCE72949',
    
    -- AI settings
    ai_provider TEXT DEFAULT 'openai',
    ai_model TEXT DEFAULT 'gpt-4',
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Prompts table (used by PromptService)
CREATE TABLE IF NOT EXISTS prompts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    questionnaire_id UUID,
    prompt_text TEXT NOT NULL,
    prompt_type TEXT NOT NULL,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Google credentials table (used by GoogleCredentialsService)
CREATE TABLE IF NOT EXISTS google_credentials (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT NOT NULL,
    name TEXT,
    access_token TEXT,
    refresh_token TEXT,
    expires_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    UNIQUE(user_id, email)
);

-- Google profile links table
CREATE TABLE IF NOT EXISTS google_profile_links (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    google_credential_id UUID NOT NULL REFERENCES google_credentials(id) ON DELETE CASCADE,
    professional_profile_id UUID NOT NULL REFERENCES professional_profiles(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    UNIQUE(google_credential_id, professional_profile_id)
);
