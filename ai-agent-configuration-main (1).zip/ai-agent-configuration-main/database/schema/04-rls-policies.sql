-- Row Level Security (RLS) policies

-- Enable RLS on all tables
ALTER TABLE professional_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE whatsapp_instances ENABLE ROW LEVEL SECURITY;
ALTER TABLE conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE appointments ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE prompts ENABLE ROW LEVEL SECURITY;
ALTER TABLE google_credentials ENABLE ROW LEVEL SECURITY;
ALTER TABLE google_profile_links ENABLE ROW LEVEL SECURITY;
ALTER TABLE clientes ENABLE ROW LEVEL SECURITY;
ALTER TABLE assinaturas ENABLE ROW LEVEL SECURITY;

-- Professional profiles policies
CREATE POLICY "Users can view their own professional profiles" ON professional_profiles
    FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own professional profiles" ON professional_profiles
    FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own professional profiles" ON professional_profiles
    FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own professional profiles" ON professional_profiles
    FOR DELETE USING (auth.uid() = user_id);

-- Profiles policies
CREATE POLICY "Users can view their own profiles" ON profiles
    FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own profiles" ON profiles
    FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own profiles" ON profiles
    FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own profiles" ON profiles
    FOR DELETE USING (auth.uid() = user_id);

-- WhatsApp instances policies
CREATE POLICY "Users can view their own whatsapp instances" ON whatsapp_instances
    FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own whatsapp instances" ON whatsapp_instances
    FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own whatsapp instances" ON whatsapp_instances
    FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own whatsapp instances" ON whatsapp_instances
    FOR DELETE USING (auth.uid() = user_id);

-- Conversations policies
CREATE POLICY "Users can view their own conversations" ON conversations
    FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own conversations" ON conversations
    FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own conversations" ON conversations
    FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own conversations" ON conversations
    FOR DELETE USING (auth.uid() = user_id);

-- Messages policies
CREATE POLICY "Users can view messages from their conversations" ON messages
    FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM conversations 
            WHERE conversations.id = messages.conversation_id 
            AND conversations.user_id = auth.uid()
        )
    );

CREATE POLICY "Users can insert messages to their conversations" ON messages
    FOR INSERT WITH CHECK (
        EXISTS (
            SELECT 1 FROM conversations 
            WHERE conversations.id = messages.conversation_id 
            AND conversations.user_id = auth.uid()
        )
    );

CREATE POLICY "Users can update messages from their conversations" ON messages
    FOR UPDATE USING (
        EXISTS (
            SELECT 1 FROM conversations 
            WHERE conversations.id = messages.conversation_id 
            AND conversations.user_id = auth.uid()
        )
    );

CREATE POLICY "Users can delete messages from their conversations" ON messages
    FOR DELETE USING (
        EXISTS (
            SELECT 1 FROM conversations 
            WHERE conversations.id = messages.conversation_id 
            AND conversations.user_id = auth.uid()
        )
    );

-- Appointments policies
CREATE POLICY "Users can view their own appointments" ON appointments
    FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own appointments" ON appointments
    FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own appointments" ON appointments
    FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own appointments" ON appointments
    FOR DELETE USING (auth.uid() = user_id);

-- User settings policies
CREATE POLICY "Users can view their own settings" ON user_settings
    FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own settings" ON user_settings
    FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own settings" ON user_settings
    FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own settings" ON user_settings
    FOR DELETE USING (auth.uid() = user_id);

-- Prompts policies
CREATE POLICY "Users can view their own prompts" ON prompts
    FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own prompts" ON prompts
    FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own prompts" ON prompts
    FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own prompts" ON prompts
    FOR DELETE USING (auth.uid() = user_id);

-- Google credentials policies
CREATE POLICY "Users can view their own google credentials" ON google_credentials
    FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own google credentials" ON google_credentials
    FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own google credentials" ON google_credentials
    FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own google credentials" ON google_credentials
    FOR DELETE USING (auth.uid() = user_id);

-- Google profile links policies
CREATE POLICY "Users can view their own google profile links" ON google_profile_links
    FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM google_credentials 
            WHERE google_credentials.id = google_profile_links.google_credential_id 
            AND google_credentials.user_id = auth.uid()
        )
    );

CREATE POLICY "Users can insert their own google profile links" ON google_profile_links
    FOR INSERT WITH CHECK (
        EXISTS (
            SELECT 1 FROM google_credentials 
            WHERE google_credentials.id = google_profile_links.google_credential_id 
            AND google_credentials.user_id = auth.uid()
        )
    );

CREATE POLICY "Users can update their own google profile links" ON google_profile_links
    FOR UPDATE USING (
        EXISTS (
            SELECT 1 FROM google_credentials 
            WHERE google_credentials.id = google_profile_links.google_credential_id 
            AND google_credentials.user_id = auth.uid()
        )
    );

CREATE POLICY "Users can delete their own google profile links" ON google_profile_links
    FOR DELETE USING (
        EXISTS (
            SELECT 1 FROM google_credentials 
            WHERE google_credentials.id = google_profile_links.google_credential_id 
            AND google_credentials.user_id = auth.uid()
        )
    );

-- Billing policies
CREATE POLICY "Users can view their own client data" ON clientes
    FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own client data" ON clientes
    FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own client data" ON clientes
    FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can view their own subscriptions" ON assinaturas
    FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM clientes 
            WHERE clientes.id = assinaturas.id_cliente_supabase 
            AND clientes.user_id = auth.uid()
        )
    );

CREATE POLICY "Users can insert their own subscriptions" ON assinaturas
    FOR INSERT WITH CHECK (
        EXISTS (
            SELECT 1 FROM clientes 
            WHERE clientes.id = assinaturas.id_cliente_supabase 
            AND clientes.user_id = auth.uid()
        )
    );

CREATE POLICY "Users can update their own subscriptions" ON assinaturas
    FOR UPDATE USING (
        EXISTS (
            SELECT 1 FROM clientes 
            WHERE clientes.id = assinaturas.id_cliente_supabase 
            AND clientes.user_id = auth.uid()
        )
    );

-- Plans table is public read-only
CREATE POLICY "Anyone can view plans" ON planos
    FOR SELECT USING (ativo = true);
