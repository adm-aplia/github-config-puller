-- Database functions and triggers

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create triggers for updated_at
CREATE TRIGGER update_professional_profiles_updated_at BEFORE UPDATE ON professional_profiles FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON profiles FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_whatsapp_instances_updated_at BEFORE UPDATE ON whatsapp_instances FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_conversations_updated_at BEFORE UPDATE ON conversations FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_appointments_updated_at BEFORE UPDATE ON appointments FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_user_settings_updated_at BEFORE UPDATE ON user_settings FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_prompts_updated_at BEFORE UPDATE ON prompts FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_google_credentials_updated_at BEFORE UPDATE ON google_credentials FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_clientes_updated_at BEFORE UPDATE ON clientes FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_assinaturas_updated_at BEFORE UPDATE ON assinaturas FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_planos_updated_at BEFORE UPDATE ON planos FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Function to handle new user registration
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
    -- Create default user settings
    INSERT INTO user_settings (user_id)
    VALUES (NEW.id);
    
    -- Create default client record
    INSERT INTO clientes (user_id, nome, email, plano)
    VALUES (
        NEW.id,
        COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email),
        NEW.email,
        'Básico'
    );
    
    RETURN NEW;
END;
$$ language 'plpgsql' SECURITY DEFINER;

-- Create trigger for new user
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- Function to get user plan limits
CREATE OR REPLACE FUNCTION get_user_plan_limits(user_uuid UUID)
RETURNS TABLE (
    plan_name TEXT,
    whatsapp_instances INTEGER,
    max_appointments INTEGER,
    max_assistants INTEGER,
    support_level TEXT,
    advanced_reports BOOLEAN,
    hospital_integration BOOLEAN,
    advanced_customization BOOLEAN,
    api_access BOOLEAN,
    priority_support BOOLEAN,
    custom_branding BOOLEAN
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        c.plano,
        p.whatsapp_instances,
        p.max_appointments,
        p.max_assistants,
        p.support_level,
        p.advanced_reports,
        p.hospital_integration,
        p.advanced_customization,
        p.api_access,
        p.priority_support,
        p.custom_branding
    FROM clientes c
    JOIN planos p ON p.nome = c.plano
    WHERE c.user_id = user_uuid
    AND c.is_active = true
    AND c.status = 'ativo'
    AND p.ativo = true;
END;
$$ language 'plpgsql' SECURITY DEFINER;

-- Function to get user current usage
CREATE OR REPLACE FUNCTION get_user_current_usage(user_uuid UUID)
RETURNS TABLE (
    whatsapp_instances_count BIGINT,
    appointments_this_month BIGINT,
    assistants_count BIGINT
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        (SELECT COUNT(*) FROM whatsapp_instances WHERE user_id = user_uuid),
        (SELECT COUNT(*) FROM appointments 
         WHERE user_id = user_uuid 
         AND created_at >= date_trunc('month', CURRENT_DATE)),
        (SELECT COUNT(*) FROM profiles WHERE user_id = user_uuid);
END;
$$ language 'plpgsql' SECURITY DEFINER;
