/**
 * Mapeamento de Funcionalidades → Tabelas
 * Este arquivo documenta quais tabelas são usadas por cada funcionalidade do sistema
 */

export const FUNCTIONALITY_TABLE_MAPPING = {
  // 🏠 DASHBOARD PRINCIPAL
  dashboard: {
    tables: ["appointments", "conversations", "whatsapp_instances", "professional_profiles"],
    description: "Métricas gerais, estatísticas e visão geral do sistema",
  },

  // 👤 PERFIS PROFISSIONAIS
  profiles: {
    tables: ["professional_profiles", "google_credentials", "google_profile_links"],
    description: "Criação, edição e gerenciamento de perfis médicos",
  },

  // 🤖 ASSISTENTES/AGENTES IA
  agents: {
    tables: ["profiles", "whatsapp_instances", "prompts"],
    description: "Configuração de assistentes IA e suas configurações",
  },

  // 📱 WHATSAPP
  whatsapp: {
    tables: ["whatsapp_instances", "profiles", "professional_profiles"],
    description: "Conexões WhatsApp e vinculação com perfis profissionais",
  },

  // 💬 CONVERSAS/CHAT
  conversations: {
    tables: ["conversations", "messages", "whatsapp_instances", "professional_profiles"],
    description: "Histórico de conversas e mensagens com pacientes",
  },

  // 📅 AGENDAMENTOS
  appointments: {
    tables: ["appointments", "professional_profiles", "conversations"],
    description: "Sistema completo de agendamentos médicos",
  },

  // 🎯 PROMPTS IA
  prompts: {
    tables: ["prompts"],
    description: "Gerenciamento de prompts personalizados para IA",
  },

  // ⚙️ CONFIGURAÇÕES
  settings: {
    tables: ["user_settings", "profiles"],
    description: "Configurações pessoais e preferências do usuário",
  },

  // 💳 COBRANÇA/PLANOS
  billing: {
    tables: ["clientes", "assinaturas", "planos"],
    description: "Sistema de cobrança, planos e assinaturas",
  },

  // 🔐 AUTENTICAÇÃO
  auth: {
    tables: ["profiles", "clientes"],
    description: "Login, registro e gerenciamento de usuários",
  },

  // 🔗 INTEGRAÇÕES
  integrations: {
    tables: ["google_credentials", "google_profile_links"],
    description: "Integrações com Google Calendar e outros serviços",
  },

  // 📊 RELATÓRIOS
  reports: {
    tables: ["appointments", "conversations", "messages", "whatsapp_instances"],
    description: "Relatórios e análises de dados",
  },
} as const

/**
 * Tabelas por ordem de importância no sistema
 */
export const TABLE_PRIORITY = {
  critical: [
    "profiles", // Usuários base do sistema
    "professional_profiles", // Perfis médicos
    "whatsapp_instances", // Conexões WhatsApp
    "clientes", // Sistema de cobrança
  ],
  important: [
    "conversations", // Conversas com pacientes
    "appointments", // Agendamentos
    "messages", // Mensagens do chat
    "assinaturas", // Assinaturas ativas
  ],
  optional: [
    "prompts", // Prompts personalizados
    "user_settings", // Configurações pessoais
    "google_credentials", // Integração Google
    "google_profile_links", // Links Google-Perfil
    "planos", // Definição de planos
  ],
} as const
