/**
 * Mapeamento: Services → Tabelas que utilizam
 */

export const SERVICE_TABLE_MAPPING = {
  // 🔧 SERVICES PRINCIPAIS
  ProfileService: {
    primary: ["professional_profiles"],
    secondary: ["google_credentials", "google_profile_links"],
    methods: {
      getCurrentUserProfiles: ["professional_profiles"],
      updateProfessionalProfile: ["professional_profiles"],
      deleteProfessionalProfile: ["professional_profiles", "google_profile_links"],
    },
  },

  AgentService: {
    primary: ["profiles"],
    secondary: ["whatsapp_instances"],
    methods: {
      getUserAgents: ["profiles"],
      createAgent: ["profiles"],
      associateAgentWithInstances: ["profiles", "whatsapp_instances"],
    },
  },

  WhatsAppService: {
    primary: ["whatsapp_instances"],
    secondary: ["professional_profiles", "conversations"],
    methods: {
      getUserInstances: ["whatsapp_instances"],
      assignProfessionalProfile: ["whatsapp_instances", "professional_profiles"],
      getInstanceConversations: ["conversations", "whatsapp_instances"],
    },
  },

  ConversationService: {
    primary: ["conversations", "messages"],
    secondary: ["whatsapp_instances", "professional_profiles"],
    methods: {
      getUserConversations: ["conversations", "professional_profiles"],
      getConversation: ["conversations", "messages"],
      addMessage: ["messages", "conversations"],
    },
  },

  AppointmentService: {
    primary: ["appointments"],
    secondary: ["professional_profiles", "conversations"],
    methods: {
      getUserAppointments: ["appointments", "professional_profiles"],
      createAppointment: ["appointments"],
      getAppointmentsByContact: ["appointments"],
    },
  },

  BillingService: {
    primary: ["clientes", "assinaturas"],
    secondary: ["planos"],
    methods: {
      processBilling: ["clientes", "assinaturas"],
      findCliente: ["clientes"],
      activateClient: ["clientes"],
    },
  },

  UserSubscriptionService: {
    primary: ["clientes", "planos"],
    secondary: ["whatsapp_instances", "appointments", "profiles"],
    methods: {
      hasActiveSubscription: ["clientes"],
      getUserPlanLimits: ["clientes", "planos"],
      getCurrentUsage: ["whatsapp_instances", "appointments", "profiles"],
    },
  },

  PromptService: {
    primary: ["prompts"],
    secondary: [],
    methods: {
      getUserPrompts: ["prompts"],
      createPrompt: ["prompts"],
      updatePrompt: ["prompts"],
    },
  },

  SettingsService: {
    primary: ["user_settings"],
    secondary: ["profiles"],
    methods: {
      getUserSettings: ["user_settings"],
      updateSettings: ["user_settings"],
      createDefaultSettings: ["user_settings"],
    },
  },
} as const
