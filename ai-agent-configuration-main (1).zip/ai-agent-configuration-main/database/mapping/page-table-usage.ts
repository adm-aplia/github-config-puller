/**
 * Mapeamento detalhado: Páginas → Tabelas utilizadas
 */

export const PAGE_TABLE_USAGE = {
  // 📄 PÁGINAS PRINCIPAIS
  "/dashboard": {
    primary: ["appointments", "conversations", "whatsapp_instances"],
    secondary: ["professional_profiles", "profiles"],
    operations: ["SELECT (estatísticas)", "COUNT (métricas)"],
  },

  "/dashboard/perfis": {
    primary: ["professional_profiles"],
    secondary: ["google_credentials", "google_profile_links"],
    operations: ["SELECT", "INSERT", "UPDATE", "DELETE"],
  },

  "/dashboard/perfis/novo": {
    primary: ["professional_profiles"],
    secondary: ["google_credentials"],
    operations: ["INSERT (criar perfil)", "SELECT (validações)"],
  },

  "/dashboard/perfis/[id]/edit": {
    primary: ["professional_profiles"],
    secondary: ["google_credentials", "google_profile_links"],
    operations: ["SELECT", "UPDATE", "DELETE"],
  },

  "/dashboard/whatsapp": {
    primary: ["whatsapp_instances"],
    secondary: ["professional_profiles", "profiles"],
    operations: ["SELECT", "INSERT", "UPDATE", "DELETE"],
  },

  "/dashboard/conversas": {
    primary: ["conversations", "messages"],
    secondary: ["whatsapp_instances", "professional_profiles"],
    operations: ["SELECT", "UPDATE (status)"],
  },

  "/dashboard/conversas/[id]": {
    primary: ["conversations", "messages"],
    secondary: ["appointments", "professional_profiles"],
    operations: ["SELECT", "INSERT (mensagens)", "UPDATE"],
  },

  "/dashboard/agendamentos": {
    primary: ["appointments"],
    secondary: ["professional_profiles", "conversations"],
    operations: ["SELECT", "INSERT", "UPDATE", "DELETE"],
  },

  "/dashboard/prompts": {
    primary: ["prompts"],
    secondary: [],
    operations: ["SELECT", "INSERT", "UPDATE", "DELETE"],
  },

  "/dashboard/configuracoes": {
    primary: ["profiles", "user_settings"],
    secondary: [],
    operations: ["SELECT", "UPDATE"],
  },

  "/dashboard/planos": {
    primary: ["clientes", "assinaturas", "planos"],
    secondary: [],
    operations: ["SELECT", "UPDATE (upgrade/downgrade)"],
  },

  // 📄 PÁGINAS DE AUTENTICAÇÃO
  "/login": {
    primary: ["profiles"],
    secondary: ["clientes"],
    operations: ["SELECT (verificação)", "INSERT (primeiro login)"],
  },

  "/cadastro": {
    primary: ["profiles"],
    secondary: ["clientes"],
    operations: ["INSERT (novo usuário)"],
  },

  // 📄 PÁGINAS DE COBRANÇA
  "/checkout": {
    primary: ["clientes", "assinaturas"],
    secondary: ["planos"],
    operations: ["INSERT", "UPDATE"],
  },

  // 📄 API ROUTES
  "/api/profiles/save": {
    primary: ["professional_profiles"],
    secondary: ["google_credentials"],
    operations: ["INSERT", "UPDATE"],
  },

  "/api/whatsapp/[action]": {
    primary: ["whatsapp_instances"],
    secondary: ["conversations", "messages"],
    operations: ["SELECT", "UPDATE", "INSERT"],
  },

  "/api/billing/process": {
    primary: ["clientes", "assinaturas"],
    secondary: ["planos"],
    operations: ["INSERT", "UPDATE"],
  },
} as const
