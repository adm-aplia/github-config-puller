-- =====================================================
-- DADOS INICIAIS - PLANOS PADRÃO
-- =====================================================

INSERT INTO planos (nome, descricao, preco, max_assistants, max_conversations, max_messages, features) VALUES
('Gratuito', 'Plano básico para teste', 0.00, 1, 50, 500, '{"whatsapp": true, "basic_ai": true}'),
('Profissional', 'Plano para profissionais da saúde', 97.00, 3, 500, 5000, '{"whatsapp": true, "advanced_ai": true, "calendar_integration": true, "custom_prompts": true}'),
('Clínica', 'Plano para clínicas e consultórios', 297.00, 10, 2000, 20000, '{"whatsapp": true, "advanced_ai": true, "calendar_integration": true, "custom_prompts": true, "multi_user": true, "analytics": true}'),
('Empresa', 'Plano para grandes empresas', 597.00, 50, 10000, 100000, '{"whatsapp": true, "advanced_ai": true, "calendar_integration": true, "custom_prompts": true, "multi_user": true, "analytics": true, "priority_support": true, "custom_integrations": true}')
ON CONFLICT DO NOTHING;
