-- Default data for the application

-- Insert default plans
INSERT INTO planos (nome, descricao, valor, whatsapp_instances, max_appointments, max_assistants, support_level, advanced_reports, hospital_integration, advanced_customization, api_access, priority_support, custom_branding) VALUES
('Básico', 'Plano Básico Aplia – 1 número WhatsApp, até 300 agendamentos, 1 assistente, suporte por e-mail.', 199.00, 1, 300, 1, 'email', false, false, false, false, false, false),
('Profissional', 'Plano Profissional Aplia – 3 números WhatsApp, até 1000 agendamentos, 3 assistentes, suporte prioritário, relatórios avançados.', 399.00, 3, 1000, 3, 'priority', true, false, false, true, true, false),
('Empresarial', 'Plano Empresarial Aplia – +10 números WhatsApp, agendamentos ilimitados, assistentes ilimitados, suporte 24/7, integração com sistemas hospitalares, personalização avançada.', 899.00, 10, -1, -1, '24/7', true, true, true, true, true, true)
ON CONFLICT (nome) DO UPDATE SET
    descricao = EXCLUDED.descricao,
    valor = EXCLUDED.valor,
    whatsapp_instances = EXCLUDED.whatsapp_instances,
    max_appointments = EXCLUDED.max_appointments,
    max_assistants = EXCLUDED.max_assistants,
    support_level = EXCLUDED.support_level,
    advanced_reports = EXCLUDED.advanced_reports,
    hospital_integration = EXCLUDED.hospital_integration,
    advanced_customization = EXCLUDED.advanced_customization,
    api_access = EXCLUDED.api_access,
    priority_support = EXCLUDED.priority_support,
    custom_branding = EXCLUDED.custom_branding,
    updated_at = NOW();
