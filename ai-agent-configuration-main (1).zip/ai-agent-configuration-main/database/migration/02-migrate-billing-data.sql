-- MIGRAÇÃO DOS DADOS DE COBRANÇA
-- Migra clientes, assinaturas e planos para novo schema

-- 1. MIGRAR PLANOS (se não existirem)
-- Inserir planos padrão se não existirem
INSERT INTO planos (nome, descricao, valor, whatsapp_instances, max_appointments, max_assistants, support_level, advanced_reports, hospital_integration, advanced_customization, api_access, priority_support, custom_branding)
SELECT 'Básico', 'Plano Básico Aplia', 199.00, 1, 300, 1, 'email', false, false, false, false, false, false
WHERE NOT EXISTS (SELECT 1 FROM planos WHERE nome = 'Básico')
UNION ALL
SELECT 'Profissional', 'Plano Profissional Aplia', 399.00, 3, 1000, 3, 'priority', true, false, false, true, true, false
WHERE NOT EXISTS (SELECT 1 FROM planos WHERE nome = 'Profissional')
UNION ALL
SELECT 'Empresarial', 'Plano Empresarial Aplia', 899.00, 10, -1, -1, '24/7', true, true, true, true, true, true
WHERE NOT EXISTS (SELECT 1 FROM planos WHERE nome = 'Empresarial');

-- 2. MIGRAR CLIENTES
-- Consolidar dados de clientes de diferentes fontes
INSERT INTO clientes (
    id, user_id, nome, email, telefone, cpf_cnpj, endereco, cidade, estado, cep,
    plano, customer_id_asaas, status, is_active, data_contratacao, observacoes,
    created_at, updated_at
)
SELECT 
    COALESCE(c.id, gen_random_uuid()) as id,
    c.user_id,
    c.nome,
    c.email,
    c.telefone,
    c.cpf_cnpj,
    c.endereco,
    c.cidade,
    c.estado,
    c.cep,
    COALESCE(c.plano, 'Básico') as plano,
    c.customer_id as customer_id_asaas,
    COALESCE(c.status, 'ativo') as status,
    COALESCE(c.is_active, true) as is_active,
    COALESCE(c.data_contratacao, c.created_at, NOW()) as data_contratacao,
    c.observacoes,
    c.created_at,
    c.updated_at
FROM clientes_old c
WHERE c.user_id IS NOT NULL
ON CONFLICT (email) DO UPDATE SET
    nome = EXCLUDED.nome,
    telefone = EXCLUDED.telefone,
    cpf_cnpj = EXCLUDED.cpf_cnpj,
    endereco = EXCLUDED.endereco,
    cidade = EXCLUDED.cidade,
    estado = EXCLUDED.estado,
    cep = EXCLUDED.cep,
    plano = EXCLUDED.plano,
    customer_id_asaas = EXCLUDED.customer_id_asaas,
    status = EXCLUDED.status,
    is_active = EXCLUDED.is_active,
    updated_at = NOW();

-- 3. CRIAR CLIENTES PARA USUÁRIOS SEM REGISTRO DE COBRANÇA
-- Garantir que todo usuário tenha um registro de cliente
INSERT INTO clientes (
    user_id, nome, email, plano, status, is_active, data_contratacao
)
SELECT 
    u.id as user_id,
    COALESCE(u.raw_user_meta_data->>'full_name', split_part(u.email, '@', 1)) as nome,
    u.email,
    'Básico' as plano,
    'ativo' as status,
    false as is_active, -- Usuários sem pagamento ficam inativos
    u.created_at as data_contratacao
FROM auth.users u
WHERE NOT EXISTS (
    SELECT 1 FROM clientes WHERE clientes.user_id = u.id
)
ON CONFLICT (email) DO NOTHING;

-- 4. MIGRAR ASSINATURAS
-- Migrar dados de assinaturas existentes
INSERT INTO assinaturas (
    id, id_cliente_supabase, customer_id_asaas, subscription_id, plano, valor,
    descricao, status, data_contratacao, next_due_date, remote_ip,
    created_at, updated_at
)
SELECT 
    COALESCE(a.id, gen_random_uuid()) as id,
    c.id as id_cliente_supabase,
    a.customer_id_asaas,
    a.subscription_id,
    COALESCE(a.plano, c.plano) as plano,
    a.valor,
    a.descricao,
    COALESCE(a.status, 'ACTIVE') as status,
    COALESCE(a.data_contratacao, a.created_at, NOW()) as data_contratacao,
    a.next_due_date,
    a.remote_ip::INET,
    a.created_at,
    a.updated_at
FROM assinaturas_old a
JOIN clientes c ON c.customer_id_asaas = a.customer_id_asaas
WHERE a.subscription_id IS NOT NULL
ON CONFLICT (subscription_id) DO UPDATE SET
    status = EXCLUDED.status,
    valor = EXCLUDED.valor,
    next_due_date = EXCLUDED.next_due_date,
    updated_at = NOW();

-- 5. ATUALIZAR STATUS DOS CLIENTES BASEADO NAS ASSINATURAS
-- Ativar clientes que têm assinaturas ativas
UPDATE clientes 
SET 
    is_active = true,
    status = 'ativo',
    updated_at = NOW()
WHERE id IN (
    SELECT DISTINCT id_cliente_supabase 
    FROM assinaturas 
    WHERE status IN ('ACTIVE', 'RECEIVED')
);

-- 6. VERIFICAÇÕES DE INTEGRIDADE
SELECT 'MIGRAÇÃO DE COBRANÇA CONCLUÍDA - VERIFICANDO...' as status;

-- Verificar se todos os usuários têm cliente
SELECT 
    COUNT(u.id) as total_usuarios,
    COUNT(c.id) as total_clientes,
    COUNT(u.id) - COUNT(c.id) as usuarios_sem_cliente
FROM auth.users u
LEFT JOIN clientes c ON c.user_id = u.id;

-- Verificar distribuição de planos
SELECT 
    plano,
    COUNT(*) as quantidade,
    COUNT(CASE WHEN is_active THEN 1 END) as ativos,
    COUNT(CASE WHEN NOT is_active THEN 1 END) as inativos
FROM clientes
GROUP BY plano
ORDER BY plano;

-- Verificar assinaturas por status
SELECT 
    status,
    COUNT(*) as quantidade,
    SUM(valor) as valor_total
FROM assinaturas
GROUP BY status
ORDER BY status;

SELECT 'MIGRAÇÃO DE COBRANÇA FINALIZADA COM SUCESSO!' as resultado;
