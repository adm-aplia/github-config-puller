/**
 * PLANO DE MIGRAÇÃO E ORGANIZAÇÃO DO PROJETO
 * Etapas detalhadas para reorganizar o sistema
 */

export const MIGRATION_PLAN = {
  // FASE 1: PREPARAÇÃO (1-2 dias)
  phase1_preparation: {
    title: "Preparação e Backup",
    duration: "1-2 dias",
    tasks: [
      {
        task: "Backup completo do banco atual",
        description: "Fazer dump completo do Supabase atual",
        files: ["scripts/backup-current-database.sql"],
        priority: "CRÍTICO",
      },
      {
        task: "Análise de dependências",
        description: "Mapear todas as queries e relacionamentos atuais",
        files: ["database/analysis/current-dependencies.md"],
        priority: "ALTO",
      },
      {
        task: "Teste do schema novo",
        description: "Criar banco de teste com novo schema",
        files: ["database/test/test-new-schema.sql"],
        priority: "ALTO",
      },
    ],
  },

  // FASE 2: MIGRAÇÃO DE DADOS (2-3 dias)
  phase2_data_migration: {
    title: "Migração de Dados",
    duration: "2-3 dias",
    tasks: [
      {
        task: "Migrar tabelas principais",
        description: "Migrar dados das tabelas críticas primeiro",
        files: ["database/migration/01-migrate-core-tables.sql"],
        priority: "CRÍTICO",
      },
      {
        task: "Migrar dados de cobrança",
        description: "Migrar clientes, assinaturas e planos",
        files: ["database/migration/02-migrate-billing-data.sql"],
        priority: "ALTO",
      },
      {
        task: "Migrar configurações",
        description: "Migrar settings e prompts",
        files: ["database/migration/03-migrate-settings.sql"],
        priority: "MÉDIO",
      },
      {
        task: "Validar integridade",
        description: "Verificar se todos os dados foram migrados corretamente",
        files: ["database/validation/validate-migration.sql"],
        priority: "CRÍTICO",
      },
    ],
  },

  // FASE 3: ATUALIZAÇÃO DE SERVICES (3-4 dias)
  phase3_update_services: {
    title: "Atualização dos Services",
    duration: "3-4 dias",
    tasks: [
      {
        task: "Atualizar ProfileService",
        description: "Adaptar para novo schema de professional_profiles",
        files: ["lib/services/profile-service-v2.ts"],
        priority: "ALTO",
      },
      {
        task: "Consolidar AgentService",
        description: "Unificar agents em profiles",
        files: ["lib/services/agent-service-v2.ts"],
        priority: "ALTO",
      },
      {
        task: "Otimizar ConversationService",
        description: "Usar novas queries otimizadas",
        files: ["lib/services/conversation-service-v2.ts"],
        priority: "MÉDIO",
      },
      {
        task: "Simplificar BillingService",
        description: "Usar funções do banco para cálculos",
        files: ["lib/services/billing-service-v2.ts"],
        priority: "ALTO",
      },
    ],
  },

  // FASE 4: TESTES E VALIDAÇÃO (2-3 dias)
  phase4_testing: {
    title: "Testes e Validação",
    duration: "2-3 dias",
    tasks: [
      {
        task: "Testes unitários dos services",
        description: "Testar todos os services atualizados",
        files: ["tests/services/*.test.ts"],
        priority: "ALTO",
      },
      {
        task: "Testes de integração",
        description: "Testar fluxos completos do sistema",
        files: ["tests/integration/*.test.ts"],
        priority: "ALTO",
      },
      {
        task: "Testes de performance",
        description: "Verificar se as otimizações funcionaram",
        files: ["tests/performance/*.test.ts"],
        priority: "MÉDIO",
      },
      {
        task: "Testes de UI",
        description: "Verificar se todas as páginas funcionam",
        files: ["tests/ui/*.test.ts"],
        priority: "MÉDIO",
      },
    ],
  },

  // FASE 5: DEPLOY E MONITORAMENTO (1-2 dias)
  phase5_deploy: {
    title: "Deploy e Monitoramento",
    duration: "1-2 dias",
    tasks: [
      {
        task: "Deploy em staging",
        description: "Testar em ambiente de homologação",
        files: ["deploy/staging-deploy.yml"],
        priority: "ALTO",
      },
      {
        task: "Monitoramento de performance",
        description: "Configurar alertas e métricas",
        files: ["monitoring/performance-alerts.yml"],
        priority: "MÉDIO",
      },
      {
        task: "Deploy em produção",
        description: "Deploy final com rollback preparado",
        files: ["deploy/production-deploy.yml"],
        priority: "CRÍTICO",
      },
      {
        task: "Limpeza de tabelas antigas",
        description: "Remover tabelas não utilizadas após validação",
        files: ["database/cleanup/remove-old-tables.sql"],
        priority: "BAIXO",
      },
    ],
  },
} as const

export const ESTIMATED_TIMELINE = {
  total_duration: "9-14 dias",
  phases: {
    preparation: "1-2 dias",
    migration: "2-3 dias",
    services: "3-4 dias",
    testing: "2-3 dias",
    deploy: "1-2 dias",
  },
  critical_path: [
    "Backup do banco atual",
    "Migração das tabelas principais",
    "Atualização dos services críticos",
    "Testes de integração",
    "Deploy em produção",
  ],
} as const
