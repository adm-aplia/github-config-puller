-- Migration script to move from existing Supabase to new optimized schema
-- Run this script to migrate your existing data

-- Step 1: Backup existing data (optional but recommended)
-- You can create backup tables if needed

-- Step 2: Create new optimized schema
-- Run all the schema files first:
-- 01-core-tables.sql
-- 02-billing-tables.sql  
-- 03-indexes.sql
-- 04-rls-policies.sql
-- 05-functions.sql
-- 01-default-data.sql

-- Step 3: Migrate existing data
-- This assumes you have existing data in the old schema

-- Migrate professional_profiles (if structure changed)
-- Most fields should already exist, this handles any missing ones
DO $$
BEGIN
    -- Add any missing columns that might not exist
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'professional_profiles' AND column_name = 'fullname') THEN
        ALTER TABLE professional_profiles ADD COLUMN fullname TEXT;
    END IF;
    
    -- Update fullname from fullName if needed
    UPDATE professional_profiles SET fullname = "fullName" WHERE fullname IS NULL AND "fullName" IS NOT NULL;
END $$;

-- Migrate agents to profiles table
INSERT INTO profiles (id, user_id, name, specialty, description, appointment_response, emergency_response, followup_response, medical_advice_policy, personal_info_policy, escalation_criteria, instance_ids, created_at, updated_at)
SELECT 
    a.id,
    a.user_id,
    a.name,
    a.specialty,
    a.description,
    s.appointment_response,
    s.emergency_response,
    s.followup_response,
    s.medical_advice_policy,
    s.personal_info_policy,
    s.escalation_criteria,
    COALESCE(
        ARRAY(SELECT ai.instance_id::text FROM agent_instances ai WHERE ai.agent_id = a.id),
        '{}'::text[]
    ),
    a.created_at,
    a.updated_at
FROM agents a
LEFT JOIN agent_settings s ON s.agent_id = a.id
ON CONFLICT (id) DO UPDATE SET
    name = EXCLUDED.name,
    specialty = EXCLUDED.specialty,
    description = EXCLUDED.description,
    appointment_response = EXCLUDED.appointment_response,
    emergency_response = EXCLUDED.emergency_response,
    followup_response = EXCLUDED.followup_response,
    medical_advice_policy = EXCLUDED.medical_advice_policy,
    personal_info_policy = EXCLUDED.personal_info_policy,
    escalation_criteria = EXCLUDED.escalation_criteria,
    instance_ids = EXCLUDED.instance_ids,
    updated_at = EXCLUDED.updated_at;

-- Update conversations to reference profiles instead of agents
UPDATE conversations SET agent_id = (
    SELECT p.id FROM profiles p WHERE p.id = conversations.agent_id
) WHERE agent_id IS NOT NULL;

-- Update appointments to reference profiles instead of agents  
UPDATE appointments SET agent_id = (
    SELECT p.id FROM profiles p WHERE p.id = appointments.agent_id
) WHERE agent_id IS NOT NULL;

-- Migrate billing data (if needed)
-- Update clientes table with any missing user_id references
UPDATE clientes SET user_id = (
    SELECT id FROM auth.users WHERE email = clientes.email
) WHERE user_id IS NULL;

-- Step 4: Clean up old tables (CAREFUL - only run after verifying migration)
-- Uncomment these lines only after you've verified the migration worked correctly

-- DROP TABLE IF EXISTS agents CASCADE;
-- DROP TABLE IF EXISTS agent_settings CASCADE;
-- DROP TABLE IF EXISTS agent_instances CASCADE;
-- DROP TABLE IF EXISTS cobrancas CASCADE;
-- DROP TABLE IF EXISTS cliente_usage CASCADE;
-- DROP TABLE IF EXISTS dashboard_settings CASCADE;

-- Step 5: Verify migration
SELECT 'Migration completed. Please verify your data.' as status;

-- Verification queries:
SELECT COUNT(*) as professional_profiles_count FROM professional_profiles;
SELECT COUNT(*) as profiles_count FROM profiles;
SELECT COUNT(*) as whatsapp_instances_count FROM whatsapp_instances;
SELECT COUNT(*) as conversations_count FROM conversations;
SELECT COUNT(*) as appointments_count FROM appointments;
SELECT COUNT(*) as clientes_count FROM clientes;
SELECT COUNT(*) as assinaturas_count FROM assinaturas;
