/**
 * CHECKLIST DE MIGRAÇÃO
 * Lista de verificação para garantir que tudo foi migrado corretamente
 */

export const MIGRATION_CHECKLIST = {
  // ✅ PRÉ-MIGRAÇÃO
  pre_migration: [
    {
      task: "Backup completo do banco atual",
      command: "pg_dump -h host -U user -d database > backup_$(date +%Y%m%d).sql",
      status: "pending",
    },
    {
      task: "Verificar espaço em disco",
      command: "df -h",
      status: "pending",
    },
    {
      task: "Testar conexão com banco de destino",
      command: "psql -h new_host -U user -d new_database -c 'SELECT 1;'",
      status: "pending",
    },
    {
      task: "Validar schema novo",
      command: "psql -f database/schema/*.sql",
      status: "pending",
    },
  ],

  // 🔄 DURANTE A MIGRAÇÃO
  during_migration: [
    {
      task: "Executar migração de tabelas principais",
      file: "database/migration/01-migrate-core-tables.sql",
      validation: "SELECT COUNT(*) FROM professional_profiles;",
      status: "pending",
    },
    {
      task: "Executar migração de dados de cobrança",
      file: "database/migration/02-migrate-billing-data.sql",
      validation: "SELECT COUNT(*) FROM clientes;",
      status: "pending",
    },
    {
      task: "Verificar integridade referencial",
      validation: `
        SELECT 
          'conversations' as tabela,
          COUNT(*) as total,
          COUNT(CASE WHEN instance_id IS NULL THEN 1 END) as sem_instance
        FROM conversations
        UNION ALL
        SELECT 
          'appointments',
          COUNT(*),
          COUNT(CASE WHEN user_id IS NULL THEN 1 END)
        FROM appointments;
      `,
      status: "pending",
    },
  ],

  // ✅ PÓS-MIGRAÇÃO
  post_migration: [
    {
      task: "Verificar contagem de registros",
      validation: `
        SELECT 
          'professional_profiles' as tabela, COUNT(*) as total FROM professional_profiles
        UNION ALL
        SELECT 'profiles', COUNT(*) FROM profiles
        UNION ALL  
        SELECT 'whatsapp_instances', COUNT(*) FROM whatsapp_instances
        UNION ALL
        SELECT 'conversations', COUNT(*) FROM conversations
        UNION ALL
        SELECT 'messages', COUNT(*) FROM messages
        UNION ALL
        SELECT 'appointments', COUNT(*) FROM appointments
        UNION ALL
        SELECT 'clientes', COUNT(*) FROM clientes
        UNION ALL
        SELECT 'assinaturas', COUNT(*) FROM assinaturas;
      `,
      status: "pending",
    },
    {
      task: "Testar queries principais",
      validation: `
        -- Teste 1: Buscar perfis de um usuário
        SELECT COUNT(*) FROM professional_profiles WHERE user_id = (SELECT id FROM auth.users LIMIT 1);
        
        -- Teste 2: Buscar conversas com instâncias
        SELECT COUNT(*) FROM conversations c 
        JOIN whatsapp_instances w ON w.id = c.instance_id;
        
        -- Teste 3: Verificar planos e limites
        SELECT * FROM get_user_plan_limits((SELECT id FROM auth.users LIMIT 1));
      `,
      status: "pending",
    },
    {
      task: "Verificar performance das queries",
      validation: "EXPLAIN ANALYZE SELECT * FROM conversations WHERE user_id = $1 ORDER BY updated_at DESC LIMIT 10;",
      status: "pending",
    },
    {
      task: "Testar RLS policies",
      validation: `
        SET ROLE authenticated;
        SELECT COUNT(*) FROM professional_profiles; -- Deve retornar apenas perfis do usuário
        RESET ROLE;
      `,
      status: "pending",
    },
  ],

  // 🧪 TESTES DE VALIDAÇÃO
  validation_tests: [
    {
      name: "Teste de integridade de dados",
      description: "Verificar se não há dados órfãos",
      query: `
        -- Verificar conversas sem instância
        SELECT COUNT(*) as conversas_orfas FROM conversations 
        WHERE instance_id NOT IN (SELECT id FROM whatsapp_instances);
        
        -- Verificar mensagens sem conversa
        SELECT COUNT(*) as mensagens_orfas FROM messages 
        WHERE conversation_id NOT IN (SELECT id FROM conversations);
        
        -- Verificar agendamentos sem usuário
        SELECT COUNT(*) as agendamentos_orfaos FROM appointments 
        WHERE user_id NOT IN (SELECT id FROM auth.users);
      `,
      expected: "Todos os valores devem ser 0",
    },
    {
      name: "Teste de performance",
      description: "Verificar se queries principais são rápidas",
      queries: [
        "SELECT * FROM conversations WHERE user_id = $1 ORDER BY updated_at DESC LIMIT 10;",
        "SELECT * FROM appointments WHERE user_id = $1 AND appointment_date >= CURRENT_DATE;",
        "SELECT * FROM professional_profiles WHERE user_id = $1;",
      ],
      expected: "Todas as queries devem executar em < 100ms",
    },
    {
      name: "Teste funcional",
      description: "Verificar se funcionalidades principais funcionam",
      tests: [
        "Criar novo perfil profissional",
        "Criar nova instância WhatsApp",
        "Criar novo agendamento",
        "Buscar conversas do usuário",
        "Verificar limites do plano",
      ],
    },
  ],
} as const

export const ROLLBACK_PLAN = {
  description: "Plano de rollback em caso de problemas na migração",
  steps: [
    {
      step: 1,
      action: "Parar aplicação",
      command: "systemctl stop medical-ai-app",
    },
    {
      step: 2,
      action: "Restaurar backup do banco",
      command: "psql -h host -U user -d database < backup_YYYYMMDD.sql",
    },
    {
      step: 3,
      action: "Reverter código para versão anterior",
      command: "git checkout previous-stable-version",
    },
    {
      step: 4,
      action: "Reiniciar aplicação",
      command: "systemctl start medical-ai-app",
    },
    {
      step: 5,
      action: "Verificar funcionamento",
      command: "curl -f http://localhost:3000/health",
    },
  ],
  estimated_time: "15-30 minutos",
} as const
