-- MIGRAÇÃO DAS TABELAS PRINCIPAIS
-- Este script migra os dados das tabelas antigas para o novo schema

-- 1. MIGRAR PROFESSIONAL_PROFILES
-- Consolidar dados de perfis profissionais
INSERT INTO professional_profiles (
    id, user_id, fullName, fullname, specialty, professionalId, professionalid,
    phoneNumber, phonenumber, email, education, avatar_url, locations, 
    workingHours, workinghours, procedures, healthInsurance, healthinsurance,
    paymentMethods, paymentmethods, consultationFees, consultationfees,
    cancellationPolicy, cancellationpolicy, consultationDuration, consultationduration,
    timeBetweenConsultations, timebetweenconsultations, reschedulingPolicy, reschedulingpolicy,
    onlineConsultations, onlineconsultations, reminderPreferences, reminderpreferences,
    requiredPatientInfo, requiredpatientinfo, appointmentConditions, appointmentconditions,
    medicalHistoryRequirements, medicalhistoryrequirements, ageRequirements, agerequirements,
    communicationChannels, communicationchannels, preAppointmentInfo, preappointmentinfo,
    requiredDocuments, requireddocuments, additionalInfo, created_at, updated_at
)
SELECT 
    id, user_id, 
    COALESCE(fullName, fullname, 'Nome não informado') as fullName,
    COALESCE(fullName, fullname, 'Nome não informado') as fullname,
    COALESCE(specialty, 'Medicina Geral') as specialty,
    professionalId, professionalid,
    phoneNumber, phonenumber,
    email, education, avatar_url, locations,
    workingHours, workinghours,
    procedures,
    healthInsurance, healthinsurance,
    paymentMethods, paymentmethods,
    consultationFees, consultationfees,
    cancellationPolicy, cancellationpolicy,
    consultationDuration, consultationduration,
    timeBetweenConsultations, timebetweenconsultations,
    reschedulingPolicy, reschedulingpolicy,
    onlineConsultations, onlineconsultations,
    reminderPreferences, reminderpreferences,
    requiredPatientInfo, requiredpatientinfo,
    appointmentConditions, appointmentconditions,
    medicalHistoryRequirements, medicalhistoryrequirements,
    ageRequirements, agerequirements,
    communicationChannels, communicationchannels,
    preAppointmentInfo, preappointmentinfo,
    requiredDocuments, requireddocuments,
    additionalInfo,
    created_at, updated_at
FROM professional_profiles_old
WHERE user_id IS NOT NULL;

-- 2. MIGRAR PROFILES (consolidando agents)
-- Migrar dados de agents para profiles
INSERT INTO profiles (
    id, user_id, name, specialty, description,
    appointment_response, emergency_response, followup_response,
    medical_advice_policy, personal_info_policy, escalation_criteria,
    instance_ids, created_at, updated_at
)
SELECT 
    a.id, a.user_id, a.name, a.specialty, a.description,
    COALESCE(s.appointment_response, 'Resposta padrão para agendamentos') as appointment_response,
    COALESCE(s.emergency_response, 'Em caso de emergência, procure atendimento médico imediato') as emergency_response,
    COALESCE(s.followup_response, 'Resposta padrão para follow-up') as followup_response,
    COALESCE(s.medical_advice_policy, 'Não forneço diagnósticos ou prescrições por chat') as medical_advice_policy,
    COALESCE(s.personal_info_policy, 'Mantenho confidencialidade das informações pessoais') as personal_info_policy,
    COALESCE(s.escalation_criteria, 'Casos urgentes são encaminhados para atendimento humano') as escalation_criteria,
    ARRAY[]::TEXT[] as instance_ids,
    a.created_at, a.updated_at
FROM agents_old a
LEFT JOIN agent_settings_old s ON a.id = s.agent_id
WHERE a.user_id IS NOT NULL;

-- 3. MIGRAR WHATSAPP_INSTANCES
-- Manter estrutura atual, apenas limpar campos desnecessários
INSERT INTO whatsapp_instances (
    id, user_id, instance_name, profile_name, profile_picture_url,
    phone_number, status, professional_profile_id, last_connected_at,
    created_at, updated_at
)
SELECT 
    id, user_id, instance_name, profile_name, profile_picture_url,
    phone_number, COALESCE(status, 'disconnected') as status,
    professional_profile_id, last_connected_at,
    created_at, updated_at
FROM whatsapp_instances_old
WHERE user_id IS NOT NULL;

-- 4. MIGRAR CONVERSATIONS
-- Ajustar referências para nova estrutura
INSERT INTO conversations (
    id, user_id, instance_id, agent_id, contact_name, contact_phone,
    status, last_message_at, created_at, updated_at
)
SELECT 
    c.id, c.user_id, c.instance_id, c.agent_id, c.contact_name, c.contact_phone,
    COALESCE(c.status, 'active') as status,
    COALESCE(c.updated_at, c.created_at) as last_message_at,
    c.created_at, c.updated_at
FROM conversations_old c
WHERE c.user_id IS NOT NULL
AND c.instance_id IS NOT NULL;

-- 5. MIGRAR MESSAGES
-- Ajustar tipos de sender
INSERT INTO messages (
    id, conversation_id, sender_type, content, message_type, metadata, created_at
)
SELECT 
    m.id, m.conversation_id,
    CASE 
        WHEN m.sender = 'user' THEN 'user'
        WHEN m.sender = 'agent' THEN 'agent'
        ELSE 'system'
    END as sender_type,
    m.content,
    COALESCE(m.message_type, 'text') as message_type,
    '{}'::JSONB as metadata,
    m.created_at
FROM messages_old m
WHERE EXISTS (
    SELECT 1 FROM conversations WHERE conversations.id = m.conversation_id
);

-- 6. MIGRAR APPOINTMENTS
-- Manter estrutura atual
INSERT INTO appointments (
    id, user_id, agent_id, conversation_id, patient_name, patient_phone,
    patient_email, appointment_date, duration_minutes, status,
    appointment_type, notes, created_at, updated_at
)
SELECT 
    a.id, a.user_id, a.agent_id, a.conversation_id, a.patient_name, a.patient_phone,
    a.patient_email, a.appointment_date,
    60 as duration_minutes, -- padrão 60 minutos
    COALESCE(a.status, 'scheduled') as status,
    'consulta' as appointment_type,
    a.notes, a.created_at, a.updated_at
FROM appointments_old a
WHERE a.user_id IS NOT NULL;

-- 7. MIGRAR USER_SETTINGS
-- Consolidar configurações do usuário
INSERT INTO user_settings (
    id, user_id, language, timezone, theme, notifications_enabled,
    api_url, api_key, ai_provider, ai_model, created_at, updated_at
)
SELECT 
    gen_random_uuid() as id,
    us.user_id,
    COALESCE(us.language, 'pt-BR') as language,
    COALESCE(us.timezone, 'America/Sao_Paulo') as timezone,
    COALESCE(us.theme, 'light') as theme,
    COALESCE(us.notifications_enabled, true) as notifications_enabled,
    COALESCE(us.api_url, 'https://dinastia-evolution.kpgkys.easypanel.host') as api_url,
    COALESCE(us.api_key, '8C65A277A7E2A8EBC81BDDCE72949') as api_key,
    COALESCE(us.ai_provider, 'openai') as ai_provider,
    COALESCE(us.ai_model, 'gpt-4') as ai_model,
    us.created_at, us.updated_at
FROM user_settings_old us
WHERE us.user_id IS NOT NULL
ON CONFLICT (user_id) DO UPDATE SET
    language = EXCLUDED.language,
    timezone = EXCLUDED.timezone,
    theme = EXCLUDED.theme,
    notifications_enabled = EXCLUDED.notifications_enabled,
    api_url = EXCLUDED.api_url,
    api_key = EXCLUDED.api_key,
    ai_provider = EXCLUDED.ai_provider,
    ai_model = EXCLUDED.ai_model,
    updated_at = NOW();

-- 8. MIGRAR PROMPTS
-- Manter estrutura atual
INSERT INTO prompts (
    id, user_id, questionnaire_id, prompt_text, prompt_type, is_active, created_at, updated_at
)
SELECT 
    p.id, p.user_id, p.questionnaire_id, p.prompt_text,
    COALESCE(p.prompt_type, 'general') as prompt_type,
    COALESCE(p.is_active, true) as is_active,
    p.created_at, p.updated_at
FROM prompts_old p
WHERE p.user_id IS NOT NULL;

-- 9. MIGRAR GOOGLE_CREDENTIALS
-- Manter estrutura atual
INSERT INTO google_credentials (
    id, user_id, email, name, access_token, refresh_token, expires_at, created_at, updated_at
)
SELECT 
    gc.id, gc.user_id, gc.email, gc.name, gc.access_token, gc.refresh_token,
    gc.expires_at, gc.created_at, gc.updated_at
FROM google_credentials_old gc
WHERE gc.user_id IS NOT NULL
ON CONFLICT (user_id, email) DO UPDATE SET
    name = EXCLUDED.name,
    access_token = EXCLUDED.access_token,
    refresh_token = EXCLUDED.refresh_token,
    expires_at = EXCLUDED.expires_at,
    updated_at = NOW();

-- 10. MIGRAR GOOGLE_PROFILE_LINKS
-- Manter estrutura atual
INSERT INTO google_profile_links (
    id, google_credential_id, professional_profile_id, created_at
)
SELECT 
    gpl.id, gpl.google_credential_id, gpl.professional_profile_id, gpl.created_at
FROM google_profile_links_old gpl
WHERE EXISTS (
    SELECT 1 FROM google_credentials WHERE google_credentials.id = gpl.google_credential_id
)
AND EXISTS (
    SELECT 1 FROM professional_profiles WHERE professional_profiles.id = gpl.professional_profile_id
)
ON CONFLICT (google_credential_id, professional_profile_id) DO NOTHING;

-- VERIFICAÇÕES DE INTEGRIDADE
SELECT 'MIGRAÇÃO CONCLUÍDA - VERIFICANDO INTEGRIDADE...' as status;

-- Contar registros migrados
SELECT 
    'professional_profiles' as tabela,
    COUNT(*) as registros_migrados
FROM professional_profiles
UNION ALL
SELECT 'profiles', COUNT(*) FROM profiles
UNION ALL
SELECT 'whatsapp_instances', COUNT(*) FROM whatsapp_instances
UNION ALL
SELECT 'conversations', COUNT(*) FROM conversations
UNION ALL
SELECT 'messages', COUNT(*) FROM messages
UNION ALL
SELECT 'appointments', COUNT(*) FROM appointments
UNION ALL
SELECT 'user_settings', COUNT(*) FROM user_settings
UNION ALL
SELECT 'prompts', COUNT(*) FROM prompts
UNION ALL
SELECT 'google_credentials', COUNT(*) FROM google_credentials
UNION ALL
SELECT 'google_profile_links', COUNT(*) FROM google_profile_links;
