"use client"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Loader2, Link, CheckCircle, AlertCircle } from "lucide-react"
import { useAuth } from "@/hooks/use-auth"
import { useToast } from "@/hooks/use-toast"

interface GoogleAccount {
  id: string
  email: string
  name: string
  isLinked: boolean
  linkedProfileId?: string | null
}

interface GoogleLinkModalProps {
  profileId: string | null
  isOpen: boolean
  onClose: () => void
  fetchAvailableGoogleCredentials: () => Promise<any[]>
  handleLinkGoogleAccount: (profileId: string, credentialId: string) => Promise<void>
}

export function GoogleLinkModal({
  profileId,
  isOpen,
  onClose,
  fetchAvailableGoogleCredentials,
  handleLinkGoogleAccount,
}: GoogleLinkModalProps) {
  const [googleAccounts, setGoogleAccounts] = useState<GoogleAccount[]>([])
  const [loading, setLoading] = useState(false)
  const [linking, setLinking] = useState<string | null>(null)

  const { user } = useAuth()
  const { toast } = useToast()

  // Função para carregar contas Google
  const loadGoogleAccounts = async () => {
    if (!user?.id) {
      console.error("❌ Usuário não autenticado")
      toast({
        title: "Erro",
        description: "Usuário não autenticado",
        variant: "destructive",
      })
      return
    }

    try {
      setLoading(true)
      console.log("🔍 Carregando contas Google...")

      const response = await fetch(`/api/integrations/google-calendar/status?user_id=${user.id}`)

      if (!response.ok) {
        throw new Error("Erro ao carregar contas Google")
      }

      const data = await response.json()
      console.log("📧 Dados recebidos da API:", data)

      // Mapear os dados para o formato esperado
      const mappedAccounts: GoogleAccount[] = (data.credentials || []).map((credential: any) => ({
        id: credential.id,
        email: credential.email,
        name: credential.name || credential.email,
        isLinked: credential.linked || false,
        linkedProfileId: credential.professional_profile_id || null,
      }))

      console.log("📧 Contas Google mapeadas:", mappedAccounts)
      setGoogleAccounts(mappedAccounts)
    } catch (error) {
      console.error("❌ Erro ao carregar contas Google:", error)
      toast({
        title: "Erro",
        description: "Erro ao carregar contas Google",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  // Carregar contas quando o modal abrir
  useEffect(() => {
    if (isOpen && profileId) {
      loadGoogleAccounts()
    }
  }, [isOpen, profileId, user?.id])

  // Função para lidar com vinculação
  const handleLink = async (accountId: string) => {
    if (!profileId) return

    try {
      setLinking(accountId)
      console.log("🔗 Vinculando conta:", accountId, "ao perfil:", profileId)

      await handleLinkGoogleAccount(profileId, accountId)

      // Recarregar contas após vinculação
      await loadGoogleAccounts()

      toast({
        title: "Sucesso",
        description: "Conta Google vinculada com sucesso",
      })
    } catch (error) {
      console.error("❌ Erro ao vincular conta:", error)
      toast({
        title: "Erro",
        description: "Erro ao vincular conta Google",
        variant: "destructive",
      })
    } finally {
      setLinking(null)
    }
  }

  // Função para obter iniciais do nome
  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2)
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Vincular Conta Google</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {loading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-6 w-6 animate-spin" />
              <span className="ml-2">Carregando contas...</span>
            </div>
          ) : googleAccounts.length === 0 ? (
            <div className="text-center py-8">
              <AlertCircle className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium mb-2">Nenhuma conta encontrada</h3>
              <p className="text-muted-foreground mb-4">
                Você precisa conectar uma conta Google primeiro nas configurações.
              </p>
              <Button onClick={onClose} variant="outline">
                Fechar
              </Button>
            </div>
          ) : (
            <>
              <p className="text-sm text-muted-foreground">
                Selecione uma conta Google para vincular a este perfil profissional:
              </p>

              <div className="space-y-3">
                {googleAccounts.map((account) => (
                  <div
                    key={account.id}
                    className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50"
                  >
                    <div className="flex items-center space-x-3">
                      <Avatar className="h-10 w-10">
                        <AvatarFallback className="bg-red-500 text-white">{getInitials(account.name)}</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium">{account.name}</p>
                        <p className="text-sm text-muted-foreground">{account.email}</p>
                      </div>
                    </div>

                    <div className="flex items-center space-x-2">
                      {account.isLinked && account.linkedProfileId === profileId ? (
                        <Badge variant="outline" className="text-green-700 border-green-200">
                          <CheckCircle className="h-3 w-3 mr-1" />
                          Vinculado
                        </Badge>
                      ) : account.isLinked ? (
                        <Badge variant="secondary">Vinculado a outro perfil</Badge>
                      ) : (
                        <Button
                          size="sm"
                          onClick={() => handleLink(account.id)}
                          disabled={linking === account.id}
                          className="bg-red-500 hover:bg-red-600 text-white"
                        >
                          {linking === account.id ? (
                            <>
                              <Loader2 className="h-3 w-3 mr-1 animate-spin" />
                              Vinculando...
                            </>
                          ) : (
                            <>
                              <Link className="h-3 w-3 mr-1" />
                              Vincular
                            </>
                          )}
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex justify-end space-x-2 pt-4">
                <Button onClick={onClose} variant="outline">
                  Fechar
                </Button>
              </div>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
