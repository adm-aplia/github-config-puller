"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { User, MapPin, CreditCard, Calendar, FileText, Settings, ChevronLeft, ChevronRight } from "lucide-react"
import { useAuth } from "@/hooks/use-auth"
import { useToast } from "@/hooks/use-toast"

interface ProfileFormProps {
  mode: "create" | "edit"
  profileId?: string
  onSuccess: () => void
}

interface FormData {
  fullname: string
  specialty: string
  professionalid: string
  phonenumber: string
  email: string
  education: string
  locations: string
  workinghours: string
  procedures: string
  healthinsurance: string
  paymentmethods: string
  consultationfees: string
  cancellationpolicy: string
  consultationduration: string
  timebetweenconsultations: string
  reschedulingpolicy: string
  onlineconsultations: string
  reminderpreferences: string
  requiredpatientinfo: string
  appointmentconditions: string
  medicalhistoryrequirements: string
  agerequirements: string
  communicationchannels: string
  preappointmentinfo: string
  requireddocuments: string
}

const initialFormData: FormData = {
  fullname: "",
  specialty: "",
  professionalid: "",
  phonenumber: "",
  email: "",
  education: "",
  locations: "",
  workinghours: "",
  procedures: "",
  healthinsurance: "",
  paymentmethods: "",
  consultationfees: "",
  cancellationpolicy: "",
  consultationduration: "",
  timebetweenconsultations: "",
  reschedulingpolicy: "",
  onlineconsultations: "",
  reminderpreferences: "",
  requiredpatientinfo: "",
  appointmentconditions: "",
  medicalhistoryrequirements: "",
  agerequirements: "",
  communicationchannels: "",
  preappointmentinfo: "",
  requireddocuments: "",
}

const steps = [
  {
    id: 1,
    title: "Informações Básicas",
    subtitle: "Dados pessoais e profissionais",
    icon: User,
    fields: ["fullname", "specialty", "professionalid", "phonenumber", "email", "education"],
  },
  {
    id: 2,
    title: "Localização e Atendimento",
    subtitle: "Onde e como você atende",
    icon: MapPin,
    fields: ["locations", "workinghours", "procedures"],
  },
  {
    id: 3,
    title: "Planos e Pagamento",
    subtitle: "Convênios e formas de pagamento",
    icon: CreditCard,
    fields: ["healthinsurance", "paymentmethods", "consultationfees"],
  },
  {
    id: 4,
    title: "Agendamento e Políticas",
    subtitle: "Regras de agendamento",
    icon: Calendar,
    fields: ["cancellationpolicy", "consultationduration", "timebetweenconsultations", "reschedulingpolicy"],
  },
  {
    id: 5,
    title: "Consultas Online",
    subtitle: "Configurações de telemedicina",
    icon: FileText,
    fields: ["onlineconsultations", "reminderpreferences", "requiredpatientinfo"],
  },
  {
    id: 6,
    title: "Configurações Finais",
    subtitle: "Últimos detalhes",
    icon: Settings,
    fields: [
      "appointmentconditions",
      "medicalhistoryrequirements",
      "agerequirements",
      "communicationchannels",
      "preappointmentinfo",
      "requireddocuments",
    ],
  },
]

export function ProfileForm({ mode, profileId, onSuccess }: ProfileFormProps) {
  const [currentStep, setCurrentStep] = useState(1)
  const [formData, setFormData] = useState<FormData>(initialFormData)
  const [loading, setLoading] = useState(false)
  const [initialLoading, setInitialLoading] = useState(mode === "edit")

  const { user } = useAuth()
  const { toast } = useToast()

  // Calcular progresso
  const progress = (currentStep / steps.length) * 100

  // Carregar dados do perfil para edição
  useEffect(() => {
    if (mode === "edit" && profileId && user?.id) {
      loadProfileData()
    }
  }, [mode, profileId, user?.id])

  const loadProfileData = async () => {
    try {
      setInitialLoading(true)
      console.log("🔍 Carregando dados do perfil:", profileId)

      const response = await fetch(`/api/profiles?id=${profileId}&user_id=${user?.id}`)

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Erro ao carregar dados do perfil")
      }

      const data = await response.json()
      console.log("📋 Dados do perfil carregados:", data)

      // A API agora retorna { success: true, profile: {...} } para perfil específico
      if (data.success && data.profile) {
        console.log("✅ Definindo dados do formulário:", data.profile)
        setFormData(data.profile)
      } else {
        console.error("❌ Estrutura de resposta inesperada:", data)
        throw new Error("Dados do perfil não encontrados")
      }
    } catch (error) {
      console.error("❌ Erro ao carregar perfil:", error)
      toast({
        title: "Erro",
        description: error instanceof Error ? error.message : "Não foi possível carregar os dados do perfil",
        variant: "destructive",
      })
    } finally {
      setInitialLoading(false)
    }
  }

  // Atualizar campo do formulário
  const updateField = (field: keyof FormData, value: string) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  // Validar etapa atual
  const validateCurrentStep = () => {
    // Validação específica para a primeira etapa (campos obrigatórios)
    if (currentStep === 1) {
      if (!formData.fullname?.trim()) {
        toast({
          title: "Campo obrigatório",
          description: "Por favor, preencha o Nome Completo",
          variant: "destructive",
        })
        return false
      }

      if (!formData.specialty?.trim()) {
        toast({
          title: "Campo obrigatório",
          description: "Por favor, preencha a Especialidade",
          variant: "destructive",
        })
        return false
      }
    }

    return true
  }

  // Navegar para próxima etapa
  const handleNextStep = () => {
    console.log("🔄 Tentando ir para próxima etapa. Etapa atual:", currentStep)

    if (!validateCurrentStep()) {
      console.log("❌ Validação falhou")
      return
    }

    if (currentStep < steps.length) {
      const nextStep = currentStep + 1
      console.log("✅ Indo para etapa:", nextStep)
      setCurrentStep(nextStep)
    }
  }

  // Navegar para etapa anterior
  const handlePrevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1)
    }
  }

  // Ir para etapa específica
  const goToStep = (stepNumber: number) => {
    // Só permite ir para etapas já visitadas ou a próxima etapa
    if (stepNumber <= currentStep) {
      setCurrentStep(stepNumber)
    }
  }

  // Salvar perfil
  const handleSubmit = async () => {
    if (!user?.id) {
      toast({
        title: "Erro",
        description: "Usuário não encontrado",
        variant: "destructive",
      })
      return
    }

    try {
      setLoading(true)
      console.log("💾 Salvando perfil:", { mode, profileId, formData })

      const payload = {
        ...formData,
        user_id: user.id,
      }

      if (mode === "edit" && profileId) {
        payload.id = profileId
      }

      const response = await fetch("/api/profiles/save", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Erro ao salvar perfil")
      }

      const result = await response.json()
      console.log("✅ Perfil salvo com sucesso:", result)

      toast({
        title: "Sucesso",
        description: mode === "edit" ? "Perfil atualizado com sucesso" : "Perfil criado com sucesso",
      })

      onSuccess()
    } catch (error) {
      console.error("❌ Erro ao salvar perfil:", error)
      toast({
        title: "Erro",
        description: error instanceof Error ? error.message : "Erro ao salvar perfil",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  // Renderizar campo
  const renderField = (
    field: keyof FormData,
    label: string,
    placeholder: string,
    type: "input" | "textarea" = "input",
    required = false,
  ) => {
    const value = formData[field] || ""

    return (
      <div className="space-y-2">
        <Label htmlFor={field} className="text-sm font-medium">
          {label} {required && <span className="text-red-500">*</span>}
        </Label>
        {type === "textarea" ? (
          <Textarea
            id={field}
            placeholder={placeholder}
            value={value}
            onChange={(e) => updateField(field, e.target.value)}
            className="min-h-[100px] resize-none"
          />
        ) : (
          <Input
            id={field}
            type="text"
            placeholder={placeholder}
            value={value}
            onChange={(e) => updateField(field, e.target.value)}
          />
        )}
      </div>
    )
  }

  // Renderizar conteúdo da etapa
  const renderStepContent = () => {
    if (initialLoading) {
      return (
        <div className="flex items-center justify-center py-12">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-orange-500 mx-auto mb-4"></div>
            <p className="text-muted-foreground">Carregando dados do perfil...</p>
          </div>
        </div>
      )
    }

    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                <User className="h-5 w-5 text-orange-600" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900">Informações Básicas</h3>
                <p className="text-sm text-gray-600">Dados pessoais e profissionais</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {renderField("fullname", "Nome Completo", "Seu nome completo", "input", true)}
              {renderField("specialty", "Especialidade", "Sua especialidade médica", "input", true)}
              {renderField("professionalid", "Registro Profissional", "CRM, CRO, etc.", "input")}
              {renderField("phonenumber", "Telefone", "(11) 99999-9999", "input")}
            </div>

            <div className="grid grid-cols-1 gap-4">
              {renderField("email", "E-mail", "seu@email.com", "input")}
              {renderField(
                "education",
                "Formação Acadêmica",
                "Descreva sua formação acadêmica, residência, especializações...",
                "textarea",
              )}
            </div>
          </div>
        )

      case 2:
        return (
          <div className="space-y-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                <MapPin className="h-5 w-5 text-orange-600" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900">Localização e Atendimento</h3>
                <p className="text-sm text-gray-600">Onde e como você atende</p>
              </div>
            </div>

            <div className="space-y-4">
              {renderField("locations", "Locais de Atendimento", "Endereços dos consultórios, clínicas...", "textarea")}
              {renderField("workinghours", "Horários de Funcionamento", "Segunda a sexta: 8h às 18h...", "textarea")}
              {renderField(
                "procedures",
                "Procedimentos Realizados",
                "Lista dos procedimentos que você realiza",
                "textarea",
              )}
            </div>
          </div>
        )

      case 3:
        return (
          <div className="space-y-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                <CreditCard className="h-5 w-5 text-orange-600" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900">Planos e Pagamento</h3>
                <p className="text-sm text-gray-600">Convênios e formas de pagamento</p>
              </div>
            </div>

            <div className="space-y-4">
              {renderField("healthinsurance", "Convênios Aceitos", "Lista dos convênios que você aceita", "textarea")}
              {renderField("paymentmethods", "Formas de Pagamento", "Dinheiro, cartão, PIX...", "textarea")}
              {renderField("consultationfees", "Valores de Consulta", "Valores para consulta particular", "textarea")}
            </div>
          </div>
        )

      case 4:
        return (
          <div className="space-y-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                <Calendar className="h-5 w-5 text-orange-600" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900">Agendamento e Políticas</h3>
                <p className="text-sm text-gray-600">Regras de agendamento</p>
              </div>
            </div>

            <div className="space-y-4">
              {renderField(
                "cancellationpolicy",
                "Política de Cancelamento",
                "Regras para cancelamento de consultas",
                "textarea",
              )}
              {renderField("consultationduration", "Duração da Consulta", "Tempo médio de cada consulta", "input")}
              {renderField(
                "timebetweenconsultations",
                "Intervalo Entre Consultas",
                "Tempo entre uma consulta e outra",
                "input",
              )}
              {renderField("reschedulingpolicy", "Política de Reagendamento", "Regras para reagendamento", "textarea")}
            </div>
          </div>
        )

      case 5:
        return (
          <div className="space-y-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                <FileText className="h-5 w-5 text-orange-600" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900">Consultas Online</h3>
                <p className="text-sm text-gray-600">Configurações de telemedicina</p>
              </div>
            </div>

            <div className="space-y-4">
              {renderField("onlineconsultations", "Consultas Online", "Informações sobre telemedicina", "textarea")}
              {renderField(
                "reminderpreferences",
                "Preferências de Lembrete",
                "Como e quando enviar lembretes",
                "textarea",
              )}
              {renderField(
                "requiredpatientinfo",
                "Informações Necessárias do Paciente",
                "Dados que o paciente deve fornecer",
                "textarea",
              )}
            </div>
          </div>
        )

      case 6:
        return (
          <div className="space-y-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                <Settings className="h-5 w-5 text-orange-600" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900">Configurações Finais</h3>
                <p className="text-sm text-gray-600">Últimos detalhes</p>
              </div>
            </div>

            <div className="space-y-4">
              {renderField(
                "appointmentconditions",
                "Condições de Agendamento",
                "Condições especiais para agendamento",
                "textarea",
              )}
              {renderField(
                "medicalhistoryrequirements",
                "Requisitos de Histórico Médico",
                "Informações médicas necessárias",
                "textarea",
              )}
              {renderField("agerequirements", "Requisitos de Idade", "Faixa etária atendida", "input")}
              {renderField(
                "communicationchannels",
                "Canais de Comunicação",
                "WhatsApp, telefone, email...",
                "textarea",
              )}
              {renderField(
                "preappointmentinfo",
                "Informações Pré-Consulta",
                "O que o paciente deve saber antes",
                "textarea",
              )}
              {renderField(
                "requireddocuments",
                "Documentos Necessários",
                "Documentos que o paciente deve levar",
                "textarea",
              )}
            </div>
          </div>
        )

      default:
        return null
    }
  }

  return (
    <div className="w-full max-w-4xl mx-auto">
      {/* Header com progresso */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm text-gray-600">
            Etapa {currentStep} de {steps.length}
          </span>
          <span className="text-sm text-gray-600">{Math.round(progress)}% concluído</span>
        </div>
        <Progress value={progress} className="h-2 bg-gray-200">
          <div
            className="h-full bg-gradient-to-r from-orange-400 to-red-500 transition-all duration-300 ease-out rounded-full"
            style={{ width: `${progress}%` }}
          />
        </Progress>
      </div>

      {/* Tabs das etapas - Layout horizontal com scroll */}
      <div className="mb-8">
        <div className="overflow-x-auto pb-2">
          <div className="flex gap-2 min-w-max">
            {steps.map((step) => {
              const isActive = step.id === currentStep
              const isCompleted = step.id < currentStep
              const isAccessible = step.id <= currentStep

              return (
                <button
                  key={step.id}
                  onClick={() => isAccessible && goToStep(step.id)}
                  disabled={!isAccessible}
                  className={`
                    flex items-center gap-2 px-4 py-3 rounded-lg text-sm font-medium transition-all whitespace-nowrap
                    ${
                      isActive
                        ? "bg-orange-100 text-orange-700 border-2 border-orange-200"
                        : isCompleted
                          ? "bg-green-50 text-green-700 border border-green-200 hover:bg-green-100"
                          : isAccessible
                            ? "bg-gray-50 text-gray-600 border border-gray-200 hover:bg-gray-100"
                            : "bg-gray-50 text-gray-400 border border-gray-200 cursor-not-allowed"
                    }
                  `}
                >
                  <step.icon className="h-4 w-4 flex-shrink-0" />
                  <span>{step.title}</span>
                </button>
              )
            })}
          </div>
        </div>
      </div>

      {/* Conteúdo da etapa */}
      <Card className="mb-6">
        <CardContent className="p-6">{renderStepContent()}</CardContent>
      </Card>

      {/* Botões de navegação */}
      <div className="flex items-center justify-between">
        <Button
          variant="outline"
          onClick={handlePrevStep}
          disabled={currentStep === 1}
          className="flex items-center gap-2 bg-transparent"
        >
          <ChevronLeft className="h-4 w-4" />
          Anterior
        </Button>

        <div className="flex items-center gap-2">
          {currentStep < steps.length ? (
            <Button onClick={handleNextStep} className="bg-red-500 hover:bg-red-600 text-white flex items-center gap-2">
              Próximo
              <ChevronRight className="h-4 w-4" />
            </Button>
          ) : (
            <Button
              onClick={handleSubmit}
              disabled={loading}
              className="bg-red-500 hover:bg-red-600 text-white flex items-center gap-2"
            >
              {loading ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  Salvando...
                </>
              ) : (
                <>{mode === "edit" ? "Atualizar Perfil" : "Criar Perfil"}</>
              )}
            </Button>
          )}
        </div>
      </div>
    </div>
  )
}

// Exportação padrão
export default ProfileForm
