"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Edit, Trash2, Link, User, Loader2, RefreshCw } from "lucide-react"
import { useAuth } from "@/hooks/use-auth"
import { EditProfileModal } from "@/components/profiles/edit-profile-modal"
import { GoogleLinkModal } from "@/components/profiles/google-link-modal"
import { useToast } from "@/hooks/use-toast"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"

interface Profile {
  id: string
  user_id: string
  fullname: string
  specialty: string
  professionalid: string
  phonenumber: string
  email: string
  education: string
  locations: string
  workinghours: string
  procedures: string
  healthinsurance: string
  paymentmethods: string
  consultationfees: string
  cancellationpolicy: string
  consultationduration: string
  timebetweenconsultations: string
  reschedulingpolicy: string
  onlineconsultations: string
  reminderpreferences: string
  requiredpatientinfo: string
  appointmentconditions: string
  medicalhistoryrequirements: string
  agerequirements: string
  communicationchannels: string
  preappointmentinfo: string
  requireddocuments: string
  created_at: string
  updated_at: string
}

interface WhatsAppConnection {
  id: string
  instance_name: string
  profile_name: string
  status: string
  professional_profile_id: string | null
  phone_number: string | null
  created_at: string
}

interface GoogleCredential {
  id: string
  email: string
  name?: string | null
  professional_profile_id?: string | null
  linked?: boolean
  created_at: string
}

interface GoogleProfileLink {
  id: string
  google_credential_id: string
  professional_profile_id: string
  created_at: string
}

interface ProfilesListProps {
  refreshKey?: number
}

export function ProfilesList({ refreshKey }: ProfilesListProps) {
  const [profiles, setProfiles] = useState<Profile[]>([])
  const [whatsappConnections, setWhatsappConnections] = useState<WhatsAppConnection[]>([])
  const [googleCredentials, setGoogleCredentials] = useState<GoogleCredential[]>([])
  const [googleProfileLinks, setGoogleProfileLinks] = useState<GoogleProfileLink[]>([])
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [isEditModalOpen, setIsEditModalOpen] = useState(false)
  const [isGoogleLinkModalOpen, setIsGoogleLinkModalOpen] = useState(false)
  const [editingProfileId, setEditingProfileId] = useState<string | null>(null)
  const [linkingProfileId, setLinkingProfileId] = useState<string | null>(null)
  const [isDeletingProfile, setIsDeletingProfile] = useState<string | null>(null)
  const [loadingEditProfile, setLoadingEditProfile] = useState<string | null>(null)

  const { user } = useAuth()
  const { toast } = useToast()

  // Função para buscar credenciais Google disponíveis
  const fetchAvailableGoogleCredentials = async (): Promise<GoogleCredential[]> => {
    if (!user?.id) {
      console.log("❌ fetchAvailableGoogleCredentials: user.id não disponível")
      return []
    }

    try {
      console.log("🔍 Buscando credenciais Google para usuário:", user.id)

      const response = await fetch(`/api/integrations/google-calendar/status?user_id=${user.id}`)

      if (response.ok) {
        const data = await response.json()
        console.log("📧 Credenciais Google encontradas:", data)

        // Atualizar estados locais
        setGoogleCredentials(data.credentials || [])
        setGoogleProfileLinks(data.links || [])

        return data.credentials || []
      } else {
        console.log("⚠️ Erro ao buscar credenciais Google:", response.status)
        return []
      }
    } catch (error) {
      console.error("❌ Erro ao buscar credenciais Google:", error)
      return []
    }
  }

  // Função para vincular conta Google
  const handleLinkGoogleAccount = async (profileId: string, credentialId: string): Promise<void> => {
    if (!user?.id) {
      console.log("❌ handleLinkGoogleAccount: user.id não disponível")
      return
    }

    try {
      console.log("🔗 Vinculando conta Google:", { profileId, credentialId })

      const response = await fetch(`/api/integrations/google-calendar/link-profile`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          user_id: user.id,
          profile_id: profileId,
          credential_id: credentialId,
        }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Erro ao vincular conta Google")
      }

      const result = await response.json()
      console.log("✅ Conta Google vinculada com sucesso:", result)

      // Atualizar dados
      await fetchProfiles()
      await fetchGoogleCredentials()

      toast({
        title: "Sucesso",
        description: `Conta ${result.credential_email} vinculada com sucesso`,
      })
    } catch (error) {
      console.error("❌ Erro ao vincular conta Google:", error)
      toast({
        title: "Erro",
        description: error instanceof Error ? error.message : "Erro ao vincular conta Google",
        variant: "destructive",
      })
      throw error
    }
  }

  // Função para buscar credenciais Google
  const fetchGoogleCredentials = async () => {
    if (!user?.id) {
      console.log("❌ fetchGoogleCredentials: user.id não disponível")
      return
    }

    try {
      await fetchAvailableGoogleCredentials()
    } catch (error) {
      console.error("❌ Erro ao buscar credenciais Google:", error)
      setGoogleCredentials([])
      setGoogleProfileLinks([])
    }
  }

  // Função para buscar conexões WhatsApp
  const fetchWhatsAppConnections = async () => {
    if (!user?.id) {
      console.log("❌ fetchWhatsAppConnections: user.id não disponível")
      return
    }

    try {
      console.log("🔍 Buscando conexões WhatsApp para usuário:", user.id)

      const response = await fetch(`/api/whatsapp/status?user_id=${user.id}`)

      if (response.ok) {
        const data = await response.json()
        console.log("📱 Conexões WhatsApp encontradas:", data)
        setWhatsappConnections(data.connections || [])
      } else {
        console.log("⚠️ Erro ao buscar conexões WhatsApp:", response.status)
        setWhatsappConnections([])
      }
    } catch (error) {
      console.error("❌ Erro ao buscar conexões WhatsApp:", error)
      setWhatsappConnections([])
    }
  }

  // Função para buscar perfis
  const fetchProfiles = async () => {
    if (!user?.id) {
      console.log("❌ fetchProfiles: user.id não disponível")
      setLoading(false)
      return
    }

    try {
      setLoading(true)
      console.log("🔍 ProfilesList: Buscando perfis para usuário:", user.id)

      const response = await fetch(`/api/profiles?user_id=${user.id}`)

      if (!response.ok) {
        const errorText = await response.text()
        console.error("❌ Erro na resposta da API profiles:", response.status, errorText)
        throw new Error(`Erro ao buscar perfis: ${response.status}`)
      }

      const data = await response.json()
      console.log("📋 ProfilesList: Perfis recebidos:", data)

      setProfiles(data.profiles || [])
    } catch (error) {
      console.error("❌ ProfilesList: Erro ao buscar perfis:", error)
      toast({
        title: "Erro",
        description: "Não foi possível carregar os perfis",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  // Função para atualizar todos os dados
  const refreshAllData = async () => {
    if (!user?.id) {
      console.log("❌ refreshAllData: user.id não disponível")
      return
    }

    try {
      setRefreshing(true)
      console.log("🔄 Atualizando todos os dados...")

      await Promise.all([fetchProfiles(), fetchWhatsAppConnections(), fetchGoogleCredentials()])

      console.log("✅ Todos os dados atualizados")
      toast({
        title: "Atualizado",
        description: "Dados atualizados com sucesso",
      })
    } catch (error) {
      console.error("❌ Erro ao atualizar dados:", error)
      toast({
        title: "Erro",
        description: "Erro ao atualizar dados",
        variant: "destructive",
      })
    } finally {
      setRefreshing(false)
    }
  }

  // Carregar dados quando o componente montar ou refreshKey mudar
  useEffect(() => {
    if (user?.id) {
      console.log("🔄 ProfilesList useEffect: Carregando dados para user.id:", user.id)
      fetchProfiles()
      fetchWhatsAppConnections()
      fetchGoogleCredentials()
    } else {
      console.log("⚠️ ProfilesList useEffect: user.id não disponível:", user)
      setLoading(false)
    }
  }, [user, refreshKey])

  // Função para lidar com edição de perfil
  const handleEditProfile = async (profile: Profile) => {
    console.log("✏️ Editando perfil:", profile.id)

    try {
      setLoadingEditProfile(profile.id)

      // Primeiro, vamos verificar se conseguimos buscar os dados do perfil
      const response = await fetch(`/api/profiles?id=${profile.id}&user_id=${user?.id}`)

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Erro ao carregar dados do perfil")
      }

      const data = await response.json()
      console.log("📋 Dados do perfil para edição:", data)

      if (!data.success || !data.profile) {
        throw new Error("Dados do perfil não encontrados")
      }

      // Se conseguiu carregar os dados, abre o modal
      setEditingProfileId(profile.id)
      setIsEditModalOpen(true)
    } catch (error) {
      console.error("❌ Erro ao carregar perfil para edição:", error)
      toast({
        title: "Erro",
        description:
          error instanceof Error ? error.message : "Não foi possível carregar os dados do perfil para edição",
        variant: "destructive",
      })
    } finally {
      setLoadingEditProfile(null)
    }
  }

  // Função para lidar com vinculação Google
  const handleLinkGoogle = (profile: Profile) => {
    console.log("🔗 Vinculando Google para perfil:", profile.id)
    setLinkingProfileId(profile.id)
    setIsGoogleLinkModalOpen(true)
  }

  // Função para lidar com exclusão de perfil
  const handleDeleteProfile = async (profileId: string) => {
    if (!user?.id) {
      console.log("❌ handleDeleteProfile: user.id não disponível")
      return
    }

    if (isDeletingProfile) {
      console.log("⏳ Já está excluindo um perfil...")
      return
    }

    try {
      setIsDeletingProfile(profileId)
      console.log("🗑️ Excluindo perfil:", profileId)

      const response = await fetch(`/api/profiles/delete?id=${profileId}&user_id=${user.id}`, {
        method: "DELETE",
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Erro ao excluir perfil")
      }

      console.log("✅ Perfil excluído com sucesso")

      // Atualizar lista de perfis
      await fetchProfiles()

      toast({
        title: "Sucesso",
        description: "Perfil excluído com sucesso",
      })
    } catch (error) {
      console.error("❌ Erro ao excluir perfil:", error)
      toast({
        title: "Erro",
        description: error instanceof Error ? error.message : "Erro ao excluir perfil",
        variant: "destructive",
      })
    } finally {
      setIsDeletingProfile(null)
    }
  }

  // Função para lidar com sucesso da edição
  const handleEditModalSuccess = async () => {
    console.log("✅ Perfil editado com sucesso")
    setIsEditModalOpen(false)
    setEditingProfileId(null)
    await fetchProfiles()
    toast({
      title: "Sucesso",
      description: "Perfil atualizado com sucesso",
    })
  }

  // Função para formatar data
  const formatDate = (dateString: string) => {
    try {
      const date = new Date(dateString)
      return date.toLocaleDateString("pt-BR")
    } catch {
      return "Data inválida"
    }
  }

  // Função para capitalizar primeira letra
  const capitalizeFirst = (str: string) => {
    return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase()
  }

  // Função para renderizar status Google por perfil
  const renderGoogleStatusForProfile = (profileId: string) => {
    // Buscar credencial vinculada a este perfil
    const linkedCredential = googleCredentials.find((cred) => cred.professional_profile_id === profileId)

    if (!linkedCredential) {
      return <Badge variant="secondary">Não vinculado</Badge>
    }

    return <Badge variant="outline">{linkedCredential.email}</Badge>
  }

  // Função para renderizar status WhatsApp por perfil
  const renderWhatsAppStatusForProfile = (profileId: string) => {
    // Buscar conexões WhatsApp vinculadas a este perfil
    const profileConnections = whatsappConnections.filter((conn) => conn.professional_profile_id === profileId)

    if (profileConnections.length === 0) {
      return <Badge variant="secondary">Não vinculado</Badge>
    }

    // Obter nomes das conexões com primeira letra maiúscula
    const connectionNames = profileConnections
      .map((conn) => capitalizeFirst(conn.profile_name || conn.instance_name))
      .join(", ")

    return <Badge variant="outline">{connectionNames}</Badge>
  }

  // Se não há usuário, mostrar mensagem
  if (!user?.id) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Seus Perfis</CardTitle>
          <p className="text-sm text-muted-foreground">Lista de perfis profissionais cadastrados no sistema</p>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <User className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium mb-2">Usuário não encontrado</h3>
            <p className="text-muted-foreground mb-4">Faça login para ver seus perfis profissionais</p>
          </div>
        </CardContent>
      </Card>
    )
  }

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Seus Perfis</CardTitle>
          <p className="text-sm text-muted-foreground">Lista de perfis profissionais cadastrados no sistema</p>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="animate-pulse">
                <div className="h-4 bg-gray-200 rounded w-full mb-2"></div>
                <div className="h-4 bg-gray-200 rounded w-3/4"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Seus Perfis</CardTitle>
            <p className="text-sm text-muted-foreground">Lista de perfis profissionais cadastrados no sistema</p>
          </div>
          <Button onClick={refreshAllData} disabled={refreshing} variant="outline" size="sm">
            {refreshing ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {profiles.length === 0 ? (
          <div className="text-center py-8">
            <User className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium mb-2">Nenhum perfil encontrado</h3>
            <p className="text-muted-foreground mb-4">
              Seus perfis profissionais aparecerão aqui quando você criar o primeiro
            </p>
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nome</TableHead>
                <TableHead>Especialidade</TableHead>
                <TableHead>Data de Criação</TableHead>
                <TableHead>Conta Google</TableHead>
                <TableHead>Status WhatsApp</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {profiles.map((profile) => (
                <TableRow key={profile.id}>
                  <TableCell className="font-medium">{profile.fullname || "Nome não informado"}</TableCell>
                  <TableCell>{profile.specialty || "Especialidade não informada"}</TableCell>
                  <TableCell>{formatDate(profile.created_at)}</TableCell>
                  <TableCell>{renderGoogleStatusForProfile(profile.id)}</TableCell>
                  <TableCell>{renderWhatsAppStatusForProfile(profile.id)}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleEditProfile(profile)}
                        disabled={loadingEditProfile === profile.id}
                        className="hover:bg-gray-100"
                      >
                        {loadingEditProfile === profile.id ? (
                          <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                        ) : (
                          <Edit className="h-4 w-4 mr-1" />
                        )}
                        Editar
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleLinkGoogle(profile)}
                        className="hover:bg-gray-100"
                      >
                        <Link className="h-4 w-4 mr-1" />
                        Vincular
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button
                            variant="ghost"
                            size="sm"
                            disabled={isDeletingProfile === profile.id}
                            className="text-red-600 hover:text-red-800 hover:bg-red-50"
                          >
                            {isDeletingProfile === profile.id ? (
                              <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                            ) : (
                              <Trash2 className="h-4 w-4 mr-1" />
                            )}
                            Excluir
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Você tem certeza?</AlertDialogTitle>
                            <AlertDialogDescription>
                              Esta ação não pode ser desfeita. Isso excluirá permanentemente o perfil "
                              {profile.fullname}" e removerá todos os dados associados a ele.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancelar</AlertDialogCancel>
                            <AlertDialogAction
                              onClick={() => handleDeleteProfile(profile.id)}
                              className="bg-red-600 hover:bg-red-700"
                            >
                              Sim, excluir
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}

        {/* Modal de Edição */}
        <EditProfileModal
          profileId={editingProfileId}
          isOpen={isEditModalOpen}
          onClose={() => {
            setIsEditModalOpen(false)
            setEditingProfileId(null)
          }}
          onProfileUpdated={handleEditModalSuccess}
        />

        {/* Modal de Vinculação Google */}
        <GoogleLinkModal
          profileId={linkingProfileId}
          isOpen={isGoogleLinkModalOpen}
          onClose={() => {
            setIsGoogleLinkModalOpen(false)
            setLinkingProfileId(null)
          }}
          fetchAvailableGoogleCredentials={fetchAvailableGoogleCredentials}
          handleLinkGoogleAccount={handleLinkGoogleAccount}
        />
      </CardContent>
    </Card>
  )
}
