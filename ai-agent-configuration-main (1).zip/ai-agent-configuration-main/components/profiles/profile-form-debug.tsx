"use client"

/**
 * Wrapper para depuração.
 * Por enquanto apenas reaproveita o ProfileForm comum.
 * Adicione exibições de estados/valores conforme necessário.
 */

import ProfileForm, { type ProfileFormProps } from "./profile-form"

export function ProfileFormDebug(props: ProfileFormProps) {
  return <ProfileForm {...props} />
}

export default ProfileFormDebug
