"use client"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { ProfileForm } from "./profile-form"

interface EditProfileModalProps {
  profileId: string | null
  isOpen: boolean
  onClose: () => void
  onProfileUpdated: () => void
}

export function EditProfileModal({ profileId, isOpen, onClose, onProfileUpdated }: EditProfileModalProps) {
  const handleSuccess = () => {
    console.log("✅ EditProfileModal: Perfil atualizado com sucesso")
    onProfileUpdated()
    onClose()
  }

  const handleClose = () => {
    console.log("🔄 EditProfileModal: Modal fechado")
    onClose()
  }

  if (!profileId) return null

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-5xl max-h-[95vh] overflow-y-auto p-0">
        <DialogHeader className="p-6 pb-0">
          <DialogTitle className="text-xl font-semibold">Editar Perfil Profissional</DialogTitle>
          <DialogDescription className="text-gray-600">
            Atualize as informações do seu perfil profissional.
          </DialogDescription>
        </DialogHeader>
        <div className="p-6 pt-2">
          <ProfileForm mode="edit" profileId={profileId} onSuccess={handleSuccess} />
        </div>
      </DialogContent>
    </Dialog>
  )
}
