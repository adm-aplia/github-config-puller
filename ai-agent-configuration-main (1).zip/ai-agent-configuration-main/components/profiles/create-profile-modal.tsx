"use client"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { ProfileForm } from "./profile-form"

interface CreateProfileModalProps {
  isOpen: boolean
  onClose: () => void
  onProfileCreated: () => void
}

export function CreateProfileModal({ isOpen, onClose, onProfileCreated }: CreateProfileModalProps) {
  const handleSuccess = () => {
    console.log("✅ CreateProfileModal: Perfil criado com sucesso")
    onProfileCreated()
    onClose()
  }

  const handleClose = () => {
    console.log("🔄 CreateProfileModal: Modal fechado")
    onClose()
  }

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-5xl max-h-[95vh] overflow-y-auto p-0">
        <DialogHeader className="p-6 pb-0">
          <DialogTitle className="text-xl font-semibold">Criar Novo Perfil Profissional</DialogTitle>
          <DialogDescription className="text-gray-600">
            Preencha as informações para criar seu perfil profissional em 6 etapas.
          </DialogDescription>
        </DialogHeader>
        <div className="p-6 pt-2">
          <ProfileForm mode="create" onSuccess={handleSuccess} />
        </div>
      </DialogContent>
    </Dialog>
  )
}
