"use client"

import type React from "react"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { CalendarIcon, Plus, Loader2, AlertCircle, CheckCircle } from "lucide-react"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"
import { cn } from "@/lib/utils"
import { AppointmentService } from "@/lib/services/appointment-service"
import { WebhookService } from "@/lib/services/webhook-service"
import { useAuth } from "@/hooks/use-auth"

interface CreateAppointmentModalProps {
  onAppointmentCreated?: () => void
  defaultDate?: Date
  defaultAgentId?: string
  conversationId?: string
  patientPhone?: string
  patientName?: string
}

const statusOptions = [
  { value: "scheduled", label: "Agendado", color: "bg-blue-500" },
  { value: "confirmed", label: "Confirmado", color: "bg-green-500" },
  { value: "completed", label: "Concluído", color: "bg-emerald-500" },
  { value: "cancelled", label: "Cancelado", color: "bg-red-500" },
  { value: "no-show", label: "Não Compareceu", color: "bg-orange-500" },
  { value: "rescheduled", label: "Remarcado", color: "bg-yellow-500" },
]

export function CreateAppointmentModal({
  onAppointmentCreated,
  defaultDate,
  defaultAgentId,
  conversationId,
  patientPhone,
  patientName,
}: CreateAppointmentModalProps) {
  const { user } = useAuth()
  const [open, setOpen] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)

  // Form state
  const [formData, setFormData] = useState({
    patient_name: patientName || "",
    patient_phone: patientPhone || "",
    patient_email: "",
    appointment_date: defaultDate || new Date(),
    appointment_time: "09:00",
    status: "scheduled",
    notes: "",
    agent_id: defaultAgentId || "",
  })

  const [isCalendarOpen, setIsCalendarOpen] = useState(false)

  const validateEmail = (email: string) => {
    if (!email) return true // Email é opcional
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    return emailRegex.test(email)
  }

  const validatePhone = (phone: string) => {
    // Remove todos os caracteres não numéricos
    const cleanPhone = phone.replace(/\D/g, "")
    // Verifica se tem pelo menos 10 dígitos (DDD + número)
    return cleanPhone.length >= 10
  }

  const formatPhone = (phone: string) => {
    // Remove todos os caracteres não numéricos
    const cleanPhone = phone.replace(/\D/g, "")

    // Adiciona o código do país se não tiver
    if (cleanPhone.length >= 10 && !cleanPhone.startsWith("55")) {
      return `+55${cleanPhone}`
    } else if (cleanPhone.length >= 12 && cleanPhone.startsWith("55")) {
      return `+${cleanPhone}`
    }

    return phone
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!user) {
      setError("Usuário não autenticado")
      return
    }

    // Validações
    if (!formData.patient_name.trim()) {
      setError("Nome do paciente é obrigatório")
      return
    }

    if (!formData.patient_phone.trim()) {
      setError("Telefone do paciente é obrigatório")
      return
    }

    if (!validatePhone(formData.patient_phone)) {
      setError("Telefone inválido. Use o formato: (11) 99999-9999")
      return
    }

    if (formData.patient_email && !validateEmail(formData.patient_email)) {
      setError("Email inválido")
      return
    }

    try {
      setLoading(true)
      setError(null)

      // Combinar data e hora
      const appointmentDateTime = new Date(formData.appointment_date)
      const [hours, minutes] = formData.appointment_time.split(":")
      appointmentDateTime.setHours(Number.parseInt(hours), Number.parseInt(minutes), 0, 0)

      const appointmentData = {
        patient_name: formData.patient_name.trim(),
        patient_phone: formatPhone(formData.patient_phone),
        patient_email: formData.patient_email.trim() || null,
        appointment_date: appointmentDateTime.toISOString(),
        status: formData.status,
        notes: formData.notes.trim() || null,
        agent_id: formData.agent_id || null,
        conversation_id: conversationId || null,
      }

      console.log("Criando agendamento:", appointmentData)

      const appointment = await AppointmentService.createAppointment(appointmentData)

      console.log("Agendamento criado:", appointment)

      // Enviar webhook
      try {
        await WebhookService.sendAppointmentCreated({
          ...appointment,
          user_id: user.id,
        })
      } catch (webhookError) {
        console.error("Erro ao enviar webhook:", webhookError)
        // Não falhar a criação por causa do webhook
      }

      setSuccess(true)

      // Resetar formulário após 2 segundos
      setTimeout(() => {
        setFormData({
          patient_name: "",
          patient_phone: "",
          patient_email: "",
          appointment_date: new Date(),
          appointment_time: "09:00",
          status: "scheduled",
          notes: "",
          agent_id: "",
        })
        setSuccess(false)
        setOpen(false)
        onAppointmentCreated?.()
      }, 2000)
    } catch (error) {
      console.error("Erro ao criar agendamento:", error)
      setError(error instanceof Error ? error.message : "Erro ao criar agendamento")
    } finally {
      setLoading(false)
    }
  }

  const selectedStatus = statusOptions.find((option) => option.value === formData.status)

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          Novo Agendamento
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Criar Novo Agendamento</DialogTitle>
        </DialogHeader>

        {success && (
          <Alert className="border-green-200 bg-green-50">
            <CheckCircle className="h-4 w-4 text-green-600" />
            <AlertDescription className="text-green-800">Agendamento criado com sucesso!</AlertDescription>
          </Alert>
        )}

        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Informações do Paciente */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="patient_name">Nome do Paciente *</Label>
              <Input
                id="patient_name"
                value={formData.patient_name}
                onChange={(e) => setFormData((prev) => ({ ...prev, patient_name: e.target.value }))}
                placeholder="Nome completo do paciente"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="patient_phone">Telefone *</Label>
              <Input
                id="patient_phone"
                value={formData.patient_phone}
                onChange={(e) => setFormData((prev) => ({ ...prev, patient_phone: e.target.value }))}
                placeholder="(11) 99999-9999"
                required
              />
            </div>
          </div>

          {/* Email (opcional) */}
          <div className="space-y-2">
            <Label htmlFor="patient_email">Email (opcional)</Label>
            <Input
              id="patient_email"
              type="email"
              value={formData.patient_email}
              onChange={(e) => setFormData((prev) => ({ ...prev, patient_email: e.target.value }))}
              placeholder="email@exemplo.com"
            />
          </div>

          {/* Data e Hora */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Data do Agendamento *</Label>
              <Popover open={isCalendarOpen} onOpenChange={setIsCalendarOpen}>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !formData.appointment_date && "text-muted-foreground",
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {formData.appointment_date
                      ? format(formData.appointment_date, "dd/MM/yyyy", { locale: ptBR })
                      : "Selecione a data"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={formData.appointment_date}
                    onSelect={(date) => {
                      if (date) {
                        setFormData((prev) => ({ ...prev, appointment_date: date }))
                        setIsCalendarOpen(false)
                      }
                    }}
                    disabled={(date) => date < new Date(new Date().setHours(0, 0, 0, 0))}
                    initialFocus
                    locale={ptBR}
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div className="space-y-2">
              <Label htmlFor="appointment_time">Horário *</Label>
              <Input
                id="appointment_time"
                type="time"
                value={formData.appointment_time}
                onChange={(e) => setFormData((prev) => ({ ...prev, appointment_time: e.target.value }))}
                required
              />
            </div>
          </div>

          {/* Status */}
          <div className="space-y-2">
            <Label>Status do Agendamento</Label>
            <Select
              value={formData.status}
              onValueChange={(value) => setFormData((prev) => ({ ...prev, status: value }))}
            >
              <SelectTrigger>
                <SelectValue>
                  {selectedStatus && (
                    <div className="flex items-center gap-2">
                      <div className={cn("w-2 h-2 rounded-full", selectedStatus.color)} />
                      {selectedStatus.label}
                    </div>
                  )}
                </SelectValue>
              </SelectTrigger>
              <SelectContent>
                {statusOptions.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    <div className="flex items-center gap-2">
                      <div className={cn("w-2 h-2 rounded-full", option.color)} />
                      {option.label}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Observações */}
          <div className="space-y-2">
            <Label htmlFor="notes">Observações</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e) => setFormData((prev) => ({ ...prev, notes: e.target.value }))}
              placeholder="Observações adicionais sobre o agendamento..."
              rows={3}
            />
          </div>

          {/* Botões */}
          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => setOpen(false)} disabled={loading}>
              Cancelar
            </Button>
            <Button type="submit" disabled={loading}>
              {loading && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Criar Agendamento
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
