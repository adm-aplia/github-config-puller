"use client"

import { useState } from "react"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Clock, User, Phone } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface RescheduleAppointmentModalProps {
  isOpen: boolean
  onClose: () => void
  appointment: any
  onReschedule: (appointmentId: string, newDate: string) => Promise<void>
}

export function RescheduleAppointmentModal({
  isOpen,
  onClose,
  appointment,
  onReschedule,
}: RescheduleAppointmentModalProps) {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date())
  const [selectedTime, setSelectedTime] = useState<string>("")
  const [isLoading, setIsLoading] = useState(false)
  const { toast } = useToast()

  // Verificar se appointment existe antes de renderizar
  if (!appointment) {
    return null
  }

  // Horários disponíveis (8h às 18h)
  const availableTimes = Array.from({ length: 11 }, (_, i) => {
    const hour = i + 8
    return [`${hour}:00`, `${hour}:30`]
  }).flat()

  const handleReschedule = async () => {
    if (!selectedDate || !selectedTime) {
      toast({
        title: "Erro",
        description: "Por favor, selecione uma data e horário.",
        variant: "destructive",
      })
      return
    }

    try {
      setIsLoading(true)

      // Criar nova data/hora
      const newDateTime = new Date(selectedDate)
      const [hours, minutes] = selectedTime.split(":")
      newDateTime.setHours(Number.parseInt(hours), Number.parseInt(minutes), 0, 0)

      await onReschedule(appointment.id, newDateTime.toISOString())

      toast({
        title: "Agendamento remarcado",
        description: `Agendamento de ${appointment.patient_name} foi remarcado para ${format(newDateTime, "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}.`,
      })

      onClose()
    } catch (error) {
      console.error("Erro ao remarcar:", error)
      toast({
        title: "Erro",
        description: "Não foi possível remarcar o agendamento.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Remarcar Agendamento</DialogTitle>
          <DialogDescription>Selecione uma nova data e horário para o agendamento.</DialogDescription>
        </DialogHeader>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Informações do agendamento atual */}
          <div className="space-y-4">
            <div className="p-4 border rounded-lg bg-muted/50">
              <h3 className="font-medium mb-3">Agendamento Atual</h3>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <User className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">{appointment.patient_name}</span>
                </div>
                {appointment.patient_phone && (
                  <div className="flex items-center gap-2">
                    <Phone className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">{appointment.patient_phone}</span>
                  </div>
                )}
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">
                    {format(new Date(appointment.appointment_date), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
                  </span>
                </div>
                {appointment.professional_profiles?.fullName && (
                  <div className="text-sm text-muted-foreground">
                    Profissional: {appointment.professional_profiles.fullName}
                  </div>
                )}
              </div>
            </div>

            {/* Resumo da nova data/hora */}
            {selectedDate && selectedTime && (
              <div className="p-4 border rounded-lg bg-primary/5">
                <h3 className="font-medium mb-2">Nova Data/Hora</h3>
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-primary" />
                  <span className="text-sm font-medium">
                    {format(selectedDate, "dd/MM/yyyy", { locale: ptBR })} às {selectedTime}
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* Seleção de data e horário */}
          <div className="space-y-4">
            <div>
              <h3 className="font-medium mb-2">Selecionar Data</h3>
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={setSelectedDate}
                disabled={(date) => date < new Date() || date.getDay() === 0} // Não permite datas passadas nem domingos
                className="rounded-md border"
              />
            </div>

            {selectedDate && (
              <div>
                <h3 className="font-medium mb-2">Selecionar Horário</h3>
                <div className="grid grid-cols-3 gap-2 max-h-48 overflow-y-auto">
                  {availableTimes.map((time) => (
                    <Button
                      key={time}
                      variant={selectedTime === time ? "default" : "outline"}
                      size="sm"
                      onClick={() => setSelectedTime(time)}
                      className="text-xs"
                    >
                      {time}
                    </Button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={isLoading}>
            Cancelar
          </Button>
          <Button onClick={handleReschedule} disabled={!selectedDate || !selectedTime || isLoading}>
            {isLoading ? "Remarcando..." : "Remarcar Agendamento"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
