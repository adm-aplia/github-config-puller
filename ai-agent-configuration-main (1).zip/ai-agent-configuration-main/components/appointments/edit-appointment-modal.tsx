"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/hooks/use-toast"
import { CalendarIcon, User, Clock, FileText, UserCheck } from "lucide-react"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"
import { cn } from "@/lib/utils"
import { AppointmentService } from "@/lib/services/appointment-service"

interface EditAppointmentModalProps {
  appointmentId: string | null
  isOpen: boolean
  onClose: () => void
  onAppointmentUpdated?: () => void
}

export function EditAppointmentModal({
  appointmentId,
  isOpen,
  onClose,
  onAppointmentUpdated,
}: EditAppointmentModalProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [date, setDate] = useState<Date>()
  const [profiles, setProfiles] = useState<any[]>([])
  const [appointment, setAppointment] = useState<any>(null)
  const [formData, setFormData] = useState({
    patient_name: "",
    patient_phone: "",
    patient_email: "",
    time: "",
    notes: "",
    status: "scheduled",
    agent_id: "defaultAgentId", // Updated: default value changed to "defaultAgentId"
  })

  const { toast } = useToast()

  useEffect(() => {
    if (isOpen && appointmentId) {
      loadAppointment()
      fetchProfiles()
    }
  }, [isOpen, appointmentId])

  const loadAppointment = async () => {
    if (!appointmentId) return

    setIsLoading(true)
    try {
      const data = await AppointmentService.getAppointment(appointmentId)
      setAppointment(data)

      const appointmentDate = new Date(data.appointment_date)
      setDate(appointmentDate)

      setFormData({
        patient_name: data.patient_name || "",
        patient_phone: data.patient_phone || "",
        patient_email: data.patient_email || "",
        time: format(appointmentDate, "HH:mm"),
        notes: data.notes || "",
        status: data.status || "scheduled",
        agent_id: data.agent_id || "defaultAgentId", // Updated: uses "defaultAgentId" when no agent_id
      })
    } catch (error: any) {
      console.error("Erro ao carregar agendamento:", error)
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Não foi possível carregar o agendamento: " + error.message,
      })
    } finally {
      setIsLoading(false)
    }
  }

  const fetchProfiles = async () => {
    try {
      const supabase = (await import("@/lib/supabase-singleton")).getSupabaseInstance()
      if (!supabase) return

      const { data, error } = await supabase
        .from("professional_profiles")
        .select("id, fullName, specialty")
        .order("fullName")

      if (error) {
        console.error("Erro ao buscar perfis:", error)
        return
      }

      setProfiles(data || [])
    } catch (error) {
      console.error("Erro ao buscar perfis:", error)
    }
  }

  const handleSubmit = async () => {
    if (!appointmentId) return

    // Validação
    if (!formData.patient_name || !formData.patient_phone || !date || !formData.time) {
      toast({
        variant: "destructive",
        title: "Campos Obrigatórios",
        description: "Por favor, preencha todos os campos obrigatórios (nome, telefone, data, horário).",
      })
      return
    }

    setIsSaving(true)

    try {
      // Combinar data e hora
      const appointmentDateTime = new Date(date)
      const [hours, minutes] = formData.time.split(":")
      appointmentDateTime.setHours(Number.parseInt(hours), Number.parseInt(minutes))

      // Corrigido a lógica de envio: converte string vazia em null
      const agentId = formData.agent_id && formData.agent_id !== "defaultAgentId" ? formData.agent_id : null

      await AppointmentService.updateAppointment(appointmentId, {
        patient_name: formData.patient_name,
        patient_phone: formData.patient_phone,
        patient_email: formData.patient_email || null,
        appointment_date: appointmentDateTime.toISOString(),
        notes: formData.notes,
        status: formData.status,
        agent_id: agentId, // Usa a variável corrigida
      })

      toast({
        title: "Agendamento atualizado",
        description: "O agendamento foi atualizado com sucesso.",
      })

      onClose()

      // Callback para atualizar a lista
      if (onAppointmentUpdated) {
        onAppointmentUpdated()
      }
    } catch (error: any) {
      console.error("Erro ao atualizar agendamento:", error)
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Não foi possível atualizar o agendamento: " + error.message,
      })
    } finally {
      setIsSaving(false)
    }
  }

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      scheduled: { label: "Agendado", variant: "default" as const },
      confirmed: { label: "Confirmado", variant: "secondary" as const },
      completed: { label: "Concluído", variant: "default" as const },
      cancelled: { label: "Cancelado", variant: "destructive" as const },
      "no-show": { label: "Não compareceu", variant: "outline" as const },
    }

    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.scheduled
    return <Badge variant={config.variant}>{config.label}</Badge>
  }

  if (!isOpen) return null

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[900px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Editar Agendamento</DialogTitle>
        </DialogHeader>

        {isLoading ? (
          <div className="flex items-center justify-center py-8">
            <div className="text-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-2"></div>
              <p className="text-sm text-muted-foreground">Carregando agendamento...</p>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 py-4">
            {/* Coluna 1: Informações do Paciente */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <User className="h-4 w-4" />
                  Informações do Paciente
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="patient_name">Nome do Paciente *</Label>
                  <Input
                    id="patient_name"
                    value={formData.patient_name}
                    onChange={(e) => setFormData({ ...formData, patient_name: e.target.value })}
                    placeholder="Nome completo do paciente"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="patient_phone">Telefone *</Label>
                  <Input
                    id="patient_phone"
                    value={formData.patient_phone}
                    onChange={(e) => setFormData({ ...formData, patient_phone: e.target.value })}
                    placeholder="(11) 99999-9999"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="patient_email">Email</Label>
                  <Input
                    id="patient_email"
                    type="email"
                    value={formData.patient_email}
                    onChange={(e) => setFormData({ ...formData, patient_email: e.target.value })}
                    placeholder="email@exemplo.com"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Coluna 2: Detalhes do Agendamento */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <Clock className="h-4 w-4" />
                  Detalhes do Agendamento
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Data *</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        type="button"
                        variant="outline"
                        className={cn("w-full justify-start text-left font-normal", !date && "text-muted-foreground")}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {date ? format(date, "dd/MM/yyyy", { locale: ptBR }) : "Selecionar data"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar mode="single" selected={date} onSelect={setDate} initialFocus />
                    </PopoverContent>
                  </Popover>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="time">Horário *</Label>
                  <Input
                    id="time"
                    type="time"
                    value={formData.time}
                    onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Status</Label>
                  <Select
                    value={formData.status}
                    onValueChange={(value) => setFormData({ ...formData, status: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecionar status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="scheduled">Agendado</SelectItem>
                      <SelectItem value="confirmed">Confirmado</SelectItem>
                      <SelectItem value="completed">Concluído</SelectItem>
                      <SelectItem value="cancelled">Cancelado</SelectItem>
                      <SelectItem value="no-show">Não compareceu</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {profiles.length > 0 && (
                  <div className="space-y-2">
                    <Label>Perfil Profissional</Label>
                    <Select
                      value={formData.agent_id}
                      onValueChange={(value) => setFormData({ ...formData, agent_id: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecionar perfil (opcional)" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="defaultAgentId">Nenhum perfil</SelectItem>{" "}
                        {/* Updated: changed value to "defaultAgentId" */}
                        {profiles.map((profile) => (
                          <SelectItem key={profile.id} value={profile.id}>
                            {profile.fullName} - {profile.specialty}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Coluna 3: Observações e Resumo */}
            <div className="space-y-4">
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium flex items-center gap-2">
                    <FileText className="h-4 w-4" />
                    Observações
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Textarea
                    value={formData.notes}
                    onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                    placeholder="Observações adicionais sobre o agendamento"
                    rows={4}
                  />
                </CardContent>
              </Card>

              {appointment && (
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium flex items-center gap-2">
                      <UserCheck className="h-4 w-4" />
                      Resumo
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Status:</span>
                      {getStatusBadge(formData.status)}
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Criado em:</span>
                      <span className="text-sm">
                        {format(new Date(appointment.created_at), "dd/MM/yyyy", { locale: ptBR })}
                      </span>
                    </div>
                    {appointment.updated_at !== appointment.created_at && (
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">Atualizado em:</span>
                        <span className="text-sm">
                          {format(new Date(appointment.updated_at), "dd/MM/yyyy", { locale: ptBR })}
                        </span>
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        )}

        <div className="flex justify-end space-x-2 pt-4 border-t">
          <Button variant="outline" onClick={onClose} disabled={isSaving}>
            Cancelar
          </Button>
          <Button type="button" onClick={handleSubmit} disabled={isLoading || isSaving}>
            {isSaving ? "Salvando..." : "Salvar Alterações"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
