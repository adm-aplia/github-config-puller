"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Bot, MoreHorizontal, Pencil, Trash2, Loader2, Plus } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { AgentService, type Agent } from "@/lib/services/agent-service"
import { useToast } from "@/hooks/use-toast"
import { useMobile } from "@/hooks/use-mobile"
import { Card, CardContent } from "@/components/ui/card"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"

export function AgentsList() {
  const [agents, setAgents] = useState<Agent[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [agentToDelete, setAgentToDelete] = useState<string | null>(null)
  const { toast } = useToast()
  const isMobile = useMobile()

  // Carregar agentes ao montar o componente
  useEffect(() => {
    loadAgents()
  }, [])

  // Função para carregar agentes
  const loadAgents = async () => {
    try {
      setIsLoading(true)
      const data = await AgentService.getUserAgents()
      setAgents(data)
    } catch (error) {
      console.error("Erro ao carregar agentes:", error)
      toast({
        variant: "destructive",
        title: "Erro ao carregar agentes",
        description: "Não foi possível carregar a lista de agentes.",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Função para confirmar exclusão
  const confirmDelete = (id: string) => {
    setAgentToDelete(id)
    setDeleteDialogOpen(true)
  }

  // Função para excluir agente
  const handleDelete = async () => {
    if (!agentToDelete) return

    try {
      await AgentService.deleteAgent(agentToDelete)
      setAgents(agents.filter((agent) => agent.id !== agentToDelete))
      toast({
        title: "Agente excluído",
        description: "O agente foi excluído com sucesso.",
      })
    } catch (error) {
      console.error("Erro ao excluir agente:", error)
      toast({
        variant: "destructive",
        title: "Erro ao excluir agente",
        description: "Não foi possível excluir o agente.",
      })
    } finally {
      setAgentToDelete(null)
      setDeleteDialogOpen(false)
    }
  }

  // Renderizar estado de carregamento
  if (isLoading) {
    return (
      <div className="flex justify-center items-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    )
  }

  // Renderizar mensagem se não houver agentes
  if (agents.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-muted-foreground mb-4">Nenhum agente encontrado</p>
        <Button asChild>
          <Link href="/dashboard/agents/new">Criar Primeiro Agente</Link>
        </Button>
      </div>
    )
  }

  // Formatar data
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("pt-BR")
  }

  // Renderização para dispositivos móveis
  if (isMobile) {
    return (
      <div className="space-y-4">
        <div className="flex justify-end mb-2">
          <Button asChild size="sm" className="gap-2">
            <Link href="/dashboard/agents/new">
              <Plus className="h-4 w-4" />
              Novo Agente
            </Link>
          </Button>
        </div>

        {agents.map((agent) => (
          <Card key={agent.id} className="overflow-hidden">
            <CardContent className="p-0">
              <div className="p-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                    <Bot className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-medium">{agent.name}</h3>
                      <Badge variant="default" className="ml-auto">
                        Ativo
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">{agent.specialty || "Sem especialidade"}</p>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2 mt-3">
                  <div>
                    <p className="text-xs font-medium text-muted-foreground">Modelo</p>
                    <p className="text-sm">{agent.model}</p>
                  </div>
                  <div>
                    <p className="text-xs font-medium text-muted-foreground">Criado em</p>
                    <p className="text-sm">{formatDate(agent.created_at)}</p>
                  </div>
                </div>
              </div>
              <div className="flex border-t">
                <Button variant="ghost" className="flex-1 rounded-none py-2 h-auto" asChild>
                  <Link href={`/dashboard/agents/${agent.id}`}>
                    <Pencil className="h-4 w-4 mr-2" />
                    Editar
                  </Link>
                </Button>
                <div className="w-px bg-border" />
                <Button
                  variant="ghost"
                  className="flex-1 rounded-none py-2 h-auto text-destructive"
                  onClick={() => confirmDelete(agent.id)}
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Excluir
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    )
  }

  // Renderização para desktop
  return (
    <div className="space-y-4">
      {agents.map((agent) => (
        <div key={agent.id} className="flex items-center justify-between rounded-lg border p-4">
          <div className="flex items-center gap-4">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
              <Bot className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h3 className="font-medium">{agent.name}</h3>
              <p className="text-sm text-muted-foreground">{agent.specialty || "Sem especialidade"}</p>
            </div>
          </div>

          <div className="hidden md:flex items-center gap-4">
            <div className="text-center">
              <p className="text-sm font-medium">Modelo</p>
              <p className="text-xs text-muted-foreground">{agent.model}</p>
            </div>
            <div className="text-center">
              <p className="text-sm font-medium">Criado em</p>
              <p className="text-xs text-muted-foreground">{formatDate(agent.created_at)}</p>
            </div>
            <Badge variant="default">Ativo</Badge>
          </div>

          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" asChild>
              <Link href={`/dashboard/agents/${agent.id}`}>
                <Pencil className="h-4 w-4" />
                <span className="sr-only">Editar</span>
              </Link>
            </Button>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <MoreHorizontal className="h-4 w-4" />
                  <span className="sr-only">Mais</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem>Ver Análises</DropdownMenuItem>
                <DropdownMenuItem>Duplicar</DropdownMenuItem>
                <DropdownMenuItem className="text-destructive" onClick={() => confirmDelete(agent.id)}>
                  <Trash2 className="mr-2 h-4 w-4" />
                  Excluir
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      ))}

      {/* Diálogo de confirmação para exclusão */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir Agente</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir este agente? Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>Excluir</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
