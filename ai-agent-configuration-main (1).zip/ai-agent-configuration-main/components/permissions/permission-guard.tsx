"use client"

import type React from "react"

import { usePermissions } from "@/hooks/use-permissions"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import { Lock, Loader2 } from "lucide-react"
import Link from "next/link"

interface PermissionGuardProps {
  children: React.ReactNode
  feature?: "whatsapp" | "appointment" | "assistant" | "advanced_reports" | "hospital_integration" | "api_access"
  fallback?: React.ReactNode
  showUpgrade?: boolean
}

export function PermissionGuard({ children, feature, fallback, showUpgrade = true }: PermissionGuardProps) {
  const { limits, permissions, features, loading, error } = usePermissions()

  if (loading) {
    return (
      <div className="flex items-center justify-center p-4">
        <Loader2 className="h-6 w-6 animate-spin" />
        <span className="ml-2">Verificando permissões...</span>
      </div>
    )
  }

  if (error || !limits) {
    return (
      <Alert variant="destructive">
        <Lock className="h-4 w-4" />
        <AlertDescription>Erro ao verificar permissões. Tente novamente.</AlertDescription>
      </Alert>
    )
  }

  // Verificar permissão específica
  if (feature) {
    let hasPermission = false
    let errorMessage = ""

    switch (feature) {
      case "whatsapp":
        hasPermission = permissions.canCreateWhatsApp.allowed
        errorMessage = permissions.canCreateWhatsApp.reason
        break
      case "appointment":
        hasPermission = permissions.canCreateAppointment.allowed
        errorMessage = permissions.canCreateAppointment.reason
        break
      case "assistant":
        hasPermission = permissions.canCreateAssistant.allowed
        errorMessage = permissions.canCreateAssistant.reason
        break
      case "advanced_reports":
      case "hospital_integration":
      case "api_access":
        hasPermission = features[feature]
        errorMessage = `Funcionalidade '${feature}' não disponível no seu plano`
        break
    }

    if (!hasPermission) {
      if (fallback) {
        return <>{fallback}</>
      }

      return (
        <Alert>
          <Lock className="h-4 w-4" />
          <AlertDescription className="flex items-center justify-between">
            <span>{errorMessage}</span>
            {showUpgrade && (
              <Link href="/billing/upgrade">
                <Button size="sm" variant="outline">
                  Fazer Upgrade
                </Button>
              </Link>
            )}
          </AlertDescription>
        </Alert>
      )
    }
  }

  return <>{children}</>
}
