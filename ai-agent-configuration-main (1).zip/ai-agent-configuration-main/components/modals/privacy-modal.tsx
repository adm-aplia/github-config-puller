"use client"

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { useState } from "react"

export interface PrivacyModalProps {
  isOpen?: boolean
  onClose?: () => void
}

export function PrivacyModal({ isOpen = false, onClose }: PrivacyModalProps) {
  const [internalOpen, setInternalOpen] = useState(false)

  const handleClose = () => {
    if (onClose) {
      onClose()
    } else {
      setInternalOpen(false)
    }
  }

  const modalOpen = onClose ? isOpen : internalOpen
  const setModalOpen = onClose ? onClose : setInternalOpen

  return (
    <Dialog open={modalOpen} onOpenChange={handleClose}>
      <DialogTrigger asChild>
        <Button variant="link">Privacidade</Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold">Política de Privacidade</DialogTitle>
          <DialogDescription>Como coletamos, usamos e protegemos suas informações.</DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4 max-h-[60vh] overflow-y-auto">
          <p>
            Sua privacidade é importante para nós. Esta política de privacidade explica como coletamos, usamos e
            protegemos suas informações pessoais.
          </p>
          <p>
            Coletamos informações como seu nome, endereço de e-mail e localização quando você usa nossos serviços. Essas
            informações são usadas para personalizar sua experiência, melhorar nossos serviços e comunicar-se com você.
          </p>
          <p>
            Tomamos medidas razoáveis para proteger suas informações pessoais contra acesso, uso ou divulgação não
            autorizados. No entanto, nenhum método de transmissão pela internet ou método de armazenamento eletrônico é
            100% seguro.
          </p>
        </div>
        <DialogFooter>
          <Button onClick={handleClose}>Fechar</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
