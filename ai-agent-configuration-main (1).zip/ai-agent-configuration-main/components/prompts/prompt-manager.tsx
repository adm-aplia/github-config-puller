"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Loader2, Plus, Trash2, Edit, Save } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { PromptService, type Prompt } from "@/lib/services/prompt-service"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

interface PromptManagerProps {
  questionnaireId?: string
  defaultType?: string
  onPromptSelect?: (prompt: Prompt) => void
}

export function PromptManager({ questionnaireId, defaultType = "general", onPromptSelect }: PromptManagerProps) {
  const [prompts, setPrompts] = useState<Prompt[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isCreating, setIsCreating] = useState(false)
  const [isEditing, setIsEditing] = useState(false)
  const [selectedPrompt, setSelectedPrompt] = useState<Prompt | null>(null)
  const [formData, setFormData] = useState({
    prompt_text: "",
    prompt_type: defaultType,
    is_active: true,
  })
  const [filterType, setFilterType] = useState<string | undefined>(defaultType)
  const { toast } = useToast()

  // Carregar prompts ao montar o componente
  useEffect(() => {
    loadPrompts()
  }, [questionnaireId, filterType])

  const loadPrompts = async () => {
    try {
      setIsLoading(true)
      const data = await PromptService.getUserPrompts({
        questionnaireId,
        type: filterType,
      })
      setPrompts(data)
    } catch (error: any) {
      console.error("Erro ao carregar prompts:", error)
      toast({
        variant: "destructive",
        title: "Erro ao carregar prompts",
        description: error.message || "Não foi possível carregar os prompts.",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSwitchChange = (name: string, checked: boolean) => {
    setFormData((prev) => ({ ...prev, [name]: checked }))
  }

  const handleCreatePrompt = async () => {
    try {
      setIsCreating(true)
      const newPrompt = await PromptService.createPrompt({
        prompt_text: formData.prompt_text,
        prompt_type: formData.prompt_type,
        is_active: formData.is_active,
        questionnaire_id: questionnaireId,
      })

      setPrompts((prev) => [newPrompt, ...prev])
      setFormData({
        prompt_text: "",
        prompt_type: defaultType,
        is_active: true,
      })

      toast({
        title: "Prompt criado",
        description: "O prompt foi criado com sucesso.",
      })
    } catch (error: any) {
      console.error("Erro ao criar prompt:", error)
      toast({
        variant: "destructive",
        title: "Erro ao criar prompt",
        description: error.message || "Não foi possível criar o prompt.",
      })
    } finally {
      setIsCreating(false)
    }
  }

  const handleEditPrompt = (prompt: Prompt) => {
    setSelectedPrompt(prompt)
    setFormData({
      prompt_text: prompt.prompt_text,
      prompt_type: prompt.prompt_type,
      is_active: prompt.is_active,
    })
    setIsEditing(true)
  }

  const handleUpdatePrompt = async () => {
    if (!selectedPrompt) return

    try {
      const updatedPrompt = await PromptService.updatePrompt(selectedPrompt.id, {
        prompt_text: formData.prompt_text,
        prompt_type: formData.prompt_type,
        is_active: formData.is_active,
        questionnaire_id: questionnaireId,
      })

      setPrompts((prev) => prev.map((p) => (p.id === updatedPrompt.id ? updatedPrompt : p)))

      setSelectedPrompt(null)
      setFormData({
        prompt_text: "",
        prompt_type: defaultType,
        is_active: true,
      })

      toast({
        title: "Prompt atualizado",
        description: "O prompt foi atualizado com sucesso.",
      })
    } catch (error: any) {
      console.error("Erro ao atualizar prompt:", error)
      toast({
        variant: "destructive",
        title: "Erro ao atualizar prompt",
        description: error.message || "Não foi possível atualizar o prompt.",
      })
    } finally {
      setIsEditing(false)
    }
  }

  const handleDeletePrompt = async (id: string) => {
    try {
      await PromptService.deletePrompt(id)
      setPrompts((prev) => prev.filter((p) => p.id !== id))

      toast({
        title: "Prompt excluído",
        description: "O prompt foi excluído com sucesso.",
      })
    } catch (error: any) {
      console.error("Erro ao excluir prompt:", error)
      toast({
        variant: "destructive",
        title: "Erro ao excluir prompt",
        description: error.message || "Não foi possível excluir o prompt.",
      })
    }
  }

  const handleToggleActive = async (id: string, isActive: boolean) => {
    try {
      const updatedPrompt = await PromptService.togglePromptActive(id, isActive)
      setPrompts((prev) => prev.map((p) => (p.id === updatedPrompt.id ? updatedPrompt : p)))

      toast({
        title: isActive ? "Prompt ativado" : "Prompt desativado",
        description: `O prompt foi ${isActive ? "ativado" : "desativado"} com sucesso.`,
      })
    } catch (error: any) {
      console.error("Erro ao atualizar status do prompt:", error)
      toast({
        variant: "destructive",
        title: "Erro ao atualizar status",
        description: error.message || "Não foi possível atualizar o status do prompt.",
      })
    }
  }

  const promptTypes = [
    { value: "general", label: "Geral" },
    { value: "appointment", label: "Agendamento" },
    { value: "emergency", label: "Emergência" },
    { value: "followup", label: "Acompanhamento" },
    { value: "greeting", label: "Saudação" },
    { value: "medical_advice", label: "Conselho Médico" },
  ]

  if (isLoading) {
    return (
      <div className="flex justify-center items-center py-8">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Gerenciar Prompts</CardTitle>
          <CardDescription>Crie e gerencie prompts personalizados para seus agentes de IA</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-col md:flex-row gap-4 mb-4">
            <Select
              value={filterType || "all"}
              onValueChange={(value) => setFilterType(value === "all" ? undefined : value)}
            >
              <SelectTrigger className="w-full md:w-[200px]">
                <SelectValue placeholder="Filtrar por tipo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os tipos</SelectItem>
                {promptTypes.map((type) => (
                  <SelectItem key={type.value} value={type.value}>
                    {type.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Dialog>
              <DialogTrigger asChild>
                <Button className="ml-auto">
                  <Plus className="mr-2 h-4 w-4" />
                  Novo Prompt
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Criar Novo Prompt</DialogTitle>
                  <DialogDescription>Crie um novo prompt para seu agente de IA</DialogDescription>
                </DialogHeader>

                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="prompt_type">Tipo de Prompt</Label>
                    <Select
                      value={formData.prompt_type}
                      onValueChange={(value) => handleSelectChange("prompt_type", value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o tipo" />
                      </SelectTrigger>
                      <SelectContent>
                        {promptTypes.map((type) => (
                          <SelectItem key={type.value} value={type.value}>
                            {type.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="prompt_text">Texto do Prompt</Label>
                    <Textarea
                      id="prompt_text"
                      name="prompt_text"
                      value={formData.prompt_text}
                      onChange={handleInputChange}
                      placeholder="Digite o texto do prompt..."
                      rows={6}
                    />
                  </div>

                  <div className="flex items-center space-x-2">
                    <Switch
                      id="is_active"
                      checked={formData.is_active}
                      onCheckedChange={(checked) => handleSwitchChange("is_active", checked)}
                    />
                    <Label htmlFor="is_active">Ativo</Label>
                  </div>
                </div>

                <DialogFooter>
                  <Button
                    variant="outline"
                    onClick={() =>
                      setFormData({
                        prompt_text: "",
                        prompt_type: defaultType,
                        is_active: true,
                      })
                    }
                  >
                    Cancelar
                  </Button>
                  <Button onClick={handleCreatePrompt} disabled={isCreating}>
                    {isCreating ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Criando...
                      </>
                    ) : (
                      "Criar Prompt"
                    )}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>

          {prompts.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground">Nenhum prompt encontrado</p>
              <p className="text-sm text-muted-foreground mt-2">
                Crie seu primeiro prompt clicando no botão "Novo Prompt"
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {prompts.map((prompt) => (
                <Card key={prompt.id} className="overflow-hidden">
                  <CardContent className="p-4">
                    <div className="flex flex-col gap-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Badge variant={prompt.is_active ? "default" : "secondary"}>
                            {promptTypes.find((t) => t.value === prompt.prompt_type)?.label || prompt.prompt_type}
                          </Badge>
                          {!prompt.is_active && <Badge variant="outline">Inativo</Badge>}
                        </div>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleToggleActive(prompt.id, !prompt.is_active)}
                          >
                            {prompt.is_active ? "Desativar" : "Ativar"}
                          </Button>
                          <Button variant="ghost" size="icon" onClick={() => handleEditPrompt(prompt)}>
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" onClick={() => handleDeletePrompt(prompt.id)}>
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                      <p className="whitespace-pre-line">{prompt.prompt_text}</p>
                      {onPromptSelect && (
                        <Button
                          variant="outline"
                          size="sm"
                          className="mt-2 self-end"
                          onClick={() => onPromptSelect(prompt)}
                        >
                          Selecionar
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={isEditing} onOpenChange={(open) => !open && setIsEditing(false)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Editar Prompt</DialogTitle>
            <DialogDescription>Edite as informações do prompt</DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="edit_prompt_type">Tipo de Prompt</Label>
              <Select value={formData.prompt_type} onValueChange={(value) => handleSelectChange("prompt_type", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o tipo" />
                </SelectTrigger>
                <SelectContent>
                  {promptTypes.map((type) => (
                    <SelectItem key={type.value} value={type.value}>
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit_prompt_text">Texto do Prompt</Label>
              <Textarea
                id="edit_prompt_text"
                name="prompt_text"
                value={formData.prompt_text}
                onChange={handleInputChange}
                placeholder="Digite o texto do prompt..."
                rows={6}
              />
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                id="edit_is_active"
                checked={formData.is_active}
                onCheckedChange={(checked) => handleSwitchChange("is_active", checked)}
              />
              <Label htmlFor="edit_is_active">Ativo</Label>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditing(false)}>
              Cancelar
            </Button>
            <Button onClick={handleUpdatePrompt}>
              <Save className="mr-2 h-4 w-4" />
              Salvar Alterações
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
