"use client"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { ChevronLeft, ChevronRight, Save, Loader2 } from "lucide-react"
import { useAuth } from "@/hooks/use-auth"
import { useToast } from "@/hooks/use-toast"

interface ProfileQuestionnaireModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onComplete: () => void
  profileId?: string | null
}

interface ProfileData {
  fullname: string
  specialty: string
  professionalid: string
  phonenumber: string
  email: string
  education: string
  locations: string
  workinghours: string
  procedures: string
  healthinsurance: string
  paymentmethods: string
  consultationfees: string
  cancellationpolicy: string
  consultationduration: string
  timebetweenconsultations: string
  reschedulingpolicy: string
  onlineconsultations: string
  reminderpreferences: string
  requiredpatientinfo: string
  appointmentconditions: string
  medicalhistoryrequirements: string
  agerequirements: string
  communicationchannels: string
  preappointmentinfo: string
  requireddocuments: string
}

const initialProfileData: ProfileData = {
  fullname: "",
  specialty: "",
  professionalid: "",
  phonenumber: "",
  email: "",
  education: "",
  locations: "",
  workinghours: "",
  procedures: "",
  healthinsurance: "",
  paymentmethods: "",
  consultationfees: "",
  cancellationpolicy: "",
  consultationduration: "",
  timebetweenconsultations: "",
  reschedulingpolicy: "",
  onlineconsultations: "",
  reminderpreferences: "",
  requiredpatientinfo: "",
  appointmentconditions: "",
  medicalhistoryrequirements: "",
  agerequirements: "",
  communicationchannels: "",
  preappointmentinfo: "",
  requireddocuments: "",
}

export function ProfileQuestionnaireModal({
  open,
  onOpenChange,
  onComplete,
  profileId,
}: ProfileQuestionnaireModalProps) {
  const [currentStep, setCurrentStep] = useState(1)
  const [profileData, setProfileData] = useState<ProfileData>(initialProfileData)
  const [loading, setLoading] = useState(false)
  const [loadingProfile, setLoadingProfile] = useState(false)

  const { user } = useAuth()
  const { toast } = useToast()

  const totalSteps = 6
  const progress = (currentStep / totalSteps) * 100

  // Carregar dados do perfil se estiver editando
  useEffect(() => {
    if (open && profileId) {
      loadProfileData()
    } else if (open && !profileId) {
      setProfileData(initialProfileData)
      setCurrentStep(1)
    }
  }, [open, profileId])

  const loadProfileData = async () => {
    if (!profileId || !user?.id) return

    try {
      setLoadingProfile(true)
      console.log("🔍 Carregando dados do perfil:", profileId)

      const response = await fetch(`/api/profiles/${profileId}?user_id=${user.id}`)

      if (response.ok) {
        const data = await response.json()
        if (data.success && data.profile) {
          setProfileData(data.profile)
          console.log("✅ Dados do perfil carregados")
        }
      } else {
        console.error("❌ Erro ao carregar perfil:", response.status)
        toast({
          title: "Erro",
          description: "Não foi possível carregar os dados do perfil",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("❌ Erro ao carregar perfil:", error)
      toast({
        title: "Erro",
        description: "Erro ao carregar dados do perfil",
        variant: "destructive",
      })
    } finally {
      setLoadingProfile(false)
    }
  }

  const handleInputChange = (field: keyof ProfileData, value: string) => {
    setProfileData((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  const handleNext = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1)
    }
  }

  const handlePrevious = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1)
    }
  }

  const handleSave = async () => {
    if (!user?.id) {
      toast({
        title: "Erro",
        description: "Usuário não autenticado",
        variant: "destructive",
      })
      return
    }

    try {
      setLoading(true)
      console.log("💾 Salvando perfil...")

      const url = profileId ? `/api/profiles/${profileId}` : "/api/profiles"
      const method = profileId ? "PUT" : "POST"

      const response = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          user_id: user.id,
          ...profileData,
        }),
      })

      if (response.ok) {
        const data = await response.json()
        if (data.success) {
          console.log("✅ Perfil salvo com sucesso")
          toast({
            title: "Sucesso",
            description: profileId ? "Perfil atualizado com sucesso" : "Perfil criado com sucesso",
          })
          onComplete()
        } else {
          throw new Error(data.error || "Erro ao salvar perfil")
        }
      } else {
        const errorData = await response.json()
        throw new Error(errorData.error || "Erro ao salvar perfil")
      }
    } catch (error) {
      console.error("❌ Erro ao salvar perfil:", error)
      toast({
        title: "Erro",
        description: error instanceof Error ? error.message : "Erro ao salvar perfil",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const renderStep = () => {
    if (loadingProfile) {
      return (
        <div className="flex items-center justify-center py-8">
          <Loader2 className="h-8 w-8 animate-spin" />
          <span className="ml-2">Carregando dados do perfil...</span>
        </div>
      )
    }

    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="fullname">Nome Completo *</Label>
              <Input
                id="fullname"
                value={profileData.fullname}
                onChange={(e) => handleInputChange("fullname", e.target.value)}
                placeholder="Digite seu nome completo"
              />
            </div>
            <div>
              <Label htmlFor="specialty">Especialidade *</Label>
              <Input
                id="specialty"
                value={profileData.specialty}
                onChange={(e) => handleInputChange("specialty", e.target.value)}
                placeholder="Ex: Cardiologia, Dermatologia, etc."
              />
            </div>
            <div>
              <Label htmlFor="professionalid">Registro Profissional *</Label>
              <Input
                id="professionalid"
                value={profileData.professionalid}
                onChange={(e) => handleInputChange("professionalid", e.target.value)}
                placeholder="Ex: CRM 12345/SP"
              />
            </div>
            <div>
              <Label htmlFor="phonenumber">Telefone *</Label>
              <Input
                id="phonenumber"
                value={profileData.phonenumber}
                onChange={(e) => handleInputChange("phonenumber", e.target.value)}
                placeholder="(11) 99999-9999"
              />
            </div>
            <div>
              <Label htmlFor="email">E-mail *</Label>
              <Input
                id="email"
                type="email"
                value={profileData.email}
                onChange={(e) => handleInputChange("email", e.target.value)}
                placeholder="seu@email.com"
              />
            </div>
          </div>
        )

      case 2:
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="education">Formação Acadêmica</Label>
              <Textarea
                id="education"
                value={profileData.education}
                onChange={(e) => handleInputChange("education", e.target.value)}
                placeholder="Descreva sua formação acadêmica, residência, especializações..."
                rows={4}
              />
            </div>
            <div>
              <Label htmlFor="locations">Locais de Atendimento</Label>
              <Textarea
                id="locations"
                value={profileData.locations}
                onChange={(e) => handleInputChange("locations", e.target.value)}
                placeholder="Liste os locais onde você atende (clínicas, hospitais, consultório próprio...)"
                rows={3}
              />
            </div>
            <div>
              <Label htmlFor="workinghours">Horários de Funcionamento</Label>
              <Textarea
                id="workinghours"
                value={profileData.workinghours}
                onChange={(e) => handleInputChange("workinghours", e.target.value)}
                placeholder="Ex: Segunda a Sexta: 8h às 18h, Sábado: 8h às 12h"
                rows={3}
              />
            </div>
          </div>
        )

      case 3:
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="procedures">Procedimentos e Serviços</Label>
              <Textarea
                id="procedures"
                value={profileData.procedures}
                onChange={(e) => handleInputChange("procedures", e.target.value)}
                placeholder="Liste os principais procedimentos e serviços que você oferece..."
                rows={4}
              />
            </div>
            <div>
              <Label htmlFor="healthinsurance">Convênios Aceitos</Label>
              <Textarea
                id="healthinsurance"
                value={profileData.healthinsurance}
                onChange={(e) => handleInputChange("healthinsurance", e.target.value)}
                placeholder="Liste os convênios médicos que você aceita..."
                rows={3}
              />
            </div>
            <div>
              <Label htmlFor="paymentmethods">Formas de Pagamento</Label>
              <Input
                id="paymentmethods"
                value={profileData.paymentmethods}
                onChange={(e) => handleInputChange("paymentmethods", e.target.value)}
                placeholder="Ex: Dinheiro, Cartão, PIX, Transferência"
              />
            </div>
          </div>
        )

      case 4:
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="consultationfees">Valores de Consulta</Label>
              <Input
                id="consultationfees"
                value={profileData.consultationfees}
                onChange={(e) => handleInputChange("consultationfees", e.target.value)}
                placeholder="Ex: Consulta particular: R$ 200,00"
              />
            </div>
            <div>
              <Label htmlFor="consultationduration">Duração da Consulta</Label>
              <Select
                value={profileData.consultationduration}
                onValueChange={(value) => handleInputChange("consultationduration", value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione a duração" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="30min">30 minutos</SelectItem>
                  <SelectItem value="45min">45 minutos</SelectItem>
                  <SelectItem value="60min">60 minutos</SelectItem>
                  <SelectItem value="90min">90 minutos</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="timebetweenconsultations">Intervalo Entre Consultas</Label>
              <Select
                value={profileData.timebetweenconsultations}
                onValueChange={(value) => handleInputChange("timebetweenconsultations", value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o intervalo" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="15min">15 minutos</SelectItem>
                  <SelectItem value="30min">30 minutos</SelectItem>
                  <SelectItem value="60min">60 minutos</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        )

      case 5:
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="cancellationpolicy">Política de Cancelamento</Label>
              <Textarea
                id="cancellationpolicy"
                value={profileData.cancellationpolicy}
                onChange={(e) => handleInputChange("cancellationpolicy", e.target.value)}
                placeholder="Ex: Cancelamentos devem ser feitos com 24h de antecedência..."
                rows={3}
              />
            </div>
            <div>
              <Label htmlFor="reschedulingpolicy">Política de Reagendamento</Label>
              <Textarea
                id="reschedulingpolicy"
                value={profileData.reschedulingpolicy}
                onChange={(e) => handleInputChange("reschedulingpolicy", e.target.value)}
                placeholder="Ex: Reagendamentos podem ser feitos até 12h antes da consulta..."
                rows={3}
              />
            </div>
            <div>
              <Label htmlFor="onlineconsultations">Consultas Online</Label>
              <Select
                value={profileData.onlineconsultations}
                onValueChange={(value) => handleInputChange("onlineconsultations", value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Oferece consultas online?" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="sim">Sim, ofereço consultas online</SelectItem>
                  <SelectItem value="nao">Não ofereço consultas online</SelectItem>
                  <SelectItem value="casos_especificos">Apenas em casos específicos</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        )

      case 6:
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="reminderpreferences">Preferências de Lembrete</Label>
              <Select
                value={profileData.reminderpreferences}
                onValueChange={(value) => handleInputChange("reminderpreferences", value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Como prefere enviar lembretes?" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="whatsapp">WhatsApp</SelectItem>
                  <SelectItem value="sms">SMS</SelectItem>
                  <SelectItem value="email">E-mail</SelectItem>
                  <SelectItem value="todos">Todos os canais</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="requiredpatientinfo">Informações Necessárias do Paciente</Label>
              <Textarea
                id="requiredpatientinfo"
                value={profileData.requiredpatientinfo}
                onChange={(e) => handleInputChange("requiredpatientinfo", e.target.value)}
                placeholder="Ex: Nome completo, CPF, telefone, convênio..."
                rows={3}
              />
            </div>
            <div>
              <Label htmlFor="requireddocuments">Documentos Necessários</Label>
              <Textarea
                id="requireddocuments"
                value={profileData.requireddocuments}
                onChange={(e) => handleInputChange("requireddocuments", e.target.value)}
                placeholder="Ex: RG, CPF, carteirinha do convênio, exames anteriores..."
                rows={3}
              />
            </div>
          </div>
        )

      default:
        return null
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{profileId ? "Editar Perfil Profissional" : "Criar Perfil Profissional"}</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          <div>
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium">
                Etapa {currentStep} de {totalSteps}
              </span>
              <span className="text-sm text-muted-foreground">{Math.round(progress)}% concluído</span>
            </div>
            <Progress value={progress} className="w-full" />
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">
                {currentStep === 1 && "Informações Básicas"}
                {currentStep === 2 && "Formação e Locais"}
                {currentStep === 3 && "Serviços e Convênios"}
                {currentStep === 4 && "Consultas e Valores"}
                {currentStep === 5 && "Políticas de Atendimento"}
                {currentStep === 6 && "Configurações Finais"}
              </CardTitle>
            </CardHeader>
            <CardContent>{renderStep()}</CardContent>
          </Card>

          <div className="flex justify-between">
            <Button variant="outline" onClick={handlePrevious} disabled={currentStep === 1}>
              <ChevronLeft className="h-4 w-4 mr-2" />
              Anterior
            </Button>

            <div className="flex gap-2">
              {currentStep < totalSteps ? (
                <Button onClick={handleNext}>
                  Próximo
                  <ChevronRight className="h-4 w-4 ml-2" />
                </Button>
              ) : (
                <Button onClick={handleSave} disabled={loading}>
                  {loading ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Salvando...
                    </>
                  ) : (
                    <>
                      <Save className="h-4 w-4 mr-2" />
                      {profileId ? "Atualizar Perfil" : "Criar Perfil"}
                    </>
                  )}
                </Button>
              )}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
