// components/privacy-modal.tsx
// Re-export from the correct location using the alias
export { PrivacyModal } from "@/components/modals/privacy-modal"
