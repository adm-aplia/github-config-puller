"use client"

import type React from "react"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { LayoutDashboard, MessageSquare, Phone, User, Calendar, Users } from "lucide-react"
import { useMobile } from "@/hooks/use-mobile"

interface NavItem {
  title: string
  href: string
  icon: React.ComponentType<{ className?: string }>
}

const navItems: NavItem[] = [
  {
    title: "Painel",
    href: "/dashboard",
    icon: LayoutDashboard,
  },
  {
    title: "Agendamentos",
    href: "/dashboard/appointments",
    icon: Calendar,
  },
  {
    title: "Conversas",
    href: "/dashboard/conversations",
    icon: MessageSquare,
  },
  {
    title: "WhatsApp",
    href: "/dashboard/whatsapp",
    icon: Phone,
  },
  {
    title: "Perfis",
    href: "/dashboard/profiles",
    icon: Users,
  },
  {
    title: "Perfil",
    href: "/dashboard/profile",
    icon: User,
  },
]

export function DashboardNav() {
  const pathname = usePathname()
  const isMobile = useMobile()

  return (
    <div className="group fixed left-0 top-16 flex flex-col gap-4 py-4 border-r w-[220px] h-[calc(100vh-4rem)] bg-background z-10">
      <div className="flex h-[52px] items-center px-4">
        <Link href="/" className="flex items-center gap-2 font-bold text-xl">
          <img src="/LOGO FUNDO TRANSPARENTE.png" alt="Aplia" className="h-8 dark:hidden" />
          <img
            src="/Aplia_logotipo_variação cor 2 fundo transparente.png"
            alt="Aplia"
            className="h-8 hidden dark:block"
          />
        </Link>
      </div>
      <ScrollArea className="flex-1 px-3">
        <div className="space-y-1 py-2">
          {navItems.map((item) => (
            <Button
              key={item.href}
              variant={pathname === item.href ? "secondary" : "ghost"}
              className={cn(
                "w-full justify-start",
                pathname === item.href
                  ? "bg-secondary text-secondary-foreground"
                  : "hover:bg-transparent hover:underline",
              )}
              asChild
            >
              <Link href={item.href}>
                <item.icon className="mr-2 h-4 w-4" />
                {item.title}
              </Link>
            </Button>
          ))}
        </div>
      </ScrollArea>
    </div>
  )
}
