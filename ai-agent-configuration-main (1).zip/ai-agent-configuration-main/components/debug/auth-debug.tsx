"use client"

import { useAuth } from "@/hooks/use-auth"
import { getSupabaseInstance } from "@/lib/supabase-singleton"
import { useEffect, useState } from "react"

interface DebugInfo {
  user: any
  session: any
  error: any
  profileExists: boolean
  profileError: any
  rlsTest: any
}

export function AuthDebug() {
  const { user, isLoading } = useAuth()
  const [debugInfo, setDebugInfo] = useState<DebugInfo | null>(null)
  const [isDev, setIsDev] = useState(false)

  useEffect(() => {
    // Só mostrar em desenvolvimento
    setIsDev(process.env.NODE_ENV === "development")
  }, [])

  useEffect(() => {
    const checkDebugInfo = async () => {
      const supabase = getSupabaseInstance()
      if (!supabase || !user) return

      try {
        // Verificar sessão
        const {
          data: { session },
          error: sessionError,
        } = await supabase.auth.getSession()

        // Teste 1: Verificar se perfil existe (busca por ID)
        const { data: profileById, error: profileByIdError } = await supabase
          .from("profiles")
          .select("id, name, email")
          .eq("id", user.id)

        // Teste 2: Verificar se perfil existe (busca por email)
        const { data: profileByEmail, error: profileByEmailError } = await supabase
          .from("profiles")
          .select("id, name, email")
          .eq("email", user.email)

        // Teste 3: Contar perfis acessíveis
        const { count, error: countError } = await supabase.from("profiles").select("*", { count: "exact", head: true })

        setDebugInfo({
          user: {
            id: user.id,
            email: user.email,
            metadata: user.user_metadata,
          },
          session: {
            exists: !!session,
            userId: session?.user?.id,
            expires: session?.expires_at,
            accessToken: !!session?.access_token,
          },
          error: sessionError,
          profileExists: !!(profileById?.length || profileByEmail?.length),
          profileError: profileByIdError || profileByEmailError,
          rlsTest: {
            profileById: profileById?.length || 0,
            profileByEmail: profileByEmail?.length || 0,
            totalAccessible: count || 0,
            errors: {
              byId: profileByIdError?.message,
              byEmail: profileByEmailError?.message,
              count: countError?.message,
            },
          },
        })
      } catch (error) {
        console.error("Erro no debug:", error)
      }
    }

    if (user && !isLoading) {
      checkDebugInfo()
    }
  }, [user, isLoading])

  if (!isDev || !debugInfo) return null

  return (
    <div className="fixed bottom-4 right-4 bg-black/95 text-white p-4 rounded-lg text-xs max-w-md z-50 max-h-96 overflow-y-auto">
      <div className="font-bold mb-3 text-yellow-300">🔍 RLS Debug Info</div>

      <div className="space-y-2">
        <div>
          <span className="text-blue-300">Loading:</span> {isLoading ? "✅" : "❌"}
        </div>

        <div>
          <span className="text-blue-300">User:</span> {debugInfo.user ? "✅" : "❌"}
        </div>

        {debugInfo.user && (
          <div className="ml-2 text-gray-300">
            <div>ID: {debugInfo.user.id?.slice(0, 8)}...</div>
            <div>Email: {debugInfo.user.email}</div>
          </div>
        )}

        <div>
          <span className="text-blue-300">Session:</span> {debugInfo.session?.exists ? "✅" : "❌"}
        </div>

        {debugInfo.session?.exists && (
          <div className="ml-2 text-gray-300">
            <div>User ID Match: {debugInfo.session.userId === debugInfo.user?.id ? "✅" : "❌"}</div>
            <div>Access Token: {debugInfo.session.accessToken ? "✅" : "❌"}</div>
          </div>
        )}

        <div className="border-t border-gray-600 pt-2 mt-2">
          <div className="text-yellow-300 font-bold">🔒 RLS Tests:</div>
          <div>Profile by ID: {debugInfo.rlsTest?.profileById || 0}</div>
          <div>Profile by Email: {debugInfo.rlsTest?.profileByEmail || 0}</div>
          <div>Total Accessible: {debugInfo.rlsTest?.totalAccessible || 0}</div>
        </div>

        {debugInfo.rlsTest?.errors && (
          <div className="border-t border-gray-600 pt-2 mt-2">
            <div className="text-red-300 font-bold">❌ RLS Errors:</div>
            {debugInfo.rlsTest.errors.byId && (
              <div className="text-red-300 text-xs">ID: {debugInfo.rlsTest.errors.byId}</div>
            )}
            {debugInfo.rlsTest.errors.byEmail && (
              <div className="text-red-300 text-xs">Email: {debugInfo.rlsTest.errors.byEmail}</div>
            )}
            {debugInfo.rlsTest.errors.count && (
              <div className="text-red-300 text-xs">Count: {debugInfo.rlsTest.errors.count}</div>
            )}
          </div>
        )}

        {debugInfo.profileError && (
          <div className="text-red-300">
            <div>Profile Error: {debugInfo.profileError.code}</div>
            <div className="text-xs">{debugInfo.profileError.message}</div>
          </div>
        )}
      </div>

      <div className="mt-3 pt-2 border-t border-gray-600 text-xs text-gray-400">
        {debugInfo.profileExists ? "✅ Perfil encontrado" : "❌ Perfil não encontrado"}
      </div>
    </div>
  )
}
