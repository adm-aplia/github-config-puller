"use client"

import { Button } from "@/components/ui/button"
import { Moon, Sun } from "lucide-react"
import { useTheme } from "next-themes"
import { useMobile } from "@/hooks/use-mobile"
import { Logo } from "@/components/logo"

export function DashboardHeader() {
  const { setTheme, theme } = useTheme()
  const isMobile = useMobile()

  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark")
  }

  return (
    <header className="flex h-16 items-center gap-4 px-6 border-b">
      {/* Logo centralizada no mobile */}
      {isMobile && (
        <div className="flex-1 flex justify-center">
          <Logo size="medium" />
        </div>
      )}

      {/* Botão de tema sempre à direita */}
      <div className={`flex items-center gap-4 ${isMobile ? "" : "flex-1 justify-end"}`}>
        <Button variant="ghost" size="icon" onClick={toggleTheme} className="flex">
          {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
          <span className="sr-only">Alternar tema</span>
        </Button>
      </div>
    </header>
  )
}

export default DashboardHeader
