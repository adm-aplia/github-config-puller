"use client"

import Image from "next/image"
import * as React from "react"
import { cn } from "@/lib/utils"
import { useTheme } from "next-themes"

export interface LogoProps extends React.HTMLAttributes<HTMLDivElement> {
  size?: "small" | "medium" | "large" | "xlarge"
  variant?: "auto" | "blue" | "white"
}

export const Logo = React.forwardRef<HTMLDivElement, LogoProps>(
  ({ className, size = "medium", variant = "auto", ...props }, ref) => {
    const { theme } = useTheme()
    let height = 35 // Tamanho reduzido
    let width = 100 // Tamanho reduzido

    // Determinar o tamanho com base na prop size
    switch (size) {
      case "small":
        height = 25
        width = 80
        break
      case "medium":
        height = 35
        width = 100
        break
      case "large":
        height = 45
        width = 130
        break
      case "xlarge":
        height = 55
        width = 160
        break
    }

    // CORREÇÃO: Os nomes dos arquivos estavam invertidos
    // "Aplia_logotipo_variação cor 2 fundo transparente.png" = Logo com escrita BRANCA (para fundo escuro)
    // "LOGO FUNDO TRANSPARENTE.png" = Logo com escrita AZUL/ESCURA (para fundo claro)

    // Determinar qual logo usar com base no tema e na variante
    let logoSrc = "/LOGO FUNDO TRANSPARENTE.png" // Padrão: logo com escrita AZUL/ESCURA para fundo claro

    if (variant === "auto") {
      // No modo automático, usar a logo com escrita branca no tema escuro
      if (theme === "dark") {
        logoSrc = "/Aplia_logotipo_variação cor 2 fundo transparente.png" // Logo com escrita BRANCA
      }
    } else if (variant === "white") {
      logoSrc = "/Aplia_logotipo_variação cor 2 fundo transparente.png" // Logo com escrita BRANCA
    } else if (variant === "blue") {
      logoSrc = "/LOGO FUNDO TRANSPARENTE.png" // Logo com escrita AZUL/ESCURA
    }

    return (
      <div ref={ref} className={cn("relative", className)} {...props}>
        <Image
          src={logoSrc || "/placeholder.svg"}
          alt="Aplia Logo"
          height={height}
          width={width}
          className="object-contain"
        />
      </div>
    )
  },
)
Logo.displayName = "Logo"
