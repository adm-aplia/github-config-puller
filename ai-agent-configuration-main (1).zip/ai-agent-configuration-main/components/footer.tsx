import Link from "next/link"

const Footer = () => {
  return (
    <footer className="bg-white dark:bg-gray-800 py-4">
      <div className="container mx-auto text-center">
        <div className="flex space-x-4 justify-center">
          <Link
            href="/termos"
            className="text-sm text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300"
          >
            Termos de Uso
          </Link>
          <Link
            href="/privacidade"
            className="text-sm text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300"
          >
            Política de Privacidade
          </Link>
        </div>
        <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">
          &copy; {new Date().getFullYear()} My Company. All rights reserved.
        </p>
      </div>
    </footer>
  )
}

export default Footer
