"use client"

import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Calendar } from "lucide-react"

interface GoogleCalendarModalProps {
  isOpen: boolean
  onClose: () => void
}

export function GoogleCalendarModal({ isOpen, onClose }: GoogleCalendarModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Conectar Google Agenda</DialogTitle>
          <DialogDescription>
            Sincronize seus agendamentos com o Google Agenda para facilitar o gerenciamento.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Calendar className="mr-2 h-4 w-4" />
            <p>Conecte sua conta Google para sincronizar seus agendamentos.</p>
          </div>
        </div>
        <Button onClick={onClose}>Fechar</Button>
      </DialogContent>
    </Dialog>
  )
}
