"use client"
import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  RefreshCw,
  Loader2,
  Plus,
  QrCode,
  UserPlus,
  LogOut,
  Trash2,
  MoreVertical,
  User,
  Edit2,
  Check,
  X,
} from "lucide-react"
import { evolutionAPI, type Instance } from "@/lib/evolution-api"
import { useToast } from "@/hooks/use-toast"
import { Label } from "@/components/ui/label"
import { WhatsAppService } from "@/lib/services/whatsapp-service"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { TooltipProvider } from "@/components/ui/tooltip"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar"

// Tipo para perfil profissional
type ProfessionalProfile = {
  id: string
  fullName: string
  specialty: string | null
  created_at: string
}

// Tipo estendido para instância com informações de perfil
type ExtendedInstance = Instance & {
  professionalProfile?: {
    id: string
    fullName: string
    specialty: string | null
  } | null
}

// Componente de dropdown customizado para cada instância
function InstanceDropdown({
  instanceName,
  onDisconnect,
  onDelete,
}: {
  instanceName: string
  onDisconnect: () => void
  onDelete: () => void
}) {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <div className="relative inline-block text-left">
      <button
        type="button"
        className="inline-flex justify-center items-center w-8 h-8 rounded-md border border-gray-300 shadow-sm bg-white text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
        onClick={() => setIsOpen(!isOpen)}
      >
        <MoreVertical className="h-4 w-4" />
      </button>

      {isOpen && (
        <>
          {/* Overlay para fechar quando clicar fora */}
          <div className="fixed inset-0 z-40" onClick={() => setIsOpen(false)} />

          <div className="origin-top-right absolute right-0 mt-2 w-56 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 focus:outline-none z-50">
            <div className="py-1">
              <button
                onClick={() => {
                  onDisconnect()
                  setIsOpen(false)
                }}
                className="flex items-center px-4 py-2 text-sm text-orange-600 hover:bg-gray-100 w-full text-left"
              >
                <LogOut className="h-4 w-4 mr-2" />
                Desconectar
              </button>
              <button
                onClick={() => {
                  onDelete()
                  setIsOpen(false)
                }}
                className="flex items-center px-4 py-2 text-sm text-red-600 hover:bg-gray-100 w-full text-left"
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Excluir Permanentemente
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  )
}

export function WhatsAppManager() {
  // Estados para gerenciamento de instâncias
  const [instances, setInstances] = useState<ExtendedInstance[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [disconnectingInstance, setDisconnectingInstance] = useState<string | null>(null)
  const [showDisconnectDialog, setShowDisconnectDialog] = useState(false)
  const [deletingInstance, setDeletingInstance] = useState<string | null>(null)
  const [showDeleteDialog, setShowDeleteDialog] = useState(false)

  // Estados para criação de nova conexão
  const [showCreateModal, setShowCreateModal] = useState(false)
  const [newInstanceName, setNewInstanceName] = useState("")
  const [isCreating, setIsCreating] = useState(false)
  const [instanceNameError, setInstanceNameError] = useState("")
  const [qrCodeBase64, setQrCodeBase64] = useState<string | null>(null)
  const [qrCodeUrl, setQrCodeUrl] = useState<string | null>(null)
  const [errorMessage, setErrorMessage] = useState<string | null>(null)
  const [imgError, setImgError] = useState(false)
  const [currentQRInstance, setCurrentQRInstance] = useState<string | null>(null)
  const [showQRModal, setShowQRModal] = useState(false)

  // Estados para vinculação de perfil
  const [showProfileDialog, setShowProfileDialog] = useState(false)
  const [selectedInstanceId, setSelectedInstanceId] = useState<string | null>(null)
  const [selectedProfileId, setSelectedProfileId] = useState<string | null>("none")
  const [profiles, setProfiles] = useState<ProfessionalProfile[]>([])
  const [isLoadingProfiles, setIsLoadingProfiles] = useState(false)
  const [isAssigningProfile, setIsAssigningProfile] = useState(false)
  const [isRemovingProfile, setIsRemovingProfile] = useState<string | null>(null)

  // Estados para edição de nome
  const [editingInstance, setEditingInstance] = useState<string | null>(null)
  const [editingName, setEditingName] = useState("")
  const [customNames, setCustomNames] = useState<Record<string, string>>({})

  // Adicionar após os outros estados
  const [qrTimer, setQrTimer] = useState<NodeJS.Timeout | null>(null)
  const [qrCountdown, setQrCountdown] = useState(30)

  const { toast } = useToast()

  // Carregar nomes customizados do localStorage
  useEffect(() => {
    const savedNames = localStorage.getItem("whatsapp-custom-names")
    if (savedNames) {
      try {
        setCustomNames(JSON.parse(savedNames))
      } catch (error) {
        console.error("Erro ao carregar nomes customizados:", error)
      }
    }
  }, [])

  // Salvar nomes customizados no localStorage
  const saveCustomNames = (names: Record<string, string>) => {
    setCustomNames(names)
    localStorage.setItem("whatsapp-custom-names", JSON.stringify(names))
  }

  // Função para obter o nome de exibição
  const getDisplayName = (instanceName: string, profileName?: string) => {
    return customNames[instanceName] || profileName || instanceName
  }

  // Função para iniciar edição de nome
  const startEditingName = (instanceName: string) => {
    setEditingInstance(instanceName)
    setEditingName(getDisplayName(instanceName))
  }

  // Função para salvar nome editado
  const saveEditedName = () => {
    if (editingInstance && editingName.trim()) {
      const newCustomNames = {
        ...customNames,
        [editingInstance]: editingName.trim(),
      }
      saveCustomNames(newCustomNames)
      toast({
        title: "Nome atualizado",
        description: "O nome da conexão foi alterado com sucesso.",
      })
    }
    setEditingInstance(null)
    setEditingName("")
  }

  // Função para cancelar edição de nome
  const cancelEditingName = () => {
    setEditingInstance(null)
    setEditingName("")
  }

  // Função para carregar instâncias
  const loadInstances = async (skipStatusCheck = false) => {
    try {
      setIsRefreshing(true)

      // Obter instâncias com informações de perfil do banco de dados
      const instancesWithProfiles = await WhatsAppService.getInstancesWithProfiles()

      if (skipStatusCheck) {
        // Se skipStatusCheck for true, apenas mapear sem verificar status na API
        const mappedInstances: ExtendedInstance[] = instancesWithProfiles.map((dbInstance) => ({
          instance: {
            instanceName: dbInstance.instance_name,
            owner: dbInstance.user_id,
            profileName: dbInstance.profile_name || dbInstance.instance_name,
            profilePictureUrl: dbInstance.profile_picture_url || "",
            profileStatus: "",
            status: dbInstance.status as "connected" | "connecting" | "disconnected" | "qrcode",
            number: dbInstance.phone_number || null,
          },
          professionalProfile: dbInstance.professional_profiles,
        }))

        setInstances(mappedInstances)
        return
      }

      // Para cada instância, verificar o status real na API do Evolution
      const updatedInstances = await Promise.all(
        instancesWithProfiles.map(async (dbInstance) => {
          try {
            // Verificar o status real na API do Evolution
            const realStatus = await evolutionAPI.getInstanceStatus(dbInstance.instance_name)

            // Se o status no banco for diferente do status real, atualizar no banco
            if (
              realStatus.instance.status !== dbInstance.status ||
              realStatus.instance.profilePictureUrl !== dbInstance.profile_picture_url ||
              realStatus.instance.number !== dbInstance.phone_number
            ) {
              await WhatsAppService.updateInstanceStatus(
                dbInstance.id,
                realStatus.instance.status as "connected" | "connecting" | "disconnected" | "qrcode",
                realStatus.instance.profileName,
                realStatus.instance.profilePictureUrl,
                realStatus.instance.number,
              )

              // Atualizar o status na instância local
              return {
                ...dbInstance,
                status: realStatus.instance.status as "connected" | "connecting" | "disconnected" | "qrcode",
                profile_name: realStatus.instance.profileName || dbInstance.profile_name,
                profile_picture_url: realStatus.instance.profilePictureUrl || dbInstance.profile_picture_url,
                phone_number: realStatus.instance.number || dbInstance.phone_number,
              }
            }

            return dbInstance
          } catch (error: any) {
            console.error(`Erro ao verificar status da instância ${dbInstance.instance_name}:`, error)

            // Se a instância não foi encontrada na API (404), pode ter sido excluída
            if (error.message?.includes("não encontrada") || error.status === 404) {
              console.log(`Instância ${dbInstance.instance_name} não encontrada na API, marcando como desconectada`)
              // Marcar como desconectada no banco
              try {
                await WhatsAppService.updateInstanceStatus(dbInstance.id, "disconnected")
                return {
                  ...dbInstance,
                  status: "disconnected" as "connected" | "connecting" | "disconnected" | "qrcode",
                }
              } catch (updateError) {
                console.error(`Erro ao atualizar status da instância ${dbInstance.instance_name}:`, updateError)
              }
            }

            return dbInstance // Manter o status atual em caso de erro
          }
        }),
      )

      // Mapear para o formato esperado pelo componente
      const mappedInstances: ExtendedInstance[] = updatedInstances.map((dbInstance) => ({
        instance: {
          instanceName: dbInstance.instance_name,
          owner: dbInstance.user_id,
          profileName: dbInstance.profile_name || dbInstance.instance_name,
          profilePictureUrl: dbInstance.profile_picture_url || "",
          profileStatus: "",
          status: dbInstance.status as "connected" | "connecting" | "disconnected" | "qrcode",
          number: dbInstance.phone_number || null,
        },
        professionalProfile: dbInstance.professional_profiles,
      }))

      setInstances(mappedInstances)
    } catch (error) {
      console.error("Erro ao carregar instâncias:", error)
      setInstances([])
      toast({
        variant: "destructive",
        title: "Erro ao carregar conexões",
        description: "Não foi possível obter as conexões do WhatsApp.",
      })
    } finally {
      setIsLoading(false)
      setIsRefreshing(false)
    }
  }

  // Carregar instâncias ao montar o componente
  useEffect(() => {
    loadInstances()
    loadProfiles()
  }, [])

  // Função para carregar perfis profissionais
  const loadProfiles = async () => {
    try {
      setIsLoadingProfiles(true)
      const profilesData = await WhatsAppService.getProfessionalProfiles()
      setProfiles(profilesData)
    } catch (error) {
      console.error("Erro ao carregar perfis profissionais:", error)
      toast({
        variant: "destructive",
        title: "Erro ao carregar perfis",
        description: "Não foi possível obter a lista de perfis profissionais.",
      })
    } finally {
      setIsLoadingProfiles(false)
    }
  }

  // Validar o nome da instância
  const validateInstanceName = (name: string): boolean => {
    if (!name) {
      setInstanceNameError("Nome da instância é obrigatório")
      return false
    }

    if (!/^[a-zA-Z0-9_-]+$/.test(name)) {
      setInstanceNameError("Use apenas letras, números, underscores e hífens")
      return false
    }

    setInstanceNameError("")
    return true
  }

  // Substituir a função createInstance completa:
  const createInstance = async () => {
    if (!validateInstanceName(newInstanceName)) {
      return
    }

    setIsCreating(true)
    setErrorMessage(null)

    try {
      // Gerar um nome único para evitar conflitos
      const timestamp = Date.now().toString().slice(-6) // Últimos 6 dígitos do timestamp
      const randomSuffix = Math.random().toString(36).substring(2, 6) // 4 caracteres aleatórios
      const uniqueInstanceName = `${newInstanceName}_${timestamp}_${randomSuffix}`

      // Verificar se a instância já existe no Supabase (usando o nome único)
      const existingInstance = await WhatsAppService.getInstanceByName(uniqueInstanceName)

      let finalInstanceName = uniqueInstanceName

      if (existingInstance) {
        // Se mesmo com o nome único ainda existir, tentar novamente com outro sufixo
        const newRandomSuffix = Math.random().toString(36).substring(2, 8)
        finalInstanceName = `${newInstanceName}_${timestamp}_${newRandomSuffix}`

        // Criar a instância usando o serviço WhatsApp (que salva no Supabase)
        await WhatsAppService.createInstance(finalInstanceName)

        // Atualizar o nome de exibição no banco para mostrar apenas o nome que o usuário digitou
        const createdInstance = await WhatsAppService.getInstanceByName(finalInstanceName)
        if (createdInstance) {
          await WhatsAppService.updateInstance(createdInstance.id, {
            profile_name: newInstanceName, // Nome de exibição será o que o usuário digitou
          })
        }
      } else {
        // Criar a instância usando o serviço WhatsApp (que salva no Supabase)
        await WhatsAppService.createInstance(uniqueInstanceName)

        // Atualizar o nome de exibição no banco para mostrar apenas o nome que o usuário digitou
        const createdInstance = await WhatsAppService.getInstanceByName(uniqueInstanceName)
        if (createdInstance) {
          await WhatsAppService.updateInstance(createdInstance.id, {
            profile_name: newInstanceName, // Nome de exibição será o que o usuário digitou
          })
        }
      }

      setCurrentQRInstance(finalInstanceName)

      // Recarregar a lista para mostrar a nova instância
      await loadInstances(true) // Skip status check para evitar erros

      // Fechar o modal de criação e abrir o modal de QR code
      setShowCreateModal(false)
      setShowQRModal(true)

      // Aguardar mais tempo e tentar múltiplas vezes
      await waitForInstanceAndLoadQR(finalInstanceName)

      toast({
        title: "Instância criada",
        description: "A nova instância foi criada com sucesso.",
      })
    } catch (error: any) {
      console.error("Erro ao criar instância:", error)
      setErrorMessage(error.message || "Não foi possível criar a nova instância")
      toast({
        variant: "destructive",
        title: "Erro ao criar instância",
        description: error.message || "Não foi possível criar a nova instância. Tente novamente.",
      })
    } finally {
      setIsCreating(false)
    }
  }

  // Função para aguardar a instância estar pronta e carregar QR code
  const waitForInstanceAndLoadQR = async (instanceName: string) => {
    setCurrentQRInstance(instanceName)

    // Tentar carregar QR code com retry
    let attempts = 0
    const maxAttempts = 5
    const baseDelay = 2000 // 2 segundos inicial

    const tryLoadQR = async (): Promise<boolean> => {
      attempts++
      console.log(`🔄 Tentativa ${attempts}/${maxAttempts} de carregar QR code para ${instanceName}`)

      try {
        // Primeiro, verificar se a instância existe na API
        const instances = await evolutionAPI.getInstances()
        const instanceExists = instances.some(
          (i) => i.instance.instanceName.toLowerCase() === instanceName.toLowerCase(),
        )

        if (!instanceExists) {
          console.log(`⏳ Instância ${instanceName} ainda não existe na API, aguardando...`)
          return false
        }

        // Se existe, tentar obter o QR code
        await loadQRCode(instanceName)

        // Verificar se o QR code foi carregado com sucesso
        if (qrCodeBase64 || qrCodeUrl) {
          console.log(`✅ QR code carregado com sucesso para ${instanceName}`)
          startQRTimer()
          return true
        }

        return false
      } catch (error) {
        console.log(`❌ Erro na tentativa ${attempts}:`, error)
        return false
      }
    }

    // Loop de retry
    while (attempts < maxAttempts) {
      const success = await tryLoadQR()

      if (success) {
        break
      }

      // Aguardar antes da próxima tentativa (delay progressivo)
      const delay = baseDelay * attempts
      console.log(`⏳ Aguardando ${delay}ms antes da próxima tentativa...`)
      await new Promise((resolve) => setTimeout(resolve, delay))
    }

    // Se não conseguiu após todas as tentativas
    if (attempts >= maxAttempts) {
      console.log(`❌ Não foi possível carregar QR code após ${maxAttempts} tentativas`)
      setErrorMessage(
        "A instância foi criada, mas o QR code ainda não está disponível. " +
          "Clique em 'Atualizar QR Code' em alguns segundos.",
      )
    }
  }

  // Adicionar após a função loadQRCode:
  const startQRTimer = () => {
    // Limpar timer existente se houver
    if (qrTimer) {
      clearInterval(qrTimer)
    }

    setQrCountdown(30)

    const timer = setInterval(() => {
      setQrCountdown((prev) => {
        if (prev <= 1) {
          // Quando chegar a 0, recarregar o QR code
          if (currentQRInstance) {
            loadQRCode(currentQRInstance)
          }
          return 30 // Resetar para 30 segundos
        }
        return prev - 1
      })
    }, 1000)

    setQrTimer(timer)
  }

  const stopQRTimer = () => {
    if (qrTimer) {
      clearInterval(qrTimer)
      setQrTimer(null)
    }
    setQrCountdown(30)
  }

  // Função para carregar o QR code
  const loadQRCode = async (instanceName: string) => {
    console.log(`🔍 Carregando QR code para instância: ${instanceName}`)
    if (!instanceName) return

    try {
      // Resetar estados
      setQrCodeBase64(null)
      setQrCodeUrl(null)
      setErrorMessage(null)
      setImgError(false)

      // Mostrar loading
      console.log(`⏳ Iniciando processo de obtenção do QR code...`)

      // Primeiro, verificar se a instância existe na API
      try {
        const instances = await evolutionAPI.getInstances()
        const instanceExists = instances.some(
          (i) => i.instance.instanceName.toLowerCase() === instanceName.toLowerCase(),
        )

        if (!instanceExists) {
          console.log(`❌ Instância ${instanceName} não encontrada na API`)
          throw new Error(
            `Instância ${instanceName} não foi encontrada na API. Aguarde alguns segundos e tente novamente.`,
          )
        }

        console.log(`✅ Instância ${instanceName} encontrada na API`)
      } catch (error) {
        console.log("❌ Erro ao verificar instância:", error)
        throw new Error("Erro ao verificar se a instância existe na API")
      }

      // Estratégia 1: Tentar conectar primeiro para gerar QR
      try {
        const connectResponse = await evolutionAPI.connectInstance(instanceName)

        const normalized = normalizeQRCodeResponse(connectResponse)

        if (normalized.qrcode?.base64) {
          setImgError(false) // Reset error state
          setQrCodeBase64(normalized.qrcode.base64)
          const dataUrl = `data:image/png;base64,${normalized.qrcode.base64}`
          setQrCodeUrl(dataUrl)
          return
        }
      } catch (error) {
        console.log("Estratégia de conexão falhou:", error)
      }

      // Estratégia 2: Usar endpoint específico para QR code
      try {
        const timestamp = new Date().getTime()
        const response = await fetch(`/api/evolution-proxy/instance/qrcode/${instanceName}?_=${timestamp}`, {
          method: "GET",
          headers: { "Content-Type": "application/json" },
          cache: "no-store",
        })

        if (response.ok) {
          const data = await response.json()
          const normalized = normalizeQRCodeResponse(data)
          if (normalized.qrcode?.base64) {
            setImgError(false) // Reset error state
            setQrCodeBase64(normalized.qrcode.base64)
            const dataUrl = `data:image/png;base64,${normalized.qrcode.base64}`
            setQrCodeUrl(dataUrl)
            return
          }
        } else {
          console.log(`Endpoint QR code retornou: ${response.status}`)
        }
      } catch (error) {
        console.log("Endpoint QR code falhou:", error)
      }

      // Estratégia 3: Obter do status da instância
      try {
        const statusResponse = await evolutionAPI.getInstanceStatus(instanceName)

        if (statusResponse.instance.qrcode?.base64) {
          setImgError(false) // Reset error state
          setQrCodeBase64(statusResponse.instance.qrcode.base64)
          const dataUrl = `data:image/png;base64,${statusResponse.instance.qrcode.base64}`
          setQrCodeUrl(dataUrl)
          return
        }
      } catch (error) {
        console.log("Status da instância falhou:", error)
      }

      // Se chegou até aqui, nenhuma estratégia funcionou
      throw new Error(
        "Não foi possível obter o QR code. A instância pode não estar pronta ou pode haver um problema de conectividade.",
      )
    } catch (error: any) {
      console.error("Erro ao obter QR code:", error)
      setErrorMessage(error.message || "Erro ao carregar QR code. Tente novamente em alguns segundos.")
      toast({
        variant: "destructive",
        title: "Erro ao carregar QR code",
        description: "Verifique se a instância foi criada corretamente e tente novamente.",
      })
    } finally {
      // Se o modal estiver aberto, garantir que o timer esteja rodando
      if (showQRModal && currentQRInstance) {
        if (!qrTimer) {
          startQRTimer()
        }
      }
    }
  }

  // Função auxiliar para normalizar resposta do QR code
  const normalizeQRCodeResponse = (data: any) => {
    // Verificar se tem o campo 'code' diretamente (como mostrado nos logs)
    if (data.code && typeof data.code === "string") {
      // Se já tem o prefixo data:image, usar diretamente
      if (data.code.startsWith("data:image/png;base64,")) {
        return { qrcode: { base64: data.code.replace("data:image/png;base64,", "") } }
      }
      return { qrcode: { base64: data.code } }
    }

    if (data.qrcode && data.qrcode.base64) {
      // Se já tem o prefixo data:image, remover
      if (data.qrcode.base64.startsWith("data:image/png;base64,")) {
        return { qrcode: { base64: data.qrcode.base64.replace("data:image/png;base64,", "") } }
      }
      return data
    }

    if (data.base64) {
      if (typeof data.base64 === "object" && data.base64.value) {
        return { qrcode: { base64: data.base64.value } }
      }
      // Se já tem o prefixo data:image, remover
      if (data.base64.startsWith("data:image/png;base64,")) {
        return { qrcode: { base64: data.base64.replace("data:image/png;base64,", "") } }
      }
      return { qrcode: { base64: data.base64 } }
    }

    if (data.qr) {
      return { qrcode: { base64: data.qr } }
    }

    if (data.data && data.data.base64) {
      return { qrcode: { base64: data.data.base64 } }
    }

    return { qrcode: { base64: "" }, status: "error" }
  }

  // Função para iniciar o processo de criação de nova conexão
  const startNewConnection = () => {
    setNewInstanceName("")
    setInstanceNameError("")
    setErrorMessage(null)
    setQrCodeBase64(null)
    setQrCodeUrl(null)
    setCurrentQRInstance(null)
    setShowCreateModal(true)
  }

  // Função para cancelar a criação de nova conexão
  const cancelNewConnection = () => {
    setShowCreateModal(false)
    setNewInstanceName("")
    setInstanceNameError("")
    setErrorMessage(null)
    setQrCodeBase64(null)
    setQrCodeUrl(null)
    setCurrentQRInstance(null)
  }

  // Função para verificar e atualizar o status de uma instância específica
  const checkAndUpdateInstanceStatus = async (instanceName: string) => {
    try {
      // Verificar o status real na API do Evolution
      const realStatus = await evolutionAPI.getInstanceStatus(instanceName)

      // Encontrar a instância no banco de dados
      const dbInstance = await WhatsAppService.getInstanceByName(instanceName)

      if (dbInstance && realStatus.instance.status !== dbInstance.status) {
        // Atualizar o status no banco de dados
        await WhatsAppService.updateInstanceStatus(
          dbInstance.id,
          realStatus.instance.status as "connected" | "connecting" | "disconnected" | "qrcode",
          realStatus.instance.profileName,
          realStatus.instance.profilePictureUrl,
          realStatus.instance.number,
        )

        // Recarregar a lista para mostrar o status atualizado
        loadInstances(true) // Skip status check para evitar loops

        return realStatus.instance.status
      }

      return dbInstance?.status || realStatus.instance.status
    } catch (error) {
      console.error(`Erro ao verificar status da instância ${instanceName}:`, error)
      return null
    }
  }

  // Função para confirmar desconexão
  const confirmDisconnect = (instanceName: string) => {
    setDisconnectingInstance(instanceName)
    setShowDisconnectDialog(true)
  }

  // Função para confirmar exclusão permanente
  const confirmDelete = (instanceName: string) => {
    setDeletingInstance(instanceName)
    setShowDeleteDialog(true)
  }

  // Função para desconectar uma instância
  const handleDisconnect = async () => {
    console.log("handleDisconnect chamado para:", disconnectingInstance)
    if (!disconnectingInstance) return

    try {
      await evolutionAPI.disconnectInstance(disconnectingInstance)

      // Atualizar o status no Supabase
      const dbInstance = await WhatsAppService.getInstanceByName(disconnectingInstance)
      if (dbInstance) {
        await WhatsAppService.updateInstanceStatus(dbInstance.id, "disconnected")
      }

      toast({
        title: "Desconectado com sucesso",
        description: "O número foi desconectado do WhatsApp.",
      })

      // Recarregar a lista imediatamente
      await loadInstances(true) // Skip status check para evitar erros
    } catch (error) {
      console.error("Erro ao desconectar:", error)
      toast({
        variant: "destructive",
        title: "Erro ao desconectar",
        description: "Não foi possível desconectar o número do WhatsApp.",
      })
    } finally {
      setDisconnectingInstance(null)
      setShowDisconnectDialog(false)
    }
  }

  // Função para excluir uma instância permanentemente
  const handleDelete = async () => {
    console.log("handleDelete chamado para:", deletingInstance)
    if (!deletingInstance) return

    try {
      // Encontrar a instância no banco de dados
      const dbInstance = await WhatsAppService.getInstanceByName(deletingInstance)

      if (dbInstance) {
        // Excluir a instância usando o serviço
        await WhatsAppService.deleteInstance(dbInstance.id)

        toast({
          title: "Instância excluída",
          description: "A instância foi excluída permanentemente.",
        })

        // Remover a instância da lista local imediatamente
        setInstances((prev) => prev.filter((instance) => instance.instance.instanceName !== deletingInstance))

        // Recarregar a lista do banco para garantir sincronização
        setTimeout(() => loadInstances(true), 500) // Skip status check para evitar erros
      } else {
        // Se não encontrar no banco, tentar excluir apenas da API
        await evolutionAPI.deleteInstance(deletingInstance)
        toast({
          title: "Instância excluída",
          description: "A instância foi excluída da API, mas não foi encontrada no banco de dados.",
        })

        // Remover da lista local
        setInstances((prev) => prev.filter((instance) => instance.instance.instanceName !== deletingInstance))
      }
    } catch (error) {
      console.error("Erro ao excluir instância:", error)
      toast({
        variant: "destructive",
        title: "Erro ao excluir instância",
        description: "Não foi possível excluir a instância. Tente novamente.",
      })
    } finally {
      setDeletingInstance(null)
      setShowDeleteDialog(false)
    }
  }

  // Função para abrir o diálogo de atribuição de perfil
  const openProfileDialog = async (instanceName: string) => {
    try {
      // Encontrar a instância no banco de dados
      const dbInstance = await WhatsAppService.getInstanceByName(instanceName)

      if (dbInstance) {
        setSelectedInstanceId(dbInstance.id)

        // Se já tiver um perfil atribuído, pré-selecionar
        const instanceWithProfile = instances.find((instance) => instance.instance.instanceName === instanceName)

        if (instanceWithProfile?.professionalProfile) {
          setSelectedProfileId(instanceWithProfile.professionalProfile.id)
        } else {
          setSelectedProfileId("none")
        }

        setShowProfileDialog(true)
      } else {
        toast({
          variant: "destructive",
          title: "Erro",
          description: "Instância não encontrada no banco de dados.",
        })
      }
    } catch (error) {
      console.error("Erro ao preparar diálogo de perfil:", error)
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Não foi possível abrir o diálogo de atribuição de perfil.",
      })
    }
  }

  // Função para atribuir perfil a uma instância
  const assignProfile = async () => {
    if (!selectedInstanceId) return

    try {
      setIsAssigningProfile(true)

      if (selectedProfileId !== "none") {
        // Atribuir perfil
        await WhatsAppService.assignProfessionalProfile(selectedInstanceId, selectedProfileId)

        toast({
          title: "Perfil atribuído",
          description: "O perfil profissional foi vinculado com sucesso à conexão WhatsApp.",
        })
      } else {
        // Remover atribuição de perfil
        await WhatsAppService.removeProfessionalProfile(selectedInstanceId)

        toast({
          title: "Perfil removido",
          description: "A vinculação com o perfil profissional foi removida.",
        })
      }

      // Forçar reload completo das instâncias
      await loadInstances(true) // Skip status check para evitar erros
    } catch (error) {
      console.error("Erro ao atribuir/remover perfil:", error)
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Não foi possível atribuir ou remover o perfil profissional.",
      })
    } finally {
      setIsAssigningProfile(false)
      setShowProfileDialog(false)
    }
  }

  // Função para remover perfil de uma instância
  const removeProfile = async (instanceId: string) => {
    try {
      setIsRemovingProfile(instanceId)

      await WhatsAppService.removeProfessionalProfile(instanceId)

      toast({
        title: "Perfil removido",
        description: "A vinculação com o perfil profissional foi removida.",
      })

      // Forçar reload completo das instâncias
      await loadInstances(true) // Skip status check para evitar erros
    } catch (error) {
      console.error("Erro ao remover perfil:", error)
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Não foi possível remover a vinculação com o perfil profissional.",
      })
    } finally {
      setIsRemovingProfile(null)
    }
  }

  // Adicionar um novo useEffect após o useEffect existente:
  useEffect(() => {
    return () => {
      // Limpar timer quando o componente for desmontado
      if (qrTimer) {
        clearInterval(qrTimer)
      }
    }
  }, [qrTimer])

  // Adicionar outro useEffect para controlar o timer baseado no modal:
  useEffect(() => {
    if (showQRModal && currentQRInstance) {
      startQRTimer()
    } else {
      stopQRTimer()
    }

    return () => {
      stopQRTimer()
    }
  }, [showQRModal, currentQRInstance])

  // Renderizar estado de carregamento
  if (isLoading) {
    return (
      <div className="flex justify-center items-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    )
  }

  return (
    <TooltipProvider>
      <div className="space-y-6">
        {/* Cabeçalho simplificado */}
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-3">
            <Button variant="outline" onClick={() => loadInstances(false)} disabled={isRefreshing} className="gap-2">
              {isRefreshing ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
              Atualizar
            </Button>

            <Button onClick={startNewConnection} className="gap-2">
              <Plus className="h-4 w-4" />
              Criar Nova Conexão
            </Button>
          </div>
        </div>

        {/* Lista de conexões simplificada */}
        <div className="space-y-4">
          {instances.length === 0 ? (
            <div className="text-center py-8 border border-gray-200 bg-gray-50/30 rounded-lg dark:border-gray-700 dark:bg-transparent">
              <QrCode className="h-12 w-12 mx-auto text-muted-foreground mb-2" />
              <p className="text-muted-foreground">Nenhuma conexão WhatsApp encontrada</p>
              <p className="text-sm text-muted-foreground mt-1">
                Clique em "Criar Nova Conexão" para adicionar sua primeira conexão
              </p>
            </div>
          ) : (
            <div className="rounded-md border">
              <div className="grid grid-cols-1 md:grid-cols-5 gap-4 p-4 border-b bg-gray-50/50 dark:bg-gray-800/50 font-medium text-sm">
                <div>Nome</div>
                <div>Número</div>
                <div>Perfil Vinculado</div>
                <div>Status</div>
                <div className="text-right">Ações</div>
              </div>

              {instances.map((instance) => {
                const instanceName = instance.instance.instanceName
                const displayName = getDisplayName(instanceName, instance.instance.profileName)

                return (
                  <div
                    key={instanceName}
                    className="grid grid-cols-1 md:grid-cols-5 gap-4 p-4 border-b last:border-b-0 items-center"
                  >
                    <div className="flex items-center gap-3">
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={instance.instance.profilePictureUrl || undefined} alt={displayName} />
                        <AvatarFallback className="bg-gray-200 dark:bg-gray-700">
                          <User className="h-4 w-4 text-gray-500 dark:text-gray-400" />
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex items-center gap-2">
                        {editingInstance === instanceName ? (
                          <div className="flex items-center gap-2">
                            <Input
                              value={editingName}
                              onChange={(e) => setEditingName(e.target.value)}
                              className="h-8 w-32"
                              onKeyDown={(e) => {
                                if (e.key === "Enter") {
                                  saveEditedName()
                                } else if (e.key === "Escape") {
                                  cancelEditingName()
                                }
                              }}
                              autoFocus
                            />
                            <Button size="sm" variant="ghost" onClick={saveEditedName} className="h-6 w-6 p-0">
                              <Check className="h-3 w-3 text-green-600" />
                            </Button>
                            <Button size="sm" variant="ghost" onClick={cancelEditingName} className="h-6 w-6 p-0">
                              <X className="h-3 w-3 text-red-600" />
                            </Button>
                          </div>
                        ) : (
                          <div className="flex items-center gap-2">
                            <div className="font-medium">{displayName}</div>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => startEditingName(instanceName)}
                              className="h-6 w-6 p-0 opacity-0 group-hover:opacity-100 hover:opacity-100"
                            >
                              <Edit2 className="h-3 w-3 text-gray-500" />
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="text-sm text-muted-foreground">
                      {instance.instance.status === "connected" && instance.instance.number
                        ? `+${instance.instance.number}`
                        : "-"}
                    </div>

                    <div className="text-sm">
                      {instance.professionalProfile ? (
                        <div>
                          <div className="font-medium">{instance.professionalProfile.fullName}</div>
                          {instance.professionalProfile.specialty && (
                            <div className="text-xs text-muted-foreground">
                              {instance.professionalProfile.specialty}
                            </div>
                          )}
                        </div>
                      ) : (
                        <span className="text-gray-500">Nenhum perfil</span>
                      )}
                    </div>

                    <div>
                      <Badge
                        variant="outline"
                        className={
                          instance.instance.status === "connected"
                            ? "text-gray-700 border-gray-300 bg-gray-100"
                            : "text-gray-700 border-gray-200 bg-gray-50"
                        }
                      >
                        {instance.instance.status === "connected"
                          ? "Conectado"
                          : instance.instance.status === "connecting" || instance.instance.status === "qrcode"
                            ? "Aguardando QR"
                            : "Desconectado"}
                      </Badge>
                    </div>

                    <div className="flex justify-end gap-2">
                      {/* Botão para atribuir/alterar perfil */}
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => openProfileDialog(instanceName)}
                        disabled={isRemovingProfile === instanceName}
                      >
                        <UserPlus className="h-4 w-4 mr-1" />
                        {instance.professionalProfile ? "Alterar Perfil" : "Atribuir Perfil"}
                      </Button>

                      {/* Botão para mostrar QR code */}
                      {instance.instance.status !== "connected" && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setCurrentQRInstance(instanceName)
                            setShowQRModal(true)
                            loadQRCode(instanceName)
                            startQRTimer()
                          }}
                        >
                          <QrCode className="h-4 w-4 mr-1" />
                          QR Code
                        </Button>
                      )}

                      {/* Dropdown para ações */}
                      <InstanceDropdown
                        instanceName={instanceName}
                        onDisconnect={() => confirmDisconnect(instanceName)}
                        onDelete={() => confirmDelete(instanceName)}
                      />
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </div>

        {/* Modal de criação de nova conexão */}
        <Dialog open={showCreateModal} onOpenChange={setShowCreateModal}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Criar Nova Conexão WhatsApp</DialogTitle>
              <DialogDescription>Digite um nome para identificar esta conexão WhatsApp</DialogDescription>
            </DialogHeader>

            <div className="space-y-4">
              <div>
                <Label htmlFor="instanceName">Nome da Instância</Label>
                <Input
                  id="instanceName"
                  value={newInstanceName}
                  onChange={(e) => setNewInstanceName(e.target.value)}
                  placeholder="Ex: Atendimento, Consultório, etc."
                  disabled={isCreating}
                />
                {instanceNameError && <p className="text-sm text-red-500 mt-1">{instanceNameError}</p>}
              </div>

              {errorMessage && <div className="text-sm text-red-500 bg-red-50 p-3 rounded-md">{errorMessage}</div>}

              <DialogFooter>
                <Button variant="outline" onClick={() => setShowCreateModal(false)} disabled={isCreating}>
                  Cancelar
                </Button>
                <Button onClick={createInstance} disabled={isCreating}>
                  {isCreating ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Criando...
                    </>
                  ) : (
                    "Criar Conexão"
                  )}
                </Button>
              </DialogFooter>
            </div>
          </DialogContent>
        </Dialog>

        {/* Modal de QR Code */}
        <Dialog open={showQRModal} onOpenChange={setShowQRModal}>
          <DialogContent className="sm:max-w-lg">
            <DialogHeader>
              <DialogTitle>Conectar WhatsApp</DialogTitle>
              <DialogDescription>Escaneie o código QR com seu telefone</DialogDescription>
            </DialogHeader>

            <div className="space-y-6">
              <div className="text-center">
                {qrCodeUrl && !imgError ? (
                  <div className="flex justify-center mb-4">
                    <div className="bg-white p-4 rounded-lg border">
                      <img
                        src={qrCodeUrl || "/placeholder.svg"}
                        alt="WhatsApp QR Code"
                        className="w-64 h-64 object-contain"
                        onError={(e) => {
                          console.error("Erro ao carregar imagem QR:", e)
                          setImgError(true)
                        }}
                      />
                    </div>
                  </div>
                ) : (
                  <div className="flex justify-center mb-4">
                    <div className="w-64 h-64 bg-gray-50 border border-gray-200 rounded-lg flex items-center justify-center dark:bg-gray-800 dark:border-gray-700">
                      {errorMessage ? (
                        <div className="text-center p-4">
                          <QrCode className="h-10 w-10 mx-auto text-muted-foreground mb-2" />
                          <p className="text-sm text-muted-foreground">QR code não disponível</p>
                          <p className="text-xs text-muted-foreground mt-1">Clique em "Atualizar QR Code"</p>
                        </div>
                      ) : (
                        <div className="text-center">
                          {/* Ícone de loading da cor da Aplia */}
                          <div className="relative">
                            <div className="w-12 h-12 mx-auto mb-3">
                              <div className="absolute inset-0 border-4 border-gray-200 rounded-full"></div>
                              <div className="absolute inset-0 border-4 border-transparent border-t-[#FF6B6B] rounded-full animate-spin"></div>
                            </div>
                          </div>
                          <p className="text-sm text-muted-foreground">Gerando QR code...</p>
                          <p className="text-xs text-muted-foreground mt-1">Isso pode levar alguns segundos</p>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                <Button
                  variant="outline"
                  onClick={() => {
                    if (currentQRInstance) {
                      loadQRCode(currentQRInstance)
                      startQRTimer() // Reiniciar o timer
                    }
                  }}
                  className="mb-4"
                >
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Atualizar QR Code
                </Button>
              </div>

              <div className="space-y-2 text-sm">
                <h4 className="font-medium">Como conectar:</h4>
                <p>1. Abra o WhatsApp no seu telefone</p>
                <p>2. Toque em Menu ou Configurações e selecione Dispositivos Conectados</p>
                <p>3. Toque em "Conectar um Dispositivo"</p>
                <p>4. Aponte seu telefone para esta tela para escanear o código QR</p>
              </div>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setShowQRModal(false)}>
                Fechar
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Diálogo de atribuição de perfil */}
        <Dialog open={showProfileDialog} onOpenChange={setShowProfileDialog}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Atribuir Perfil Profissional</DialogTitle>
              <DialogDescription>
                Selecione um perfil profissional para vincular a esta conexão WhatsApp
              </DialogDescription>
            </DialogHeader>

            <div className="py-4">
              {isLoadingProfiles ? (
                <div className="flex justify-center py-4">
                  <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                </div>
              ) : profiles.length === 0 ? (
                <div className="text-center py-4">
                  <p className="text-muted-foreground">Nenhum perfil profissional disponível</p>
                  <p className="text-sm text-muted-foreground mt-1">
                    Crie um perfil profissional antes de vinculá-lo a uma conexão WhatsApp
                  </p>
                  <Button
                    variant="outline"
                    className="mt-4 bg-transparent"
                    onClick={() => {
                      setShowProfileDialog(false)
                      window.location.href = "/dashboard/profiles/new"
                    }}
                  >
                    Criar Perfil
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  <Label htmlFor="profile-select">Perfil Profissional</Label>
                  <Select value={selectedProfileId || "none"} onValueChange={setSelectedProfileId}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione um perfil" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">Nenhum (remover vinculação)</SelectItem>
                      {profiles.map((profile) => (
                        <SelectItem key={profile.id} value={profile.id}>
                          {profile.fullName} {profile.specialty && `(${profile.specialty})`}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setShowProfileDialog(false)}>
                Cancelar
              </Button>
              <Button
                onClick={assignProfile}
                disabled={isAssigningProfile || isLoadingProfiles || profiles.length === 0}
              >
                {isAssigningProfile ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Salvando...
                  </>
                ) : (
                  "Salvar"
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Diálogo de confirmação de desconexão */}
        <AlertDialog open={showDisconnectDialog} onOpenChange={setShowDisconnectDialog}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Desconectar WhatsApp</AlertDialogTitle>
              <AlertDialogDescription>
                Tem certeza que deseja desconectar esta instância do WhatsApp? Você precisará escanear o código QR
                novamente para reconectar.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancelar</AlertDialogCancel>
              <AlertDialogAction onClick={handleDisconnect} className="bg-orange-600 hover:bg-orange-700">
                Desconectar
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

        {/* Diálogo de confirmação de exclusão */}
        <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Excluir Instância Permanentemente</AlertDialogTitle>
              <AlertDialogDescription>
                Esta ação não pode ser desfeita. A instância será excluída permanentemente do sistema e você perderá
                todas as configurações e histórico associados.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancelar</AlertDialogCancel>
              <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">
                Excluir Permanentemente
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </TooltipProvider>
  )
}
