"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"

export interface TermsModalProps {
  isOpen: boolean
  onClose: () => void
  onAccept?: () => void
}

export function TermsModal({ isOpen, onClose, onAccept }: TermsModalProps) {
  const [accepted, setAccepted] = useState(false)

  const handleAccept = () => {
    setAccepted(true)
    if (onAccept) onAccept()
    onClose()
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px] max-h-[80vh] flex flex-col">
        <DialogHeader>
          <DialogTitle>Termos e Condições</DialogTitle>
        </DialogHeader>
        <ScrollArea className="flex-1 p-4 rounded-md">
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">1. Aceitação dos Termos</h3>
            <p>
              Ao acessar e utilizar esta plataforma, você concorda em cumprir e estar vinculado aos seguintes termos e
              condições de uso. Se você não concordar com qualquer parte destes termos, não poderá acessar ou utilizar
              nossos serviços.
            </p>

            <h3 className="text-lg font-semibold">2. Descrição do Serviço</h3>
            <p>
              Nossa plataforma oferece serviços de agendamento médico, gerenciamento de perfis profissionais e
              comunicação entre pacientes e profissionais de saúde. Os serviços são fornecidos "como estão" e podem ser
              modificados a qualquer momento.
            </p>

            <h3 className="text-lg font-semibold">3. Privacidade e Dados Pessoais</h3>
            <p>
              Respeitamos sua privacidade e protegemos seus dados pessoais de acordo com nossa Política de Privacidade.
              Ao utilizar nossos serviços, você concorda com a coleta e uso de informações conforme descrito em nossa
              política.
            </p>

            <h3 className="text-lg font-semibold">4. Responsabilidades do Usuário</h3>
            <p>
              Você é responsável por manter a confidencialidade de sua conta e senha. Você concorda em notificar-nos
              imediatamente sobre qualquer uso não autorizado de sua conta. Você é responsável por todas as atividades
              que ocorrem sob sua conta.
            </p>

            <h3 className="text-lg font-semibold">5. Limitação de Responsabilidade</h3>
            <p>
              Em nenhuma circunstância seremos responsáveis por danos diretos, indiretos, incidentais, especiais ou
              consequentes resultantes do uso ou incapacidade de usar nossos serviços.
            </p>

            <h3 className="text-lg font-semibold">6. Alterações nos Termos</h3>
            <p>
              Reservamo-nos o direito de modificar estes termos a qualquer momento. As alterações entrarão em vigor
              imediatamente após a publicação dos termos atualizados. O uso continuado de nossos serviços após tais
              alterações constitui sua aceitação dos novos termos.
            </p>

            <h3 className="text-lg font-semibold">7. Lei Aplicável</h3>
            <p>
              Estes termos serão regidos e interpretados de acordo com as leis do Brasil, independentemente de conflitos
              de princípios legais.
            </p>
          </div>
        </ScrollArea>
        <div className="flex justify-end space-x-2 mt-4">
          <Button variant="outline" onClick={onClose}>
            Cancelar
          </Button>
          <Button onClick={handleAccept}>Aceitar Termos</Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}

// Re-export for compatibility
export default TermsModal
