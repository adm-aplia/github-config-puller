"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { AlertCircle, Loader2 } from "lucide-react"
import { ConversationService } from "@/lib/services/conversation-service"
import { formatDistanceToNow } from "date-fns"
import { ptBR } from "date-fns/locale"

interface ConversationsListProps {
  searchQuery?: string
  statusFilter?: string
  dateRange?: { from?: Date; to?: Date }
}

export function ConversationsList({ searchQuery = "", statusFilter, dateRange }: ConversationsListProps) {
  const [conversations, setConversations] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    async function fetchConversations() {
      try {
        setLoading(true)
        setError(null)

        // Construir filtros baseados nos props
        const filters: any = {}

        if (statusFilter) {
          filters.status = statusFilter
        }

        if (dateRange?.from) {
          filters.startDate = dateRange.from.toISOString()
        }

        if (dateRange?.to) {
          filters.endDate = dateRange.to.toISOString()
        }

        if (searchQuery) {
          filters.search = searchQuery
        }

        // Buscar conversas com os filtros aplicados
        const { data } = await ConversationService.getUserConversations(filters)
        setConversations(data || [])
      } catch (err) {
        console.error("Erro ao buscar conversas:", err)
        setError("Não foi possível carregar as conversas. Tente novamente mais tarde.")
      } finally {
        setLoading(false)
      }
    }

    fetchConversations()
  }, [searchQuery, statusFilter, dateRange])

  // Função para formatar a data relativa (ex: "há 10 minutos")
  const formatRelativeTime = (dateString: string) => {
    try {
      return formatDistanceToNow(new Date(dateString), {
        addSuffix: true,
        locale: ptBR,
      })
    } catch (e) {
      return "Data desconhecida"
    }
  }

  // Função para determinar se uma conversa requer atenção
  const requiresAttention = (conversation: any) => {
    // Lógica para determinar se uma conversa requer atenção
    // Por exemplo, se tiver status "flagged" ou não tiver sido respondida por um tempo
    return (
      conversation.status === "flagged" ||
      (conversation.last_message_role === "user" &&
        new Date(conversation.updated_at).getTime() < Date.now() - 24 * 60 * 60 * 1000)
    )
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  if (error) {
    return (
      <div className="text-center py-8">
        <AlertCircle className="h-8 w-8 text-destructive mx-auto mb-2" />
        <p className="text-muted-foreground">{error}</p>
        <Button variant="outline" className="mt-4" onClick={() => window.location.reload()}>
          Tentar novamente
        </Button>
      </div>
    )
  }

  if (conversations.length === 0) {
    return (
      <div className="text-center py-8">
        <p className="text-muted-foreground">Nenhuma conversa encontrada</p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {conversations.map((conversation) => (
        <div key={conversation.id} className="flex items-center gap-4 p-3 rounded-lg border">
          <Avatar>
            <AvatarImage
              src={`/abstract-geometric-shapes.png?height=32&width=32&query=${encodeURIComponent(conversation.contact_name || "Paciente")}`}
              alt={conversation.contact_name || "Paciente"}
            />
            <AvatarFallback>{(conversation.contact_name || "P").charAt(0)}</AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <p className="font-medium">{conversation.contact_name || "Paciente sem nome"}</p>
              {requiresAttention(conversation) && (
                <Badge variant="destructive" className="ml-2 flex items-center gap-1">
                  <AlertCircle className="h-3 w-3" />
                  <span>Requer atenção</span>
                </Badge>
              )}
              <Badge
                variant={
                  conversation.status === "active"
                    ? "default"
                    : conversation.status === "closed"
                      ? "secondary"
                      : conversation.status === "flagged"
                        ? "destructive"
                        : "outline"
                }
                className="ml-auto"
              >
                {conversation.status === "active"
                  ? "ativa"
                  : conversation.status === "closed"
                    ? "fechada"
                    : conversation.status === "flagged"
                      ? "sinalizada"
                      : conversation.status}
              </Badge>
            </div>
            <p className="text-sm text-muted-foreground truncate">{conversation.last_message || "Sem mensagens"}</p>
            <div className="flex items-center gap-2 mt-1">
              <p className="text-xs text-muted-foreground">{formatRelativeTime(conversation.updated_at)}</p>
              <span className="text-xs text-muted-foreground">•</span>
              <p className="text-xs text-muted-foreground">
                {conversation.professional_profiles?.fullName || "Sem profissional atribuído"}
              </p>
            </div>
          </div>
          <Button variant="ghost" size="sm" asChild>
            <Link href={`/dashboard/conversations/${conversation.id}`}>Ver</Link>
          </Button>
        </div>
      ))}
    </div>
  )
}
