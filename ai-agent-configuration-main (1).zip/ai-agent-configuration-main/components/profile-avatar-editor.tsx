"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Loader2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

// Lista de avatares fictícios
const AVATAR_OPTIONS = [
  "/images/avatars/doctor-male-1.png",
  "/images/avatars/doctor-female-1.png",
  "/images/avatars/doctor-male-2.png",
  "/images/avatars/doctor-female-2.png",
  "/images/avatars/nurse-1.png",
  "/images/avatars/medical-specialist-1.png",
  "/images/avatars/medical-specialist-2.png",
  "/images/avatars/surgeon-1.png",
  "/images/avatars/therapist-1.png",
  "/images/avatars/lab-technician-1.png",
]

interface ProfileAvatarEditorProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onAvatarChange?: (avatarUrl: string) => void
}

export function ProfileAvatarEditor({ open, onOpenChange, onAvatarChange }: ProfileAvatarEditorProps) {
  const [selectedAvatar, setSelectedAvatar] = useState<string | null>(null)
  const [isSaving, setIsSaving] = useState(false)
  const { toast } = useToast()

  const handleSave = async () => {
    if (!selectedAvatar) {
      toast({
        variant: "destructive",
        title: "Nenhum avatar selecionado",
        description: "Por favor, selecione um avatar para continuar.",
      })
      return
    }

    setIsSaving(true)
    try {
      // Simulação de um atraso para dar feedback visual
      await new Promise((resolve) => setTimeout(resolve, 1000))

      if (onAvatarChange) {
        onAvatarChange(selectedAvatar)
      }

      toast({
        title: "Avatar atualizado",
        description: "Seu avatar foi atualizado com sucesso.",
      })

      onOpenChange(false)
    } catch (error) {
      console.error("Erro ao salvar avatar:", error)
      toast({
        variant: "destructive",
        title: "Erro ao salvar avatar",
        description: "Não foi possível atualizar seu avatar. Tente novamente mais tarde.",
      })
    } finally {
      setIsSaving(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Escolha seu Avatar</DialogTitle>
          <DialogDescription>Selecione um avatar para representar seu perfil profissional.</DialogDescription>
        </DialogHeader>

        <div className="grid grid-cols-5 gap-4 py-4">
          {AVATAR_OPTIONS.map((avatar, index) => (
            <div
              key={index}
              className={`
                cursor-pointer rounded-lg p-2 transition-all
                ${selectedAvatar === avatar ? "bg-primary/10 ring-2 ring-primary" : "hover:bg-muted"}
              `}
              onClick={() => setSelectedAvatar(avatar)}
            >
              {/* Usamos placeholder.svg como fallback, mas em produção seriam imagens reais */}
              <img
                src={avatar || `/placeholder.svg?text=Avatar${index + 1}&height=80&width=80`}
                alt={`Avatar ${index + 1}`}
                className="h-16 w-16 rounded-full object-cover"
              />
            </div>
          ))}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancelar
          </Button>
          <Button onClick={handleSave} disabled={isSaving || !selectedAvatar}>
            {isSaving ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Salvando...
              </>
            ) : (
              "Salvar Avatar"
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
