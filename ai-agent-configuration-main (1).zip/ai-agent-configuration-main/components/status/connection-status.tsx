"use client"

import { useEffect, useState } from "react"
import { useSupabase } from "@/contexts/supabase-context"
import { WifiOff, CheckCircle, RefreshCw } from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

export function ConnectionStatus() {
  const { supabase, isLoading, isError, reinitialize } = useSupabase()
  const [isOnline, setIsOnline] = useState(true)
  const [isChecking, setIsChecking] = useState(false)
  const [connectionStatus, setConnectionStatus] = useState<"connected" | "disconnected" | "checking">("checking")

  // Verificar status de conexão com internet
  useEffect(() => {
    const updateOnlineStatus = () => {
      setIsOnline(navigator.onLine)
    }

    // Definir estado inicial
    updateOnlineStatus()

    // Adicionar event listeners
    window.addEventListener("online", updateOnlineStatus)
    window.addEventListener("offline", updateOnlineStatus)

    return () => {
      window.removeEventListener("online", updateOnlineStatus)
      window.removeEventListener("offline", updateOnlineStatus)
    }
  }, [])

  // Verificar status da conexão com Supabase
  useEffect(() => {
    if (!isOnline) {
      setConnectionStatus("disconnected")
      return
    }

    if (isLoading) {
      setConnectionStatus("checking")
      return
    }

    if (isError || !supabase) {
      setConnectionStatus("disconnected")
      return
    }

    // Se temos uma instância e não há erro, verificar com uma operação simples
    const checkConnection = async () => {
      setConnectionStatus("checking")
      try {
        const { error } = await supabase.auth.getSession()
        setConnectionStatus(error ? "disconnected" : "connected")
      } catch (error) {
        console.error("Erro ao verificar conexão:", error)
        setConnectionStatus("disconnected")
      }
    }

    checkConnection()
  }, [supabase, isLoading, isError, isOnline])

  // Função para verificar manualmente
  const handleCheckConnection = async () => {
    setIsChecking(true)
    try {
      await reinitialize()
    } finally {
      setIsChecking(false)
    }
  }

  // Não mostrar nada se estiver conectado (opcional, para não poluir a UI)
  if (connectionStatus === "connected" && !isChecking) {
    return null
  }

  return (
    <div
      className={cn(
        "fixed bottom-4 right-4 flex items-center gap-2 rounded-lg p-2 shadow-md z-50 text-sm",
        connectionStatus === "connected"
          ? "bg-green-100 text-green-800"
          : connectionStatus === "disconnected"
            ? "bg-red-100 text-red-800"
            : "bg-yellow-100 text-yellow-800",
      )}
    >
      {connectionStatus === "connected" && <CheckCircle className="h-4 w-4" />}
      {connectionStatus === "disconnected" && <WifiOff className="h-4 w-4" />}
      {connectionStatus === "checking" && <RefreshCw className="h-4 w-4 animate-spin" />}

      <span>
        {connectionStatus === "connected" && "Conectado ao banco de dados"}
        {connectionStatus === "disconnected" && "Desconectado do banco de dados"}
        {connectionStatus === "checking" && "Verificando conexão..."}
      </span>

      {connectionStatus === "disconnected" && (
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="outline"
                size="sm"
                className="ml-2 h-7 bg-white"
                onClick={handleCheckConnection}
                disabled={isChecking || !isOnline}
              >
                <RefreshCw className={cn("h-3 w-3 mr-1", isChecking && "animate-spin")} />
                Reconectar
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              {!isOnline
                ? "Você está offline. Verifique sua conexão com a internet."
                : "Tentar reconectar ao banco de dados"}
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      )}
    </div>
  )
}
