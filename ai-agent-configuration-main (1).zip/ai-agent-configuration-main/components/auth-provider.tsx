"use client"

import type React from "react"
import { createContext, useContext, useEffect, useState, useRef } from "react"
import { supabase } from "@/lib/supabase"
import type { User, Session } from "@/lib/supabase"
import { toast } from "./ui/use-toast"

interface AuthContextType {
  user: User | null
  session: Session | null
  isAuthenticated: boolean
  isInitialized: boolean
  signIn: (email: string, password: string) => Promise<void>
  signUp: (email: string, password: string, userData?: any) => Promise<{ error?: string }>
  signOut: () => Promise<void>
  resendConfirmationEmail: (email: string) => Promise<void>
  loading: boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

// ---------------------------------------------------------------------------
// Exporta também o contexto para quem precisar consumir diretamente
export { AuthContext }

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [session, setSession] = useState<Session | null>(null)
  const [loading, setLoading] = useState(true)
  const [isInitialized, setIsInitialized] = useState(false)
  const mountedRef = useRef(true)

  useEffect(() => {
    mountedRef.current = true
    return () => {
      mountedRef.current = false
    }
  }, [])

  useEffect(() => {
    let mounted = true

    async function initializeAuth() {
      try {
        console.log("🔐 Inicializando autenticação...")

        // Get initial session
        const {
          data: { session: initialSession },
          error,
        } = await supabase.auth.getSession()

        if (error) {
          console.error("❌ Erro ao obter sessão inicial:", error)
        } else if (initialSession?.user && mounted) {
          console.log("📱 Sessão inicial encontrada:", initialSession.user.email)
          setSession(initialSession)
          setUser({
            id: initialSession.user.id,
            email: initialSession.user.email,
            name: initialSession.user.user_metadata?.name,
            role: initialSession.user.user_metadata?.role,
            isConfirmed: !!initialSession.user.email_confirmed_at,
          })
        }

        // Set up auth listener
        const {
          data: { subscription },
        } = supabase.auth.onAuthStateChange(async (event, session) => {
          if (!mounted) return

          console.log("🔐 Auth event:", event, session?.user?.email)

          if (event === "SIGNED_IN" && session?.user) {
            console.log("✅ Sign in successful:", session.user.email)
            setSession(session)
            setUser({
              id: session.user.id,
              email: session.user.email,
              name: session.user.user_metadata?.name,
              role: session.user.user_metadata?.role,
              isConfirmed: !!session.user.email_confirmed_at,
            })
          } else if (event === "SIGNED_OUT") {
            console.log("👋 Sign out successful")
            setSession(null)
            setUser(null)
          } else if (event === "TOKEN_REFRESHED" && session?.user) {
            console.log("🔄 Token refreshed:", session.user.email)
            setSession(session)
            setUser({
              id: session.user.id,
              email: session.user.email,
              name: session.user.user_metadata?.name,
              role: session.user.user_metadata?.role,
              isConfirmed: !!session.user.email_confirmed_at,
            })
          }
        })

        if (mounted) {
          setIsInitialized(true)
          setLoading(false)
        }

        return () => {
          subscription.unsubscribe()
        }
      } catch (error) {
        console.error("❌ Erro na inicialização da auth:", error)
        if (mounted) {
          setIsInitialized(true)
          setLoading(false)
        }
      }
    }

    initializeAuth()

    return () => {
      mounted = false
    }
  }, [])

  // Verificar se o usuário existe no banco de dados
  const checkUserExists = async (email: string): Promise<boolean> => {
    try {
      const { data, error } = await supabase.from("profiles").select("id").eq("email", email).limit(1)

      if (error) {
        console.error("Erro ao verificar usuário:", error)
        return false
      }

      return data && data.length > 0
    } catch (error) {
      console.error("Erro ao verificar usuário:", error)
      return false
    }
  }

  const signIn = async (email: string, password: string) => {
    try {
      console.log("🔑 Verificando se usuário existe:", email)

      // Primeiro, verificar se o usuário existe no banco
      const userExists = await checkUserExists(email)

      if (!userExists) {
        console.log("❌ Usuário não encontrado no banco de dados")
        toast({
          title: "Usuário Não Encontrado",
          description: "Não encontramos uma conta com este e-mail. Verifique o e-mail ou crie uma nova conta.",
          variant: "destructive",
        })
        throw new Error("User not found")
      }

      console.log("✅ Usuário encontrado, tentando fazer login...")
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      })

      if (error) {
        console.log("❌ Erro no login:", error.message)

        // Mapear erros específicos para mensagens amigáveis
        if (error.message === "Invalid login credentials") {
          toast({
            title: "Dados Incorretos",
            description: "E-mail ou senha incorretos. Verifique seus dados e tente novamente.",
            variant: "destructive",
          })
        } else if (error.message === "Email not confirmed") {
          console.log("📧 E-mail não confirmado")
          throw new Error("Email not confirmed")
        } else if (error.message.includes("Too many requests")) {
          toast({
            title: "Muitas Tentativas",
            description: "Você fez muitas tentativas de login. Aguarde alguns minutos e tente novamente.",
            variant: "destructive",
          })
        } else {
          toast({
            title: "Erro no Login",
            description: "Ops! Algo deu errado. Tente novamente.",
            variant: "destructive",
          })
        }

        throw error
      }

      console.log("✅ Login realizado com sucesso para:", data.user?.email)
    } catch (error: any) {
      console.log("❌ Exceção no login:", error.message)
      throw error
    }
  }

  const signUp = async (email: string, password: string, userData?: any) => {
    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: userData,
        },
      })

      if (error) {
        console.error("❌ Erro no cadastro:", error)
        return { error: error.message }
      }

      return {}
    } catch (error: any) {
      console.error("❌ Exceção no cadastro:", error)
      return { error: error.message }
    }
  }

  const signOut = async () => {
    try {
      const { error } = await supabase.auth.signOut()
      if (error) {
        console.error("❌ Erro ao sair:", error)
      } else {
        console.log("✅ Logout realizado com sucesso")
      }
    } catch (error) {
      console.error("❌ Exceção no logout:", error)
    }
  }

  const resendConfirmationEmail = async (email: string) => {
    try {
      const { error } = await supabase.auth.resend({
        type: "signup",
        email: email,
      })

      if (error) {
        console.error("❌ Erro ao reenviar confirmação:", error)
        throw new Error(error.message)
      }

      console.log("✅ E-mail de confirmação reenviado para:", email)
    } catch (error: any) {
      console.error("❌ Exceção ao reenviar confirmação:", error)
      throw error
    }
  }

  const value: AuthContextType = {
    user,
    session,
    isAuthenticated: !!user,
    isInitialized,
    signIn,
    signUp,
    signOut,
    resendConfirmationEmail,
    loading,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
