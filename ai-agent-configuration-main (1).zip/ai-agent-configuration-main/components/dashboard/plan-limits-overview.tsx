"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { usePermissions } from "@/hooks/use-permissions"
import { Loader2, MessageSquare, Calendar, Bot, AlertTriangle, Crown } from "lucide-react"
import Link from "next/link"

export function PlanLimitsOverview() {
  const { limits, usage, permissions, features, loading, error } = usePermissions()

  if (loading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center p-6">
          <Loader2 className="h-6 w-6 animate-spin" />
          <span className="ml-2">Carregando informações do plano...</span>
        </CardContent>
      </Card>
    )
  }

  if (error || !limits || !usage) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center p-6">
          <AlertTriangle className="h-6 w-6 text-yellow-500" />
          <span className="ml-2">Erro ao carregar informações do plano</span>
        </CardContent>
      </Card>
    )
  }

  const getProgressColor = (current: number, limit: number) => {
    if (limit === -1) return "bg-green-500" // Ilimitado
    const percentage = (current / limit) * 100
    if (percentage >= 90) return "bg-red-500"
    if (percentage >= 70) return "bg-yellow-500"
    return "bg-green-500"
  }

  const formatLimit = (limit: number) => {
    return limit === -1 ? "Ilimitado" : limit.toString()
  }

  const getProgressPercentage = (current: number, limit: number) => {
    if (limit === -1) return 0 // Não mostrar barra para ilimitado
    return Math.min((current / limit) * 100, 100)
  }

  return (
    <div className="grid gap-6 md:grid-cols-2">
      {/* Resumo do Plano */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Crown className="h-5 w-5 text-yellow-500" />
            Seu Plano Atual
          </CardTitle>
          <CardDescription>Informações sobre sua assinatura</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-2xl font-bold">{limits.plano || "Básico"}</span>
              <Badge variant="outline" className="bg-aplia-blue text-white">
                Ativo
              </Badge>
            </div>

            <div className="space-y-2">
              <h4 className="font-medium">Funcionalidades Incluídas:</h4>
              <div className="grid grid-cols-1 gap-1 text-sm">
                <div className="flex items-center gap-2">
                  <div
                    className={`w-2 h-2 rounded-full ${features.advanced_reports ? "bg-green-500" : "bg-gray-300"}`}
                  />
                  <span className={features.advanced_reports ? "text-green-600" : "text-gray-500"}>
                    Relatórios Avançados
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <div
                    className={`w-2 h-2 rounded-full ${features.hospital_integration ? "bg-green-500" : "bg-gray-300"}`}
                  />
                  <span className={features.hospital_integration ? "text-green-600" : "text-gray-500"}>
                    Integração Hospitalar
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <div className={`w-2 h-2 rounded-full ${features.api_access ? "bg-green-500" : "bg-gray-300"}`} />
                  <span className={features.api_access ? "text-green-600" : "text-gray-500"}>Acesso à API</span>
                </div>
                <div className="flex items-center gap-2">
                  <div
                    className={`w-2 h-2 rounded-full ${features.custom_branding ? "bg-green-500" : "bg-gray-300"}`}
                  />
                  <span className={features.custom_branding ? "text-green-600" : "text-gray-500"}>
                    Marca Personalizada
                  </span>
                </div>
              </div>
            </div>

            <Link href="/dashboard/planos">
              <Button variant="outline" className="w-full">
                Fazer Upgrade
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>

      {/* Uso dos Recursos */}
      <Card>
        <CardHeader>
          <CardTitle>Uso dos Recursos</CardTitle>
          <CardDescription>Acompanhe o consumo dos seus limites</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* WhatsApp Instances */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <MessageSquare className="h-4 w-4 text-green-600" />
                <span className="text-sm font-medium">WhatsApp</span>
              </div>
              <span className="text-sm text-muted-foreground">
                {usage.whatsapp_instances_used} / {formatLimit(limits.whatsapp_instances)}
              </span>
            </div>
            {limits.whatsapp_instances !== -1 && (
              <Progress
                value={getProgressPercentage(usage.whatsapp_instances_used, limits.whatsapp_instances)}
                className="h-2"
              />
            )}
            {!permissions.canCreateWhatsApp.allowed && (
              <p className="text-xs text-red-600">{permissions.canCreateWhatsApp.reason}</p>
            )}
          </div>

          {/* Assistentes */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Bot className="h-4 w-4 text-purple-600" />
                <span className="text-sm font-medium">Atendentes</span>
              </div>
              <span className="text-sm text-muted-foreground">
                {usage.assistants_created} / {formatLimit(limits.max_assistants)}
              </span>
            </div>
            {limits.max_assistants !== -1 && (
              <Progress
                value={getProgressPercentage(usage.assistants_created, limits.max_assistants)}
                className="h-2"
              />
            )}
            {!permissions.canCreateAssistant.allowed && (
              <p className="text-xs text-red-600">{permissions.canCreateAssistant.reason}</p>
            )}
          </div>

          {/* Agendamentos */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Calendar className="h-4 w-4 text-blue-600" />
                <span className="text-sm font-medium">Agendamentos (mês)</span>
              </div>
              <span className="text-sm text-muted-foreground">
                {usage.appointments_this_month} / {formatLimit(limits.max_appointments)}
              </span>
            </div>
            {limits.max_appointments !== -1 && (
              <Progress
                value={getProgressPercentage(usage.appointments_this_month, limits.max_appointments)}
                className="h-2"
              />
            )}
            {!permissions.canCreateAppointment.allowed && (
              <p className="text-xs text-red-600">{permissions.canCreateAppointment.reason}</p>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
