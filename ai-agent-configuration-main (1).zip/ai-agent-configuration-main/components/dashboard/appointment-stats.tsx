"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Skeleton } from "@/components/ui/skeleton"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import {
  CalendarDays,
  CheckCircle,
  XCircle,
  CalendarIcon,
  RefreshCw,
  Clock,
  UserCheck,
  UserX,
  RotateCcw,
} from "lucide-react"
import { format, startOfMonth, endOfMonth, subDays, subMonths } from "date-fns"
import { ptBR } from "date-fns/locale"
import type { DateRange } from "react-day-picker"
import { useAuth } from "@/hooks/use-auth"
import { cn } from "@/lib/utils"

interface AppointmentStats {
  total: number
  scheduled: number
  confirmed: number
  completed: number
  cancelled: number
  noShow: number
  rescheduled: number
  appointments: Array<{
    id: string
    status: string
    appointment_date: string
    patient_name: string
  }>
}

const presets = [
  {
    label: "Hoje",
    getValue: () => ({
      from: new Date(),
      to: new Date(),
    }),
  },
  {
    label: "Últimos 7 dias",
    getValue: () => ({
      from: subDays(new Date(), 6),
      to: new Date(),
    }),
  },
  {
    label: "Últimos 30 dias",
    getValue: () => ({
      from: subDays(new Date(), 29),
      to: new Date(),
    }),
  },
  {
    label: "Mês atual",
    getValue: () => ({
      from: startOfMonth(new Date()),
      to: endOfMonth(new Date()),
    }),
  },
  {
    label: "Mês passado",
    getValue: () => {
      const lastMonth = subMonths(new Date(), 1)
      return {
        from: startOfMonth(lastMonth),
        to: endOfMonth(lastMonth),
      }
    },
  },
]

const statusConfig = {
  scheduled: {
    label: "Agendados",
    icon: Clock,
    color: "bg-blue-500",
    variant: "default" as const,
  },
  confirmed: {
    label: "Confirmados",
    icon: UserCheck,
    color: "bg-green-500",
    variant: "secondary" as const,
  },
  completed: {
    label: "Concluídos",
    icon: CheckCircle,
    color: "bg-emerald-500",
    variant: "default" as const,
  },
  cancelled: {
    label: "Cancelados",
    icon: XCircle,
    color: "bg-red-500",
    variant: "destructive" as const,
  },
  "no-show": {
    label: "Não Compareceram",
    icon: UserX,
    color: "bg-orange-500",
    variant: "destructive" as const,
  },
  rescheduled: {
    label: "Remarcados",
    icon: RotateCcw,
    color: "bg-yellow-500",
    variant: "outline" as const,
  },
}

export function AppointmentStats() {
  const { user } = useAuth()
  const [stats, setStats] = useState<AppointmentStats | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [dateRange, setDateRange] = useState<DateRange | undefined>(() => {
    const today = new Date()
    return {
      from: startOfMonth(today),
      to: endOfMonth(today),
    }
  })
  const [isCalendarOpen, setIsCalendarOpen] = useState(false)

  const fetchStats = async () => {
    if (!user?.id || !dateRange?.from || !dateRange?.to) return

    try {
      setLoading(true)
      setError(null)

      const params = new URLSearchParams({
        userId: user.id,
        startDate: format(dateRange.from, "yyyy-MM-dd"),
        endDate: format(dateRange.to, "yyyy-MM-dd"),
      })

      console.log("📊 Buscando estatísticas:", {
        userId: user.id,
        startDate: format(dateRange.from, "yyyy-MM-dd"),
        endDate: format(dateRange.to, "yyyy-MM-dd"),
      })

      const response = await fetch(`/api/appointments/stats?${params}`)

      if (!response.ok) {
        const errorText = await response.text()
        throw new Error(`Erro na API: ${response.status} - ${errorText}`)
      }

      const result = await response.json()
      console.log("📈 Estatísticas recebidas:", result)

      setStats(result)
    } catch (error) {
      console.error("❌ Erro ao buscar estatísticas:", error)
      setError(`Erro ao buscar estatísticas: ${error instanceof Error ? error.message : "Erro desconhecido"}`)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchStats()
  }, [user?.id, dateRange])

  const handleDateSelect = (range: DateRange | undefined) => {
    console.log("📅 Data selecionada:", range)
    if (range?.from && range?.to) {
      setDateRange(range)
      setIsCalendarOpen(false)
    }
  }

  const handlePresetSelect = (preset: (typeof presets)[0]) => {
    const range = preset.getValue()
    setDateRange(range)
    setIsCalendarOpen(false)
  }

  const formatDateRange = () => {
    if (!dateRange?.from || !dateRange?.to) return "Selecione o período"

    if (format(dateRange.from, "yyyy-MM-dd") === format(dateRange.to, "yyyy-MM-dd")) {
      return format(dateRange.from, "dd/MM/yyyy", { locale: ptBR })
    }

    return `${format(dateRange.from, "dd/MM/yyyy", { locale: ptBR })} - ${format(dateRange.to, "dd/MM/yyyy", { locale: ptBR })}`
  }

  if (error) {
    return (
      <Card>
        <CardContent className="p-6">
          <Alert variant="destructive">
            <XCircle className="h-4 w-4" />
            <AlertDescription className="flex items-center justify-between">
              <span>Erro ao carregar estatísticas</span>
              <Button variant="outline" size="sm" onClick={fetchStats} className="ml-4 bg-transparent">
                <RefreshCw className="h-4 w-4 mr-2" />
                Tentar novamente
              </Button>
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header com seletor de período */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Estatísticas de Agendamentos</h2>
          <p className="text-muted-foreground">Acompanhe o desempenho dos seus agendamentos</p>
        </div>

        <div className="flex items-center gap-2">
          {/* Presets rápidos */}
          <div className="hidden md:flex items-center gap-2">
            {presets.slice(0, 3).map((preset) => (
              <Button
                key={preset.label}
                variant="outline"
                size="sm"
                onClick={() => handlePresetSelect(preset)}
                className="bg-transparent"
              >
                {preset.label}
              </Button>
            ))}
          </div>

          {/* Seletor de período */}
          <Popover open={isCalendarOpen} onOpenChange={setIsCalendarOpen}>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className={cn(
                  "justify-start text-left font-normal min-w-[280px]",
                  !dateRange && "text-muted-foreground",
                )}
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {formatDateRange()}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="end">
              <div className="p-3 border-b">
                <div className="grid grid-cols-2 gap-2">
                  {presets.map((preset) => (
                    <Button
                      key={preset.label}
                      variant="ghost"
                      size="sm"
                      onClick={() => handlePresetSelect(preset)}
                      className="justify-start"
                    >
                      {preset.label}
                    </Button>
                  ))}
                </div>
              </div>
              <Calendar
                initialFocus
                mode="range"
                defaultMonth={dateRange?.from}
                selected={dateRange}
                onSelect={handleDateSelect}
                numberOfMonths={2}
                disabled={(date) => date > new Date()}
                locale={ptBR}
                classNames={{
                  months: "flex flex-col sm:flex-row space-y-4 sm:space-x-4 sm:space-y-0",
                  month: "space-y-4",
                  caption: "flex justify-center pt-1 relative items-center",
                  caption_label: "text-sm font-medium",
                  nav: "space-x-1 flex items-center",
                  nav_button: "h-7 w-7 bg-transparent p-0 opacity-50 hover:opacity-100",
                  nav_button_previous: "absolute left-1",
                  nav_button_next: "absolute right-1",
                  table: "w-full border-collapse space-y-1",
                  head_row: "flex",
                  head_cell: "text-muted-foreground rounded-md w-8 font-normal text-[0.8rem] text-center",
                  row: "flex w-full mt-2",
                  cell: "text-center text-sm p-0 relative [&:has([aria-selected])]:bg-accent first:[&:has([aria-selected])]:rounded-l-md last:[&:has([aria-selected])]:rounded-r-md focus-within:relative focus-within:z-20 w-8 h-8",
                  day: "h-8 w-8 p-0 font-normal aria-selected:opacity-100 hover:bg-accent hover:text-accent-foreground rounded-md",
                  day_selected:
                    "bg-primary text-primary-foreground hover:bg-primary hover:text-primary-foreground focus:bg-primary focus:text-primary-foreground",
                  day_today: "bg-accent text-accent-foreground",
                  day_outside: "text-muted-foreground opacity-50",
                  day_disabled: "text-muted-foreground opacity-50",
                  day_range_middle: "aria-selected:bg-accent aria-selected:text-accent-foreground",
                  day_hidden: "invisible",
                }}
              />
              <div className="p-3 border-t">
                <Button
                  onClick={() => setIsCalendarOpen(false)}
                  className="w-full"
                  disabled={!dateRange?.from || !dateRange?.to}
                >
                  Aplicar
                </Button>
              </div>
            </PopoverContent>
          </Popover>
        </div>
      </div>

      {/* Cards de estatísticas principais */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Agendamentos</CardTitle>
            <CalendarDays className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {loading ? (
              <Skeleton className="h-8 w-16" />
            ) : (
              <div className="text-2xl font-bold">{stats?.total || 0}</div>
            )}
          </CardContent>
        </Card>

        {/* Cards para cada status */}
        {Object.entries(statusConfig).map(([status, config]) => {
          const Icon = config.icon
          const value = (stats?.[status as keyof AppointmentStats] as number) || 0

          return (
            <Card key={status}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{config.label}</CardTitle>
                <Icon className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                {loading ? (
                  <Skeleton className="h-8 w-16" />
                ) : (
                  <div className="flex items-center gap-2">
                    <div className="text-2xl font-bold">{value}</div>
                    <Badge variant={config.variant} className="text-xs">
                      {stats?.total ? Math.round((value / stats.total) * 100) : 0}%
                    </Badge>
                  </div>
                )}
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Lista de agendamentos recentes */}
      {stats?.appointments && stats.appointments.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Agendamentos Recentes</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {stats.appointments.slice(0, 10).map((appointment) => {
                const config = statusConfig[appointment.status as keyof typeof statusConfig]
                const Icon = config?.icon || Clock

                return (
                  <div key={appointment.id} className="flex items-center justify-between p-2 rounded-lg border">
                    <div className="flex items-center gap-3">
                      <Icon className="h-4 w-4 text-muted-foreground" />
                      <div>
                        <p className="font-medium">{appointment.patient_name}</p>
                        <p className="text-sm text-muted-foreground">
                          {format(new Date(appointment.appointment_date), "dd/MM/yyyy HH:mm", { locale: ptBR })}
                        </p>
                      </div>
                    </div>
                    <Badge variant={config?.variant || "default"}>{config?.label || appointment.status}</Badge>
                  </div>
                )
              })}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
