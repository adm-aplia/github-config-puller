"use client"

import { useState, useEffect } from "react"
import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis, Tooltip } from "recharts"
import { Skeleton } from "@/components/ui/skeleton"

interface OverviewProps {
  data: any[]
}

export function Overview({ data = [] }: OverviewProps) {
  const [isLoading, setIsLoading] = useState(true)
  const [chartData, setChartData] = useState<any[]>([])

  useEffect(() => {
    // Se recebemos dados, não estamos mais carregando
    if (data && data.length > 0) {
      setChartData(data)
      setIsLoading(false)
    } else {
      // Se não temos dados, mostrar estado de carregamento
      setIsLoading(true)
    }
  }, [data])

  if (isLoading) {
    return (
      <div className="w-full h-[350px] flex items-center justify-center">
        <div className="w-full space-y-4">
          <Skeleton className="h-[300px] w-full" />
          <div className="flex justify-between">
            <Skeleton className="h-4 w-[100px]" />
            <Skeleton className="h-4 w-[100px]" />
            <Skeleton className="h-4 w-[100px]" />
          </div>
        </div>
      </div>
    )
  }

  return (
    <ResponsiveContainer width="100%" height={350}>
      <BarChart data={chartData}>
        <XAxis dataKey="date" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
        <YAxis stroke="#888888" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => `${value}`} />
        <Tooltip
          formatter={(value: number) => [`${value} conversas`, "Total"]}
          labelFormatter={(label) => `Data: ${label}`}
        />
        <Bar dataKey="conversations" fill="currentColor" radius={[4, 4, 0, 0]} className="fill-primary" />
      </BarChart>
    </ResponsiveContainer>
  )
}
