"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Loader2, Settings2 } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { DashboardSettingsService, type DashboardWidget } from "@/lib/services/dashboard-settings-service"
import { useToast } from "@/hooks/use-toast"

interface DashboardCustomizerProps {
  onSettingsChange: (settings: {
    visible_widgets: DashboardWidget[]
  }) => void
}

export function DashboardCustomizer({ onSettingsChange }: DashboardCustomizerProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [visibleWidgets, setVisibleWidgets] = useState<DashboardWidget[]>([])
  const { toast } = useToast()

  // Carregar configurações ao abrir o diálogo
  useEffect(() => {
    if (isOpen) {
      loadSettings()
    }
  }, [isOpen])

  const loadSettings = async () => {
    try {
      setIsLoading(true)
      const settings = await DashboardSettingsService.getUserDashboardSettings()
      setVisibleWidgets(settings.visible_widgets)
    } catch (error) {
      console.error("Erro ao carregar configurações:", error)
      toast({
        variant: "destructive",
        title: "Erro ao carregar configurações",
        description: "Não foi possível carregar as configurações do dashboard.",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Modificar a função handleSaveSettings para lidar com erros de tabela não existente
  const handleSaveSettings = async () => {
    try {
      setIsSaving(true)
      const settings = {
        visible_widgets: visibleWidgets,
      }

      // Tentar salvar as configurações
      const savedSettings = await DashboardSettingsService.updateDashboardSettings(settings)

      // Notificar o componente pai sobre as alterações
      onSettingsChange(settings)

      toast({
        title: "Configurações salvas",
        description: "As configurações do dashboard foram atualizadas com sucesso.",
      })

      setIsOpen(false)
    } catch (error: any) {
      console.error("Erro ao salvar configurações:", error)

      // Verificar se o erro é relacionado à tabela não existente
      if (error.message && (error.message.includes("does not exist") || error.message.includes("relation"))) {
        // Mesmo que não possamos salvar no banco, ainda podemos atualizar a interface
        onSettingsChange({
          visible_widgets: visibleWidgets,
        })

        toast({
          title: "Configurações aplicadas",
          description: "As configurações foram aplicadas, mas não puderam ser salvas permanentemente.",
        })

        setIsOpen(false)
      } else {
        toast({
          variant: "destructive",
          title: "Erro ao salvar configurações",
          description: "Não foi possível salvar as configurações do dashboard.",
        })
      }
    } finally {
      setIsSaving(false)
    }
  }

  const toggleWidget = (widget: DashboardWidget) => {
    setVisibleWidgets((prev) => {
      if (prev.includes(widget)) {
        return prev.filter((w) => w !== widget)
      } else {
        return [...prev, widget]
      }
    })
  }

  const widgetOptions = [
    { id: "recent_conversations", label: "Conversas Recentes" },
    { id: "whatsapp_status", label: "Status do WhatsApp" },
    { id: "appointment_calendar", label: "Calendário de Agendamentos" },
    { id: "appointment_stats", label: "Estatísticas de Agendamentos" },
  ]

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="gap-2 bg-transparent">
          <Settings2 className="h-4 w-4" />
          Personalizar Dashboard
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Personalizar Dashboard</DialogTitle>
          <DialogDescription>
            Escolha quais widgets deseja exibir e a visualização padrão do dashboard.
          </DialogDescription>
        </DialogHeader>

        {isLoading ? (
          <div className="flex justify-center items-center py-8">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        ) : (
          <>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <h4 className="font-medium">Widgets Visíveis</h4>
                <p className="text-sm text-muted-foreground">Selecione os widgets que deseja exibir no dashboard.</p>
                <div className="grid gap-2 pt-2">
                  {widgetOptions.map((option) => (
                    <div key={option.id} className="flex items-center space-x-2">
                      <Checkbox
                        id={option.id}
                        checked={visibleWidgets.includes(option.id as DashboardWidget)}
                        onCheckedChange={() => toggleWidget(option.id as DashboardWidget)}
                      />
                      <Label htmlFor={option.id}>{option.label}</Label>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setIsOpen(false)}>
                Cancelar
              </Button>
              <Button onClick={handleSaveSettings} disabled={isSaving}>
                {isSaving ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Salvando...
                  </>
                ) : (
                  "Salvar Alterações"
                )}
              </Button>
            </DialogFooter>
          </>
        )}
      </DialogContent>
    </Dialog>
  )
}
