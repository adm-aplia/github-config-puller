"use client"

import { useEffect, useState } from "react"
import { StatsService } from "@/lib/services/stats-service"
import { Loader2, MessageSquare, CheckCircle, XCircle } from "lucide-react"
import { useAuth } from "@/hooks/use-auth"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

export function WhatsAppStatus() {
  const [stats, setStats] = useState<{ total: number; connected: number; disconnected: number } | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const { isAuthenticated } = useAuth()

  useEffect(() => {
    async function loadStats() {
      try {
        setIsLoading(true)

        // Verificar se o usuário está autenticado antes de carregar os dados
        if (!isAuthenticated) {
          console.log("Usuário não autenticado, aguardando autenticação...")
          return
        }

        const dashboardStats = await StatsService.getDashboardStats()
        setStats({
          total: dashboardStats.instanceCount,
          connected: dashboardStats.connectedInstanceCount,
          disconnected: dashboardStats.instanceCount - dashboardStats.connectedInstanceCount,
        })
        setError(null)
      } catch (err) {
        console.error("Erro ao carregar estatísticas de WhatsApp:", err)
        setError("Não foi possível carregar as estatísticas de WhatsApp")
        // Definir dados vazios em caso de erro
        setStats({ total: 0, connected: 0, disconnected: 0 })
      } finally {
        setIsLoading(false)
      }
    }

    // Carregar dados iniciais
    loadStats()

    // Atualizar a cada 5 minutos em vez de a cada 10 segundos
    const interval = setInterval(() => {
      if (isAuthenticated) {
        loadStats()
      }
    }, 300000) // 5 minutos = 300000ms

    return () => clearInterval(interval)
  }, [isAuthenticated])

  if (isLoading) {
    return (
      <div className="flex justify-center py-4">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    )
  }

  if (error) {
    return <div className="text-sm text-muted-foreground py-2">{error}</div>
  }

  return (
    <TooltipProvider>
      <div className="grid grid-cols-3 gap-4 text-center">
        <div>
          <Tooltip>
            <TooltipTrigger asChild>
              <div className="cursor-help">
                <div className="text-2xl font-bold h-8 flex items-center justify-center gap-2">
                  <MessageSquare className="h-5 w-5 text-muted-foreground" />
                  {stats?.total || 0}
                </div>
                <div className="text-xs text-muted-foreground mt-1">Total</div>
              </div>
            </TooltipTrigger>
            <TooltipContent side="bottom" className="max-w-xs">
              <p>
                Número total de instâncias de WhatsApp configuradas. Cada instância representa uma conexão com o
                WhatsApp que pode ser vinculada a um perfil profissional.
              </p>
            </TooltipContent>
          </Tooltip>
        </div>
        <div>
          <Tooltip>
            <TooltipTrigger asChild>
              <div className="cursor-help">
                <div className="text-2xl font-bold text-aplia-coral h-8 flex items-center justify-center gap-2">
                  <CheckCircle className="h-5 w-5" />
                  {stats?.connected || 0}
                </div>
                <div className="text-xs text-muted-foreground mt-1">Conectadas</div>
              </div>
            </TooltipTrigger>
            <TooltipContent side="bottom" className="max-w-xs">
              <p>
                Instâncias atualmente conectadas ao WhatsApp e prontas para enviar/receber mensagens. Se uma instância
                estiver conectada, ela pode ser usada para comunicação com pacientes.
              </p>
            </TooltipContent>
          </Tooltip>
        </div>
        <div>
          <Tooltip>
            <TooltipTrigger asChild>
              <div className="cursor-help">
                <div className="text-2xl font-bold text-muted-foreground h-8 flex items-center justify-center gap-2">
                  <XCircle className="h-5 w-5" />
                  {stats?.disconnected || 0}
                </div>
                <div className="text-xs text-muted-foreground mt-1">Desconectadas</div>
              </div>
            </TooltipTrigger>
            <TooltipContent side="bottom" className="max-w-xs">
              <p>
                Instâncias que não estão conectadas ao WhatsApp. Para conectar uma instância, acesse a página de
                WhatsApp, escaneie o código QR e aguarde a confirmação de conexão.
              </p>
            </TooltipContent>
          </Tooltip>
        </div>
      </div>
    </TooltipProvider>
  )
}
