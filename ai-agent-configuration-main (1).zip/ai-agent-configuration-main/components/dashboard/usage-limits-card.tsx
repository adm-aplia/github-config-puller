"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { usePermissions } from "@/hooks/use-permissions"
import { Loader2, MessageSquare, Calendar, Bot, AlertTriangle } from "lucide-react"

export function UsageLimitsCard() {
  const { limits, usage, permissions, features, loading, error } = usePermissions()

  if (loading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center p-6">
          <Loader2 className="h-6 w-6 animate-spin" />
          <span className="ml-2">Carregando limites...</span>
        </CardContent>
      </Card>
    )
  }

  if (error || !limits || !usage) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center p-6">
          <AlertTriangle className="h-6 w-6 text-yellow-500" />
          <span className="ml-2">Erro ao carregar limites</span>
        </CardContent>
      </Card>
    )
  }

  const getProgressColor = (current: number, limit: number) => {
    if (limit === -1) return "bg-green-500" // Ilimitado
    const percentage = (current / limit) * 100
    if (percentage >= 90) return "bg-red-500"
    if (percentage >= 70) return "bg-yellow-500"
    return "bg-green-500"
  }

  const formatLimit = (limit: number) => {
    return limit === -1 ? "Ilimitado" : limit.toString()
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          Uso do Plano
          <Badge variant="outline">{limits.plano || "Básico"}</Badge>
        </CardTitle>
        <CardDescription>Acompanhe o uso dos recursos do seu plano</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* WhatsApp Instances */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <MessageSquare className="h-4 w-4 text-green-600" />
              <span className="text-sm font-medium">Instâncias WhatsApp</span>
            </div>
            <span className="text-sm text-muted-foreground">
              {usage.whatsapp_instances_used} / {formatLimit(limits.whatsapp_instances)}
            </span>
          </div>
          {limits.whatsapp_instances !== -1 && (
            <Progress value={(usage.whatsapp_instances_used / limits.whatsapp_instances) * 100} className="h-2" />
          )}
          {!permissions.canCreateWhatsApp.allowed && (
            <p className="text-xs text-red-600">{permissions.canCreateWhatsApp.reason}</p>
          )}
        </div>

        {/* Appointments */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Calendar className="h-4 w-4 text-blue-600" />
              <span className="text-sm font-medium">Agendamentos (mês)</span>
            </div>
            <span className="text-sm text-muted-foreground">
              {usage.appointments_this_month} / {formatLimit(limits.max_appointments)}
            </span>
          </div>
          {limits.max_appointments !== -1 && (
            <Progress value={(usage.appointments_this_month / limits.max_appointments) * 100} className="h-2" />
          )}
          {!permissions.canCreateAppointment.allowed && (
            <p className="text-xs text-red-600">{permissions.canCreateAppointment.reason}</p>
          )}
        </div>

        {/* Assistants */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Bot className="h-4 w-4 text-purple-600" />
              <span className="text-sm font-medium">Assistentes</span>
            </div>
            <span className="text-sm text-muted-foreground">
              {usage.assistants_created} / {formatLimit(limits.max_assistants)}
            </span>
          </div>
          {limits.max_assistants !== -1 && (
            <Progress value={(usage.assistants_created / limits.max_assistants) * 100} className="h-2" />
          )}
          {!permissions.canCreateAssistant.allowed && (
            <p className="text-xs text-red-600">{permissions.canCreateAssistant.reason}</p>
          )}
        </div>

        {/* Features */}
        <div className="pt-4 border-t">
          <h4 className="text-sm font-medium mb-3">Funcionalidades Disponíveis</h4>
          <div className="grid grid-cols-2 gap-2">
            <Badge variant={features.advanced_reports ? "default" : "secondary"}>Relatórios Avançados</Badge>
            <Badge variant={features.hospital_integration ? "default" : "secondary"}>Integração Hospitalar</Badge>
            <Badge variant={features.api_access ? "default" : "secondary"}>Acesso API</Badge>
            <Badge variant={features.priority_support ? "default" : "secondary"}>Suporte Prioritário</Badge>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
