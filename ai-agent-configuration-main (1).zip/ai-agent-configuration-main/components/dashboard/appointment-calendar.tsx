"use client"

import React from "react"

import { useState, useEffect } from "react"
import { ChevronLeft, ChevronRight, MoreHorizontal, Clock } from "lucide-react"
import {
  format,
  startOfMonth,
  endOfMonth,
  eachDayOfInterval,
  isSameMonth,
  isSameDay,
  addMonths,
  subMonths,
  startOfWeek,
  endOfWeek,
  addWeeks,
  subWeeks,
  addDays,
  subDays,
  isWithinInterval,
} from "date-fns"
import { ptBR } from "date-fns/locale"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Loader2 } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { cn } from "@/lib/utils"
import { useAuth } from "@/hooks/use-auth"
import { useRouter } from "next/navigation"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { useToast } from "@/hooks/use-toast"
import { RescheduleAppointmentModal } from "@/components/appointments/reschedule-appointment-modal"
import { EditAppointmentModal } from "@/components/appointments/edit-appointment-modal"

type AppointmentWithDetails = {
  id: string
  patient_name: string
  patient_phone: string | null
  appointment_date: string
  status: string
  notes: string | null
  agent_id?: string | null
  professional_profiles?: {
    id: string
    fullName: string
    specialty?: string
  } | null
  patient_email?: string | null
}

interface AppointmentCalendarProps {
  contactPhone?: string | null
  conversationId?: string | null
}

export function AppointmentCalendar({ contactPhone, conversationId }: AppointmentCalendarProps) {
  const router = useRouter()
  const [currentDate, setCurrentDate] = useState(new Date())
  const [view, setView] = useState<"month" | "week" | "day">("month")
  const [appointments, setAppointments] = useState<AppointmentWithDetails[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [selectedDate, setSelectedDate] = useState<Date | null>(null)
  const [selectedDateAppointments, setSelectedDateAppointments] = useState<AppointmentWithDetails[]>([])
  const [selectedProfessional, setSelectedProfessional] = useState<string>("")
  const [rescheduleModal, setRescheduleModal] = useState<{
    isOpen: boolean
    appointment: AppointmentWithDetails | null
  }>({ isOpen: false, appointment: null })
  const [editModal, setEditModal] = useState<{
    isOpen: boolean
    appointmentId: string | null
  }>({ isOpen: false, appointmentId: null })
  const { user, isAuthenticated } = useAuth()
  const { toast } = useToast()

  const [professionals, setProfessionals] = useState<{ id: string; name: string }[]>([
    { id: "all", name: "Todos os profissionais" },
  ])

  useEffect(() => {
    async function loadProfessionals() {
      if (!isAuthenticated) {
        console.log("Usuário não autenticado, não carregando profissionais")
        return
      }

      try {
        setProfessionals([{ id: "all", name: "Todos os profissionais" }])

        try {
          const { ProfileService } = await import("@/lib/services/profile-service")
          console.log("Buscando perfis profissionais para o calendário...")

          const profiles = await ProfileService.getAllProfessionalProfiles()
          console.log("Perfis encontrados para o calendário:", profiles)

          if (profiles && profiles.length > 0) {
            const profsData = profiles.map((profile) => ({
              id: profile.id,
              name: profile.fullName || "Profissional",
            }))
            setProfessionals([{ id: "all", name: "Todos os profissionais" }, ...profsData])
          }
        } catch (error) {
          console.error("Erro ao importar ou usar ProfileService:", error)
        }
      } catch (error) {
        console.error("Erro ao carregar profissionais:", error)
      }
    }

    if (isAuthenticated) {
      loadProfessionals()
    }
  }, [isAuthenticated])

  useEffect(() => {
    if (professionals.length > 0 && !selectedProfessional) {
      setSelectedProfessional("all")
    }
  }, [professionals, selectedProfessional])

  useEffect(() => {
    loadAppointments()
  }, [contactPhone, conversationId, isAuthenticated])

  useEffect(() => {
    if (selectedDate && appointments.length > 0) {
      const dateAppointments = appointments.filter((appointment) => {
        const appointmentDate = new Date(appointment.appointment_date)
        return isSameDay(appointmentDate, selectedDate)
      })

      const filteredAppointments =
        selectedProfessional && selectedProfessional !== "all"
          ? dateAppointments.filter((appointment) => appointment.agent_id === selectedProfessional)
          : dateAppointments

      setSelectedDateAppointments(filteredAppointments)
    } else {
      setSelectedDateAppointments([])
    }
  }, [selectedDate, appointments, selectedProfessional, professionals])

  const goToPrevious = () => {
    if (view === "month") {
      setCurrentDate(subMonths(currentDate, 1))
    } else if (view === "week") {
      setCurrentDate(subWeeks(currentDate, 1))
    } else if (view === "day") {
      setCurrentDate(subDays(currentDate, 1))
    }
  }

  const goToNext = () => {
    if (view === "month") {
      setCurrentDate(addMonths(currentDate, 1))
    } else if (view === "week") {
      setCurrentDate(addWeeks(currentDate, 1))
    } else if (view === "day") {
      setCurrentDate(addDays(currentDate, 1))
    }
  }

  const hasAppointments = (day: Date) => {
    return appointments.some((appointment) => {
      const appointmentDate = new Date(appointment.appointment_date)
      return isSameDay(appointmentDate, day)
    })
  }

  const countAppointments = (day: Date) => {
    return appointments.filter((appointment) => {
      const appointmentDate = new Date(appointment.appointment_date)
      return isSameDay(appointmentDate, day)
    }).length
  }

  const formatStatus = (status: string) => {
    switch (status) {
      case "scheduled":
        return "Agendado"
      case "completed":
        return "Concluído"
      case "cancelled":
        return "Cancelado"
      case "rescheduled":
        return "Remarcado"
      case "confirmed":
        return "Confirmado"
      case "no-show":
        return "Faltou"
      default:
        return status
    }
  }

  const getStatusVariant = (status: string) => {
    switch (status) {
      case "scheduled":
        return "default"
      case "completed":
        return "secondary"
      case "cancelled":
        return "destructive"
      case "rescheduled":
        return "secondary"
      case "confirmed":
        return "outline"
      case "no-show":
        return "destructive"
      default:
        return "secondary"
    }
  }

  const formatTime = (dateString: string) => {
    return format(new Date(dateString), "HH:mm", { locale: ptBR })
  }

  const viewAppointmentDetails = (appointmentId: string) => {
    router.push(`/dashboard/appointments/${appointmentId}`)
  }

  const editAppointment = (appointmentId: string) => {
    setEditModal({ isOpen: true, appointmentId })
  }

  const handleStatusUpdate = async (appointmentId: string, newStatus: string, appointmentName: string) => {
    try {
      console.log("=== INICIANDO ATUALIZAÇÃO DE STATUS ===")
      console.log("Appointment ID:", appointmentId)
      console.log("Novo Status:", newStatus)
      console.log("Nome do Paciente:", appointmentName)

      // Show loading toast
      toast({
        title: "Atualizando...",
        description: `Atualizando status do agendamento de ${appointmentName}...`,
      })

      const { AppointmentService } = await import("@/lib/services/appointment-service")

      // Update status
      const updatedAppointment = await AppointmentService.updateAppointmentStatus(appointmentId, newStatus)
      console.log("Agendamento atualizado:", updatedAppointment)

      // Force reload appointments to get fresh data
      await loadAppointments()

      // Also refresh the specific appointment to ensure UI sync
      try {
        const freshAppointment = await AppointmentService.refreshAppointment(appointmentId)
        console.log("Dados atualizados do agendamento:", freshAppointment)

        // Update the appointment in the local state
        setAppointments((prev) =>
          prev.map((apt) =>
            apt.id === appointmentId
              ? { ...apt, status: freshAppointment.status, updated_at: freshAppointment.updated_at }
              : apt,
          ),
        )
      } catch (refreshError) {
        console.warn("Erro ao recarregar agendamento específico:", refreshError)
      }

      toast({
        title: "Status atualizado",
        description: `Agendamento de ${appointmentName} foi ${getStatusText(newStatus)}.`,
      })

      console.log("=== ATUALIZAÇÃO CONCLUÍDA COM SUCESSO ===")
    } catch (error) {
      console.error("=== ERRO NA ATUALIZAÇÃO DE STATUS ===", error)
      toast({
        title: "Erro",
        description: "Não foi possível atualizar o status do agendamento. Tente novamente.",
        variant: "destructive",
      })
    }
  }

  const handleRescheduleAppointment = async (appointmentId: string, newDate: string) => {
    try {
      const { AppointmentService } = await import("@/lib/services/appointment-service")
      await AppointmentService.updateAppointment(appointmentId, {
        appointment_date: newDate,
        status: "rescheduled",
      })

      await loadAppointments()
    } catch (error) {
      console.error("Erro ao remarcar agendamento:", error)
      throw error
    }
  }

  const handleDeleteAppointment = async (appointmentId: string, appointmentName: string) => {
    try {
      const { AppointmentService } = await import("@/lib/services/appointment-service")
      await AppointmentService.deleteAppointment(appointmentId)

      await loadAppointments()

      toast({
        title: "Agendamento excluído",
        description: `Agendamento de ${appointmentName} foi excluído com sucesso.`,
      })
    } catch (error) {
      console.error("Erro ao excluir agendamento:", error)
      toast({
        title: "Erro",
        description: "Não foi possível excluir o agendamento.",
        variant: "destructive",
      })
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "confirmed":
        return "confirmado"
      case "completed":
        return "concluído"
      case "cancelled":
        return "cancelado"
      case "rescheduled":
        return "remarcado"
      case "no-show":
        return "marcado como falta"
      default:
        return "atualizado"
    }
  }

  const loadAppointments = async () => {
    if (!isAuthenticated) return

    try {
      setIsLoading(true)
      console.log("=== CARREGANDO AGENDAMENTOS ===")

      const { AppointmentService } = await import("@/lib/services/appointment-service")

      let appointmentsData = []
      if (contactPhone) {
        console.log("Carregando por telefone:", contactPhone)
        appointmentsData = await AppointmentService.getAppointmentsByContact(contactPhone)
      } else if (conversationId) {
        console.log("Carregando por conversa:", conversationId)
        appointmentsData = await AppointmentService.getAppointmentsByConversation(conversationId)
      } else {
        console.log("Carregando todos os agendamentos do usuário")
        appointmentsData = await AppointmentService.getUserAppointments()
      }

      console.log("Agendamentos carregados:", appointmentsData?.length || 0)

      const formattedAppointments = (appointmentsData || []).map((appointment) => ({
        id: appointment.id,
        patient_name: appointment.patient_name,
        patient_phone: appointment.patient_phone,
        appointment_date: appointment.appointment_date,
        status: appointment.status,
        notes: appointment.notes,
        agent_id: appointment.agent_id,
        professional_profiles: appointment.professional_profiles,
        patient_email: appointment.patient_email,
      }))

      console.log("Agendamentos formatados:", formattedAppointments)
      setAppointments(formattedAppointments)

      console.log("=== CARREGAMENTO CONCLUÍDO ===")
    } catch (error) {
      console.error("=== ERRO NO CARREGAMENTO ===", error)
      setError("Erro ao carregar agendamentos")
    } finally {
      setIsLoading(false)
    }
  }

  const renderAppointmentActions = (appointment: AppointmentWithDetails) => (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon">
          <MoreHorizontal className="h-4 w-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuItem onClick={() => viewAppointmentDetails(appointment.id)}>Ver Detalhes</DropdownMenuItem>
        <DropdownMenuItem onClick={() => editAppointment(appointment.id)}>Editar</DropdownMenuItem>

        {appointment.status !== "confirmed" && (
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <DropdownMenuItem onSelect={(e) => e.preventDefault()}>Confirmar</DropdownMenuItem>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Confirmar Agendamento</AlertDialogTitle>
                <AlertDialogDescription>
                  Tem certeza que deseja confirmar o agendamento de {appointment.patient_name}?
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancelar</AlertDialogCancel>
                <AlertDialogAction
                  onClick={() => handleStatusUpdate(appointment.id, "confirmed", appointment.patient_name)}
                >
                  Confirmar
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        )}

        {appointment.status !== "completed" && (
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <DropdownMenuItem onSelect={(e) => e.preventDefault()}>Marcar como Concluído</DropdownMenuItem>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Marcar como Concluído</AlertDialogTitle>
                <AlertDialogDescription>
                  Tem certeza que deseja marcar o agendamento de {appointment.patient_name} como concluído?
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancelar</AlertDialogCancel>
                <AlertDialogAction
                  onClick={() => handleStatusUpdate(appointment.id, "completed", appointment.patient_name)}
                >
                  Marcar como Concluído
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        )}

        <DropdownMenuItem onClick={() => setRescheduleModal({ isOpen: true, appointment })}>Remarcar</DropdownMenuItem>

        {appointment.status !== "cancelled" && (
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <DropdownMenuItem onSelect={(e) => e.preventDefault()}>Cancelar</DropdownMenuItem>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Cancelar Agendamento</AlertDialogTitle>
                <AlertDialogDescription>
                  Tem certeza que deseja cancelar o agendamento de {appointment.patient_name}?
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancelar</AlertDialogCancel>
                <AlertDialogAction
                  onClick={() => handleStatusUpdate(appointment.id, "cancelled", appointment.patient_name)}
                  className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                >
                  Cancelar Agendamento
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        )}

        {appointment.status !== "no-show" && (
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <DropdownMenuItem onSelect={(e) => e.preventDefault()}>Marcar Falta</DropdownMenuItem>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Marcar como Falta</AlertDialogTitle>
                <AlertDialogDescription>
                  Tem certeza que deseja marcar {appointment.patient_name} como falta?
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancelar</AlertDialogCancel>
                <AlertDialogAction
                  onClick={() => handleStatusUpdate(appointment.id, "no-show", appointment.patient_name)}
                  className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                >
                  Marcar Falta
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        )}

        <AlertDialog>
          <AlertDialogTrigger asChild>
            <DropdownMenuItem onSelect={(e) => e.preventDefault()}>Excluir</DropdownMenuItem>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Excluir Agendamento</AlertDialogTitle>
              <AlertDialogDescription>
                Tem certeza que deseja excluir permanentemente o agendamento de {appointment.patient_name}? Esta ação
                não pode ser desfeita.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancelar</AlertDialogCancel>
              <AlertDialogAction
                onClick={() => handleDeleteAppointment(appointment.id, appointment.patient_name)}
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              >
                Excluir
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </DropdownMenuContent>
    </DropdownMenu>
  )

  const renderMonthView = () => {
    const daysInMonth = eachDayOfInterval({
      start: startOfMonth(currentDate),
      end: endOfMonth(currentDate),
    })

    const weekDays = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"]

    return (
      <div className="space-y-4">
        <div className="text-center font-semibold text-lg mb-4">
          {format(currentDate, "MMMM 'de' yyyy", { locale: ptBR })}
        </div>
        <div className="grid grid-cols-7 gap-1">
          {weekDays.map((day) => (
            <div key={day} className="text-center text-sm font-medium py-2">
              {day}
            </div>
          ))}

          {daysInMonth.map((day) => {
            const isCurrentMonth = isSameMonth(day, currentDate)
            const isToday = isSameDay(day, new Date())
            const isSelected = selectedDate ? isSameDay(day, selectedDate) : false
            const dayHasAppointments = hasAppointments(day)
            const appointmentCount = countAppointments(day)

            return (
              <div
                key={day.toString()}
                className={cn(
                  "min-h-14 p-1 relative border border-border rounded-md cursor-pointer",
                  !isCurrentMonth && "opacity-50 bg-muted/20",
                  isToday && "border-primary",
                  isSelected && "bg-primary/10",
                  "hover:bg-accent",
                )}
                onClick={() => {
                  setSelectedDate(day)
                  if (!isSameMonth(day, currentDate)) {
                    setCurrentDate(day)
                  }
                }}
              >
                <div className="text-right text-sm p-1">{format(day, "d")}</div>

                {dayHasAppointments && (
                  <div className="absolute bottom-1 left-1 right-1">
                    <Badge variant="outline" className="w-full flex justify-center">
                      {appointmentCount} {appointmentCount === 1 ? "consulta" : "consultas"}
                    </Badge>
                  </div>
                )}
              </div>
            )
          })}
        </div>

        {selectedDate && (
          <div className="mt-6">
            <h3 className="font-medium mb-2">
              Agendamentos para {format(selectedDate, "dd 'de' MMMM", { locale: ptBR })}
            </h3>

            {selectedDateAppointments.length === 0 ? (
              <p className="text-sm text-muted-foreground">Nenhum agendamento para este dia.</p>
            ) : (
              <div className="space-y-2">
                {selectedDateAppointments.map((appointment) => (
                  <div key={appointment.id} className="flex items-center justify-between p-2 border rounded-md">
                    <div>
                      <div className="font-medium">{appointment.patient_name}</div>
                      <div className="text-sm text-muted-foreground">
                        {formatTime(appointment.appointment_date)} •
                        {appointment.professional_profiles?.fullName
                          ? ` ${appointment.professional_profiles.fullName}`
                          : " Sem médico atribuído"}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant={getStatusVariant(appointment.status)}>{formatStatus(appointment.status)}</Badge>
                      {renderAppointmentActions(appointment)}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    )
  }

  const renderWeekView = () => {
    const daysInWeek = eachDayOfInterval({
      start: startOfWeek(currentDate, { weekStartsOn: 0 }),
      end: endOfWeek(currentDate, { weekStartsOn: 0 }),
    })

    const timeSlots = Array.from({ length: 12 }, (_, i) => i + 8)

    return (
      <div className="space-y-4">
        <div className="text-center font-semibold text-lg mb-4">
          {format(currentDate, "MMMM 'de' yyyy", { locale: ptBR })}
        </div>
        <div className="grid grid-cols-8 gap-1">
          <div className="text-center text-sm font-medium py-2 border-b"></div>
          {daysInWeek.map((day) => (
            <div
              key={day.toString()}
              className={cn(
                "text-center text-sm font-medium py-2 border-b",
                isSameDay(day, new Date()) && "text-primary font-bold",
              )}
            >
              <div>{format(day, "EEE", { locale: ptBR })}</div>
              <div>{format(day, "dd/MM")}</div>
            </div>
          ))}

          {timeSlots.map((hour) => (
            <React.Fragment key={hour}>
              <div className="text-right text-xs pr-2 py-2 border-r">{`${hour}:00`}</div>

              {daysInWeek.map((day) => {
                const dayStart = new Date(day)
                dayStart.setHours(hour, 0, 0, 0)

                const dayEnd = new Date(day)
                dayEnd.setHours(hour, 59, 59, 999)

                const hourAppointments = appointments.filter((appointment) => {
                  const appointmentDate = new Date(appointment.appointment_date)
                  return isWithinInterval(appointmentDate, { start: dayStart, end: dayEnd })
                })

                return (
                  <div
                    key={day.toString() + hour}
                    className={cn(
                      "min-h-16 border border-dashed p-1 relative",
                      isSameDay(day, new Date()) && "bg-primary/5",
                    )}
                    onClick={() => {
                      const newDate = new Date(day)
                      newDate.setHours(hour, 0, 0, 0)
                      setSelectedDate(newDate)
                    }}
                  >
                    {hourAppointments.map((appointment) => (
                      <div
                        key={appointment.id}
                        className={cn(
                          "text-xs p-1 rounded mb-1 truncate cursor-pointer",
                          appointment.status === "scheduled" && "bg-primary/20",
                          appointment.status === "completed" && "bg-green-100",
                          appointment.status === "cancelled" && "bg-red-100",
                          appointment.status === "rescheduled" && "bg-amber-100",
                          appointment.status === "confirmed" && "bg-blue-100",
                        )}
                        onClick={(e) => {
                          e.stopPropagation()
                          viewAppointmentDetails(appointment.id)
                        }}
                      >
                        <div className="font-medium truncate">{appointment.patient_name}</div>
                        <div className="truncate">{formatTime(appointment.appointment_date)}</div>
                      </div>
                    ))}
                  </div>
                )
              })}
            </React.Fragment>
          ))}
        </div>
      </div>
    )
  }

  const renderDayView = () => {
    const timeSlots = Array.from({ length: 24 }, (_, i) => i)

    const dayAppointments = appointments.filter((appointment) => {
      const appointmentDate = new Date(appointment.appointment_date)
      return isSameDay(appointmentDate, currentDate)
    })

    const filteredAppointments =
      selectedProfessional && selectedProfessional !== "all"
        ? dayAppointments.filter((appointment) => appointment.agent_id === selectedProfessional)
        : dayAppointments

    return (
      <div className="space-y-4">
        <div className="text-center font-medium py-2">
          {format(currentDate, "EEEE, dd 'de' MMMM 'de' yyyy", { locale: ptBR })}
        </div>

        <div className="grid grid-cols-1 gap-1">
          {timeSlots
            .map((hour) => {
              const hourStart = new Date(currentDate)
              hourStart.setHours(hour, 0, 0, 0)

              const hourEnd = new Date(currentDate)
              hourEnd.setHours(hour, 59, 59, 999)

              const hourAppointments = filteredAppointments.filter((appointment) => {
                const appointmentDate = new Date(appointment.appointment_date)
                return isWithinInterval(appointmentDate, { start: hourStart, end: hourEnd })
              })

              if (hour < 7 || hour > 19) {
                if (hourAppointments.length === 0) {
                  return null
                }
              }

              return (
                <div key={hour} className="flex border-b last:border-b-0">
                  <div className="w-16 py-2 text-right pr-2 text-sm font-medium border-r">{`${hour}:00`}</div>

                  <div className="flex-1 min-h-16 p-1">
                    {hourAppointments.length === 0 ? (
                      <div className="h-full flex items-center justify-center text-xs text-muted-foreground">
                        Sem agendamentos
                      </div>
                    ) : (
                      <div className="space-y-2">
                        {hourAppointments.map((appointment) => (
                          <div
                            key={appointment.id}
                            className={cn(
                              "p-2 rounded flex items-center justify-between",
                              appointment.status === "scheduled" && "bg-primary/20",
                              appointment.status === "completed" && "bg-green-100",
                              appointment.status === "cancelled" && "bg-red-100",
                              appointment.status === "rescheduled" && "bg-amber-100",
                              appointment.status === "confirmed" && "bg-blue-100",
                            )}
                          >
                            <div className="flex items-center gap-2">
                              <Clock className="h-4 w-4 text-muted-foreground" />
                              <div>
                                <div className="font-medium">{appointment.patient_name}</div>
                                <div className="text-xs text-muted-foreground">
                                  {formatTime(appointment.appointment_date)}
                                  {appointment.professional_profiles &&
                                    ` • ${appointment.professional_profiles.fullName}`}
                                </div>
                              </div>
                            </div>

                            <div className="flex items-center gap-2">
                              <Badge variant={getStatusVariant(appointment.status)}>
                                {formatStatus(appointment.status)}
                              </Badge>
                              {renderAppointmentActions(appointment)}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )
            })
            .filter(Boolean)}
        </div>
      </div>
    )
  }

  if (isLoading) {
    return (
      <div className="flex justify-center items-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    )
  }

  if (error) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        <p>{error}</p>
        <Button onClick={loadAppointments} className="mt-4">
          Tentar Novamente
        </Button>
      </div>
    )
  }

  return (
    <>
      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <CardTitle>Calendário de Agendamentos</CardTitle>
              <CardDescription>
                {contactPhone
                  ? `Agendamentos para o contato: ${contactPhone}`
                  : "Visualize e gerencie todos os agendamentos"}
              </CardDescription>
            </div>

            <div className="flex flex-col sm:flex-row gap-2">
              {professionals.length > 0 && (
                <Select value={selectedProfessional} onValueChange={setSelectedProfessional}>
                  <SelectTrigger className="w-[200px]">
                    <SelectValue placeholder="Selecione o profissional" />
                  </SelectTrigger>
                  <SelectContent>
                    {professionals.map((professional) => (
                      <SelectItem key={professional.id} value={professional.id}>
                        {professional.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}

              <Select
                value={format(currentDate, "yyyy-MM")}
                onValueChange={(value) => {
                  const [year, month] = value.split("-")
                  const newDate = new Date(Number.parseInt(year), Number.parseInt(month) - 1, 1)
                  setCurrentDate(newDate)
                  setSelectedDate(newDate)
                }}
              >
                <SelectTrigger className="w-[150px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Array.from({ length: 12 }, (_, i) => {
                    const date = new Date()
                    date.setMonth(i)
                    const value = format(date, "yyyy-MM")
                    const label = format(date, "MMMM", { locale: ptBR })
                    return (
                      <SelectItem key={value} value={value}>
                        {label}
                      </SelectItem>
                    )
                  })}
                </SelectContent>
              </Select>

              <div className="flex items-center gap-1">
                <Button variant="outline" size="icon" onClick={goToPrevious}>
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    const today = new Date()
                    setCurrentDate(today)
                    setSelectedDate(today)
                  }}
                  className="whitespace-nowrap"
                >
                  Mês Atual
                </Button>
                <Button variant="outline" size="icon" onClick={goToNext}>
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>

          <Tabs value={view} onValueChange={(value) => setView(value as "month" | "week" | "day")} className="mt-2">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="month">Mês</TabsTrigger>
              <TabsTrigger value="week">Semana</TabsTrigger>
              <TabsTrigger value="day">Dia</TabsTrigger>
            </TabsList>
          </Tabs>
        </CardHeader>
        <CardContent>
          {view === "month" && renderMonthView()}
          {view === "week" && renderWeekView()}
          {view === "day" && renderDayView()}
        </CardContent>
      </Card>

      {/* Modal de Remarcação */}
      {rescheduleModal.appointment && (
        <RescheduleAppointmentModal
          isOpen={rescheduleModal.isOpen}
          onClose={() => setRescheduleModal({ isOpen: false, appointment: null })}
          appointment={rescheduleModal.appointment}
          onReschedule={handleRescheduleAppointment}
        />
      )}

      {/* Modal de Edição */}
      <EditAppointmentModal
        appointmentId={editModal.appointmentId}
        isOpen={editModal.isOpen}
        onClose={() => setEditModal({ isOpen: false, appointmentId: null })}
        onAppointmentUpdated={loadAppointments}
      />
    </>
  )
}
