"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { TrendingUp, TrendingDown, Minus } from "lucide-react"

interface Metric {
  label: string
  value: number
  target: number
  unit?: string
  trend: "up" | "down" | "stable"
  trendValue: number
}

export function DashboardMetrics() {
  const [metrics, setMetrics] = useState<Metric[]>([
    {
      label: "Taxa de Resposta",
      value: 92,
      target: 95,
      unit: "%",
      trend: "up",
      trendValue: 3.2,
    },
    {
      label: "Tempo Médio de Resposta",
      value: 2.5,
      target: 2,
      unit: "min",
      trend: "down",
      trendValue: -15,
    },
    {
      label: "Satisfação do Paciente",
      value: 4.7,
      target: 5,
      unit: "/5",
      trend: "up",
      trendValue: 5.8,
    },
    {
      label: "Agendamentos Confirmados",
      value: 87,
      target: 90,
      unit: "%",
      trend: "stable",
      trendValue: 0.1,
    },
  ])

  const getTrendIcon = (trend: "up" | "down" | "stable") => {
    switch (trend) {
      case "up":
        return <TrendingUp className="h-4 w-4 text-aplia-coral" />
      case "down":
        return <TrendingDown className="h-4 w-4 text-aplia-blue" />
      case "stable":
        return <Minus className="h-4 w-4 text-muted-foreground" />
    }
  }

  const getProgressColor = (value: number, target: number) => {
    const percentage = (value / target) * 100
    if (percentage >= 90) return "bg-aplia-coral"
    if (percentage >= 70) return "bg-aplia-gray"
    return "bg-aplia-blue"
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Métricas de Desempenho</CardTitle>
        <CardDescription>Acompanhe os principais indicadores da plataforma</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {metrics.map((metric, index) => (
            <div key={index} className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium">{metric.label}</span>
                  <Badge variant="outline" className="text-xs">
                    Meta: {metric.target}
                    {metric.unit}
                  </Badge>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-2xl font-bold h-8 flex items-center">
                    {metric.value}
                    {metric.unit}
                  </span>
                  <div className="flex items-center gap-1">
                    {getTrendIcon(metric.trend)}
                    <span
                      className={`text-xs ${
                        metric.trend === "up"
                          ? "text-aplia-coral"
                          : metric.trend === "down"
                            ? "text-aplia-blue"
                            : "text-muted-foreground"
                      }`}
                    >
                      {Math.abs(metric.trendValue)}%
                    </span>
                  </div>
                </div>
              </div>
              <Progress
                value={(metric.value / metric.target) * 100}
                className="h-2"
                indicatorClassName={getProgressColor(metric.value, metric.target)}
              />
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
