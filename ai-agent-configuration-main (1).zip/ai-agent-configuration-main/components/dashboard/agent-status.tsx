"use client"

import { useEffect, useState } from "react"
import { Loader2, Users, UserCheck, UserX } from "lucide-react"
import { useAuth } from "@/hooks/use-auth"
import { getSupabaseBrowserClient } from "@/lib/supabase"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

export function AgentStatus() {
  const [profileStats, setProfileStats] = useState<{ total: number; active: number; inactive: number } | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const { isAuthenticated } = useAuth()

  useEffect(() => {
    async function loadProfileStats() {
      try {
        setIsLoading(true)

        // Verificar se o usuário está autenticado antes de carregar os dados
        if (!isAuthenticated) {
          console.log("Usuário não autenticado, aguardando autenticação...")
          return
        }

        const supabase = getSupabaseBrowserClient()

        // Obter o usuário atual
        const {
          data: { user },
        } = await supabase.auth.getUser()

        if (!user) {
          throw new Error("Usuário não autenticado")
        }

        // Buscar perfis profissionais diretamente da tabela
        const { data: profiles, error: profilesError } = await supabase
          .from("professional_profiles")
          .select("*")
          .eq("user_id", user.id)

        if (profilesError) {
          throw profilesError
        }

        // Buscar instâncias do WhatsApp para verificar perfis vinculados
        const { data: whatsappInstances, error: instancesError } = await supabase
          .from("whatsapp_instances")
          .select("professional_profile_id")
          .eq("user_id", user.id)

        if (instancesError) {
          throw instancesError
        }

        // Obter IDs de perfis vinculados a instâncias WhatsApp
        const linkedProfileIds = whatsappInstances
          .filter((instance) => instance.professional_profile_id)
          .map((instance) => instance.professional_profile_id)

        // Calcular estatísticas
        const total = profiles?.length || 0

        // Considerar um perfil como ativo se tiver status="active" OU estiver vinculado a uma instância WhatsApp
        const active = profiles?.filter((p) => p.status === "active" || linkedProfileIds.includes(p.id)).length || 0

        const inactive = total - active

        setProfileStats({
          total,
          active,
          inactive,
        })

        setError(null)
      } catch (err) {
        console.error("Erro ao carregar estatísticas de perfis:", err)
        setError("Não foi possível carregar as estatísticas de perfis")
        // Definir dados vazios em caso de erro
        setProfileStats({ total: 0, active: 0, inactive: 0 })
      } finally {
        setIsLoading(false)
      }
    }

    // Carregar dados iniciais
    loadProfileStats()

    // Atualizar a cada 5 minutos
    const interval = setInterval(() => {
      if (isAuthenticated) {
        loadProfileStats()
      }
    }, 300000) // 5 minutos = 300000ms

    return () => clearInterval(interval)
  }, [isAuthenticated])

  if (isLoading) {
    return (
      <div className="flex justify-center py-4">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    )
  }

  if (error) {
    return <div className="text-sm text-muted-foreground py-2">{error}</div>
  }

  return (
    <TooltipProvider>
      <div className="grid grid-cols-3 gap-4 text-center">
        <div>
          <Tooltip>
            <TooltipTrigger asChild>
              <div className="cursor-help">
                <div className="text-2xl font-bold h-8 flex items-center justify-center gap-2">
                  <Users className="h-5 w-5 text-muted-foreground" />
                  {profileStats?.total || 0}
                </div>
                <div className="text-xs text-muted-foreground mt-1">Total</div>
              </div>
            </TooltipTrigger>
            <TooltipContent side="bottom" className="max-w-xs">
              <p>Número total de perfis profissionais cadastrados na sua conta.</p>
            </TooltipContent>
          </Tooltip>
        </div>
        <div>
          <Tooltip>
            <TooltipTrigger asChild>
              <div className="cursor-help">
                <div className="text-2xl font-bold text-aplia-coral h-8 flex items-center justify-center gap-2">
                  <UserCheck className="h-5 w-5" />
                  {profileStats?.active || 0}
                </div>
                <div className="text-xs text-muted-foreground mt-1">Ativos</div>
              </div>
            </TooltipTrigger>
            <TooltipContent side="bottom" className="max-w-xs">
              <p>
                Perfis ativos que podem receber mensagens. Um perfil é considerado ativo quando está com status "ativo"
                ou está vinculado a uma instância de WhatsApp.
              </p>
            </TooltipContent>
          </Tooltip>
        </div>
        <div>
          <Tooltip>
            <TooltipTrigger asChild>
              <div className="cursor-help">
                <div className="text-2xl font-bold text-muted-foreground h-8 flex items-center justify-center gap-2">
                  <UserX className="h-5 w-5" />
                  {profileStats?.inactive || 0}
                </div>
                <div className="text-xs text-muted-foreground mt-1">Inativos</div>
              </div>
            </TooltipTrigger>
            <TooltipContent side="bottom" className="max-w-xs">
              <p>
                Perfis inativos que não estão recebendo mensagens. Para ativar um perfil, acesse a página de perfis e
                altere seu status ou vincule-o a uma instância de WhatsApp.
              </p>
            </TooltipContent>
          </Tooltip>
        </div>
      </div>
    </TooltipProvider>
  )
}
