"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { MessageSquarePlus, UserPlus, Calendar, FileText, Settings, BarChart3 } from "lucide-react"
import { useRouter } from "next/navigation"

export function QuickActions() {
  const router = useRouter()

  const actions = [
    {
      title: "Nova Conversa",
      description: "Iniciar uma nova conversa",
      icon: MessageSquarePlus,
      href: "/dashboard/conversations/new",
      color: "text-aplia-blue",
    },
    {
      title: "Criar Perfil",
      description: "Adicionar novo perfil profissional",
      icon: UserPlus,
      href: "/dashboard/profiles/new",
      color: "text-aplia-coral",
    },
    {
      title: "Agendar Consulta",
      description: "Criar novo agendamento",
      icon: Calendar,
      href: "/dashboard/appointments/new",
      color: "text-aplia-blue",
    },
    {
      title: "Relatórios",
      description: "Visualizar relatórios",
      icon: BarChart3,
      href: "/dashboard/reports",
      color: "text-aplia-coral",
    },
    {
      title: "Prompts",
      description: "Gerenciar prompts de IA",
      icon: FileText,
      href: "/dashboard/prompts",
      color: "text-aplia-coral",
    },
    {
      title: "Configurações",
      description: "Ajustar configurações",
      icon: Settings,
      href: "/dashboard/configuracoes",
      color: "text-muted-foreground",
    },
  ]

  return (
    <Card>
      <CardHeader>
        <CardTitle>Ações Rápidas</CardTitle>
        <CardDescription>Acesse rapidamente as principais funcionalidades</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {actions.map((action, index) => {
            const Icon = action.icon
            return (
              <Button
                key={index}
                variant="outline"
                className="h-auto flex flex-col items-center justify-center p-4 space-y-2 hover:shadow-md transition-shadow"
                onClick={() => router.push(action.href)}
              >
                <Icon className={`h-8 w-8 ${action.color}`} />
                <div className="text-center">
                  <div className="font-medium text-sm">{action.title}</div>
                  <div className="text-xs text-muted-foreground">{action.description}</div>
                </div>
              </Button>
            )
          })}
        </div>
      </CardContent>
    </Card>
  )
}
