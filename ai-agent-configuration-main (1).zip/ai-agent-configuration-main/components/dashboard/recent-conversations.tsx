"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { formatDistanceToNow } from "date-fns"
import { ptBR } from "date-fns/locale"
import { MessageSquare } from "lucide-react"
import { Skeleton } from "@/components/ui/skeleton"
import { useAuth } from "@/components/auth-provider"
import { supabase } from "@/lib/supabase"

type Conversation = {
  id: string
  title: string
  last_message: string
  created_at: string
  updated_at: string
}

export function RecentConversations() {
  const [conversations, setConversations] = useState<Conversation[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const { isAuthenticated, user } = useAuth()

  useEffect(() => {
    async function fetchConversations() {
      // Só buscar conversas se o usuário estiver autenticado
      if (!isAuthenticated || !user) {
        setIsLoading(false)
        return
      }

      try {
        setIsLoading(true)
        setError(null)

        const { data, error } = await supabase
          .from("conversations")
          .select("*")
          .order("updated_at", { ascending: false })
          .limit(5)

        if (error) {
          throw new Error(error.message)
        }

        setConversations(data || [])
      } catch (err: any) {
        console.error("Erro ao buscar conversas recentes:", err.message)
        setError("Não foi possível carregar as conversas recentes.")
      } finally {
        setIsLoading(false)
      }
    }

    // Só buscar dados se o usuário estiver autenticado
    if (isAuthenticated) {
      fetchConversations()
    } else {
      setIsLoading(false)
    }
  }, [isAuthenticated, user])

  function formatDate(dateString: string) {
    try {
      return formatDistanceToNow(new Date(dateString), {
        addSuffix: true,
        locale: ptBR,
      })
    } catch (error) {
      return "Data inválida"
    }
  }

  return (
    <>
      {isLoading ? (
        <div className="space-y-4">
          {Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="flex items-start space-x-4">
              <Skeleton className="h-10 w-10 rounded-full" />
              <div className="space-y-2 flex-1">
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-3 w-full" />
              </div>
            </div>
          ))}
        </div>
      ) : error ? (
        <div className="text-center py-6">
          <p className="text-muted-foreground">{error}</p>
        </div>
      ) : conversations.length === 0 ? (
        <div className="text-center py-6">
          <MessageSquare className="mx-auto h-8 w-8 text-muted-foreground mb-2" />
          <p className="text-muted-foreground">Nenhuma conversa recente</p>
        </div>
      ) : (
        <div className="space-y-4">
          {conversations.map((conversation) => (
            <Link
              key={conversation.id}
              href={`/dashboard/conversations/${conversation.id}`}
              className="flex items-start space-x-4 rounded-lg p-3 transition-colors hover:bg-muted"
            >
              <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                <MessageSquare className="h-5 w-5 text-primary" />
              </div>
              <div className="space-y-1 flex-1">
                <p className="font-medium leading-none">{conversation.title || "Conversa sem título"}</p>
                <p className="text-sm text-muted-foreground line-clamp-1">
                  {conversation.last_message || "Nenhuma mensagem"}
                </p>
                <p className="text-xs text-muted-foreground">{formatDate(conversation.updated_at)}</p>
              </div>
            </Link>
          ))}
        </div>
      )}
    </>
  )
}
