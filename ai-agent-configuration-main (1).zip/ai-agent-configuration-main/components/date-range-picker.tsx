"use client"

import * as React from "react"
import { format, addMonths, subMonths, startOfDay, endOfDay, subDays, startOfMonth, endOfMonth } from "date-fns"
import { ptBR } from "date-fns/locale"
import { CalendarIcon, ChevronLeft, ChevronRight } from "lucide-react"
import type { DateRange } from "react-day-picker"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"

interface DateRangePickerProps extends React.HTMLAttributes<HTMLDivElement> {
  onDateChange?: (dateRange: DateRange | undefined) => void
}

export function DateRangePicker({ className, onDateChange }: DateRangePickerProps) {
  const [date, setDate] = React.useState<DateRange | undefined>({
    from: subDays(new Date(), 7),
    to: new Date(),
  })
  const [isOpen, setIsOpen] = React.useState(false)
  const [currentMonth, setCurrentMonth] = React.useState(new Date())

  const handleDateSelect = (selectedDate: DateRange | undefined) => {
    if (selectedDate?.from && selectedDate?.to) {
      // Se um range completo foi selecionado, aplicar
      setDate(selectedDate)
      onDateChange?.(selectedDate)
      setIsOpen(false)
    } else if (selectedDate?.from && !selectedDate?.to) {
      // Se apenas uma data foi selecionada, manter o popover aberto para permitir seleção da segunda data
      setDate(selectedDate)
      // Não fechar o popover nem chamar onDateChange ainda
    } else {
      // Se nenhuma data foi selecionada (reset), limpar
      setDate(undefined)
    }
  }

  const handlePresetSelect = (preset: DateRange) => {
    setDate(preset)
    onDateChange?.(preset)
    setIsOpen(false)
  }

  const presets = [
    {
      label: "Hoje",
      range: {
        from: startOfDay(new Date()),
        to: endOfDay(new Date()),
      },
    },
    {
      label: "Últimos 7 dias",
      range: {
        from: subDays(new Date(), 6),
        to: new Date(),
      },
    },
    {
      label: "Últimos 30 dias",
      range: {
        from: subDays(new Date(), 29),
        to: new Date(),
      },
    },
    {
      label: "Mês atual",
      range: {
        from: startOfMonth(new Date()),
        to: endOfMonth(new Date()),
      },
    },
    {
      label: "Mês passado",
      range: {
        from: startOfMonth(subMonths(new Date(), 1)),
        to: endOfMonth(subMonths(new Date(), 1)),
      },
    },
  ]

  const navigateMonth = (direction: "prev" | "next") => {
    setCurrentMonth((prev) => (direction === "prev" ? subMonths(prev, 1) : addMonths(prev, 1)))
  }

  return (
    <div className={cn("grid gap-2", className)}>
      <Popover open={isOpen} onOpenChange={setIsOpen}>
        <PopoverTrigger asChild>
          <Button
            id="date"
            variant={"outline"}
            className={cn("w-[300px] justify-start text-left font-normal", !date && "text-muted-foreground")}
          >
            <CalendarIcon className="mr-2 h-4 w-4" />
            {date?.from ? (
              date.to && date.from.getTime() !== date.to.getTime() ? (
                <>
                  {format(date.from, "dd 'de' MMM 'de' yyyy", { locale: ptBR })} -{" "}
                  {format(date.to, "dd 'de' MMM 'de' yyyy", { locale: ptBR })}
                </>
              ) : (
                format(date.from, "dd 'de' MMM 'de' yyyy", { locale: ptBR })
              )
            ) : (
              <span>Selecione uma data</span>
            )}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0" align="start">
          <div className="flex">
            {/* Sidebar com presets */}
            <div className="border-r p-3 space-y-1 min-w-[140px]">
              {presets.map((preset) => (
                <Button
                  key={preset.label}
                  variant="ghost"
                  size="sm"
                  className="w-full justify-start text-sm font-normal"
                  onClick={() => handlePresetSelect(preset.range)}
                >
                  {preset.label}
                </Button>
              ))}
            </div>
            {/* Calendar com navegação customizada */}
            <div className="p-3 relative">
              {/* Header com navegação */}
              <div className="flex items-center justify-center mb-4 relative">
                <Button
                  variant="outline"
                  size="icon"
                  className="h-7 w-7 bg-transparent absolute left-0"
                  onClick={() => navigateMonth("prev")}
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <div className="font-medium">{format(currentMonth, "MMMM yyyy", { locale: ptBR })}</div>
                <Button
                  variant="outline"
                  size="icon"
                  className="h-7 w-7 bg-transparent absolute right-0"
                  onClick={() => navigateMonth("next")}
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
              {/* Calendar */}
              <Calendar
                mode="range"
                defaultMonth={currentMonth}
                month={currentMonth}
                selected={date}
                onSelect={handleDateSelect}
                numberOfMonths={1}
                locale={ptBR}
                className="rounded-md border-0"
              />
            </div>
          </div>
        </PopoverContent>
      </Popover>
    </div>
  )
}
