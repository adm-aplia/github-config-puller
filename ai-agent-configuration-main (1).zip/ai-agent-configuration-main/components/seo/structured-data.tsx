interface StructuredDataProps {
  type: "WebPage" | "Organization" | "MedicalOrganization" | "SoftwareApplication"
  data: Record<string, any>
}

export function StructuredData({ type, data }: StructuredDataProps) {
  const structuredData = {
    "@context": "https://schema.org",
    "@type": type,
    ...data,
  }

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{
        __html: JSON.stringify(structuredData),
      }}
    />
  )
}

// Componentes específicos para diferentes tipos de páginas
export function MedicalOrganizationSchema() {
  return (
    <StructuredData
      type="MedicalOrganization"
      data={{
        name: "Aplia",
        description: "Plataforma de saúde com inteligência artificial para gestão médica",
        url: process.env.NEXT_PUBLIC_APP_URL,
        logo: `${process.env.NEXT_PUBLIC_APP_URL}/Aplia_logotipo_variação cor 2 fundo transparente.png`,
        medicalSpecialty: ["Telemedicina", "Gestão Hospitalar", "Prontuário Eletrônico", "Agendamento Médico"],
        availableService: [
          {
            "@type": "MedicalService",
            name: "Agendamento de Consultas",
            description: "Sistema inteligente de agendamento médico",
          },
          {
            "@type": "MedicalService",
            name: "Gestão de Prontuários",
            description: "Prontuário eletrônico com IA",
          },
        ],
      }}
    />
  )
}

export function SoftwareApplicationSchema() {
  return (
    <StructuredData
      type="SoftwareApplication"
      data={{
        name: "Aplia",
        description: "Plataforma de saúde com inteligência artificial",
        url: process.env.NEXT_PUBLIC_APP_URL,
        applicationCategory: "HealthApplication",
        operatingSystem: "Web Browser",
        offers: {
          "@type": "Offer",
          price: "0",
          priceCurrency: "BRL",
        },
        aggregateRating: {
          "@type": "AggregateRating",
          ratingValue: "4.8",
          ratingCount: "150",
        },
      }}
    />
  )
}
