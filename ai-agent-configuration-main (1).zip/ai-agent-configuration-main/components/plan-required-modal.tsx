"use client"
import { useRouter } from "next/navigation"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { AlertTriangle, CreditCard } from "lucide-react"

interface PlanRequiredModalProps {
  isOpen: boolean
  onClose: () => void
  message?: string
}

export function PlanRequiredModal({ isOpen, onClose, message }: PlanRequiredModalProps) {
  const router = useRouter()

  const handleGoToPlans = () => {
    onClose()
    router.push("/dashboard/planos")
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <div className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-red-500" />
            <DialogTitle>Plano Ativo Necessário</DialogTitle>
          </div>
          <DialogDescription>
            {message || "Você precisa de um plano ativo para usar esta funcionalidade."}
          </DialogDescription>
        </DialogHeader>

        <div className="flex flex-col items-center gap-4 py-4">
          <CreditCard className="h-12 w-12 text-muted-foreground" />
          <div className="text-center">
            <p className="text-sm text-muted-foreground">
              Escolha um plano que atenda às suas necessidades e comece a usar todas as funcionalidades da plataforma.
            </p>
          </div>
        </div>

        <DialogFooter className="flex gap-2">
          <Button variant="outline" onClick={onClose}>
            Fechar
          </Button>
          <Button onClick={handleGoToPlans} className="bg-red-500 hover:bg-red-600">
            Ver Planos
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
