"use client"

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Check, Crown, Zap } from "lucide-react"
import { useRouter } from "next/navigation"

interface UpgradePlanModalProps {
  isOpen: boolean
  onClose: () => void
  feature: string
}

export function UpgradePlanModal({ isOpen, onClose, feature }: UpgradePlanModalProps) {
  const router = useRouter()

  const handleUpgrade = () => {
    onClose()
    router.push("/dashboard/planos")
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-center">
            <Crown className="h-5 w-5 text-yellow-500" />
            Upgrade Necessário
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <Card className="border-yellow-200 bg-yellow-50 dark:bg-yellow-950 dark:border-yellow-800">
            <CardHeader className="text-center pb-2">
              <CardTitle className="text-lg flex items-center justify-center gap-2">
                <Zap className="h-5 w-5 text-yellow-600" />
                Teste Gratuito por 7 dias
              </CardTitle>
              <CardDescription>Para {feature}, você precisa de um plano pago</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm">
                  <Check className="h-4 w-4 text-green-600" />
                  <span>Acesso completo por 7 dias</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Check className="h-4 w-4 text-green-600" />
                  <span>Todos os recursos liberados</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Check className="h-4 w-4 text-green-600" />
                  <span>Cancele a qualquer momento</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="flex gap-2">
            <Button variant="outline" onClick={onClose} className="flex-1 bg-transparent">
              Cancelar
            </Button>
            <Button onClick={handleUpgrade} className="flex-1">
              Escolher Plano
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
