"use client"

import { Card, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Check, X } from "lucide-react"

const features = [
  { key: "whatsapp_instances", label: "Números WhatsApp", basic: "1", pro: "3", enterprise: "10+" },
  { key: "max_appointments", label: "Agendamentos/mês", basic: "300", pro: "1.000", enterprise: "Ilimitado" },
  { key: "assistants", label: "Assistentes IA", basic: "1", pro: "3", enterprise: "Ilimitado" },
  { key: "support", label: "Suporte", basic: "E-mail", pro: "Prioritário", enterprise: "24/7" },
  { key: "reports", label: "Relatórios avançados", basic: false, pro: true, enterprise: true },
  { key: "api", label: "Acesso à API", basic: false, pro: true, enterprise: true },
  { key: "integration", label: "Integração hospitalar", basic: false, pro: false, enterprise: true },
  { key: "branding", label: "Marca personalizada", basic: false, pro: false, enterprise: true },
  { key: "customization", label: "Personalização avançada", basic: false, pro: false, enterprise: true },
]

export function PlansComparison() {
  const renderFeatureValue = (value: string | boolean) => {
    if (typeof value === "boolean") {
      return value ? (
        <Check className="h-5 w-5 text-green-500 mx-auto" />
      ) : (
        <X className="h-5 w-5 text-gray-300 mx-auto" />
      )
    }
    return <span className="text-sm font-medium">{value}</span>
  }

  return (
    <div className="w-full overflow-x-auto">
      <div className="min-w-[800px]">
        <div className="grid grid-cols-4 gap-4">
          {/* Header */}
          <div className="p-4">
            <h3 className="font-semibold text-lg">Recursos</h3>
          </div>

          <Card>
            <CardHeader className="text-center pb-2">
              <CardTitle className="text-lg">Básico</CardTitle>
              <div className="text-2xl font-bold">R$ 199</div>
              <div className="text-sm text-muted-foreground">/mês</div>
            </CardHeader>
          </Card>

          <Card className="border-blue-500 shadow-lg">
            <CardHeader className="text-center pb-2">
              <Badge className="mb-2 bg-blue-500">Mais Popular</Badge>
              <CardTitle className="text-lg">Profissional</CardTitle>
              <div className="text-2xl font-bold">R$ 399</div>
              <div className="text-sm text-muted-foreground">/mês</div>
            </CardHeader>
          </Card>

          <Card>
            <CardHeader className="text-center pb-2">
              <CardTitle className="text-lg">Empresarial</CardTitle>
              <div className="text-2xl font-bold">R$ 899</div>
              <div className="text-sm text-muted-foreground">/mês</div>
            </CardHeader>
          </Card>

          {/* Features */}
          {features.map((feature, index) => (
            <div key={feature.key} className="contents">
              <div className={`p-4 flex items-center ${index % 2 === 0 ? "bg-gray-50" : ""}`}>
                <span className="font-medium">{feature.label}</span>
              </div>

              <div
                className={`p-4 text-center flex items-center justify-center ${index % 2 === 0 ? "bg-gray-50" : ""}`}
              >
                {renderFeatureValue(feature.basic)}
              </div>

              <div
                className={`p-4 text-center flex items-center justify-center ${index % 2 === 0 ? "bg-gray-50" : ""}`}
              >
                {renderFeatureValue(feature.pro)}
              </div>

              <div
                className={`p-4 text-center flex items-center justify-center ${index % 2 === 0 ? "bg-gray-50" : ""}`}
              >
                {renderFeatureValue(feature.enterprise)}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
