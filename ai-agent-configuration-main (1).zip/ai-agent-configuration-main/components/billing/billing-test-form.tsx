"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { CheckCircle, AlertCircle, Loader2 } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

interface FormData {
  nome: string
  email: string
  telefone: string
  documento: string
  plano: string
  user_id: string
}

interface BillingResult {
  success: boolean
  message: string
  data?: {
    cliente: {
      id: string
      nome: string
      email: string
      plano: string
      status: string
      user_id?: string
    }
    cobranca: {
      id: string
      valor: number
      status: string
      descricao: string
      dueDate: string
      paymentLink: string
    }
  }
  error?: string
}

export function BillingTestForm() {
  const [formData, setFormData] = useState<FormData>({
    nome: "",
    email: "",
    telefone: "",
    documento: "",
    plano: "Básico",
    user_id: "",
  })

  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<BillingResult | null>(null)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (value: string) => {
    setFormData((prev) => ({ ...prev, plano: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setResult(null)

    try {
      const response = await fetch("/api/billing/process", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      })

      const data = await response.json()
      setResult(data)
    } catch (error) {
      setResult({
        success: false,
        message: "Erro ao processar requisição",
        error: error instanceof Error ? error.message : "Erro desconhecido",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="max-w-2xl mx-auto">
      <Card>
        <CardHeader>
          <CardTitle>Teste de Cobrança Aplia</CardTitle>
          <CardDescription>Preencha os dados para testar o fluxo de cadastro e cobrança</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="nome">Nome</Label>
                <Input
                  id="nome"
                  name="nome"
                  value={formData.nome}
                  onChange={handleChange}
                  placeholder="Nome completo"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="email@exemplo.com"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="telefone">Telefone</Label>
                <Input
                  id="telefone"
                  name="telefone"
                  value={formData.telefone}
                  onChange={handleChange}
                  placeholder="(00) 00000-0000"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="documento">CPF/CNPJ</Label>
                <Input
                  id="documento"
                  name="documento"
                  value={formData.documento}
                  onChange={handleChange}
                  placeholder="000.000.000-00"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="plano">Plano</Label>
                <Select value={formData.plano} onValueChange={handleSelectChange}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione um plano" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Básico">Básico - R$ 199,00</SelectItem>
                    <SelectItem value="Profissional">Profissional - R$ 399,00</SelectItem>
                    <SelectItem value="Empresarial">Empresarial - R$ 899,00</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="user_id">ID do Usuário (opcional)</Label>
                <Input
                  id="user_id"
                  name="user_id"
                  value={formData.user_id}
                  onChange={handleChange}
                  placeholder="UUID do usuário no sistema"
                />
              </div>
            </div>

            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Processando...
                </>
              ) : (
                "Processar Cobrança"
              )}
            </Button>
          </form>
        </CardContent>
      </Card>

      {result && (
        <div className="mt-6">
          {result.success ? (
            <>
              <Alert className="mb-4 bg-green-50 border-green-200">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <AlertTitle className="text-green-800">Sucesso!</AlertTitle>
                <AlertDescription className="text-green-700">{result.message}</AlertDescription>
              </Alert>

              <Card>
                <CardHeader>
                  <CardTitle>Resultado da Cobrança</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h3 className="font-medium text-sm text-gray-500">Dados do Cliente</h3>
                    <div className="mt-1 p-3 bg-gray-50 rounded-md">
                      <p>
                        <span className="font-medium">Nome:</span> {result.data?.cliente.nome}
                      </p>
                      <p>
                        <span className="font-medium">Email:</span> {result.data?.cliente.email}
                      </p>
                      <p>
                        <span className="font-medium">Plano:</span> {result.data?.cliente.plano}
                      </p>
                      <p>
                        <span className="font-medium">Status:</span> {result.data?.cliente.status}
                      </p>
                      {result.data?.cliente.user_id && (
                        <p>
                          <span className="font-medium">ID do Usuário:</span> {result.data.cliente.user_id}
                        </p>
                      )}
                    </div>
                  </div>

                  <div>
                    <h3 className="font-medium text-sm text-gray-500">Dados da Cobrança</h3>
                    <div className="mt-1 p-3 bg-gray-50 rounded-md">
                      <p>
                        <span className="font-medium">Valor:</span> R$ {result.data?.cobranca.valor.toFixed(2)}
                      </p>
                      <p>
                        <span className="font-medium">Status:</span> {result.data?.cobranca.status}
                      </p>
                      <p>
                        <span className="font-medium">Descrição:</span> {result.data?.cobranca.descricao}
                      </p>
                      <p>
                        <span className="font-medium">Vencimento:</span>{" "}
                        {new Date(result.data?.cobranca.dueDate || "").toLocaleDateString("pt-BR")}
                      </p>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <a
                    href={result.data?.cobranca.paymentLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full"
                  >
                    <Button className="w-full">Abrir Link de Pagamento</Button>
                  </a>
                </CardFooter>
              </Card>
            </>
          ) : (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Erro</AlertTitle>
              <AlertDescription>
                {result.message}: {result.error}
              </AlertDescription>
            </Alert>
          )}
        </div>
      )}
    </div>
  )
}
