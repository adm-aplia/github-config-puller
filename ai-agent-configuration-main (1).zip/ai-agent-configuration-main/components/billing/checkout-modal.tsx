"use client"

import type React from "react"

import { useState } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/hooks/use-toast"
import { Loader2 } from "lucide-react"
import { validateCPF, formatCPF } from "@/lib/utils/cpf-validator"
import { validatePhone, formatPhone, phoneToAsaasFormat } from "@/lib/utils/phone-validator"

interface Plan {
  id: string
  name: string
  price: number
  description: string
}

interface CheckoutModalProps {
  isOpen: boolean
  onClose: () => void
  plan: Plan | null
  user: any
}

export function CheckoutModal({ isOpen, onClose, plan, user }: CheckoutModalProps) {
  const [loading, setLoading] = useState(false)
  const [formData, setFormData] = useState({
    nome: "",
    telefone: "",
    documento: "",
  })
  const { toast } = useToast()

  const handleDocumentChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value
    const formatted = formatCPF(value)
    setFormData({ ...formData, documento: formatted })
  }

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value
    const formatted = formatPhone(value)
    setFormData({ ...formData, telefone: formatted })
  }

  const validateForm = () => {
    if (!formData.nome.trim()) {
      toast({
        variant: "destructive",
        title: "Nome obrigatório",
        description: "Digite seu nome completo",
      })
      return false
    }

    if (!validateCPF(formData.documento)) {
      toast({
        variant: "destructive",
        title: "CPF inválido",
        description: "Digite um CPF válido",
      })
      return false
    }

    if (!validatePhone(formData.telefone)) {
      toast({
        variant: "destructive",
        title: "Telefone inválido",
        description: "Digite um telefone válido (DDD + número)",
      })
      return false
    }

    return true
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!plan || !user || !validateForm()) return

    setLoading(true)

    try {
      const response = await fetch("/api/billing/process", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          nome: formData.nome,
          email: user.email,
          telefone: phoneToAsaasFormat(formData.telefone), // Converte para formato Asaas
          documento: formData.documento.replace(/\D/g, ""), // Remove formatação
          plano: plan.name,
          user_id: user.id,
        }),
      })

      const result = await response.json()

      if (result.success) {
        toast({
          title: "Sucesso!",
          description: "Cobrança gerada com sucesso",
        })

        // Redirecionar para o link de pagamento se disponível
        if (result.data?.cobranca?.paymentLink) {
          window.open(result.data.cobranca.paymentLink, "_blank")
        }

        onClose()
      } else {
        throw new Error(result.error || "Erro desconhecido")
      }
    } catch (error: any) {
      console.error("Erro:", error)
      toast({
        variant: "destructive",
        title: "Erro",
        description: error.message || "Erro ao processar cobrança",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Contratar Plano {plan?.name}</DialogTitle>
          <DialogDescription>Preencha seus dados para gerar a cobrança via PIX</DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="nome">Nome Completo *</Label>
            <Input
              id="nome"
              value={formData.nome}
              onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
              placeholder="Seu nome completo"
              required
            />
          </div>

          <div>
            <Label htmlFor="telefone">Telefone *</Label>
            <Input
              id="telefone"
              value={formData.telefone}
              onChange={handlePhoneChange}
              placeholder="(11) 99999-9999"
              maxLength={15}
              required
            />
            <p className="text-xs text-muted-foreground mt-1">Digite com DDD (ex: 11999999999)</p>
          </div>

          <div>
            <Label htmlFor="documento">CPF *</Label>
            <Input
              id="documento"
              value={formData.documento}
              onChange={handleDocumentChange}
              placeholder="000.000.000-00"
              maxLength={14}
              required
            />
          </div>

          <div>
            <Label htmlFor="email">Email</Label>
            <Input id="email" value={user?.email || ""} disabled className="bg-gray-50" />
          </div>

          <div className="bg-muted p-4 rounded-md">
            <h4 className="font-medium">Resumo do Plano</h4>
            <p className="text-sm text-muted-foreground">{plan?.description}</p>
            <p className="text-lg font-bold mt-2">R$ {plan?.price}/mês</p>
          </div>

          <div className="flex gap-2">
            <Button type="button" variant="outline" onClick={onClose} className="flex-1">
              Cancelar
            </Button>
            <Button type="submit" disabled={loading} className="flex-1">
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Processando...
                </>
              ) : (
                "Gerar Cobrança PIX"
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
