"use client"

import type React from "react"

import { useState } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { useToast } from "@/hooks/use-toast"
import { Loader2, CreditCard, CheckCircle } from "lucide-react"
import { validateCPF, formatCPF } from "@/lib/utils/cpf-validator"
import { validatePhone, formatPhone, phoneToAsaasFormat } from "@/lib/utils/phone-validator"
import { CardLimitAlert } from "./card-limit-alert"

interface Plan {
  id: string
  name: string
  price: number
  description: string
}

interface CreditCardCheckoutModalProps {
  isOpen: boolean
  onClose: () => void
  plan: Plan | null
  user: any
}

export function CreditCardCheckoutModal({ isOpen, onClose, plan, user }: CreditCardCheckoutModalProps) {
  const [loading, setLoading] = useState(false)
  const [step, setStep] = useState<"form" | "processing" | "success">("form")
  const [cobrancaImediata, setCobrancaImediata] = useState(true) // Default: cobrar imediatamente
  const [formData, setFormData] = useState({
    // Dados pessoais
    nome: "",
    telefone: "",
    documento: "",
    cep: "",
    endereco: "",
    numero: "",

    // Dados do cartão
    nomeCartao: "",
    numeroCartao: "",
    mesExpiracao: "",
    anoExpiracao: "",
    cvv: "",
  })
  const [resultData, setResultData] = useState<any>(null)
  const { toast } = useToast()
  const [showLimitAlert, setShowLimitAlert] = useState(false)

  const handleDocumentChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value
    const formatted = formatCPF(value)
    setFormData({ ...formData, documento: formatted })
  }

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value
    const formatted = formatPhone(value)
    setFormData({ ...formData, telefone: formatted })
  }

  const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value
    const formatted = value
      .replace(/\D/g, "")
      .replace(/(\d{4})(\d)/, "$1 $2")
      .replace(/(\d{4})(\d)/, "$1 $2")
      .replace(/(\d{4})(\d)/, "$1 $2")
      .replace(/(\d{4})\d+?$/, "$1")
    setFormData({ ...formData, numeroCartao: formatted })
  }

  const handleCEPChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value
    const formatted = value
      .replace(/\D/g, "")
      .replace(/(\d{5})(\d)/, "$1-$2")
      .replace(/(-\d{3})\d+?$/, "$1")
    setFormData({ ...formData, cep: formatted })
  }

  const validateForm = () => {
    // Validações básicas
    if (!formData.nome.trim()) {
      toast({
        variant: "destructive",
        title: "Nome obrigatório",
        description: "Digite seu nome completo",
      })
      return false
    }

    if (!validateCPF(formData.documento)) {
      toast({
        variant: "destructive",
        title: "CPF inválido",
        description: "Digite um CPF válido",
      })
      return false
    }

    if (!validatePhone(formData.telefone)) {
      toast({
        variant: "destructive",
        title: "Telefone inválido",
        description: "Digite um telefone válido (ex: (11) 99999-9999)",
      })
      return false
    }

    // Validações do cartão
    if (!formData.nomeCartao.trim()) {
      toast({
        variant: "destructive",
        title: "Nome do cartão obrigatório",
        description: "Digite o nome como está no cartão",
      })
      return false
    }

    if (formData.numeroCartao.replace(/\D/g, "").length < 16) {
      toast({
        variant: "destructive",
        title: "Número do cartão inválido",
        description: "Digite um número de cartão válido",
      })
      return false
    }

    const mes = Number.parseInt(formData.mesExpiracao)
    if (mes < 1 || mes > 12) {
      toast({
        variant: "destructive",
        title: "Mês inválido",
        description: "Digite um mês válido (01-12)",
      })
      return false
    }

    const ano = Number.parseInt(formData.anoExpiracao)
    const anoAtual = new Date().getFullYear()
    if (ano < anoAtual || ano > anoAtual + 20) {
      toast({
        variant: "destructive",
        title: "Ano inválido",
        description: "Digite um ano válido",
      })
      return false
    }

    if (formData.cvv.length < 3) {
      toast({
        variant: "destructive",
        title: "CVV inválido",
        description: "Digite o código de segurança do cartão",
      })
      return false
    }

    return true
  }

  const getErrorMessage = (errorMessage: string) => {
    const lowerMessage = errorMessage.toLowerCase()

    // Erros específicos de limite e autorização
    if (
      lowerMessage.includes("limite") ||
      lowerMessage.includes("limit") ||
      lowerMessage.includes("insufficient") ||
      lowerMessage.includes("não autorizada") ||
      lowerMessage.includes("not authorized") ||
      lowerMessage.includes("declined") ||
      lowerMessage.includes("negada") ||
      lowerMessage.includes("recusada")
    ) {
      return {
        title: "💳 Transação não autorizada",
        description: "Seu cartão não possui limite disponível para esta transação.",
        suggestion: "Verifique o limite disponível no seu cartão ou use outro cartão de crédito.",
        type: "limit_error",
        alertType: "error",
      }
    }

    // Erros de cartão inválido
    if (
      lowerMessage.includes("cartão inválido") ||
      lowerMessage.includes("invalid_card") ||
      lowerMessage.includes("card_invalid") ||
      lowerMessage.includes("dados incorretos")
    ) {
      return {
        title: "❌ Dados do cartão incorretos",
        description: "Os dados do cartão estão incorretos. Verifique o número, validade e CVV.",
        suggestion: "Confira se digitou corretamente todos os dados do cartão.",
        type: "card_error",
        alertType: "error",
      }
    }

    // Erros de cartão expirado
    if (lowerMessage.includes("expirado") || lowerMessage.includes("expired") || lowerMessage.includes("vencido")) {
      return {
        title: "⏰ Cartão vencido",
        description: "O cartão informado está com a validade vencida.",
        suggestion: "Use um cartão válido ou verifique a data de validade.",
        type: "expired_error",
        alertType: "error",
      }
    }

    // Erros de rede/conectividade
    if (
      lowerMessage.includes("network") ||
      lowerMessage.includes("timeout") ||
      lowerMessage.includes("conexão") ||
      lowerMessage.includes("503") ||
      lowerMessage.includes("502")
    ) {
      return {
        title: "🌐 Erro de conexão",
        description: "Problema temporário de conectividade com o processador de pagamentos.",
        suggestion: "Aguarde alguns minutos e tente novamente.",
        type: "network_error",
        alertType: "warning",
      }
    }

    // Erros de permissão/autorização
    if (lowerMessage.includes("403") || lowerMessage.includes("unauthorized") || lowerMessage.includes("permission")) {
      return {
        title: "🚫 Erro de autorização",
        description: "Erro de permissão no processamento do pagamento.",
        suggestion: "Tente novamente em alguns minutos ou entre em contato com o suporte.",
        type: "auth_error",
        alertType: "warning",
      }
    }

    // Erro genérico
    return {
      title: "❌ Erro no processamento",
      description: "Ocorreu um erro inesperado ao processar o pagamento.",
      suggestion: "Verifique os dados e tente novamente. Se o problema persistir, entre em contato com o suporte.",
      type: "generic_error",
      alertType: "error",
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!plan || !user || !validateForm()) return

    setLoading(true)
    setStep("processing")

    try {
      console.log("🚀 [MODAL] Enviando dados para API de assinatura...")

      const requestData = {
        // Dados do cliente
        nome: formData.nome,
        email: user.email,
        telefone: phoneToAsaasFormat(formData.telefone),
        documento: formData.documento.replace(/\D/g, ""),
        cep: formData.cep.replace(/\D/g, "") || "01310100",
        endereco: formData.endereco || "Rua Teste",
        numero: formData.numero || "100",

        // Dados do plano
        plano: plan.name,
        user_id: user.id,

        // Opção de cobrança imediata
        cobranca_imediata: cobrancaImediata,

        // Dados do cartão
        cartao: {
          nomeCartao: formData.nomeCartao,
          numeroCartao: formData.numeroCartao.replace(/\D/g, ""),
          mesExpiracao: formData.mesExpiracao.padStart(2, "0"),
          anoExpiracao: formData.anoExpiracao,
          cvv: formData.cvv,
        },
      }

      console.log("📝 [MODAL] Dados sendo enviados (mascarados):", {
        ...requestData,
        documento: "***",
        telefone: "***",
        cartao: {
          nomeCartao: requestData.cartao.nomeCartao,
          numeroCartao: `****${requestData.cartao.numeroCartao.slice(-4)}`,
          mesExpiracao: requestData.cartao.mesExpiracao,
          anoExpiracao: requestData.cartao.anoExpiracao,
          cvv: "***",
        },
      })

      const response = await fetch("/api/subscription/create", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(requestData),
      })

      console.log("📡 [MODAL] Status da resposta:", response.status)

      // Verificar se a resposta é JSON
      const contentType = response.headers.get("content-type")
      if (!contentType || !contentType.includes("application/json")) {
        const responseText = await response.text()
        console.error("❌ [MODAL] Resposta não é JSON:", responseText)
        throw new Error(`Servidor retornou resposta inválida: ${responseText.substring(0, 200)}`)
      }

      const result = await response.json()
      console.log("✅ [MODAL] Resultado da API:", result)

      if (result.success) {
        setResultData(result.data)
        setStep("success")

        const successMessage = cobrancaImediata
          ? `Assinatura criada e primeira cobrança de R$ ${plan.price} processada com sucesso!`
          : `Assinatura do plano ${plan.name} criada com sucesso!`

        toast({
          title: "🎉 Sucesso!",
          description: successMessage,
        })

        console.log("🎉 [MODAL] Assinatura criada com sucesso:", {
          cliente: result.data?.cliente?.nome,
          plano: result.data?.cliente?.plano,
          subscription_id: result.data?.assinatura?.subscription_id,
          cobranca_imediata: result.data?.cobranca_imediata,
        })
      } else {
        throw new Error(result.error || result.message || "Erro desconhecido ao criar assinatura")
      }
    } catch (error: any) {
      console.error("❌ [MODAL] Erro ao criar assinatura:", error)

      const errorInfo = getErrorMessage(error.message)
      setLoading(false)

      // Mostrar alerta de erro de limite diretamente no formulário
      if (errorInfo.type === "limit_error") {
        setShowLimitAlert(true)
        setStep("form")

        // Toast principal com o erro
        toast({
          variant: "destructive",
          title: "❌ Pagamento Recusado",
          description: "Transação não autorizada pela operadora do cartão.",
          duration: 6000,
        })

        // Mostrar alerta de limite no toast
        setTimeout(() => {
          toast({
            variant: "destructive",
            title: "💳 Verifique o limite do seu cartão",
            description: "O pagamento não foi aprovado por falta de limite disponível no cartão.",
            duration: 8000,
          })
        }, 1000)

        return
      }

      // Toast principal com o erro para outros tipos de erro
      toast({
        variant: "destructive",
        title: errorInfo.title,
        description: errorInfo.description,
        duration: 6000,
      })

      // Toast adicional com sugestão
      if (errorInfo.suggestion) {
        setTimeout(() => {
          toast({
            title: "💡 Sugestão",
            description: errorInfo.suggestion,
            duration: 6000,
          })
        }, 2000)
      }

      setStep("form")
    } finally {
      setLoading(false)
    }
  }

  const resetModal = () => {
    setStep("form")
    setLoading(false)
    setResultData(null)
    setCobrancaImediata(true)
    setShowLimitAlert(false)
    setFormData({
      nome: "",
      telefone: "",
      documento: "",
      cep: "",
      endereco: "",
      numero: "",
      nomeCartao: "",
      numeroCartao: "",
      mesExpiracao: "",
      anoExpiracao: "",
      cvv: "",
    })
  }

  const handleClose = () => {
    resetModal()
    onClose()
  }

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <CreditCard className="h-5 w-5" />
            Assinatura - Plano {plan?.name}
          </DialogTitle>
          <DialogDescription>
            Preencha seus dados para ativar sua assinatura mensal via cartão de crédito
          </DialogDescription>
        </DialogHeader>

        {step === "form" && (
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Mostrar alerta de limite quando necessário */}
            {showLimitAlert && (
              <CardLimitAlert
                variant="destructive"
                title="Pagamento Recusado - Verifique o Limite"
                description="Sua transação não foi autorizada pela operadora do cartão. Isso geralmente ocorre quando não há limite disponível."
              />
            )}

            {/* Aviso sobre Cobrança Imediata */}
            <div className="bg-blue-50 border border-blue-200 p-4 rounded-md">
              <div className="flex items-center space-x-2 mb-2">
                <Checkbox
                  id="cobranca-imediata"
                  checked={cobrancaImediata}
                  onCheckedChange={(checked) => setCobrancaImediata(checked as boolean)}
                />
                <Label htmlFor="cobranca-imediata" className="text-sm font-medium">
                  Ativar serviço imediatamente (Recomendado)
                </Label>
              </div>
              <div className="ml-6">
                {cobrancaImediata ? (
                  <div className="text-sm">
                    <p className="text-green-700 font-medium">
                      ✅ Será cobrado R$ {plan?.price} hoje + mensalidades futuras automaticamente
                    </p>
                    <p className="text-green-600 text-xs mt-1">
                      Seu serviço será ativado imediatamente após o pagamento
                    </p>
                  </div>
                ) : (
                  <div className="text-sm">
                    <p className="text-orange-700 font-medium">⏰ Primeira cobrança será feita apenas no próximo mês</p>
                    <p className="text-orange-600 text-xs mt-1">
                      Serviço ficará em modo de teste até a primeira cobrança
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* Dados Pessoais */}
            <div className="space-y-4">
              <h3 className="font-semibold">Dados Pessoais</h3>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="nome">Nome Completo *</Label>
                  <Input
                    id="nome"
                    value={formData.nome}
                    onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                    placeholder="Seu nome completo"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="documento">CPF *</Label>
                  <Input
                    id="documento"
                    value={formData.documento}
                    onChange={handleDocumentChange}
                    placeholder="000.000.000-00"
                    maxLength={14}
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="telefone">Telefone *</Label>
                  <Input
                    id="telefone"
                    value={formData.telefone}
                    onChange={handlePhoneChange}
                    placeholder="(11) 99999-9999"
                    maxLength={15}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input id="email" value={user?.email || ""} disabled className="bg-gray-50" />
                </div>
              </div>
            </div>

            {/* Endereço */}
            <div className="space-y-4">
              <h3 className="font-semibold">Endereço</h3>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="cep">CEP</Label>
                  <Input
                    id="cep"
                    value={formData.cep}
                    onChange={handleCEPChange}
                    placeholder="00000-000"
                    maxLength={9}
                  />
                </div>

                <div>
                  <Label htmlFor="endereco">Endereço</Label>
                  <Input
                    id="endereco"
                    value={formData.endereco}
                    onChange={(e) => setFormData({ ...formData, endereco: e.target.value })}
                    placeholder="Rua, Avenida..."
                  />
                </div>

                <div>
                  <Label htmlFor="numero">Número</Label>
                  <Input
                    id="numero"
                    value={formData.numero}
                    onChange={(e) => setFormData({ ...formData, numero: e.target.value })}
                    placeholder="123"
                  />
                </div>
              </div>
            </div>

            {/* Dados do Cartão */}
            <div className="space-y-4">
              <h3 className="font-semibold">Dados do Cartão</h3>

              <div>
                <Label htmlFor="nomeCartao">Nome no Cartão *</Label>
                <Input
                  id="nomeCartao"
                  value={formData.nomeCartao}
                  onChange={(e) => setFormData({ ...formData, nomeCartao: e.target.value })}
                  placeholder="Nome como está no cartão"
                  required
                />
              </div>

              <div>
                <Label htmlFor="numeroCartao">Número do Cartão *</Label>
                <Input
                  id="numeroCartao"
                  value={formData.numeroCartao}
                  onChange={handleCardNumberChange}
                  placeholder="0000 0000 0000 0000"
                  maxLength={19}
                  required
                />
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="mesExpiracao">Mês *</Label>
                  <Input
                    id="mesExpiracao"
                    value={formData.mesExpiracao}
                    onChange={(e) => setFormData({ ...formData, mesExpiracao: e.target.value })}
                    placeholder="MM"
                    maxLength={2}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="anoExpiracao">Ano *</Label>
                  <Input
                    id="anoExpiracao"
                    value={formData.anoExpiracao}
                    onChange={(e) => setFormData({ ...formData, anoExpiracao: e.target.value })}
                    placeholder="AAAA"
                    maxLength={4}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="cvv">CVV *</Label>
                  <Input
                    id="cvv"
                    value={formData.cvv}
                    onChange={(e) => setFormData({ ...formData, cvv: e.target.value })}
                    placeholder="123"
                    maxLength={4}
                    required
                  />
                </div>
              </div>
            </div>

            {/* Adicione este componente após o resumo e antes dos botões */}
            <div className="space-y-4">
              {/* Resumo existente */}
              <div className="bg-muted p-4 rounded-md">
                <h4 className="font-medium">Resumo da Assinatura</h4>
                <p className="text-sm text-muted-foreground">{plan?.description}</p>
                <p className="text-lg font-bold mt-2">R$ {plan?.price}/mês</p>
                {cobrancaImediata && (
                  <div className="mt-2 p-2 bg-green-100 rounded text-sm">
                    <strong>Cobrança Imediata:</strong> R$ {plan?.price} será cobrado hoje
                  </div>
                )}
                <p className="text-xs text-muted-foreground mt-1">Cobrança automática mensal • Cancele quando quiser</p>
              </div>

              {/* Dica sobre limite do cartão */}
              <div className="p-3 bg-blue-50 border border-blue-100 rounded-md">
                <p className="text-sm text-blue-800 flex items-center gap-2">
                  <span className="text-blue-500">💡</span>
                  <span>
                    <strong>Dica:</strong> Certifique-se de que seu cartão possui limite disponível para esta transação.
                  </span>
                </p>
              </div>
            </div>

            <div className="flex gap-2">
              <Button type="button" variant="outline" onClick={handleClose} className="flex-1">
                Cancelar
              </Button>
              <Button type="submit" disabled={loading} className="flex-1">
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Processando...
                  </>
                ) : cobrancaImediata ? (
                  `Ativar por R$ ${plan?.price}`
                ) : (
                  "Criar Assinatura"
                )}
              </Button>
            </div>
          </form>
        )}

        {step === "processing" && (
          <div className="text-center py-8">
            <Loader2 className="h-12 w-12 animate-spin mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">Processando sua assinatura...</h3>
            <p className="text-muted-foreground">
              {cobrancaImediata ? "Processando cobrança e ativando seu serviço..." : "Criando assinatura recorrente..."}
            </p>
          </div>
        )}

        {step === "success" && (
          <div className="text-center py-8">
            <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
            <h3 className="text-lg font-semibold mb-2">🎉 Assinatura ativada com sucesso!</h3>

            {resultData?.cobranca_imediata && (
              <div className="mb-4 p-4 bg-green-50 rounded-md">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <CheckCircle className="h-5 w-5 text-green-600" />
                  <span className="font-medium">Pagamento Aprovado</span>
                </div>
                <p className="text-sm text-muted-foreground">
                  Cobrança de R$ {resultData.cobranca_imediata.valor} processada com sucesso
                </p>
                <p className="text-xs text-muted-foreground mt-1">Status: {resultData.cobranca_imediata.status}</p>
              </div>
            )}

            <p className="text-muted-foreground mb-4">
              {resultData?.cobranca_imediata
                ? "Seu serviço está ativo! As próximas mensalidades serão cobradas automaticamente."
                : "Sua assinatura foi criada e a primeira cobrança será processada na data de vencimento."}
            </p>

            <div className="bg-blue-50 p-3 rounded-md mb-4">
              <p className="text-sm text-blue-700">
                💡 Acesse <strong>Configurações → Pagamentos</strong> para gerenciar sua assinatura
              </p>
            </div>

            <Button onClick={handleClose}>Começar a usar</Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}
