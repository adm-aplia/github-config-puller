"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { useToast } from "@/hooks/use-toast"
import { Loader2 } from "lucide-react"

interface UpgradeModalProps {
  isOpen: boolean
  onClose: () => void
  planName: string
  planPrice: number
  userEmail: string
  userId: string
}

export function UpgradeModal({ isOpen, onClose, planName, planPrice, userEmail, userId }: UpgradeModalProps) {
  const [loading, setLoading] = useState(false)
  const [formData, setFormData] = useState({
    nome: "",
    telefone: "",
    documento: "",
  })
  const { toast } = useToast()

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      const response = await fetch("/api/billing/process", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          nome: formData.nome,
          email: userEmail,
          telefone: formData.telefone,
          documento: formData.documento,
          plano: planName,
          user_id: userId,
        }),
      })

      const data = await response.json()

      if (data.success) {
        // Redirecionar para o link de pagamento
        window.open(data.data.cobranca.paymentLink, "_blank")

        toast({
          title: "Cobrança gerada!",
          description:
            "Você será redirecionado para o pagamento. Após a confirmação, seu plano será ativado automaticamente.",
        })

        onClose()
      } else {
        throw new Error(data.error || "Erro ao processar cobrança")
      }
    } catch (error) {
      console.error("Erro ao contratar plano:", error)
      toast({
        variant: "destructive",
        title: "Erro ao contratar plano",
        description: error instanceof Error ? error.message : "Tente novamente mais tarde",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Contratar Plano {planName}</DialogTitle>
          <DialogDescription>
            Complete seus dados para finalizar a contratação do plano {planName} por R$ {planPrice}/mês.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="nome">Nome completo</Label>
              <Input
                id="nome"
                name="nome"
                value={formData.nome}
                onChange={handleChange}
                placeholder="Seu nome completo"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="telefone">Telefone</Label>
              <Input
                id="telefone"
                name="telefone"
                value={formData.telefone}
                onChange={handleChange}
                placeholder="(00) 00000-0000"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="documento">CPF/CNPJ</Label>
              <Input
                id="documento"
                name="documento"
                value={formData.documento}
                onChange={handleChange}
                placeholder="000.000.000-00"
                required
              />
            </div>

            <div className="text-sm text-muted-foreground">
              <p>
                <strong>Email:</strong> {userEmail}
              </p>
              <p>
                <strong>Plano:</strong> {planName}
              </p>
              <p>
                <strong>Valor:</strong> R$ {planPrice}/mês
              </p>
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose} disabled={loading}>
              Cancelar
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Processando...
                </>
              ) : (
                "Finalizar Contratação"
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
