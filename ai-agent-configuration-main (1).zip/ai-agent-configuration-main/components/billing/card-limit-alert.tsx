import { AlertCircle, CreditCard, AlertTriangle } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

interface CardLimitAlertProps {
  variant?: "default" | "destructive" | "info"
  title?: string
  description?: string
}

export function CardLimitAlert({
  variant = "destructive",
  title = "Verifique o limite do seu cartão",
  description = "O pagamento não foi aprovado por falta de limite disponível no cartão de crédito.",
}: CardLimitAlertProps) {
  return (
    <Alert variant={variant} className="mb-4 animate-pulse">
      <div className="flex items-start gap-3">
        {variant === "destructive" ? (
          <AlertCircle className="h-5 w-5 mt-0.5" />
        ) : variant === "info" ? (
          <CreditCard className="h-5 w-5 mt-0.5" />
        ) : (
          <AlertTriangle className="h-5 w-5 mt-0.5" />
        )}
        <div>
          <AlertTitle className="mb-1">{title}</AlertTitle>
          <AlertDescription className="text-sm">
            {description}
            <ul className="mt-2 ml-2 space-y-1 list-disc">
              <li>Verifique o limite disponível no app do seu banco</li>
              <li>Tente com outro cartão de crédito</li>
              <li>Entre em contato com seu banco para aumentar o limite</li>
            </ul>
          </AlertDescription>
        </div>
      </div>
    </Alert>
  )
}
