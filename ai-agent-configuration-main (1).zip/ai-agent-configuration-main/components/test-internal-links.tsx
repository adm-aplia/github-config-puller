"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { useRouter } from "next/navigation"

interface LinkTest {
  name: string
  href: string
  component: string
  status: "pending" | "success" | "error"
}

export default function TestInternalLinks() {
  const router = useRouter()
  const [linkTests, setLinkTests] = useState<LinkTest[]>([
    // Links do DashboardSidebar
    { name: "Dashboard", href: "/dashboard", component: "DashboardSidebar", status: "pending" },
    { name: "Perfis", href: "/dashboard/perfis", component: "DashboardSidebar", status: "pending" },
    { name: "Agendamentos", href: "/dashboard/agendamentos", component: "DashboardSidebar", status: "pending" },
    { name: "Conversas", href: "/dashboard/conversas", component: "DashboardSidebar", status: "pending" },
    { name: "WhatsApp", href: "/dashboard/whatsapp", component: "DashboardSidebar", status: "pending" },
    { name: "Configurações", href: "/dashboard/configuracoes", component: "DashboardSidebar", status: "pending" },

    // Links do Footer
    { name: "Termos (Footer)", href: "/termos", component: "Footer", status: "pending" },
    { name: "Privacidade (Footer)", href: "/privacidade", component: "Footer", status: "pending" },

    // Links de autenticação
    { name: "Login", href: "/login", component: "AuthPages", status: "pending" },
    { name: "Cadastro", href: "/cadastro", component: "AuthPages", status: "pending" },
    { name: "Esqueci Senha", href: "/esqueci-senha", component: "AuthPages", status: "pending" },
  ])

  const testLink = (href: string, index: number) => {
    try {
      // Simular navegação
      router.prefetch(href)
      setLinkTests((prev) => prev.map((test, i) => (i === index ? { ...test, status: "success" } : test)))
    } catch (error) {
      setLinkTests((prev) => prev.map((test, i) => (i === index ? { ...test, status: "error" } : test)))
    }
  }

  const testAllLinks = () => {
    linkTests.forEach((test, index) => {
      setTimeout(() => testLink(test.href, index), index * 100)
    })
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>🔗 Teste de Links Internos</CardTitle>
        <Button onClick={testAllLinks} className="w-fit">
          Testar Todos os Links
        </Button>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {linkTests.map((test, index) => (
            <div key={index} className="flex items-center justify-between p-3 border rounded">
              <div>
                <div className="font-medium">{test.name}</div>
                <div className="text-sm text-gray-600">
                  <code>{test.href}</code> - {test.component}
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Badge
                  variant={
                    test.status === "success" ? "default" : test.status === "error" ? "destructive" : "secondary"
                  }
                >
                  {test.status}
                </Badge>
                <Button size="sm" variant="outline" onClick={() => testLink(test.href, index)}>
                  Testar
                </Button>
                <Button size="sm" variant="ghost" asChild>
                  <Link href={test.href}>Ir</Link>
                </Button>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
