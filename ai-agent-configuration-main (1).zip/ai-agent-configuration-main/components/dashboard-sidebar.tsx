"use client"

import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { cn } from "@/lib/utils"
import {
  Calendar,
  MessageSquare,
  Users,
  LayoutDashboard,
  Phone,
  Menu,
  X,
  LogOut,
  Crown,
  CalendarDays,
  ChevronUp,
  User,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { useMobile } from "@/hooks/use-mobile"
import { useState, useEffect } from "react"
import { Logo } from "@/components/logo"
import { Separator } from "@/components/ui/separator"
import { getSupabaseBrowserClient } from "@/lib/supabase/supabase-browser"

interface SidebarProps {
  className?: string
}

interface UserProfile {
  id: string
  name: string
  email: string
  first_name: string
  last_name: string
  phone: string
  created_at: string
  updated_at: string
  onboarding_completed: boolean
  notifications_email: boolean
  notifications_push: boolean
  notifications_sms: boolean
  notifications_appointments: boolean
  notifications_messages: boolean
  specialty: string | null
}

export function DashboardSidebar({ className }: SidebarProps) {
  const pathname = usePathname()
  const router = useRouter()
  const isMobile = useMobile()
  const [isOpen, setIsOpen] = useState(false)
  const [isLoggingOut, setIsLoggingOut] = useState(false)
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null)
  const [profileLoading, setProfileLoading] = useState(true)
  const [showUserMenu, setShowUserMenu] = useState(false)
  const [user, setUser] = useState<any>(null)
  const [userPlan, setUserPlan] = useState<string>("Carregando...")
  const [planLoading, setPlanLoading] = useState(true)

  useEffect(() => {
    const fetchUserProfileAndPlan = async () => {
      setProfileLoading(true)
      setPlanLoading(true)

      const supabase = getSupabaseBrowserClient()
      const {
        data: { user: fetchedUser },
      } = await supabase.auth.getUser()
      setUser(fetchedUser)

      if (!fetchedUser?.id) {
        setUserProfile(null)
        setUserPlan("Plano Gratuito")
        setProfileLoading(false)
        setPlanLoading(false)
        return
      }

      // Fetch profile
      try {
        const { data: profile, error } = await supabase.from("profiles").select("*").eq("id", fetchedUser.id).single()

        if (error) {
          console.error("Erro ao buscar perfil:", error)
          setUserProfile(null)
        } else {
          setUserProfile(profile)
        }
      } catch (error) {
        console.error("Erro ao buscar perfil do usuário:", error)
        setUserProfile(null)
      } finally {
        setProfileLoading(false)
      }

      // Fetch plan - buscar diretamente do campo 'plano' na tabela clientes
      try {
        console.log("🔍 Buscando plano diretamente do Supabase...")

        // Buscar cliente ativo
        const { data: clientes, error: clientesError } = await supabase
          .from("clientes")
          .select("*")
          .eq("user_id", fetchedUser.id)

        console.log("📋 Clientes encontrados:", clientes)

        if (clientesError || !clientes || clientes.length === 0) {
          console.log("⚠️ Nenhum cliente encontrado")
          setUserPlan("Plano Gratuito")
          setPlanLoading(false)
          return
        }

        const clienteAtivo = clientes.find((c) => c.is_active === true)

        if (!clienteAtivo) {
          console.log("⚠️ Nenhum cliente ativo")
          setUserPlan("Plano Gratuito")
          setPlanLoading(false)
          return
        }

        console.log("✅ Cliente ativo:", clienteAtivo)

        // Usar o campo 'plano' diretamente do cliente
        const planoNome = clienteAtivo.plano

        if (!planoNome) {
          console.log("⚠️ Campo plano não encontrado")
          setUserPlan("Plano Gratuito")
        } else {
          // Mapear nomes dos planos
          const planNames: { [key: string]: string } = {
            Básico: "Plano Gratuito",
            Profissional: "Plano Profissional",
            Empresarial: "Plano Empresarial",
          }

          const planName = planNames[planoNome] || planoNome
          console.log("🎯 Plano final:", planName)
          setUserPlan(planName)
        }
      } catch (error) {
        console.error("❌ Erro ao buscar plano:", error)
        setUserPlan("Plano Gratuito")
      } finally {
        setPlanLoading(false)
      }
    }

    fetchUserProfileAndPlan()
  }, [])

  const toggleSidebar = () => {
    setIsOpen(!isOpen)
  }

  const toggleUserMenu = () => {
    setShowUserMenu(!showUserMenu)
  }

  const handleSignOut = async () => {
    try {
      setIsLoggingOut(true)
      const supabase = getSupabaseBrowserClient()
      await supabase.auth.signOut()
      router.push("/")
    } catch (error) {
      console.error("Erro ao fazer logout:", error)
    } finally {
      setIsLoggingOut(false)
    }
  }

  // Rotas principais
  const mainSidebarItems = [
    {
      title: "Painel",
      href: "/dashboard",
      icon: <LayoutDashboard className="h-5 w-5" />,
    },
    {
      title: "Perfis",
      href: "/dashboard/perfis",
      icon: <Users className="h-5 w-5" />,
    },
    {
      title: "Agendamentos",
      href: "/dashboard/agendamentos",
      icon: <Calendar className="h-5 w-5" />,
    },
    {
      title: "Conversas",
      href: "/dashboard/conversas",
      icon: <MessageSquare className="h-5 w-5" />,
    },
    {
      title: "WhatsApp",
      href: "/dashboard/whatsapp",
      icon: <Phone className="h-5 w-5" />,
    },
    {
      title: "Integrações",
      href: "/dashboard/integracoes",
      icon: <CalendarDays className="h-5 w-5" />,
    },
  ]

  // Determinar nome para exibir
  const getDisplayName = () => {
    if (profileLoading) {
      return "Carregando..."
    }

    if (userProfile?.first_name && userProfile?.last_name) {
      return `${userProfile.first_name} ${userProfile.last_name}`
    }

    if (userProfile?.name) {
      return userProfile.name
    }

    if (user?.user_metadata?.full_name) {
      return user.user_metadata.full_name
    }

    if (user?.email && !profileLoading) {
      return user.email.split("@")[0]
    }

    return "Usuário"
  }

  const displayName = getDisplayName()
  const displayEmail = userProfile?.email || user?.email || ""

  const sidebarContent = (
    <>
      <div className="flex h-14 items-center px-4">
        <Link href="/dashboard" className="flex items-center gap-2">
          <Logo size="medium" />
        </Link>
      </div>
      <div className="flex-1 overflow-auto py-2">
        <nav className="grid items-start px-2 text-sm font-medium">
          {mainSidebarItems.map((item, index) => (
            <Link
              key={index}
              href={item.href}
              className={cn(
                "flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary",
                (pathname === item.href || (item.href !== "/dashboard" && pathname.startsWith(item.href))) &&
                  "bg-muted text-primary",
              )}
            >
              {item.icon}
              {item.title}
            </Link>
          ))}
        </nav>
      </div>

      {/* Seção do Perfil com Menu Customizado */}
      <div className="border-t p-2 relative">
        <Separator className="mb-2" />

        {/* Botão do usuário */}
        <Button
          variant="ghost"
          className="w-full justify-between px-3 py-2 h-auto text-left hover:bg-muted"
          onClick={toggleUserMenu}
        >
          <div className="flex flex-col items-start min-w-0 flex-1">
            <span className="text-xs text-muted-foreground truncate w-full mb-1">
              {planLoading ? "Carregando plano..." : userPlan}
            </span>
            <span className="text-sm font-medium text-foreground truncate w-full">{displayName}</span>
            <span className="text-xs text-muted-foreground truncate w-full">{displayEmail}</span>
          </div>
          <ChevronUp
            className={cn(
              "h-4 w-4 text-muted-foreground flex-shrink-0 ml-2 transition-transform",
              showUserMenu && "rotate-180",
            )}
          />
        </Button>

        {/* Menu dropdown customizado */}
        {showUserMenu && (
          <div className="absolute bottom-full left-2 right-2 mb-2 bg-background border rounded-md shadow-lg z-50">
            <div className="py-1">
              <Link
                href="/dashboard/configuracoes"
                className="flex items-center gap-2 px-3 py-2 text-sm hover:bg-muted transition-colors"
                onClick={() => setShowUserMenu(false)}
              >
                <User className="h-4 w-4" />
                Configurações
              </Link>

              <Link
                href="/dashboard/planos"
                className="flex items-center gap-2 px-3 py-2 text-sm hover:bg-muted transition-colors"
                onClick={() => setShowUserMenu(false)}
              >
                <Crown className="h-4 w-4" />
                Planos & Pagamentos
              </Link>

              <div className="border-t my-1" />

              <button
                onClick={() => {
                  setShowUserMenu(false)
                  handleSignOut()
                }}
                disabled={isLoggingOut}
                className="flex items-center gap-2 px-3 py-2 text-sm text-red-600 hover:bg-red-50 transition-colors w-full text-left"
              >
                <LogOut className="h-4 w-4" />
                {isLoggingOut ? "Saindo..." : "Sair"}
              </button>
            </div>
          </div>
        )}

        {/* Overlay para fechar o menu */}
        {showUserMenu && <div className="fixed inset-0 z-40" onClick={() => setShowUserMenu(false)} />}
      </div>
    </>
  )

  // Versão móvel com toggle
  if (isMobile) {
    return (
      <>
        {/* Botão de menu fixo */}
        <Button
          variant="ghost"
          size="icon"
          className="fixed left-4 top-4 z-50 bg-background border shadow-md md:hidden"
          onClick={toggleSidebar}
        >
          {isOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </Button>

        {/* Overlay escuro */}
        {isOpen && <div className="fixed inset-0 z-30 bg-black/50 md:hidden" onClick={toggleSidebar} />}

        {/* Sidebar mobile */}
        <div
          className={cn(
            "fixed left-0 top-0 z-40 h-full w-64 bg-background border-r shadow-lg transition-transform duration-300 md:hidden",
            isOpen ? "translate-x-0" : "-translate-x-full",
          )}
        >
          <div className="flex h-full flex-col pt-16">{sidebarContent}</div>
        </div>
      </>
    )
  }

  // Versão desktop
  return <div className={cn("hidden bg-background md:flex md:w-64 md:flex-col", className)}>{sidebarContent}</div>
}
