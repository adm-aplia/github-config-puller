"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Loader2, Eye, EyeOff, MailCheck } from "lucide-react"
import { z } from "zod"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"

import { Button } from "./ui/button"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "./ui/form"
import { Input } from "./ui/input"
import { useAuth } from "./auth-provider"
import { cn } from "../lib/utils"
import { toast } from "./ui/use-toast"

const formSchema = z.object({
  email: z.string().email({ message: "Por favor, insira um endereço de e-mail válido." }),
  password: z.string().min(1, { message: "A senha é obrigatória." }),
})

export default function LoginForm({ onConfirmationScreen }: { onConfirmationScreen?: (isShowing: boolean) => void }) {
  const [isLoading, setIsLoading] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [needsConfirmation, setNeedsConfirmation] = useState(false)
  const [emailForConfirmation, setEmailForConfirmation] = useState("")
  const [capsLockActive, setCapsLockActive] = useState(false)
  const router = useRouter()
  const auth = useAuth()

  // Notificar o componente pai quando o estado de confirmação mudar
  useEffect(() => {
    if (onConfirmationScreen) {
      onConfirmationScreen(needsConfirmation)
    }
  }, [needsConfirmation, onConfirmationScreen])

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      email: "",
      password: "",
    },
  })

  // Detectar Caps Lock
  const handleKeyPress = (e: React.KeyboardEvent) => {
    const capsLock = e.getModifierState && e.getModifierState("CapsLock")
    setCapsLockActive(capsLock)
  }

  const handleKeyUp = (e: React.KeyboardEvent) => {
    const capsLock = e.getModifierState && e.getModifierState("CapsLock")
    setCapsLockActive(capsLock)
  }

  async function onSubmit(values: z.infer<typeof formSchema>) {
    console.log("📝 Formulário enviado para:", values.email)
    setIsLoading(true)
    setNeedsConfirmation(false)

    try {
      if (!auth.isInitialized) {
        console.log("⏳ Auth ainda não inicializado")
        toast({
          title: "Aguarde um Momento",
          description: "O sistema ainda está carregando. Tente novamente em alguns segundos.",
          variant: "destructive",
        })
        return
      }

      console.log("🔑 Iniciando processo de login...")
      await auth.signIn(values.email, values.password)

      // Se chegou aqui, o login foi bem-sucedido
      console.log("✅ Login bem-sucedido, redirecionando...")
      toast({
        title: "Bem-vindo de volta! 🎉",
        description: "Login realizado com sucesso. Redirecionando...",
        variant: "success",
      })

      // Aguardar um pouco para garantir que o estado foi atualizado
      setTimeout(() => {
        router.push("/dashboard")
      }, 1000)
    } catch (error: any) {
      console.log("🚫 Login bloqueado devido ao erro:", error.message)

      // Verificar se é especificamente o erro de email não confirmado
      if (error.message === "Email not confirmed") {
        console.log("📧 Mostrando tela de confirmação de e-mail")
        setEmailForConfirmation(values.email)
        setNeedsConfirmation(true)
        return
      }

      // O toast já foi exibido no AuthProvider
      console.log("❌ Acesso negado - credenciais inválidas")
    } finally {
      setIsLoading(false)
    }
  }

  async function handleResendConfirmation() {
    setIsLoading(true)
    try {
      await auth.resendConfirmationEmail(emailForConfirmation)
      toast({
        title: "E-mail Reenviado! 📧",
        description: `Verifique sua caixa de entrada em ${emailForConfirmation}.`,
      })
    } catch (error) {
      console.error("Erro ao reenviar confirmação:", error)
      toast({
        title: "Erro no Reenvio",
        description: "Não foi possível reenviar o e-mail. Tente novamente mais tarde.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  if (needsConfirmation) {
    return (
      <div className="w-full max-w-lg mx-auto">
        {/* Ícone e título principal */}
        <div className="text-center mb-8">
          <div className="mx-auto w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mb-6">
            <MailCheck className="h-10 w-10 text-primary" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Confirme seu E-mail</h1>
          <p className="text-base text-gray-600">Quase lá! Só falta um passo.</p>
        </div>

        {/* Card principal - mais largo */}
        <div className="bg-white rounded-2xl shadow-lg border border-gray-100 p-10 mb-6">
          <div className="space-y-6">
            <div className="text-center">
              <p className="text-base font-medium text-gray-900">Enviamos um e-mail para</p>
            </div>

            <div className="bg-gray-50 rounded-lg p-4 text-center">
              <p className="font-semibold text-primary text-base">{emailForConfirmation}</p>
            </div>

            {/* Texto alinhado à esquerda com tamanho padronizado */}
            <div className="text-left">
              <p className="text-base text-gray-600">
                Por favor, verifique sua caixa de entrada (e a pasta de spam) para encontrar o link de confirmação.
              </p>
            </div>
          </div>
        </div>

        {/* Botões de ação */}
        <div className="space-y-3">
          <Button onClick={handleResendConfirmation} disabled={isLoading} className="w-full h-12 text-base font-medium">
            {isLoading && <Loader2 className="mr-2 h-5 w-5 animate-spin" />}
            Reenviar E-mail de Confirmação
          </Button>

          <Button
            variant="ghost"
            onClick={() => setNeedsConfirmation(false)}
            className="w-full h-12 text-base font-medium text-gray-600 hover:text-gray-900"
          >
            Voltar para o Login
          </Button>
        </div>

        {/* Links de ajuda */}
        <div className="mt-8 text-center">
          <p className="text-sm text-gray-500 mb-4">Precisa de ajuda?</p>
          <div className="flex justify-center space-x-6 text-sm">
            <Link href="/termos" className="text-primary hover:text-primary/80 underline">
              Termos de Uso
            </Link>
            <Link href="/privacidade" className="text-primary hover:text-primary/80 underline">
              Política de Privacidade
            </Link>
          </div>
        </div>
      </div>
    )
  }

  if (!auth.isInitialized) {
    return (
      <div className="flex flex-col items-center justify-center space-y-2">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <p className="text-sm text-muted-foreground">Carregando autenticação...</p>
      </div>
    )
  }

  return (
    <>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <FormField
            control={form.control}
            name="email"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-foreground">E-mail</FormLabel>
                <FormControl>
                  <Input
                    placeholder="seu@email.com"
                    {...field}
                    className="bg-background border-border focus:ring-primary focus:border-primary rounded-lg"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="password"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-foreground">Senha</FormLabel>
                <div className="relative">
                  <FormControl>
                    <Input
                      type={showPassword ? "text" : "password"}
                      placeholder="Sua senha"
                      {...field}
                      onKeyDown={handleKeyPress}
                      onKeyUp={handleKeyUp}
                      className="bg-background border-border focus:ring-primary focus:border-primary rounded-lg pr-10"
                    />
                  </FormControl>
                  <button
                    type="button"
                    className="absolute inset-y-0 right-0 flex items-center pr-3 text-muted-foreground hover:text-foreground"
                    onClick={() => setShowPassword(!showPassword)}
                    aria-label={showPassword ? "Esconder senha" : "Mostrar senha"}
                  >
                    {showPassword ? (
                      <EyeOff className="h-5 w-5" aria-hidden="true" />
                    ) : (
                      <Eye className="h-5 w-5" aria-hidden="true" />
                    )}
                  </button>
                </div>
                {capsLockActive && <p className="text-sm text-amber-600 mt-1 flex items-center">⚠️ Caps Lock ativo</p>}
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="flex items-center justify-between">
            <div className="text-sm">
              <Link href="/esqueci-senha" className="font-medium text-primary hover:text-primary/80">
                Esqueceu sua senha?
              </Link>
            </div>
          </div>

          <div>
            <Button
              type="submit"
              className={cn(
                "w-full flex justify-center py-3 px-4 border border-transparent rounded-lg shadow-sm text-sm font-medium text-primary-foreground",
                "bg-primary hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary",
                "disabled:opacity-50 disabled:cursor-not-allowed",
              )}
              disabled={isLoading || !auth.isInitialized}
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Entrando...
                </>
              ) : (
                "Entrar"
              )}
            </Button>
          </div>
        </form>
      </Form>

      <div className="mt-6 text-center space-y-4">
        <p className="text-sm text-muted-foreground">
          Não tem uma conta?{" "}
          <Link href="/cadastro" className="font-medium text-primary hover:text-primary/80">
            Cadastre-se
          </Link>
        </p>

        <div className="flex justify-center space-x-4 text-xs text-muted-foreground">
          <Link href="/termos" className="hover:text-primary underline">
            Termos de Uso
          </Link>
          <span>•</span>
          <Link href="/privacidade" className="hover:text-primary underline">
            Política de Privacidade
          </Link>
        </div>
      </div>
    </>
  )
}
