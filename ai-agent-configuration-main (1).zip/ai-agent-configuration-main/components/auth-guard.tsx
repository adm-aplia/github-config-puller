"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter, usePathname } from "next/navigation"
import { Loader2 } from "lucide-react"
import { useAuth } from "./auth-provider"

interface AuthGuardProps {
  children: React.ReactNode
  requireAuth?: boolean
  requireAdmin?: boolean
  redirectTo?: string
}

export default function AuthGuard({
  children,
  requireAuth = true,
  requireAdmin = false,
  redirectTo = "/login",
}: AuthGuardProps) {
  const { user, isLoading, isInitialized, isAuthenticated } = useAuth()
  const router = useRouter()
  const pathname = usePathname()
  const [isAuthorized, setIsAuthorized] = useState(false)
  const [isChecking, setIsChecking] = useState(true)

  useEffect(() => {
    // Só verificamos autorização após a inicialização do auth
    if (!isInitialized) {
      return
    }

    // Verificar se o usuário está autenticado quando necessário
    if (requireAuth && !isAuthenticated) {
      console.log("Redirecionando para login: usuário não autenticado")
      router.push(`${redirectTo}?returnUrl=${encodeURIComponent(pathname || "/")}`)
      return
    }

    // Verificar se o usuário é admin quando necessário
    if (requireAdmin && (!user || user.role !== "admin")) {
      console.log("Redirecionando: acesso de admin necessário")
      router.push("/dashboard")
      return
    }

    // Se chegou aqui, o usuário está autorizado
    setIsAuthorized(true)
    setIsChecking(false)
  }, [isInitialized, isAuthenticated, user, requireAuth, requireAdmin, router, pathname, redirectTo])

  // Mostrar loader enquanto verifica autenticação
  if (isLoading || isChecking) {
    return (
      <div className="flex h-screen w-full items-center justify-center">
        <div className="flex flex-col items-center space-y-4">
          <Loader2 className="h-10 w-10 animate-spin text-primary" />
          <p className="text-lg font-medium text-muted-foreground">Verificando autenticação...</p>
        </div>
      </div>
    )
  }

  // Renderizar filhos apenas se autorizado
  return isAuthorized ? <>{children}</> : null
}
