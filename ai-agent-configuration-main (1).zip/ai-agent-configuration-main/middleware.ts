import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

export function middleware(request: NextRequest) {
  const { pathname, search } = request.nextUrl

  // Redirecionamentos para páginas principais
  const mainRedirects: Record<string, string> = {
    "/terms": "/termos",
    "/privacy": "/privacidade",
    "/register": "/cadastro",
    "/forgot-password": "/esqueci-senha",
  }

  // Redirecionamentos para dashboard
  const dashboardRedirects: Record<string, string> = {
    "/dashboard/profiles": "/dashboard/perfis",
    "/dashboard/appointments": "/dashboard/agendamentos",
    "/dashboard/conversations": "/dashboard/conversas",
    "/dashboard/settings": "/dashboard/configuracoes",
  }

  // Verificar redirecionamentos principais
  if (mainRedirects[pathname]) {
    const url = new URL(mainRedirects[pathname] + search, request.url)
    return NextResponse.redirect(url, 301)
  }

  // Verificar redirecionamentos do dashboard
  if (dashboardRedirects[pathname]) {
    const url = new URL(dashboardRedirects[pathname] + search, request.url)
    return NextResponse.redirect(url, 301)
  }

  // Redirecionamentos para rotas dinâmicas do dashboard
  if (pathname.startsWith("/dashboard/profiles/")) {
    const newPath = pathname.replace("/dashboard/profiles/", "/dashboard/perfis/")
    const url = new URL(newPath + search, request.url)
    return NextResponse.redirect(url, 301)
  }

  if (pathname.startsWith("/dashboard/appointments/")) {
    const newPath = pathname.replace("/dashboard/appointments/", "/dashboard/agendamentos/")
    const url = new URL(newPath + search, request.url)
    return NextResponse.redirect(url, 301)
  }

  if (pathname.startsWith("/dashboard/conversations/")) {
    const newPath = pathname.replace("/dashboard/conversations/", "/dashboard/conversas/")
    const url = new URL(newPath + search, request.url)
    return NextResponse.redirect(url, 301)
  }

  return NextResponse.next()
}

export const config = {
  matcher: [
    // Páginas principais
    "/terms",
    "/privacy",
    "/register",
    "/forgot-password",
    // Dashboard estático
    "/dashboard/profiles",
    "/dashboard/appointments",
    "/dashboard/conversations",
    "/dashboard/settings",
    // Dashboard dinâmico
    "/dashboard/profiles/:path*",
    "/dashboard/appointments/:path*",
    "/dashboard/conversations/:path*",
  ],
}
