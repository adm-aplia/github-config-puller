-- Criar tabela de configurações do dashboard
CREATE TABLE IF NOT EXISTS dashboard_settings (
  user_id UUID PRIMARY KEY REFERENCES auth.users(id),
  visible_widgets TEXT[] NOT NULL DEFAULT ARRAY['conversations_overview', 'recent_conversations', 'agent_status', 'whatsapp_status', 'appointment_calendar', 'appointment_stats'],
  default_view TEXT NOT NULL DEFAULT 'overview',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Adicionar índice para melhorar performance
CREATE INDEX IF NOT EXISTS idx_dashboard_settings_user_id ON dashboard_settings(user_id);
