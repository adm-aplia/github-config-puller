-- Verificar se a tabela whatsapp_instances existe
SELECT EXISTS (
   SELECT FROM information_schema.tables 
   WHERE table_schema = 'public'
   AND table_name = 'whatsapp_instances'
);

-- Listar as colunas da tabela whatsapp_instances se ela existir
SELECT column_name, data_type 
FROM information_schema.columns 
WHERE table_schema = 'public' 
AND table_name = 'whatsapp_instances';
