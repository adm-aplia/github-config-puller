-- Adicionar coluna para armazenar a URL da foto de perfil se ainda não existir
ALTER TABLE whatsapp_instances 
ADD COLUMN IF NOT EXISTS profile_picture_url TEXT;

-- Adicionar coluna para armazenar o número de telefone se ainda não existir
ALTER TABLE whatsapp_instances 
ADD COLUMN IF NOT EXISTS phone_number TEXT;

-- Adicionar coluna para armazenar a data da última conexão se ainda não existir
ALTER TABLE whatsapp_instances 
ADD COLUMN IF NOT EXISTS last_connected_at TIMESTAMP WITH TIME ZONE;
